<?xml version="1.0" encoding="UTF-8"?>
<!-- BMAD Prompt Run Metadata -->
<!-- Epic: 1 -->
<!-- Story: 2 -->
<!-- Phase: validate-story -->
<!-- Timestamp: 20260121T175956Z -->
<compiled-workflow>
<mission><![CDATA[Adversarial Story Validation

Target: Story 1.2 - projects-gallery-section

Your mission is to FIND ISSUES in the story file:
- Identify missing requirements or acceptance criteria
- Find ambiguous or unclear specifications
- Detect gaps in technical context
- Suggest improvements for developer clarity

CRITICAL: You are a VALIDATOR, not a developer.
- Read-only: You cannot modify any files
- Adversarial: Assume the story has problems
- Thorough: Check all sections systematically

Focus on STORY QUALITY, not code implementation.]]></mission>
<context>
<file id="11c89e12" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/docs/project_context.md"><![CDATA[# Project Context: Alex Chen Photography Portfolio

## Overview

Static portfolio website for freelance photographer. Pure HTML/CSS, no JavaScript.

## File Structure

```
index.html    # Single page, semantic HTML5
styles.css    # All styles, BEM naming
```

## Coding Standards

### HTML Rules

- Use semantic elements: `<header>`, `<main>`, `<section>`, `<article>`, `<footer>`
- Proper heading hierarchy: single `<h1>`, then `<h2>`, `<h3>` as needed
- 2-space indentation
- Double quotes for attributes
- Self-closing tags for void elements: `<img />`, `<br />`
- Always include `alt` attribute on images

### CSS Rules

- **BEM naming convention:**
  - Block: `.hero`, `.projects`
  - Element: `.hero__title`, `.projects__card`
  - Modifier: `.hero__cta--primary`, `.projects__card--featured`
- 2-space indentation
- One property per line
- Opening brace on same line as selector
- Blank line between rule sets
- Properties ordered: positioning → display → box model → typography → visual → misc

### CSS Custom Properties

Define all design tokens in `:root`:

```css
:root {
  /* Colors */
  --color-primary: #1a1a2e;
  --color-accent: #e94560;
  --color-background: #ffffff;
  --color-text: #333333;
  --color-text-light: #666666;

  /* Typography */
  --font-heading: 'Georgia', serif;
  --font-body: 'Arial', sans-serif;
  --font-size-base: 16px;
  --font-size-lg: 1.25rem;
  --font-size-xl: 2rem;
  --font-size-xxl: 3rem;

  /* Spacing */
  --spacing-xs: 0.5rem;
  --spacing-sm: 1rem;
  --spacing-md: 2rem;
  --spacing-lg: 4rem;

  /* Layout */
  --max-width: 1200px;
  --border-radius: 8px;
}
```

### Responsive Design

- Mobile-first approach
- Single breakpoint: `768px`
- Use `min-width` media queries only

```css
/* Mobile styles (default) */
.projects__grid {
  display: grid;
  grid-template-columns: 1fr;
}

/* Desktop styles */
@media (min-width: 768px) {
  .projects__grid {
    grid-template-columns: repeat(3, 1fr);
  }
}
```

## Component Structure

### Hero Section

```html
<header class="hero">
  <h1 class="hero__name">Alex Chen</h1>
  <p class="hero__tagline">Capturing moments that last forever</p>
  <a href="#contact" class="hero__cta">Get in Touch</a>
</header>
```

### Projects Section

```html
<main>
  <section class="projects">
    <h2 class="projects__title">Portfolio</h2>
    <div class="projects__grid">
      <article class="projects__card">
        <div class="projects__card-image"></div>
        <h3 class="projects__card-title">Wedding</h3>
        <p class="projects__card-description">...</p>
      </article>
      <!-- Repeat for Portrait, Landscape -->
    </div>
  </section>
</main>
```

## Constraints

- No JavaScript
- No external dependencies
- No CSS preprocessors
- No build tools
- Maximum 2 files (index.html + styles.css)

## Testing Verification

Verify implementation by checking:

1. **Hero section:** `<header class="hero">` exists with `<h1>`, tagline `<p>`, and CTA `<a>`
2. **Projects section:** `<section class="projects">` with exactly 3 `<article class="projects__card">`
3. **CSS variables:** `:root` block defines `--color-*`, `--font-*`, `--spacing-*`
4. **Responsive:** `@media (min-width: 768px)` present in styles.css
5. **BEM naming:** All classes follow `block__element--modifier` pattern
]]></file>
<file id="bda659bb" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/docs/prd.md"><![CDATA[# Product Requirements Document: Alex Chen Photography Portfolio

## Overview

**Product Name:** Alex Chen Photography Portfolio
**Version:** 1.0
**Author:** John (Product Manager)
**Date:** 2025-12-11

## Problem Statement

Alex Chen is a freelance photographer who needs a simple, professional online presence to showcase work to potential clients. Current solution (social media) lacks professionalism and doesn't provide a dedicated space for portfolio presentation.

## Goals

1. Establish professional online presence
2. Showcase photography portfolio effectively
3. Provide clear call-to-action for client inquiries
4. Ensure accessibility across devices

## Target Audience

- Potential clients seeking photography services (weddings, portraits, landscapes)
- Industry peers and collaborators
- Anyone discovering Alex through referrals

## Functional Requirements

### FR-001: Hero Section with Branding

**Description:** The landing page must feature a prominent hero section that establishes brand identity.

**Acceptance Criteria:**
- Display photographer name "Alex Chen" as primary heading
- Include professional tagline communicating photography focus
- Provide clear call-to-action button for contact/inquiry
- Hero section spans full viewport width

### FR-002: Projects Gallery Section

**Description:** A dedicated section showcasing photography projects with visual cards.

**Acceptance Criteria:**
- Display exactly 3 project cards (Wedding, Portrait, Landscape)
- Each card contains: image placeholder, project title, brief description
- Cards arranged in responsive grid layout
- Semantic HTML structure using article elements

### FR-003: Consistent Visual Design System

**Description:** Implement cohesive visual design using CSS custom properties.

**Acceptance Criteria:**
- Define color palette via CSS custom properties in :root
- Establish typography scale (headings, body, captions)
- Consistent spacing using CSS variables
- BEM naming convention for all CSS classes

### FR-004: Mobile-Responsive Layout

**Description:** Ensure optimal viewing experience across device sizes.

**Acceptance Criteria:**
- Mobile-first CSS approach
- Breakpoint at 768px for tablet/desktop layouts
- Hero section adapts to viewport
- Project cards stack vertically on mobile, grid on desktop
- All interactive elements have appropriate touch targets

## Non-Functional Requirements

### NFR-001: Performance
- No JavaScript dependencies
- Single CSS file under 10KB
- Page loads in under 1 second on 3G

### NFR-002: Maintainability
- Semantic HTML5 elements
- Well-commented CSS sections
- BEM methodology for scalable styles

### NFR-003: Accessibility
- Proper heading hierarchy (h1 > h2 > h3)
- Sufficient color contrast ratios
- Focus states for interactive elements

## Out of Scope

- Contact form functionality
- Image gallery lightbox
- CMS integration
- Multi-page navigation
- JavaScript interactions

## Success Metrics

- Clean, valid HTML5 markup
- CSS passes linting with no errors
- Responsive design works on mobile and desktop viewports
- All acceptance criteria met for FR-001 through FR-004
]]></file>
<file id="07a30897" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/docs/ux-spec.md"><![CDATA[# UX Specification: Alex Chen Photography Portfolio

## Overview

**Project:** Alex Chen Photography Portfolio
**UX Designer:** Sally
**Date:** 2025-12-11
**Status:** Approved

## User Persona

### Primary Persona: Potential Client

**Name:** Sarah Mitchell
**Age:** 28-45
**Context:** Planning a wedding, looking for a photographer

**Goals:**
- Quickly assess photographer's style and quality
- See relevant work samples (wedding photography)
- Easy way to make contact

**Behaviors:**
- Browses on mobile during commute (60% mobile traffic expected)
- Makes decisions based on visual first impression
- Scans, doesn't read - needs clear visual hierarchy
- Will leave if page loads slowly or looks unprofessional

**Pain Points:**
- Cluttered portfolios with too many options
- Slow-loading image galleries
- Unclear how to get in touch
- Sites that don't work on mobile

### Secondary Persona: Industry Peer

**Name:** Marcus Rivera
**Context:** Fellow photographer, potential collaborator

**Goals:**
- Evaluate Alex's style for collaboration fit
- Quick overview of specialties

## Visual Direction

### Mood & Tone

**Keywords:** Elegant, Professional, Minimal, Gallery-like

**Concept:** The website should feel like walking into a high-end photography gallery - clean walls, focused lighting, art speaks for itself.

**Visual Metaphor:** White-cube gallery meets premium magazine layout.

### Color Psychology

| Color | Token | Hex | Rationale |
|-------|-------|-----|-----------|
| Deep Navy | `--color-primary` | #1a1a2e | Sophisticated, timeless, makes photos "pop" |
| Coral Accent | `--color-accent` | #e94560 | Warm, inviting, draws eye to CTA |
| Clean White | `--color-background` | #ffffff | Gallery-like, maximizes photo contrast |
| Charcoal | `--color-text` | #333333 | Easy reading, softer than pure black |
| Muted Gray | `--color-text-light` | #666666 | Secondary info, doesn't compete |

**Why Dark Hero + Light Content:**
- Hero section uses `--color-primary` background → dramatic first impression
- Projects section uses `--color-background` → photos are the focus
- This contrast creates natural visual sections without heavy borders

### Typography Rationale

| Element | Font | Token | Rationale |
|---------|------|-------|-----------|
| Headings | Georgia | `--font-heading` | Serif = elegance, timelessness, art-world feel |
| Body | Arial | `--font-body` | Sans-serif = clarity, modern, easy scanning |

**Type Scale:**
- Hero name: `--font-size-xxl` (3rem) - Commanding presence
- Section titles: `--font-size-xl` (2rem) - Clear hierarchy
- Card titles: `--font-size-lg` (1.25rem) - Scannable
- Body: `--font-size-base` (16px) - Comfortable reading

## Layout Design

### Information Architecture

```
┌─────────────────────────────────────┐
│             HERO                    │  ← Emotional hook (3 seconds)
│   Name + Tagline + CTA              │
└─────────────────────────────────────┘
┌─────────────────────────────────────┐
│           PORTFOLIO                 │  ← Proof of work
│   [Wedding] [Portrait] [Landscape]  │
└─────────────────────────────────────┘
```

**Why this order:**
1. Hero creates emotional connection first
2. Portfolio proves capability second
3. No navigation needed - single scroll journey

### Wireframes

**Mobile Layout (< 768px):**

```
┌──────────────────────┐
│                      │
│     ALEX CHEN        │
│                      │
│  Capturing moments   │
│  that last forever   │
│                      │
│   [ Get in Touch ]   │
│                      │
├──────────────────────┤
│      Portfolio       │
├──────────────────────┤
│  ┌────────────────┐  │
│  │   [  image  ]  │  │
│  │    Wedding     │  │
│  │  description   │  │
│  └────────────────┘  │
│  ┌────────────────┐  │
│  │   [  image  ]  │  │
│  │    Portrait    │  │
│  │  description   │  │
│  └────────────────┘  │
│  ┌────────────────┐  │
│  │   [  image  ]  │  │
│  │   Landscape    │  │
│  │  description   │  │
│  └────────────────┘  │
└──────────────────────┘
```

**Desktop Layout (≥ 768px):**

```
┌────────────────────────────────────────────────────┐
│                                                    │
│                    ALEX CHEN                       │
│          Capturing moments that last forever       │
│                                                    │
│                  [ Get in Touch ]                  │
│                                                    │
├────────────────────────────────────────────────────┤
│                     Portfolio                      │
├────────────────────────────────────────────────────┤
│  ┌──────────────┐ ┌──────────────┐ ┌──────────────┐│
│  │   [image]    │ │   [image]    │ │   [image]    ││
│  │   Wedding    │ │   Portrait   │ │  Landscape   ││
│  │ description  │ │ description  │ │ description  ││
│  └──────────────┘ └──────────────┘ └──────────────┘│
└────────────────────────────────────────────────────┘
```

## Interaction Design

### CTA Button States

| State | Visual Treatment |
|-------|------------------|
| Default | `--color-accent` background, white text |
| Hover | Slightly darker accent, subtle scale (1.02) |
| Focus | Visible outline for accessibility |
| Active | Darker accent, scale down (0.98) |

### Project Card States

| State | Visual Treatment |
|-------|------------------|
| Default | Subtle shadow, white background |
| Hover | Elevated shadow, slight lift effect |
| Focus | Visible outline around card |

**Note:** All hover effects use CSS transitions (0.2s ease) for smooth feel.

### Touch Targets

- CTA button: minimum 48x48px tap area
- Cards: entire card is tappable area on mobile
- Adequate spacing between interactive elements (min 8px)

## Accessibility Considerations

### Color Contrast

All text meets WCAG AA standards:
- `--color-text` (#333) on `--color-background` (#fff) = 12.6:1 ✓
- White text on `--color-primary` (#1a1a2e) = 15.1:1 ✓
- White text on `--color-accent` (#e94560) = 4.5:1 ✓

### Focus Indicators

- All interactive elements have visible focus states
- Focus outline uses `--color-accent` for consistency
- Never remove focus outline without replacement

### Motion

- Respect `prefers-reduced-motion` media query
- Hover animations are subtle (no jarring movements)

## Design Token Mapping

How UX decisions map to CSS custom properties:

| UX Goal | Design Token | Value |
|---------|--------------|-------|
| Sophisticated first impression | `--color-primary` | #1a1a2e |
| Draw attention to contact | `--color-accent` | #e94560 |
| Clean gallery feel | `--color-background` | #ffffff |
| Readable content | `--color-text` | #333333 |
| Elegant headings | `--font-heading` | Georgia, serif |
| Clear body text | `--font-body` | Arial, sans-serif |
| Consistent rhythm | `--spacing-*` | 0.5/1/2/4rem scale |
| Professional cards | `--border-radius` | 8px |

## Success Metrics

UX goals verification:

1. **First Impression (3 sec test):** User can identify "photographer portfolio" within 3 seconds
2. **Scannability:** All three project types visible without scrolling on desktop
3. **Mobile Usability:** Full journey completable with thumb-only navigation
4. **CTA Visibility:** Contact button visible in hero without scrolling
5. **Load Performance:** Perceived instant load (no layout shift)
]]></file>
<file id="2e55b2e3" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/docs/architecture.md"><![CDATA[# Architecture Document: Alex Chen Photography Portfolio

## Overview

**Project:** Alex Chen Photography Portfolio
**Architect:** Winston
**Date:** 2025-12-11
**Status:** Approved

## Architecture Philosophy

This is a deliberately simple, static website. We embrace "boring technology" - proven HTML and CSS patterns that require no build tools, no frameworks, and no JavaScript. The architecture prioritizes maintainability and performance over sophistication.

## Technology Decisions

### ADR-001: Pure HTML/CSS Stack

**Decision:** Use vanilla HTML5 and CSS3 only. No JavaScript.

**Context:** Portfolio is purely presentational. No dynamic functionality required.

**Rationale:**
- Zero runtime dependencies
- No build pipeline needed
- Maximum browser compatibility
- Fastest possible load times
- Easy to maintain and modify

**Consequences:**
- No interactive features (acceptable per PRD scope)
- Contact requires mailto: link or external form service

### ADR-002: Single Page Architecture

**Decision:** Entire portfolio on one `index.html` page.

**Context:** Only 2 content sections needed (hero + projects).

**Rationale:**
- Simpler navigation (scroll-based)
- Single HTTP request for HTML
- No routing complexity
- Easier testing and verification

**Consequences:**
- Must use anchor links if navigation added later
- Page weight grows with content (acceptable for 2 sections)

### ADR-003: CSS Custom Properties for Theming

**Decision:** Define all design tokens as CSS custom properties in `:root`.

**Context:** Need consistent colors, typography, and spacing.

**Rationale:**
- Single source of truth for design values
- Easy theme modifications
- Native browser support (no preprocessor)
- Runtime flexibility for future enhancements

**Implementation:**
```css
:root {
  --color-primary: #1a1a2e;
  --color-accent: #e94560;
  --color-background: #ffffff;
  --color-text: #333333;
  --font-heading: 'Georgia', serif;
  --font-body: 'Arial', sans-serif;
  --spacing-unit: 1rem;
}
```

### ADR-004: BEM Naming Convention

**Decision:** Use Block__Element--Modifier pattern for all CSS classes.

**Context:** Need scalable, predictable CSS architecture.

**Rationale:**
- Self-documenting class names
- Avoids specificity conflicts
- Clear component boundaries
- Industry standard, widely understood

**Examples:**
- `.hero` (block)
- `.hero__title` (element)
- `.hero__cta--primary` (modifier)
- `.projects__card` (element)

### ADR-005: Mobile-First Responsive Design

**Decision:** Base styles target mobile, media queries enhance for larger screens.

**Context:** Significant mobile traffic expected for portfolio viewing.

**Rationale:**
- Progressive enhancement philosophy
- Smaller devices get minimal CSS
- Easier to scale up than scale down
- Better performance on constrained devices

**Breakpoints:**
- Base: 0-767px (mobile)
- Desktop: 768px+ (tablet and above)

### ADR-006: Semantic HTML5 Structure

**Decision:** Use semantic elements over generic divs.

**Context:** Need accessible, well-structured markup.

**Rationale:**
- Built-in accessibility benefits
- Better SEO signals
- Self-documenting structure
- Screen reader friendly

**Element Mapping:**
| Content | Element |
|---------|---------|
| Page header with hero | `<header>` |
| Main content area | `<main>` |
| Hero section | `<section class="hero">` |
| Projects section | `<section class="projects">` |
| Individual project | `<article class="projects__card">` |
| Page footer | `<footer>` |

## File Structure

```
portfolio-project/
├── index.html          # Single HTML page
├── styles.css          # All styles
├── docs/
│   ├── prd.md
│   ├── architecture.md
│   ├── project_context.md
│   └── epics.md
└── bmad-assist.yaml
```

## Performance Budget

| Metric | Target |
|--------|--------|
| HTML size | < 5KB |
| CSS size | < 10KB |
| Total page weight | < 20KB (excluding images) |
| First Contentful Paint | < 1s on 3G |

## Security Considerations

- No user input handling (no forms)
- No external scripts
- No cookies or local storage
- Static hosting compatible (no server-side logic)

## Future Considerations

If requirements expand:
- Contact form: Consider external service (Formspree, Netlify Forms)
- Image optimization: Add srcset for responsive images
- Analytics: Add privacy-respecting solution (Plausible, Fathom)
- Multi-page: Consider static site generator

These are explicitly out of scope for v1.0.
]]></file>
<file id="b8bd6269" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/implementation-artifacts/1-1-hero-section-implementation.md"><![CDATA[# Story 1.1: hero-section-implementation

Status: Ready for Review

<!-- Note: Validation is optional. Run validate-create-story for quality check before dev-story. -->

## Story

As a visitor to Alex Chen's photography portfolio,
I want to see a prominent hero section when I land on the page,
so that I immediately understand who Alex Chen is and how to contact them.

## Acceptance Criteria

1. **AC-1.1.1:** Page contains `<header>` element with class `hero`
2. **AC-1.1.2:** Hero contains `<h1 class="hero__name">` with text "Alex Chen"
3. **AC-1.1.3:** Hero contains `<p>` element with class `hero__tagline` with text "Capturing moments that last forever"
4. **AC-1.1.4:** Hero contains `<a href="#contact" class="hero__cta">` element with "Get in Touch" text
5. **AC-1.1.5:** HTML is valid and uses semantic elements
6. **AC-1.1.6:** Hero section has dark background (#1a1a2e), white text, centered content, and CTA with accent background (#e94560)
7. **AC-1.1.7:** CTA link has visible focus state for keyboard accessibility

## Tasks / Subtasks

- [x] Task 1: Create HTML structure for hero section (AC: 1.1.1, 1.1.2, 1.1.3, 1.1.4, 1.1.5)
  - [x] Create `index.html` with HTML5 doctype and semantic structure
  - [x] Add `<header class="hero">` element
  - [x] Add `<h1 class="hero__name">` with "Alex Chen"
  - [x] Add `<p class="hero__tagline">` with tagline text
  - [x] Add `<a class="hero__cta">` with contact link
  - [x] Validate HTML using W3C validator or similar

- [x] Task 2: Create CSS for hero section styling (AC: 1.1.6, 1.1.7)
  - [x] Create `styles.css` file
  - [x] Link stylesheet in HTML `<head>`
  - [x] Add hero section styling (dark background #1a1a2e, white text, centered content)
  - [x] Style CTA button with accent background (#e94560) and white text
  - [x] Add visible focus state to CTA link for keyboard accessibility

## Dev Notes

### Architecture Patterns & Constraints

**Technology Stack** [Source: docs/architecture.md#Technology Decisions]
- Pure HTML5 and CSS3 only - NO JavaScript (ADR-001)
- No build tools, preprocessors, or external dependencies
- Single page architecture (ADR-002)
- Maximum browser compatibility required

**Semantic HTML Requirements** [Source: docs/architecture.md#ADR-006]
- Use `<header>` for page header with hero content
- Proper heading hierarchy: single `<h1>` on page
- All elements must be semantic (no generic divs for structural elements)
- Screen reader friendly markup

**CSS Architecture** [Source: docs/architecture.md#ADR-004]
- **BEM Naming Convention (MANDATORY):** Block__Element--Modifier pattern
- Block: `.hero`
- Elements: `.hero__name`, `.hero__tagline`, `.hero__cta`
- NO generic class names like `.title` or `.button`

**File Structure** [Source: docs/architecture.md#File Structure]
```
portfolio-project/
├── index.html          # Create this file
├── styles.css          # Create this file
```

### UX Design Specifications

**Visual Direction** [Source: docs/ux-spec.md#Visual Direction]
- Mood: Elegant, Professional, Minimal, Gallery-like
- Hero section uses dark background (`--color-primary: #1a1a2e`)
- White text on dark background for dramatic first impression
- Clean, sophisticated aesthetic

**Typography** [Source: docs/ux-spec.md#Typography Rationale]
- Hero name: Georgia serif font, `3rem` size for commanding presence
- Tagline: Arial sans-serif, clear and modern
- Text must be centered in hero section

**Layout Wireframe** [Source: docs/ux-spec.md#Wireframes]
```
┌──────────────────────┐
│                      │
│     ALEX CHEN        │
│                      │
│  Capturing moments   │
│  that last forever   │
│                      │
│   [ Get in Touch ]   │
│                      │
└──────────────────────┘
```

**Interaction Design** [Source: docs/ux-spec.md#Interaction Design]
- CTA button must use `--color-accent` (#e94560) background with white text
- Minimum touch target: 48x48px for mobile accessibility
- Hero section spans full viewport width

### Coding Standards

**HTML Rules** [Source: docs/project_context.md#HTML Rules]
- 2-space indentation
- Double quotes for attributes
- Self-closing tags for void elements: `<img />`, `<br />`
- Always include `alt` attribute on images (if any added later)

**CSS Rules** [Source: docs/project_context.md#CSS Rules]
- 2-space indentation
- One property per line
- Opening brace on same line as selector
- Blank line between rule sets
- Properties ordered: positioning → display → box model → typography → visual → misc

**CSS Custom Properties Setup** [Source: docs/project_context.md#CSS Custom Properties]
While full design tokens will be implemented in Story 2.1, basic hero styling for THIS story should prepare for token usage:

```css
/* Minimal inline values for Story 1.1 - will be replaced with tokens in 2.1 */
.hero {
  background-color: #1a1a2e;  /* Will become var(--color-primary) */
  color: #ffffff;
  /* ... other basic styles ... */
}

.hero__cta {
  background-color: #e94560;  /* Will become var(--color-accent) */
  color: #ffffff;
  /* ... button styles ... */
}

.hero__cta:focus {
  outline: 2px solid #e94560;
  outline-offset: 2px;
}
```

### Project Structure Notes

**Current State:** Empty project - no files exist yet

**Files to Create:**
1. `index.html` - Root HTML file (single page architecture)
2. `styles.css` - All CSS styles

**HTML Structure Template** [Source: docs/project_context.md#Component Structure]
```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Alex Chen Photography</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
  <header class="hero">
    <h1 class="hero__name">Alex Chen</h1>
    <p class="hero__tagline">Capturing moments that last forever</p>
    <a href="#contact" class="hero__cta">Get in Touch</a>
  </header>

  <!-- Projects section will be added in Story 1.2 -->
</body>
</html>
```

**CTA Link Behavior** [Source: docs/architecture.md#ADR-001]
- Use `#contact` anchor link for CTA href (contact form out of scope for v1.0)
- Alternative: `mailto:` link if preferred

### Performance Considerations

**Performance Budget** [Source: docs/architecture.md#Performance Budget]
- HTML size: < 5KB (hero section will be minimal)
- CSS size: < 10KB (basic styling should be ~1-2KB for this story)
- First Contentful Paint: < 1s on 3G

### Testing Verification

**Manual Verification Checklist:**
1. ✓ `<header class="hero">` exists in index.html
2. ✓ `<h1>` contains "Alex Chen"
3. ✓ Tagline `<p>` with class `hero__tagline` present
4. ✓ CTA `<a>` with class `hero__cta` present
5. ✓ HTML validates with no errors (use https://validator.w3.org/)
6. ✓ Hero section visible with dark background
7. ✓ Text is white and readable on dark background
8. ✓ CTA button has coral/accent background color
9. ✓ All classes follow BEM naming (no violations)
10. ✓ CTA has visible focus state when tabbed to (keyboard accessibility)
11. ✓ Page displays correctly in browser

**Browser Testing:**
- Open index.html in Chrome, Firefox, Safari
- Verify hero section displays correctly
- Verify text is readable and CTA is visible

### Implementation Warnings

🚨 **CRITICAL MISTAKES TO AVOID:**
1. **DO NOT** use generic class names like `.title`, `.button`, `.header` - MUST use BEM (`.hero__name`, `.hero__cta`)
2. **DO NOT** add JavaScript - this is a pure HTML/CSS project
3. **DO NOT** use CSS preprocessors (Sass, Less) - vanilla CSS only
4. **DO NOT** add multiple `<h1>` tags - only one per page
5. **DO NOT** skip semantic elements - use `<header>`, not `<div class="header">`
6. **DO NOT** add features beyond AC scope (e.g., animations, extra sections)
7. **DO NOT** create multiple HTML files - single page architecture only

### Dependencies & Next Steps

**Dependencies:** None - this is the first story

**Next Story:** Story 1.2 (Projects Gallery Section) depends on this story
- Will add `<main>` section below hero
- Will reuse CSS file created here
- Hero structure must not be modified in 1.2

**Future Enhancements:** Story 2.1 will refactor CSS to use custom properties
- Current inline color values will be replaced with CSS variables
- BEM structure must remain intact for easy refactoring

### References

- [Architecture: Technology Stack] docs/architecture.md#ADR-001
- [Architecture: Single Page Architecture] docs/architecture.md#ADR-002
- [Architecture: BEM Naming] docs/architecture.md#ADR-004
- [Architecture: Semantic HTML] docs/architecture.md#ADR-006
- [PRD: Hero Section Requirements] docs/prd.md#FR-001
- [UX: Visual Direction] docs/ux-spec.md#Visual Direction
- [UX: Typography] docs/ux-spec.md#Typography Rationale
- [UX: Hero Wireframe] docs/ux-spec.md#Wireframes
- [Project Context: HTML Rules] docs/project_context.md#HTML Rules
- [Project Context: CSS Rules] docs/project_context.md#CSS Rules
- [Project Context: Hero Structure] docs/project_context.md#Component Structure

### Success Definition

Story is complete when:
1. All 7 acceptance criteria checked off
2. HTML validates with W3C validator (no errors)
3. CSS follows BEM naming (verified by code review)
4. Hero section visually matches wireframe intent
5. Manual browser testing passes
6. Code committed with message: "feat: implement hero section with branding and CTA"

## Dev Agent Record

### Agent Model Used

Claude Opus 4.5 (claude-opus-4-5-20251101)

### Debug Log References

N/A - Implementation completed without errors.

### Completion Notes List

- Created `index.html` with semantic HTML5 structure following project conventions
- Implemented hero section with `<header class="hero">` containing name, tagline, and CTA
- Created `styles.css` with BEM-compliant class naming (`.hero`, `.hero__name`, `.hero__tagline`, `.hero__cta`)
- Applied dark background (#1a1a2e), white text, flexbox centering per UX spec
- Styled CTA with accent color (#e94560), min 48x48px touch target, visible focus state
- All 7 acceptance criteria verified and satisfied

**Code Review Synthesis Fixes (2026-01-21):**
- Added CSS reset (box-sizing, body margin) to prevent cross-browser inconsistencies
- Added `min-height: 100dvh` fallback for iOS Safari viewport issues
- Improved focus indicator visibility: changed outline from #e94560 to #ffffff (3px)
- Added `@media (prefers-reduced-motion: reduce)` for accessibility compliance
- Added meta description for SEO
- Removed internal sprint comment from HTML

### File List

- `index.html` (created, updated by synthesis) - Single-page HTML structure with hero section
- `styles.css` (created, updated by synthesis) - Hero section styles with BEM naming

### Change Log

| Date | Change | Reason |
|------|--------|--------|
| 2026-01-21 | Created index.html and styles.css | Initial hero section implementation per Story 1.1 |
| 2026-01-21 | Applied code review synthesis fixes | Added CSS reset, 100dvh fallback, improved focus visibility, prefers-reduced-motion support, meta description |]]></file>
<file id="ed9105ba" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/implementation-artifacts/1-2-projects-gallery-section.md"><![CDATA[# Story 1.2: projects-gallery-section

Status: ready-for-dev

<!-- Note: Validation is optional. Run validate-create-story for quality check before dev-story. -->

## Story

As a visitor to Alex Chen's photography portfolio,
I want to see Alex's photography projects organized in cards,
so that I can understand the types of photography services offered.

## Acceptance Criteria

1. **AC-1.2.1:** Page contains `<main>` element wrapping content below hero
2. **AC-1.2.2:** Main contains `<section>` with class `projects`
3. **AC-1.2.3:** Projects section contains `<h2>` with title "Portfolio"
4. **AC-1.2.4:** Projects section contains exactly 3 `<article>` elements with class `projects__card`
5. **AC-1.2.5:** Each card contains: image placeholder div (`projects__card-image`), `<h3>` title (`projects__card-title`), `<p>` description (`projects__card-description`)
6. **AC-1.2.6:** Card titles are: "Wedding", "Portrait", "Landscape"
7. **AC-1.2.7:** Cards are wrapped in container with class `projects__grid`
8. **AC-1.2.8:** HTML validates without errors

## Tasks / Subtasks

- [ ] Task 1: Add `<main>` element to HTML structure (AC: 1.2.1)
  - [ ] Insert `<main>` element after closing `</header>` tag
  - [ ] Ensure `<main>` wraps all content below hero section

- [ ] Task 2: Create projects section structure (AC: 1.2.2, 1.2.3, 1.2.7)
  - [ ] Add `<section class="projects">` inside `<main>`
  - [ ] Add `<h2 class="projects__title">Portfolio</h2>` as first child
  - [ ] Add `<div class="projects__grid">` container for cards

- [ ] Task 3: Implement three project cards (AC: 1.2.4, 1.2.5, 1.2.6)
  - [ ] Create Wedding card with `<article class="projects__card">`
    - [ ] Add `<div class="projects__card-image"></div>` placeholder
    - [ ] Add `<h3 class="projects__card-title">Wedding</h3>`
    - [ ] Add `<p class="projects__card-description">` with 1-2 sentence description
  - [ ] Create Portrait card with same structure
  - [ ] Create Landscape card with same structure

- [ ] Task 4: Add CSS styles for projects section (AC: visual presentation)
  - [ ] Style `.projects` section (background, padding, centered content)
  - [ ] Style `.projects__title` (typography using design tokens approach)
  - [ ] Style `.projects__grid` (single column for mobile)
  - [ ] Style `.projects__card` (background, border-radius, shadow, padding)
  - [ ] Style `.projects__card-image` (placeholder with background color, aspect ratio)
  - [ ] Style `.projects__card-title` and `.projects__card-description`

- [ ] Task 5: Validate HTML (AC: 1.2.8)
  - [ ] Run through W3C validator or equivalent
  - [ ] Fix any validation errors

## Dev Notes

### Architecture Patterns & Constraints

**Technology Stack** [Source: docs/architecture.md#ADR-001]
- Pure HTML5 and CSS3 only - NO JavaScript
- No build tools, preprocessors, or external dependencies
- Single page architecture (ADR-002)

**Semantic HTML Requirements** [Source: docs/architecture.md#ADR-006]
- Use `<main>` for main content area
- Use `<section>` for the projects section
- Use `<article>` for each individual project card (self-contained content)
- Proper heading hierarchy: `<h1>` (hero) → `<h2>` (section) → `<h3>` (cards)

**CSS Architecture** [Source: docs/architecture.md#ADR-004]
- **BEM Naming Convention (MANDATORY):**
  - Block: `.projects`
  - Elements: `.projects__title`, `.projects__grid`, `.projects__card`, `.projects__card-image`, `.projects__card-title`, `.projects__card-description`
- NO generic class names

**Performance Budget** [Source: docs/architecture.md#Performance Budget]
- HTML size: < 5KB total
- CSS size: < 10KB total
- Current CSS is ~88 lines, plenty of room

### UX Design Specifications

**Visual Direction** [Source: docs/ux-spec.md#Visual Direction]
- Projects section uses light background (`--color-background: #ffffff`)
- Photos should be the focus (gallery-like feel)
- Clean, minimal aesthetic

**Layout Wireframe - Mobile** [Source: docs/ux-spec.md#Wireframes]
```
├──────────────────────┤
│      Portfolio       │
├──────────────────────┤
│  ┌────────────────┐  │
│  │   [  image  ]  │  │
│  │    Wedding     │  │
│  │  description   │  │
│  └────────────────┘  │
│  ┌────────────────┐  │
│  │   [  image  ]  │  │
│  │    Portrait    │  │
│  │  description   │  │
│  └────────────────┘  │
│  ┌────────────────┐  │
│  │   [  image  ]  │  │
│  │   Landscape    │  │
│  │  description   │  │
│  └────────────────┘  │
└──────────────────────┘
```

**Layout Wireframe - Desktop** [Source: docs/ux-spec.md#Wireframes]
```
├────────────────────────────────────────────────────┤
│                     Portfolio                      │
├────────────────────────────────────────────────────┤
│  ┌──────────────┐ ┌──────────────┐ ┌──────────────┐│
│  │   [image]    │ │   [image]    │ │   [image]    ││
│  │   Wedding    │ │   Portrait   │ │  Landscape   ││
│  │ description  │ │ description  │ │ description  ││
│  └──────────────┘ └──────────────┘ └──────────────┘│
└────────────────────────────────────────────────────┘
```

**Card Interaction States** [Source: docs/ux-spec.md#Project Card States]
- Default: Subtle shadow, white background
- Hover: Elevated shadow, slight lift effect
- Focus: Visible outline around card

**Color Tokens** [Source: docs/project_context.md#CSS Custom Properties]
```css
--color-primary: #1a1a2e;     /* For text accents if needed */
--color-accent: #e94560;       /* Not used in cards typically */
--color-background: #ffffff;   /* Card and section background */
--color-text: #333333;         /* Card text */
--color-text-light: #666666;   /* Description text */
```

**Typography Tokens** [Source: docs/project_context.md#CSS Custom Properties]
```css
--font-heading: 'Georgia', serif;    /* For h2 section title */
--font-body: 'Arial', sans-serif;    /* For card content */
--font-size-lg: 1.25rem;             /* Card titles */
--font-size-xl: 2rem;                /* Section title */
```

**Spacing Tokens** [Source: docs/project_context.md#CSS Custom Properties]
```css
--spacing-xs: 0.5rem;
--spacing-sm: 1rem;
--spacing-md: 2rem;
--spacing-lg: 4rem;
```

### Project Structure Notes

**Current File State:**
- `index.html` - Contains hero section, needs `<main>` and projects section added
- `styles.css` - Contains CSS reset and hero styles, needs projects styles added

**HTML Structure to Add** [Source: docs/project_context.md#Component Structure]
```html
<main>
  <section class="projects">
    <h2 class="projects__title">Portfolio</h2>
    <div class="projects__grid">
      <article class="projects__card">
        <div class="projects__card-image"></div>
        <h3 class="projects__card-title">Wedding</h3>
        <p class="projects__card-description">Elegant moments captured with timeless style.</p>
      </article>
      <article class="projects__card">
        <div class="projects__card-image"></div>
        <h3 class="projects__card-title">Portrait</h3>
        <p class="projects__card-description">Revealing personality through professional portraiture.</p>
      </article>
      <article class="projects__card">
        <div class="projects__card-image"></div>
        <h3 class="projects__card-title">Landscape</h3>
        <p class="projects__card-description">Nature's beauty through an artistic lens.</p>
      </article>
    </div>
  </section>
</main>
```

**CSS Grid Pattern** [Source: docs/project_context.md#Responsive Design]
```css
/* Mobile styles (default) */
.projects__grid {
  display: grid;
  grid-template-columns: 1fr;
}

/* Desktop styles */
@media (min-width: 768px) {
  .projects__grid {
    grid-template-columns: repeat(3, 1fr);
  }
}
```

**Note:** Responsive behavior will be fully implemented in Story 2.2. For THIS story, focus on the base single-column layout. The grid CSS should be written mobile-first but desktop media query styles can be minimal/placeholder.

### Previous Story Intelligence

**Story 1.1 Implementation Patterns to Follow:**
- CSS reset and box-sizing already established - do NOT duplicate
- Use same CSS comment section headers format
- Follow same property ordering in CSS rules
- `prefers-reduced-motion` media query pattern already exists
- Transition timing: `0.2s ease` for hover effects

**Files Modified in Story 1.1:**
- `index.html` (lines 1-17) - Insert `<main>` before `</body>`
- `styles.css` (lines 1-87) - Add projects styles after hero section

### Coding Standards

**HTML Rules** [Source: docs/project_context.md#HTML Rules]
- 2-space indentation
- Double quotes for attributes
- Semantic elements only

**CSS Rules** [Source: docs/project_context.md#CSS Rules]
- 2-space indentation
- One property per line
- Opening brace on same line as selector
- Blank line between rule sets
- Property order: positioning → display → box model → typography → visual → misc

**Image Placeholder Implementation:**
- Use `<div class="projects__card-image">` with CSS background color
- Set aspect ratio using padding-bottom trick or aspect-ratio property
- Background color: use a neutral gray like `#e0e0e0` or `--color-text-light`

### Testing Verification

**Manual Verification Checklist:**
1. ✓ `<main>` element exists wrapping content below hero
2. ✓ `<section class="projects">` exists inside main
3. ✓ `<h2>` with "Portfolio" text present
4. ✓ Exactly 3 `<article class="projects__card">` elements
5. ✓ Each card has image placeholder, h3 title, p description
6. ✓ Card titles are "Wedding", "Portrait", "Landscape"
7. ✓ Cards wrapped in `<div class="projects__grid">`
8. ✓ HTML validates with no errors
9. ✓ All classes follow BEM naming
10. ✓ Cards display vertically stacked on mobile
11. ✓ Cards have visible styling (background, padding, shadow)
12. ✓ Image placeholders are visible (have height and background)

**Browser Testing:**
- Open index.html in Chrome, Firefox, Safari
- Verify projects section displays below hero
- Verify all 3 cards are visible and properly styled
- Test at mobile width (375px) - cards should stack

### Implementation Warnings

🚨 **CRITICAL MISTAKES TO AVOID:**
1. **DO NOT** modify the hero section - only ADD new content
2. **DO NOT** use generic class names like `.card`, `.grid`, `.title`
3. **DO NOT** duplicate CSS reset - it already exists
4. **DO NOT** add JavaScript
5. **DO NOT** add responsive media queries for 3-column layout yet (that's Story 2.2)
6. **DO NOT** use `<img>` tags - use div placeholders with background
7. **DO NOT** skip the `<main>` wrapper - it's required for accessibility
8. **DO NOT** break heading hierarchy - must be h1 → h2 → h3

### Dependencies & Next Steps

**Dependencies:** Story 1.1 (Hero Section) - COMPLETED ✓

**Next Stories:**
- Story 2.1 (CSS Design Tokens) - Will refactor hardcoded colors to CSS variables
- Story 2.2 (Responsive Layout) - Will add 3-column grid for desktop

**Preparation for Story 2.1:**
- Use hardcoded color values that match the token values for now
- Comment sections clearly so refactoring is easy

### References

- [Architecture: Technology Stack] docs/architecture.md#ADR-001
- [Architecture: Single Page] docs/architecture.md#ADR-002
- [Architecture: BEM Naming] docs/architecture.md#ADR-004
- [Architecture: Semantic HTML] docs/architecture.md#ADR-006
- [PRD: Projects Gallery] docs/prd.md#FR-002
- [UX: Layout Wireframes] docs/ux-spec.md#Wireframes
- [UX: Card States] docs/ux-spec.md#Project Card States
- [Project Context: CSS Properties] docs/project_context.md#CSS Custom Properties
- [Project Context: Component Structure] docs/project_context.md#Component Structure
- [Project Context: Responsive] docs/project_context.md#Responsive Design
- [Epics: Story 1.2] docs/epics.md#Story 1.2

### Success Definition

Story is complete when:
1. All 8 acceptance criteria checked off
2. HTML validates with W3C validator (no errors)
3. CSS follows BEM naming throughout
4. Projects section displays below hero
5. All 3 cards visible with proper content
6. Manual browser testing passes
7. Code committed with message: "feat: implement projects gallery with three portfolio cards"

## Dev Agent Record

### Agent Model Used

[To be filled by dev agent]

### Debug Log References

[To be filled during implementation]

### Completion Notes List

[To be filled during implementation]

### File List

[To be filled during implementation]

### Change Log

| Date | Change | Reason |
|------|--------|--------|
| 2026-01-21 | Story created | Initial story creation with comprehensive dev context |
]]></file>
</context>
<variables>
<var name="architecture_file" file_id="2e55b2e3">/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/docs/architecture.md</var>
<var name="author">BMad</var>
<var name="communication_language">English</var>
<var name="date">2026-01-21</var>
<var name="description">Quality competition validator - systematically review and improve story context created by create-story workflow</var>
<var name="document_output_language">English</var>
<var name="epic_num">1</var>
<var name="epics_file" description="Enhanced epics+stories file for story verification" />
<var name="implementation_artifacts">/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/implementation-artifacts</var>
<var name="model">validator</var>
<var name="name">validate-story</var>
<var name="output_folder">/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/implementation-artifacts</var>
<var name="planning_artifacts">/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/planning-artifacts</var>
<var name="prd_file" file_id="bda659bb">/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/docs/prd.md</var>
<var name="project_context" file_id="11c89e12">/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/docs/project_context.md</var>
<var name="project_knowledge">/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/docs</var>
<var name="project_name">simple-portfolio</var>
<var name="sprint_status">/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/implementation-artifacts/sprint-status.yaml</var>
<var name="story_dir">/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/implementation-artifacts</var>
<var name="story_file" file_id="ed9105ba">/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/implementation-artifacts/1-2-projects-gallery-section.md</var>
<var name="story_id">1.2</var>
<var name="story_key">1-2-projects-gallery-section</var>
<var name="story_num">2</var>
<var name="story_title">projects-gallery-section</var>
<var name="timestamp">20260121_185956</var>
<var name="user_name">User</var>
<var name="user_skill_level">expert</var>
<var name="ux_design_file" file_id="07a30897">/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/docs/ux-spec.md</var>
<var name="ux_file" description="UX design for user experience verification" />
<var name="validation_focus">story_quality</var>
</variables>
<file-index>
<entry id="b8bd6269" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/implementation-artifacts/1-1-hero-section-implementation.md" />
<entry id="ed9105ba" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/implementation-artifacts/1-2-projects-gallery-section.md" />
<entry id="2e55b2e3" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/docs/architecture.md" />
<entry id="bda659bb" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/docs/prd.md" />
<entry id="11c89e12" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/docs/project_context.md" />
<entry id="07a30897" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/docs/ux-spec.md" />
</file-index>
<instructions><workflow>
  <critical>All configuration and context is available in the VARIABLES section below. Use these resolved values directly.</critical>
  <critical>Communicate all responses in English and generate all documents in English</critical>

  <critical>SCOPE LIMITATION: You are a READ-ONLY VALIDATOR. Output your validation report to stdout ONLY. Do NOT create files, do NOT modify files, do NOT use Write/Edit/Bash tools. Your stdout output will be captured and saved by the orchestration system.</critical>

  <critical>🔥 CRITICAL MISSION: You are an independent quality validator in a FRESH CONTEXT competing against the original create-story LLM!</critical>
  <critical>Your purpose is to thoroughly review a story file and systematically identify any mistakes, omissions, or disasters that the original LLM missed</critical>
  <critical>🚨 COMMON LLM MISTAKES TO PREVENT: reinventing wheels, wrong libraries, wrong file locations, breaking regressions, ignoring UX, vague implementations, lying about completion, not learning from past work</critical>
  <critical>🔬 UTILIZE SUBPROCESSES AND SUBAGENTS: Use research subagents or parallel processing if available to thoroughly analyze different artifacts simultaneously</critical>

  <step n="1" goal="Story Quality Gate - INVEST validation">
    <critical>🎯 RUTHLESS STORY VALIDATION: Check story quality with surgical precision!</critical>
    <critical>This assessment determines if the story is fundamentally sound before deeper analysis</critical>

    <substep n="1a" title="INVEST Criteria Validation">
      <action>Evaluate each INVEST criterion with severity score (1-10, where 10 is critical violation):</action>

      <action>**I - Independent:** Check if story can be developed independently
        - Does it have hidden dependencies on other stories?
        - Can it be implemented without waiting for other work?
        - Are there circular dependencies?
        Score severity of any violations found
      </action>

      <action>**N - Negotiable:** Check if story allows implementation flexibility
        - Is it overly prescriptive about HOW vs WHAT?
        - Does it leave room for technical decisions?
        - Are requirements stated as outcomes, not solutions?
        Score severity of any violations found
      </action>

      <action>**V - Valuable:** Check if story delivers clear business value
        - Is the benefit clearly stated and meaningful?
        - Does it contribute to epic/product goals?
        - Would stakeholder recognize the value?
        Score severity of any violations found
      </action>

      <action>**E - Estimable:** Check if story can be accurately estimated
        - Are requirements clear enough to estimate?
        - Is scope well-defined without ambiguity?
        - Are there unknown technical risks that prevent estimation?
        Score severity of any violations found
      </action>

      <action>**S - Small:** Check if story is appropriately sized
        - Can it be completed in a single sprint?
        - Is it too large and should be split?
        - Is it too small to be meaningful?
        Score severity of any violations found
      </action>

      <action>**T - Testable:** Check if story has testable acceptance criteria
        - Are acceptance criteria specific and measurable?
        - Can each criterion be verified objectively?
        - Are edge cases and error scenarios covered?
        Score severity of any violations found
      </action>

      <action>Store INVEST results: {{invest_results}} with individual scores</action>
    </substep>

    <substep n="1b" title="Acceptance Criteria Deep Analysis">
      <action>Hunt for acceptance criteria issues:
        - Ambiguous criteria: Vague language like "should work well", "fast", "user-friendly"
        - Untestable criteria: Cannot be objectively verified
        - Missing criteria: Expected behaviors not covered
        - Conflicting criteria: Criteria that contradict each other
        - Incomplete scenarios: Missing edge cases, error handling, boundary conditions
      </action>
      <action>Document each issue with specific quote and recommendation</action>
      <action>Store as {{acceptance_criteria_issues}}</action>
    </substep>

    <substep n="1c" title="Hidden Dependencies Discovery">
      <action>Uncover hidden dependencies and future sprint-killers:
        - Undocumented technical dependencies (libraries, services, APIs)
        - Cross-team dependencies not mentioned
        - Infrastructure dependencies (databases, queues, caches)
        - Data dependencies (migrations, seeds, external data)
        - Sequential dependencies on other stories
        - External blockers (third-party services, approvals)
      </action>
      <action>Document each hidden dependency with impact assessment</action>
      <action>Store as {{hidden_dependencies}}</action>
    </substep>

    <substep n="1d" title="Estimation Reality-Check">
      <action>Reality-check the story estimate against complexity:
        - Compare stated/implied effort vs actual scope
        - Check for underestimated technical complexity
        - Identify scope creep risks
        - Assess if unknown unknowns are accounted for
        - Compare with similar stories from previous work
      </action>
      <action>Provide estimation assessment: realistic / underestimated / overestimated / unestimable</action>
      <action>Store as {{estimation_assessment}}</action>
    </substep>

    <substep n="1e" title="Technical Alignment Verification">
      <action>Verify alignment with architecture patterns from embedded context:
        - Does story follow established architectural patterns?
        - Are correct technologies/frameworks specified?
        - Does it respect defined boundaries and layers?
        - Are naming conventions and file structures aligned?
        - Does it integrate correctly with existing components?
      </action>
      <action>Document any misalignments or conflicts</action>
      <action>Store as {{technical_alignment_issues}}</action>
    </substep>

    <substep n="1f" title="Calculate Final Score and Verdict">
      <action>Calculate Final Score (1-10):
        - Average INVEST violation severities (inverted: 10 - avg_severity)
        - Weight by acceptance criteria issues count
        - Factor in hidden dependencies risk
        - Adjust for estimation confidence
        - Consider technical alignment
        Higher score = better quality story
      </action>

      <action>Determine Verdict based on score and critical issues:
        - **READY** (Score 7-10): Story is well-formed, minor issues only
        - **MAJOR REWORK** (Score 4-6): Significant issues require attention before development
        - **REJECT** (Score 1-3): Fundamental problems, story needs complete rewrite
      </action>

      <action>Store {{final_score}} and {{verdict}}</action>
    </substep>

    <o>🎯 **Story Quality Gate Results:**
      - Final Score: {{final_score}}/10
      - Verdict: **{{verdict}}**
      - INVEST Violations: {{invest_violation_count}}
      - Acceptance Criteria Issues: {{ac_issues_count}}
      - Hidden Dependencies: {{hidden_deps_count}}
      - Estimation: {{estimation_assessment}}
      - Technical Alignment: {{alignment_status}}

      ℹ️ Continuing with full analysis regardless of verdict...
    </o>
  </step>

  <step n="2" goal="Disaster prevention gap analysis">
    <critical>🚨 CRITICAL: Identify every mistake the original LLM missed that could cause DISASTERS!</critical>

    <substep n="2a" title="Reinvention Prevention Gaps">
      <action>Analyze for wheel reinvention risks:
        - Areas where developer might create duplicate functionality
        - Code reuse opportunities not identified
        - Existing solutions not mentioned that developer should extend
        - Patterns from previous stories not referenced
      </action>
      <action>Document each reinvention risk found</action>
    </substep>

    <substep n="2b" title="Technical Specification Disasters">
      <action>Analyze for technical specification gaps:
        - Wrong libraries/frameworks: Missing version requirements
        - API contract violations: Missing endpoint specifications
        - Database schema conflicts: Missing requirements that could corrupt data
        - Security vulnerabilities: Missing security requirements
        - Performance disasters: Missing requirements that could cause failures
      </action>
      <action>Document each technical specification gap</action>
    </substep>

    <substep n="2c" title="File Structure Disasters">
      <action>Analyze for file structure issues:
        - Wrong file locations: Missing organization requirements
        - Coding standard violations: Missing conventions
        - Integration pattern breaks: Missing data flow requirements
        - Deployment failures: Missing environment requirements
      </action>
      <action>Document each file structure issue</action>
    </substep>

    <substep n="2d" title="Regression Disasters">
      <action>Analyze for regression risks:
        - Breaking changes: Missing requirements that could break existing functionality
        - Test failures: Missing test requirements
        - UX violations: Missing user experience requirements
        - Learning failures: Missing previous story context
      </action>
      <action>Document each regression risk</action>
    </substep>

    <substep n="2e" title="Implementation Disasters">
      <action>Analyze for implementation issues:
        - Vague implementations: Missing details that could lead to incorrect work
        - Completion lies: Missing acceptance criteria that could allow fake implementations
        - Scope creep: Missing boundaries that could cause unnecessary work
        - Quality failures: Missing quality requirements
      </action>
      <action>Document each implementation issue</action>
    </substep>
  </step>

  <step n="3" goal="LLM-Dev-Agent optimization analysis">
    <critical>CRITICAL: Optimize story context for LLM developer agent consumption</critical>

    <action>Analyze current story for LLM optimization issues:
      - Verbosity problems: Excessive detail that wastes tokens without adding value
      - Ambiguity issues: Vague instructions that could lead to multiple interpretations
      - Context overload: Too much information not directly relevant to implementation
      - Missing critical signals: Key requirements buried in verbose text
      - Poor structure: Information not organized for efficient LLM processing
    </action>

    <action>Apply LLM Optimization Principles:
      - Clarity over verbosity: Be precise and direct, eliminate fluff
      - Actionable instructions: Every sentence should guide implementation
      - Scannable structure: Clear headings, bullet points, and emphasis
      - Token efficiency: Pack maximum information into minimum text
      - Unambiguous language: Clear requirements with no room for interpretation
    </action>

    <action>Document each LLM optimization opportunity</action>
  </step>

  <step n="4" goal="Categorize and prioritize improvements">
    <action>Categorize all identified issues into:
      - critical_issues: Must fix - essential requirements, security, blocking issues
      - enhancements: Should add - helpful guidance, better specifications
      - optimizations: Nice to have - performance hints, development tips
      - llm_optimizations: Token efficiency and clarity improvements
    </action>

    <action>Count issues in each category:
      - {{critical_count}} critical issues
      - {{enhancement_count}} enhancements
      - {{optimization_count}} optimizations
      - {{llm_opt_count}} LLM optimizations
    </action>

    <action>Assign numbers to each issue for reference</action>
  </step>

  <step n="5" goal="Generate validation report">
    <critical>OUTPUT MARKERS REQUIRED: Your validation report MUST start with the marker <!-- VALIDATION_REPORT_START --> on its own line BEFORE the report header, and MUST end with the marker <!-- VALIDATION_REPORT_END --> on its own line AFTER the final line. The orchestrator extracts ONLY content between these markers. Any text outside the markers (thinking, commentary) will be discarded.</critical>

    <action>Use the output template below as a FORMAT GUIDE</action>
    <action>Replace all {{placeholders}} with your actual analysis results</action>
    <action>Output the complete validation report to stdout with all sections filled in</action>
  </step>

</workflow></instructions>
<output-template><![CDATA[<!-- VALIDATION_REPORT_START -->

# 🎯 Story Context Validation Report

<!-- report_header -->

**Story:** {{story_key}} - {{story_title}}
**Story File:** {{story_file}}
**Validated:** {{date}}
**Validator:** Quality Competition Engine

---

<!-- executive_summary -->

## Executive Summary

### 🎯 Story Quality Verdict

| Final Score | Verdict |
|-------------|---------|
| **{{final_score}}/10** | **{{verdict}}** |

### Issues Overview

| Category | Found |
|----------|-------|
| 🚨 Critical Issues | {{critical_count}} |
| ⚡ Enhancements | {{enhancement_count}} |
| ✨ Optimizations | {{optimization_count}} |
| 🤖 LLM Optimizations | {{llm_opt_count}} |

**Overall Assessment:** {{overall_assessment}}

---

<!-- story_quality_gate -->

## 🎯 Ruthless Story Validation {{epic_num}}.{{story_num}}

### INVEST Criteria Assessment

| Criterion | Status | Severity | Details |
|-----------|--------|----------|---------|
| **I**ndependent | {{invest_i_status}} | {{invest_i_severity}}/10 | {{invest_i_details}} |
| **N**egotiable | {{invest_n_status}} | {{invest_n_severity}}/10 | {{invest_n_details}} |
| **V**aluable | {{invest_v_status}} | {{invest_v_severity}}/10 | {{invest_v_details}} |
| **E**stimable | {{invest_e_status}} | {{invest_e_severity}}/10 | {{invest_e_details}} |
| **S**mall | {{invest_s_status}} | {{invest_s_severity}}/10 | {{invest_s_details}} |
| **T**estable | {{invest_t_status}} | {{invest_t_severity}}/10 | {{invest_t_details}} |

### INVEST Violations

{{#each invest_violations}}
- **[{{severity}}/10] {{criterion}}:** {{description}}
{{/each}}

{{#if no_invest_violations}}
✅ No significant INVEST violations detected.
{{/if}}

### Acceptance Criteria Issues

{{#each acceptance_criteria_issues}}
- **{{issue_type}}:** {{description}}
  - *Quote:* "{{quote}}"
  - *Recommendation:* {{recommendation}}
{{/each}}

{{#if no_acceptance_criteria_issues}}
✅ Acceptance criteria are well-defined and testable.
{{/if}}

### Hidden Risks & Dependencies

{{#each hidden_dependencies}}
- **{{dependency_type}}:** {{description}}
  - *Impact:* {{impact}}
  - *Mitigation:* {{mitigation}}
{{/each}}

{{#if no_hidden_dependencies}}
✅ No hidden dependencies or blockers identified.
{{/if}}

### Estimation Reality-Check

**Assessment:** {{estimation_assessment}}

{{estimation_details}}

### Technical Alignment

**Status:** {{technical_alignment_status}}

{{#each technical_alignment_issues}}
- **{{issue_type}}:** {{description}}
  - *Architecture Reference:* {{architecture_reference}}
  - *Recommendation:* {{recommendation}}
{{/each}}

{{#if no_technical_alignment_issues}}
✅ Story aligns with architecture.md patterns.
{{/if}}

### Final Score: {{final_score}}/10

### Verdict: {{verdict}}

---

<!-- critical_issues_section -->

## 🚨 Critical Issues (Must Fix)

These are essential requirements, security concerns, or blocking issues that could cause implementation disasters.

{{#each critical_issues}}
### {{number}}. {{title}}

**Impact:** {{impact}}
**Source:** {{source_reference}}

**Problem:**
{{problem_description}}

**Recommended Fix:**
{{recommended_fix}}

{{/each}}

{{#if no_critical_issues}}
✅ No critical issues found - the original story covered essential requirements.
{{/if}}

---

<!-- enhancements_section -->

## ⚡ Enhancement Opportunities (Should Add)

Additional guidance that would significantly help the developer avoid mistakes.

{{#each enhancements}}
### {{number}}. {{title}}

**Benefit:** {{benefit}}
**Source:** {{source_reference}}

**Current Gap:**
{{gap_description}}

**Suggested Addition:**
{{suggested_addition}}

{{/each}}

{{#if no_enhancements}}
✅ No significant enhancement opportunities identified.
{{/if}}

---

<!-- optimizations_section -->

## ✨ Optimizations (Nice to Have)

Performance hints, development tips, and additional context for complex scenarios.

{{#each optimizations}}
### {{number}}. {{title}}

**Value:** {{value}}

**Suggestion:**
{{suggestion}}

{{/each}}

{{#if no_optimizations}}
✅ No additional optimizations identified.
{{/if}}

---

<!-- llm_optimizations_section -->

## 🤖 LLM Optimization Improvements

Token efficiency and clarity improvements for better dev agent processing.

{{#each llm_optimizations}}
### {{number}}. {{title}}

**Issue:** {{issue_type}}
**Token Impact:** {{token_impact}}

**Current:**
```
{{current_text}}
```

**Optimized:**
```
{{optimized_text}}
```

**Rationale:** {{rationale}}

{{/each}}

{{#if no_llm_optimizations}}
✅ Story content is well-optimized for LLM processing.
{{/if}}

---

<!-- competition_results -->

## 🏆 Competition Results

### Quality Metrics

| Metric | Score |
|--------|-------|
| Requirements Coverage | {{requirements_coverage}}% |
| Architecture Alignment | {{architecture_alignment}}% |
| Previous Story Integration | {{previous_story_integration}}% |
| LLM Optimization Score | {{llm_optimization_score}}% |
| **Overall Quality Score** | **{{overall_quality_score}}%** |

### Disaster Prevention Assessment

{{#each disaster_categories}}
- **{{category}}:** {{status}} {{details}}
{{/each}}

### Competition Outcome

{{#if validator_won}}
🏆 **Validator identified {{total_issues}} improvements** that enhance the story context.
{{/if}}

{{#if original_won}}
✅ **Original create-story produced high-quality output** with minimal gaps identified.
{{/if}}

---

**Report Generated:** {{date}}
**Validation Engine:** BMAD Method Quality Competition v1.0

<!-- VALIDATION_REPORT_END -->]]></output-template>
</compiled-workflow>