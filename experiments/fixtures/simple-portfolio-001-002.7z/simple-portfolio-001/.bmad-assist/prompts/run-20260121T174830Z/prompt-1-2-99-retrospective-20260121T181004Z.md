<?xml version="1.0" encoding="UTF-8"?>
<!-- BMAD Prompt Run Metadata -->
<!-- Epic: 1 -->
<!-- Story: 1.2 -->
<!-- Phase: retrospective -->
<!-- Timestamp: 20260121T181004Z -->
<compiled-workflow>
<mission><![CDATA[Run after epic completion to review overall success, extract lessons learned, and explore if new information emerged that might impact the next epic

Target: Epic 1
Generate retrospective report with extraction markers.]]></mission>
<context>
<file id="11c89e12" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/docs/project_context.md"><![CDATA[# Project Context: Alex Chen Photography Portfolio

## Overview

Static portfolio website for freelance photographer. Pure HTML/CSS, no JavaScript.

## File Structure

```
index.html    # Single page, semantic HTML5
styles.css    # All styles, BEM naming
```

## Coding Standards

### HTML Rules

- Use semantic elements: `<header>`, `<main>`, `<section>`, `<article>`, `<footer>`
- Proper heading hierarchy: single `<h1>`, then `<h2>`, `<h3>` as needed
- 2-space indentation
- Double quotes for attributes
- Self-closing tags for void elements: `<img />`, `<br />`
- Always include `alt` attribute on images

### CSS Rules

- **BEM naming convention:**
  - Block: `.hero`, `.projects`
  - Element: `.hero__title`, `.projects__card`
  - Modifier: `.hero__cta--primary`, `.projects__card--featured`
- 2-space indentation
- One property per line
- Opening brace on same line as selector
- Blank line between rule sets
- Properties ordered: positioning → display → box model → typography → visual → misc

### CSS Custom Properties

Define all design tokens in `:root`:

```css
:root {
  /* Colors */
  --color-primary: #1a1a2e;
  --color-accent: #e94560;
  --color-background: #ffffff;
  --color-text: #333333;
  --color-text-light: #666666;

  /* Typography */
  --font-heading: 'Georgia', serif;
  --font-body: 'Arial', sans-serif;
  --font-size-base: 16px;
  --font-size-lg: 1.25rem;
  --font-size-xl: 2rem;
  --font-size-xxl: 3rem;

  /* Spacing */
  --spacing-xs: 0.5rem;
  --spacing-sm: 1rem;
  --spacing-md: 2rem;
  --spacing-lg: 4rem;

  /* Layout */
  --max-width: 1200px;
  --border-radius: 8px;
}
```

### Responsive Design

- Mobile-first approach
- Single breakpoint: `768px`
- Use `min-width` media queries only

```css
/* Mobile styles (default) */
.projects__grid {
  display: grid;
  grid-template-columns: 1fr;
}

/* Desktop styles */
@media (min-width: 768px) {
  .projects__grid {
    grid-template-columns: repeat(3, 1fr);
  }
}
```

## Component Structure

### Hero Section

```html
<header class="hero">
  <h1 class="hero__name">Alex Chen</h1>
  <p class="hero__tagline">Capturing moments that last forever</p>
  <a href="#contact" class="hero__cta">Get in Touch</a>
</header>
```

### Projects Section

```html
<main>
  <section class="projects">
    <h2 class="projects__title">Portfolio</h2>
    <div class="projects__grid">
      <article class="projects__card">
        <div class="projects__card-image"></div>
        <h3 class="projects__card-title">Wedding</h3>
        <p class="projects__card-description">...</p>
      </article>
      <!-- Repeat for Portrait, Landscape -->
    </div>
  </section>
</main>
```

## Constraints

- No JavaScript
- No external dependencies
- No CSS preprocessors
- No build tools
- Maximum 2 files (index.html + styles.css)

## Testing Verification

Verify implementation by checking:

1. **Hero section:** `<header class="hero">` exists with `<h1>`, tagline `<p>`, and CTA `<a>`
2. **Projects section:** `<section class="projects">` with exactly 3 `<article class="projects__card">`
3. **CSS variables:** `:root` block defines `--color-*`, `--font-*`, `--spacing-*`
4. **Responsive:** `@media (min-width: 768px)` present in styles.css
5. **BEM naming:** All classes follow `block__element--modifier` pattern
]]></file>
<file id="bda659bb" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/docs/prd.md"><![CDATA[# Product Requirements Document: Alex Chen Photography Portfolio

## Overview

**Product Name:** Alex Chen Photography Portfolio
**Version:** 1.0
**Author:** John (Product Manager)
**Date:** 2025-12-11

## Problem Statement

Alex Chen is a freelance photographer who needs a simple, professional online presence to showcase work to potential clients. Current solution (social media) lacks professionalism and doesn't provide a dedicated space for portfolio presentation.

## Goals

1. Establish professional online presence
2. Showcase photography portfolio effectively
3. Provide clear call-to-action for client inquiries
4. Ensure accessibility across devices

## Target Audience

- Potential clients seeking photography services (weddings, portraits, landscapes)
- Industry peers and collaborators
- Anyone discovering Alex through referrals

## Functional Requirements

### FR-001: Hero Section with Branding

**Description:** The landing page must feature a prominent hero section that establishes brand identity.

**Acceptance Criteria:**
- Display photographer name "Alex Chen" as primary heading
- Include professional tagline communicating photography focus
- Provide clear call-to-action button for contact/inquiry
- Hero section spans full viewport width

### FR-002: Projects Gallery Section

**Description:** A dedicated section showcasing photography projects with visual cards.

**Acceptance Criteria:**
- Display exactly 3 project cards (Wedding, Portrait, Landscape)
- Each card contains: image placeholder, project title, brief description
- Cards arranged in responsive grid layout
- Semantic HTML structure using article elements

### FR-003: Consistent Visual Design System

**Description:** Implement cohesive visual design using CSS custom properties.

**Acceptance Criteria:**
- Define color palette via CSS custom properties in :root
- Establish typography scale (headings, body, captions)
- Consistent spacing using CSS variables
- BEM naming convention for all CSS classes

### FR-004: Mobile-Responsive Layout

**Description:** Ensure optimal viewing experience across device sizes.

**Acceptance Criteria:**
- Mobile-first CSS approach
- Breakpoint at 768px for tablet/desktop layouts
- Hero section adapts to viewport
- Project cards stack vertically on mobile, grid on desktop
- All interactive elements have appropriate touch targets

## Non-Functional Requirements

### NFR-001: Performance
- No JavaScript dependencies
- Single CSS file under 10KB
- Page loads in under 1 second on 3G

### NFR-002: Maintainability
- Semantic HTML5 elements
- Well-commented CSS sections
- BEM methodology for scalable styles

### NFR-003: Accessibility
- Proper heading hierarchy (h1 > h2 > h3)
- Sufficient color contrast ratios
- Focus states for interactive elements

## Out of Scope

- Contact form functionality
- Image gallery lightbox
- CMS integration
- Multi-page navigation
- JavaScript interactions

## Success Metrics

- Clean, valid HTML5 markup
- CSS passes linting with no errors
- Responsive design works on mobile and desktop viewports
- All acceptance criteria met for FR-001 through FR-004
]]></file>
<file id="2e55b2e3" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/docs/architecture.md"><![CDATA[# Architecture Document: Alex Chen Photography Portfolio

## Overview

**Project:** Alex Chen Photography Portfolio
**Architect:** Winston
**Date:** 2025-12-11
**Status:** Approved

## Architecture Philosophy

This is a deliberately simple, static website. We embrace "boring technology" - proven HTML and CSS patterns that require no build tools, no frameworks, and no JavaScript. The architecture prioritizes maintainability and performance over sophistication.

## Technology Decisions

### ADR-001: Pure HTML/CSS Stack

**Decision:** Use vanilla HTML5 and CSS3 only. No JavaScript.

**Context:** Portfolio is purely presentational. No dynamic functionality required.

**Rationale:**
- Zero runtime dependencies
- No build pipeline needed
- Maximum browser compatibility
- Fastest possible load times
- Easy to maintain and modify

**Consequences:**
- No interactive features (acceptable per PRD scope)
- Contact requires mailto: link or external form service

### ADR-002: Single Page Architecture

**Decision:** Entire portfolio on one `index.html` page.

**Context:** Only 2 content sections needed (hero + projects).

**Rationale:**
- Simpler navigation (scroll-based)
- Single HTTP request for HTML
- No routing complexity
- Easier testing and verification

**Consequences:**
- Must use anchor links if navigation added later
- Page weight grows with content (acceptable for 2 sections)

### ADR-003: CSS Custom Properties for Theming

**Decision:** Define all design tokens as CSS custom properties in `:root`.

**Context:** Need consistent colors, typography, and spacing.

**Rationale:**
- Single source of truth for design values
- Easy theme modifications
- Native browser support (no preprocessor)
- Runtime flexibility for future enhancements

**Implementation:**
```css
:root {
  --color-primary: #1a1a2e;
  --color-accent: #e94560;
  --color-background: #ffffff;
  --color-text: #333333;
  --font-heading: 'Georgia', serif;
  --font-body: 'Arial', sans-serif;
  --spacing-unit: 1rem;
}
```

### ADR-004: BEM Naming Convention

**Decision:** Use Block__Element--Modifier pattern for all CSS classes.

**Context:** Need scalable, predictable CSS architecture.

**Rationale:**
- Self-documenting class names
- Avoids specificity conflicts
- Clear component boundaries
- Industry standard, widely understood

**Examples:**
- `.hero` (block)
- `.hero__title` (element)
- `.hero__cta--primary` (modifier)
- `.projects__card` (element)

### ADR-005: Mobile-First Responsive Design

**Decision:** Base styles target mobile, media queries enhance for larger screens.

**Context:** Significant mobile traffic expected for portfolio viewing.

**Rationale:**
- Progressive enhancement philosophy
- Smaller devices get minimal CSS
- Easier to scale up than scale down
- Better performance on constrained devices

**Breakpoints:**
- Base: 0-767px (mobile)
- Desktop: 768px+ (tablet and above)

### ADR-006: Semantic HTML5 Structure

**Decision:** Use semantic elements over generic divs.

**Context:** Need accessible, well-structured markup.

**Rationale:**
- Built-in accessibility benefits
- Better SEO signals
- Self-documenting structure
- Screen reader friendly

**Element Mapping:**
| Content | Element |
|---------|---------|
| Page header with hero | `<header>` |
| Main content area | `<main>` |
| Hero section | `<section class="hero">` |
| Projects section | `<section class="projects">` |
| Individual project | `<article class="projects__card">` |
| Page footer | `<footer>` |

## File Structure

```
portfolio-project/
├── index.html          # Single HTML page
├── styles.css          # All styles
├── docs/
│   ├── prd.md
│   ├── architecture.md
│   ├── project_context.md
│   └── epics.md
└── bmad-assist.yaml
```

## Performance Budget

| Metric | Target |
|--------|--------|
| HTML size | < 5KB |
| CSS size | < 10KB |
| Total page weight | < 20KB (excluding images) |
| First Contentful Paint | < 1s on 3G |

## Security Considerations

- No user input handling (no forms)
- No external scripts
- No cookies or local storage
- Static hosting compatible (no server-side logic)

## Future Considerations

If requirements expand:
- Contact form: Consider external service (Formspree, Netlify Forms)
- Image optimization: Add srcset for responsive images
- Analytics: Add privacy-respecting solution (Plausible, Fathom)
- Multi-page: Consider static site generator

These are explicitly out of scope for v1.0.
]]></file>
<file id="b8bd6269" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/implementation-artifacts/1-1-hero-section-implementation.md"><![CDATA[# Story 1.1: hero-section-implementation

Status: Ready for Review

<!-- Note: Validation is optional. Run validate-create-story for quality check before dev-story. -->

## Story

As a visitor to Alex Chen's photography portfolio,
I want to see a prominent hero section when I land on the page,
so that I immediately understand who Alex Chen is and how to contact them.

## Acceptance Criteria

1. **AC-1.1.1:** Page contains `<header>` element with class `hero`
2. **AC-1.1.2:** Hero contains `<h1 class="hero__name">` with text "Alex Chen"
3. **AC-1.1.3:** Hero contains `<p>` element with class `hero__tagline` with text "Capturing moments that last forever"
4. **AC-1.1.4:** Hero contains `<a href="#contact" class="hero__cta">` element with "Get in Touch" text
5. **AC-1.1.5:** HTML is valid and uses semantic elements
6. **AC-1.1.6:** Hero section has dark background (#1a1a2e), white text, centered content, and CTA with accent background (#e94560)
7. **AC-1.1.7:** CTA link has visible focus state for keyboard accessibility

## Tasks / Subtasks

- [x] Task 1: Create HTML structure for hero section (AC: 1.1.1, 1.1.2, 1.1.3, 1.1.4, 1.1.5)
  - [x] Create `index.html` with HTML5 doctype and semantic structure
  - [x] Add `<header class="hero">` element
  - [x] Add `<h1 class="hero__name">` with "Alex Chen"
  - [x] Add `<p class="hero__tagline">` with tagline text
  - [x] Add `<a class="hero__cta">` with contact link
  - [x] Validate HTML using W3C validator or similar

- [x] Task 2: Create CSS for hero section styling (AC: 1.1.6, 1.1.7)
  - [x] Create `styles.css` file
  - [x] Link stylesheet in HTML `<head>`
  - [x] Add hero section styling (dark background #1a1a2e, white text, centered content)
  - [x] Style CTA button with accent background (#e94560) and white text
  - [x] Add visible focus state to CTA link for keyboard accessibility

## Dev Notes

### Architecture Patterns & Constraints

**Technology Stack** [Source: docs/architecture.md#Technology Decisions]
- Pure HTML5 and CSS3 only - NO JavaScript (ADR-001)
- No build tools, preprocessors, or external dependencies
- Single page architecture (ADR-002)
- Maximum browser compatibility required

**Semantic HTML Requirements** [Source: docs/architecture.md#ADR-006]
- Use `<header>` for page header with hero content
- Proper heading hierarchy: single `<h1>` on page
- All elements must be semantic (no generic divs for structural elements)
- Screen reader friendly markup

**CSS Architecture** [Source: docs/architecture.md#ADR-004]
- **BEM Naming Convention (MANDATORY):** Block__Element--Modifier pattern
- Block: `.hero`
- Elements: `.hero__name`, `.hero__tagline`, `.hero__cta`
- NO generic class names like `.title` or `.button`

**File Structure** [Source: docs/architecture.md#File Structure]
```
portfolio-project/
├── index.html          # Create this file
├── styles.css          # Create this file
```

### UX Design Specifications

**Visual Direction** [Source: docs/ux-spec.md#Visual Direction]
- Mood: Elegant, Professional, Minimal, Gallery-like
- Hero section uses dark background (`--color-primary: #1a1a2e`)
- White text on dark background for dramatic first impression
- Clean, sophisticated aesthetic

**Typography** [Source: docs/ux-spec.md#Typography Rationale]
- Hero name: Georgia serif font, `3rem` size for commanding presence
- Tagline: Arial sans-serif, clear and modern
- Text must be centered in hero section

**Layout Wireframe** [Source: docs/ux-spec.md#Wireframes]
```
┌──────────────────────┐
│                      │
│     ALEX CHEN        │
│                      │
│  Capturing moments   │
│  that last forever   │
│                      │
│   [ Get in Touch ]   │
│                      │
└──────────────────────┘
```

**Interaction Design** [Source: docs/ux-spec.md#Interaction Design]
- CTA button must use `--color-accent` (#e94560) background with white text
- Minimum touch target: 48x48px for mobile accessibility
- Hero section spans full viewport width

### Coding Standards

**HTML Rules** [Source: docs/project_context.md#HTML Rules]
- 2-space indentation
- Double quotes for attributes
- Self-closing tags for void elements: `<img />`, `<br />`
- Always include `alt` attribute on images (if any added later)

**CSS Rules** [Source: docs/project_context.md#CSS Rules]
- 2-space indentation
- One property per line
- Opening brace on same line as selector
- Blank line between rule sets
- Properties ordered: positioning → display → box model → typography → visual → misc

**CSS Custom Properties Setup** [Source: docs/project_context.md#CSS Custom Properties]
While full design tokens will be implemented in Story 2.1, basic hero styling for THIS story should prepare for token usage:

```css
/* Minimal inline values for Story 1.1 - will be replaced with tokens in 2.1 */
.hero {
  background-color: #1a1a2e;  /* Will become var(--color-primary) */
  color: #ffffff;
  /* ... other basic styles ... */
}

.hero__cta {
  background-color: #e94560;  /* Will become var(--color-accent) */
  color: #ffffff;
  /* ... button styles ... */
}

.hero__cta:focus {
  outline: 2px solid #e94560;
  outline-offset: 2px;
}
```

### Project Structure Notes

**Current State:** Empty project - no files exist yet

**Files to Create:**
1. `index.html` - Root HTML file (single page architecture)
2. `styles.css` - All CSS styles

**HTML Structure Template** [Source: docs/project_context.md#Component Structure]
```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Alex Chen Photography</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
  <header class="hero">
    <h1 class="hero__name">Alex Chen</h1>
    <p class="hero__tagline">Capturing moments that last forever</p>
    <a href="#contact" class="hero__cta">Get in Touch</a>
  </header>

  <!-- Projects section will be added in Story 1.2 -->
</body>
</html>
```

**CTA Link Behavior** [Source: docs/architecture.md#ADR-001]
- Use `#contact` anchor link for CTA href (contact form out of scope for v1.0)
- Alternative: `mailto:` link if preferred

### Performance Considerations

**Performance Budget** [Source: docs/architecture.md#Performance Budget]
- HTML size: < 5KB (hero section will be minimal)
- CSS size: < 10KB (basic styling should be ~1-2KB for this story)
- First Contentful Paint: < 1s on 3G

### Testing Verification

**Manual Verification Checklist:**
1. ✓ `<header class="hero">` exists in index.html
2. ✓ `<h1>` contains "Alex Chen"
3. ✓ Tagline `<p>` with class `hero__tagline` present
4. ✓ CTA `<a>` with class `hero__cta` present
5. ✓ HTML validates with no errors (use https://validator.w3.org/)
6. ✓ Hero section visible with dark background
7. ✓ Text is white and readable on dark background
8. ✓ CTA button has coral/accent background color
9. ✓ All classes follow BEM naming (no violations)
10. ✓ CTA has visible focus state when tabbed to (keyboard accessibility)
11. ✓ Page displays correctly in browser

**Browser Testing:**
- Open index.html in Chrome, Firefox, Safari
- Verify hero section displays correctly
- Verify text is readable and CTA is visible

### Implementation Warnings

🚨 **CRITICAL MISTAKES TO AVOID:**
1. **DO NOT** use generic class names like `.title`, `.button`, `.header` - MUST use BEM (`.hero__name`, `.hero__cta`)
2. **DO NOT** add JavaScript - this is a pure HTML/CSS project
3. **DO NOT** use CSS preprocessors (Sass, Less) - vanilla CSS only
4. **DO NOT** add multiple `<h1>` tags - only one per page
5. **DO NOT** skip semantic elements - use `<header>`, not `<div class="header">`
6. **DO NOT** add features beyond AC scope (e.g., animations, extra sections)
7. **DO NOT** create multiple HTML files - single page architecture only

### Dependencies & Next Steps

**Dependencies:** None - this is the first story

**Next Story:** Story 1.2 (Projects Gallery Section) depends on this story
- Will add `<main>` section below hero
- Will reuse CSS file created here
- Hero structure must not be modified in 1.2

**Future Enhancements:** Story 2.1 will refactor CSS to use custom properties
- Current inline color values will be replaced with CSS variables
- BEM structure must remain intact for easy refactoring

### References

- [Architecture: Technology Stack] docs/architecture.md#ADR-001
- [Architecture: Single Page Architecture] docs/architecture.md#ADR-002
- [Architecture: BEM Naming] docs/architecture.md#ADR-004
- [Architecture: Semantic HTML] docs/architecture.md#ADR-006
- [PRD: Hero Section Requirements] docs/prd.md#FR-001
- [UX: Visual Direction] docs/ux-spec.md#Visual Direction
- [UX: Typography] docs/ux-spec.md#Typography Rationale
- [UX: Hero Wireframe] docs/ux-spec.md#Wireframes
- [Project Context: HTML Rules] docs/project_context.md#HTML Rules
- [Project Context: CSS Rules] docs/project_context.md#CSS Rules
- [Project Context: Hero Structure] docs/project_context.md#Component Structure

### Success Definition

Story is complete when:
1. All 7 acceptance criteria checked off
2. HTML validates with W3C validator (no errors)
3. CSS follows BEM naming (verified by code review)
4. Hero section visually matches wireframe intent
5. Manual browser testing passes
6. Code committed with message: "feat: implement hero section with branding and CTA"

## Dev Agent Record

### Agent Model Used

Claude Opus 4.5 (claude-opus-4-5-20251101)

### Debug Log References

N/A - Implementation completed without errors.

### Completion Notes List

- Created `index.html` with semantic HTML5 structure following project conventions
- Implemented hero section with `<header class="hero">` containing name, tagline, and CTA
- Created `styles.css` with BEM-compliant class naming (`.hero`, `.hero__name`, `.hero__tagline`, `.hero__cta`)
- Applied dark background (#1a1a2e), white text, flexbox centering per UX spec
- Styled CTA with accent color (#e94560), min 48x48px touch target, visible focus state
- All 7 acceptance criteria verified and satisfied

**Code Review Synthesis Fixes (2026-01-21):**
- Added CSS reset (box-sizing, body margin) to prevent cross-browser inconsistencies
- Added `min-height: 100dvh` fallback for iOS Safari viewport issues
- Improved focus indicator visibility: changed outline from #e94560 to #ffffff (3px)
- Added `@media (prefers-reduced-motion: reduce)` for accessibility compliance
- Added meta description for SEO
- Removed internal sprint comment from HTML

### File List

- `index.html` (created, updated by synthesis) - Single-page HTML structure with hero section
- `styles.css` (created, updated by synthesis) - Hero section styles with BEM naming

### Change Log

| Date | Change | Reason |
|------|--------|--------|
| 2026-01-21 | Created index.html and styles.css | Initial hero section implementation per Story 1.1 |
| 2026-01-21 | Applied code review synthesis fixes | Added CSS reset, 100dvh fallback, improved focus visibility, prefers-reduced-motion support, meta description |]]></file>
<file id="ed9105ba" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/implementation-artifacts/1-2-projects-gallery-section.md"><![CDATA[# Story 1.2: projects-gallery-section

Status: ready-for-review

<!-- Note: Validation is optional. Run validate-create-story for quality check before dev-story. -->

## Story

As a visitor to Alex Chen's photography portfolio,
I want to see Alex's photography projects organized in cards,
so that I can understand the types of photography services offered.

## Acceptance Criteria

1. **AC-1.2.1:** Page contains `<main>` element wrapping content below hero
2. **AC-1.2.2:** Main contains `<section>` with class `projects`
3. **AC-1.2.3:** Projects section contains `<h2>` with title "Portfolio"
4. **AC-1.2.4:** Projects section contains exactly 3 `<article>` elements with class `projects__card`
5. **AC-1.2.5:** Each card contains: image placeholder div (`projects__card-image`), `<h3>` title (`projects__card-title`), `<p>` description (`projects__card-description`) with 5-15 words describing the photography specialty
6. **AC-1.2.6:** Card titles are: "Wedding", "Portrait", "Landscape"
7. **AC-1.2.7:** Cards are wrapped in container with class `projects__grid`
8. **AC-1.2.8:** HTML validates without errors
9. **AC-1.2.9:** Image placeholders have visible height using aspect-ratio (4/3) and neutral background color (#e0e0e0)
10. **AC-1.2.10:** Cards have hover effect with elevated shadow and subtle lift (respects `prefers-reduced-motion`)
11. **AC-1.2.11:** Cards have visible focus state with outline for keyboard accessibility

## Tasks / Subtasks

- [x] Task 1: Add `<main>` element to HTML structure (AC: 1.2.1)
  - [x] Insert `<main>` element after closing `</header>` tag
  - [x] Ensure `<main>` wraps all content below hero section

- [x] Task 2: Create projects section structure (AC: 1.2.2, 1.2.3, 1.2.7)
  - [x] Add `<section class="projects">` inside `<main>`
  - [x] Add `<h2 class="projects__title">Portfolio</h2>` as first child
  - [x] Add `<div class="projects__grid">` container for cards

- [x] Task 3: Implement three project cards (AC: 1.2.4, 1.2.5, 1.2.6)
  - [x] Create Wedding card with `<article class="projects__card">`
    - [x] Add `<div class="projects__card-image"></div>` placeholder
    - [x] Add `<h3 class="projects__card-title">Wedding</h3>`
    - [x] Add `<p class="projects__card-description">` with 1-2 sentence description
  - [x] Create Portrait card with same structure
  - [x] Create Landscape card with same structure

- [x] Task 4: Add CSS styles for projects section (AC: 1.2.9, 1.2.10, 1.2.11)
  - [x] Style `.projects` section (background, padding, centered content)
  - [x] Style `.projects__title` (typography using design tokens approach)
  - [x] Style `.projects__grid` (single column for mobile, gap: 2rem)
  - [x] Style `.projects__card` (background #fff, border-radius 8px, box-shadow, padding)
  - [x] Style `.projects__card-image` (aspect-ratio: 4/3, background-color: #e0e0e0)
  - [x] Style `.projects__card-title` and `.projects__card-description`
  - [x] Add `.projects__card:hover` (elevated shadow, translateY(-2px), transition 0.2s ease)
  - [x] Add `.projects__card:focus-visible` (outline: 2px solid #e94560, outline-offset: 2px)
  - [x] Extend `@media (prefers-reduced-motion: reduce)` to disable card transitions

- [x] Task 5: Validate HTML (AC: 1.2.8)
  - [x] Manual validation (no automated validator available)
  - [x] Verified proper structure, nesting, and closing tags

## Dev Notes

### Architecture Patterns & Constraints

**Technology Stack** [Source: docs/architecture.md#ADR-001]
- Pure HTML5 and CSS3 only - NO JavaScript
- No build tools, preprocessors, or external dependencies
- Single page architecture (ADR-002)

**Semantic HTML Requirements** [Source: docs/architecture.md#ADR-006]
- Use `<main>` for main content area
- Use `<section>` for the projects section
- Use `<article>` for each individual project card (self-contained content)
- Proper heading hierarchy: `<h1>` (hero) → `<h2>` (section) → `<h3>` (cards)

**CSS Architecture** [Source: docs/architecture.md#ADR-004]
- **BEM Naming Convention (MANDATORY):**
  - Block: `.projects`
  - Elements: `.projects__title`, `.projects__grid`, `.projects__card`, `.projects__card-image`, `.projects__card-title`, `.projects__card-description`
- NO generic class names

**Performance Budget** [Source: docs/architecture.md#Performance Budget]
- HTML size: < 5KB total
- CSS size: < 10KB total
- Current CSS is ~88 lines, plenty of room

### UX Design Specifications

**Visual Direction** [Source: docs/ux-spec.md#Visual Direction]
- Projects section uses light background (`--color-background: #ffffff`)
- Photos should be the focus (gallery-like feel)
- Clean, minimal aesthetic

**Layout Wireframe - Mobile** [Source: docs/ux-spec.md#Wireframes]
```
├──────────────────────┤
│      Portfolio       │
├──────────────────────┤
│  ┌────────────────┐  │
│  │   [  image  ]  │  │
│  │    Wedding     │  │
│  │  description   │  │
│  └────────────────┘  │
│  ┌────────────────┐  │
│  │   [  image  ]  │  │
│  │    Portrait    │  │
│  │  description   │  │
│  └────────────────┘  │
│  ┌────────────────┐  │
│  │   [  image  ]  │  │
│  │   Landscape    │  │
│  │  description   │  │
│  └────────────────┘  │
└──────────────────────┘
```

**Layout Wireframe - Desktop** [Source: docs/ux-spec.md#Wireframes]
```
├────────────────────────────────────────────────────┤
│                     Portfolio                      │
├────────────────────────────────────────────────────┤
│  ┌──────────────┐ ┌──────────────┐ ┌──────────────┐│
│  │   [image]    │ │   [image]    │ │   [image]    ││
│  │   Wedding    │ │   Portrait   │ │  Landscape   ││
│  │ description  │ │ description  │ │ description  ││
│  └──────────────┘ └──────────────┘ └──────────────┘│
└────────────────────────────────────────────────────┘
```

**Card Interaction States** [Source: docs/ux-spec.md#Project Card States]
- Default: Subtle shadow (`box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1)`), white background
- Hover: Elevated shadow (`box-shadow: 0 8px 16px rgba(0, 0, 0, 0.15)`), slight lift (`transform: translateY(-2px)`)
- Focus: Visible outline (`outline: 2px solid #e94560; outline-offset: 2px`)
- Transitions: `transition: box-shadow 0.2s ease, transform 0.2s ease`

**Color Tokens** [Source: docs/project_context.md#CSS Custom Properties]
```css
--color-primary: #1a1a2e;     /* For text accents if needed */
--color-accent: #e94560;       /* Not used in cards typically */
--color-background: #ffffff;   /* Card and section background */
--color-text: #333333;         /* Card text */
--color-text-light: #666666;   /* Description text */
```

**Typography Tokens** [Source: docs/project_context.md#CSS Custom Properties]
```css
--font-heading: 'Georgia', serif;    /* For h2 section title */
--font-body: 'Arial', sans-serif;    /* For card content */
--font-size-lg: 1.25rem;             /* Card titles */
--font-size-xl: 2rem;                /* Section title */
```

**Spacing Tokens** [Source: docs/project_context.md#CSS Custom Properties]
```css
--spacing-xs: 0.5rem;
--spacing-sm: 1rem;
--spacing-md: 2rem;
--spacing-lg: 4rem;
```

### Project Structure Notes

**Current File State:**
- `index.html` - Contains hero section, needs `<main>` and projects section added
- `styles.css` - Contains CSS reset and hero styles, needs projects styles added

**HTML Structure to Add** [Source: docs/project_context.md#Component Structure]
```html
<main>
  <section class="projects">
    <h2 class="projects__title">Portfolio</h2>
    <div class="projects__grid">
      <article class="projects__card">
        <div class="projects__card-image"></div>
        <h3 class="projects__card-title">Wedding</h3>
        <p class="projects__card-description">Elegant moments captured with timeless style.</p>
      </article>
      <article class="projects__card">
        <div class="projects__card-image"></div>
        <h3 class="projects__card-title">Portrait</h3>
        <p class="projects__card-description">Revealing personality through professional portraiture.</p>
      </article>
      <article class="projects__card">
        <div class="projects__card-image"></div>
        <h3 class="projects__card-title">Landscape</h3>
        <p class="projects__card-description">Nature's beauty through an artistic lens.</p>
      </article>
    </div>
  </section>
</main>
```

**CSS Grid Pattern** [Source: docs/project_context.md#Responsive Design]
```css
/* Mobile styles (default) */
.projects__grid {
  display: grid;
  grid-template-columns: 1fr;
}

/* Desktop styles */
@media (min-width: 768px) {
  .projects__grid {
    grid-template-columns: repeat(3, 1fr);
  }
}
```

**Note:** Responsive behavior will be fully implemented in Story 2.2. For THIS story, focus on the base single-column layout. The grid CSS should be written mobile-first but desktop media query styles can be minimal/placeholder.

### Previous Story Intelligence

**Story 1.1 Implementation Patterns to Follow:**
- CSS reset and box-sizing already established - do NOT duplicate
- Use same CSS comment section headers format
- Follow same property ordering in CSS rules
- `prefers-reduced-motion` media query pattern already exists
- Transition timing: `0.2s ease` for hover effects

**Files Modified in Story 1.1:**
- `index.html` (lines 1-17) - Insert `<main>` before `</body>`
- `styles.css` (lines 1-87) - Add projects styles after hero section

### Coding Standards

**HTML Rules** [Source: docs/project_context.md#HTML Rules]
- 2-space indentation
- Double quotes for attributes
- Semantic elements only

**CSS Rules** [Source: docs/project_context.md#CSS Rules]
- 2-space indentation
- One property per line
- Opening brace on same line as selector
- Blank line between rule sets
- Property order: positioning → display → box model → typography → visual → misc

**Image Placeholder Implementation:**
- Use `<div class="projects__card-image">` with CSS background color
- Set aspect ratio using padding-bottom trick or aspect-ratio property
- Background color: use a neutral gray like `#e0e0e0` or `--color-text-light`

### Testing Verification

**Manual Verification Checklist:**
1. ✓ `<main>` element exists wrapping content below hero
2. ✓ `<section class="projects">` exists inside main
3. ✓ `<h2>` with "Portfolio" text present
4. ✓ Exactly 3 `<article class="projects__card">` elements
5. ✓ Each card has image placeholder, h3 title, p description (5-15 words)
6. ✓ Card titles are "Wedding", "Portrait", "Landscape"
7. ✓ Cards wrapped in `<div class="projects__grid">`
8. ✓ HTML validates with no errors
9. ✓ Image placeholders have aspect-ratio 4/3 and #e0e0e0 background
10. ✓ Cards have hover effect (elevated shadow + slight lift)
11. ✓ Cards have visible focus state (outline) for keyboard navigation
12. ✓ All classes follow BEM naming
13. ✓ Cards display vertically stacked on mobile
14. ✓ Hover/focus transitions disabled when prefers-reduced-motion is set

**Browser Testing:**
- Open index.html in Chrome, Firefox, Safari
- Verify projects section displays below hero
- Verify all 3 cards are visible and properly styled
- Test at mobile width (375px) - cards should stack

### Implementation Warnings

🚨 **CRITICAL MISTAKES TO AVOID:**
1. **DO NOT** modify the hero section - only ADD new content
2. **DO NOT** use generic class names like `.card`, `.grid`, `.title`
3. **DO NOT** duplicate CSS reset - it already exists
4. **DO NOT** add JavaScript
5. **DO NOT** add responsive media queries for 3-column layout yet (that's Story 2.2)
6. **DO NOT** use `<img>` tags - use div placeholders with background
7. **DO NOT** skip the `<main>` wrapper - it's required for accessibility
8. **DO NOT** break heading hierarchy - must be h1 → h2 → h3

### Dependencies & Next Steps

**Dependencies:** Story 1.1 (Hero Section) - COMPLETED ✓

**Next Stories:**
- Story 2.1 (CSS Design Tokens) - Will refactor hardcoded colors to CSS variables
- Story 2.2 (Responsive Layout) - Will add 3-column grid for desktop

**Preparation for Story 2.1:**
- Use hardcoded color values that match the token values for now
- Comment sections clearly so refactoring is easy

### References

- [Architecture: Technology Stack] docs/architecture.md#ADR-001
- [Architecture: Single Page] docs/architecture.md#ADR-002
- [Architecture: BEM Naming] docs/architecture.md#ADR-004
- [Architecture: Semantic HTML] docs/architecture.md#ADR-006
- [PRD: Projects Gallery] docs/prd.md#FR-002
- [UX: Layout Wireframes] docs/ux-spec.md#Wireframes
- [UX: Card States] docs/ux-spec.md#Project Card States
- [Project Context: CSS Properties] docs/project_context.md#CSS Custom Properties
- [Project Context: Component Structure] docs/project_context.md#Component Structure
- [Project Context: Responsive] docs/project_context.md#Responsive Design
- [Epics: Story 1.2] docs/epics.md#Story 1.2

### Success Definition

Story is complete when:
1. All 11 acceptance criteria checked off
2. HTML validates with W3C validator (no errors)
3. CSS follows BEM naming throughout
4. Projects section displays below hero
5. All 3 cards visible with proper content
6. Manual browser testing passes
7. Code committed with message: "feat: implement projects gallery with three portfolio cards"

## Dev Agent Record

### Agent Model Used

claude-opus-4-5-20251101

### Debug Log References

No issues encountered during implementation.

### Completion Notes List

- Added `<main>` element wrapping projects section after hero
- Created projects section with semantic HTML5 structure (section, article elements)
- Implemented 3 project cards (Wedding, Portrait, Landscape) with BEM class naming
- Each card has image placeholder, h3 title, and p description (8-9 words each)
- Added CSS styles following existing patterns from Story 1.1
- Implemented hover state with elevated shadow and translateY transform
- Added focus-visible state with accent-colored outline for keyboard accessibility
- Extended prefers-reduced-motion media query to disable card transitions
- All colors use hardcoded values matching design tokens (prep for Story 2.1)
- Grid layout uses single column (mobile-first, desktop layout in Story 2.2)

**Code Review Synthesis Fixes (2026-01-21):**
- Added `tabindex="0"` to all 3 `<article class="projects__card">` elements to enable keyboard focus (AC-1.2.11 fix)
- Fixed self-closing void elements (`<meta>`, `<link>`) to match project_context.md HTML convention

### File List

- `index.html` - Added main element and projects section with 3 cards (lines 16-37), keyboard accessibility fix
- `styles.css` - Added projects section styles (lines 74-160)

### Change Log

| Date | Change | Reason |
|------|--------|--------|
| 2026-01-21 | Story created | Initial story creation with comprehensive dev context |
| 2026-01-21 | Implementation complete | All 11 ACs satisfied, ready for review |
| 2026-01-21 | Code review synthesis fixes | Added tabindex="0" for keyboard accessibility, fixed self-closing tags |
]]></file>
<file id="4a2614b9" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/implementation-artifacts/sprint-status.yaml"><![CDATA[# Generated by bmad-assist on 2026-01-21T18:10:04
# Sprint Status File - unknown
#
generated: '2026-01-13T16:40:56.983271+00:00'
development_status:
  # Epic 1
  # Epic 1
  # Epic 1
  # Epic 1
  # Epic 1
  # Epic 1
  # Epic 1
  # Epic 1
  # Epic 1
  # Epic 1
  # Epic 1
  # Epic 1
  # Epic 1
  # Epic 1
  # Epic 1
  epic-1: in-progress
  1-1-hero-section-implementation: done
  1-2-projects-gallery-section: review
  # Epic 2
  # Epic 2
  # Epic 2
  # Epic 2
  # Epic 2
  # Epic 2
  # Epic 2
  # Epic 2
  # Epic 2
  # Epic 2
  # Epic 2
  # Epic 2
  # Epic 2
  # Epic 2
  # Epic 2
  epic-2: backlog
  2-1-css-design-tokens-and-typography: backlog
  2-2-mobile-first-responsive-layout: backlog

]]></file>
</context>
<variables>
<var name="architecture_file" description="System architecture for context" />
<var name="author">BMad</var>
<var name="communication_language">English</var>
<var name="date">system-generated</var>
<var name="description">Run after epic completion to review overall success, extract lessons learned, and explore if new information emerged that might impact the next epic</var>
<var name="document_output_language">English</var>
<var name="document_project_file" description="Brownfield project documentation (optional)" />
<var name="epic_num">1</var>
<var name="epics_file" description="The completed epic for retrospective" />
<var name="implementation_artifacts">/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/implementation-artifacts</var>
<var name="instructions">/home/pawel/projects/bmad-assist-22/src/bmad_assist/workflows/retrospective/instructions.md</var>
<var name="name">retrospective</var>
<var name="next_epic_num">2</var>
<var name="output_folder">/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output</var>
<var name="planning_artifacts">/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/planning-artifacts</var>
<var name="prd_file" description="Product requirements for context" />
<var name="prev_epic_num"></var>
<var name="previous_retrospective_file" description="Previous epic's retrospective (optional)" />
<var name="project_context">none</var>
<var name="project_knowledge">/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/docs</var>
<var name="project_name">simple-portfolio</var>
<var name="required_inputs">[{"agent_manifest": "{project-root}/_bmad/_config/agent-manifest.csv"}]</var>
<var name="retrospectives_folder">/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/implementation-artifacts</var>
<var name="sprint_status" file_id="4a2614b9">/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/implementation-artifacts/sprint-status.yaml</var>
<var name="sprint_status_file">/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/implementation-artifacts/</var>
<var name="story_directory">/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/implementation-artifacts</var>
<var name="template">False</var>
<var name="user_name">User</var>
<var name="user_skill_level">expert</var>
</variables>
<file-index>
<entry id="b8bd6269" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/implementation-artifacts/1-1-hero-section-implementation.md" />
<entry id="ed9105ba" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/implementation-artifacts/1-2-projects-gallery-section.md" />
<entry id="4a2614b9" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/implementation-artifacts/sprint-status.yaml" />
<entry id="2e55b2e3" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/docs/architecture.md" />
<entry id="bda659bb" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/docs/prd.md" />
<entry id="11c89e12" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/docs/project_context.md" />
</file-index>
<instructions><![CDATA[# Retrospective - Epic Completion Review Instructions

<critical>You MUST have already loaded and processed: {project-root}/_bmad/bmm/workflows/4-implementation/retrospective/workflow.yaml</critical>
<critical>Communicate all responses in English and language MUST be tailored to expert</critical>
<critical>Generate all documents in English</critical>
<critical>⚠️ ABSOLUTELY NO TIME ESTIMATES - NEVER mention hours, days, weeks, months, or ANY time-based predictions. AI has fundamentally changed development speed - what once took teams weeks/months can now be done by one person in hours. DO NOT give ANY time estimates whatsoever.</critical>

<critical>
SCOPE LIMITATION: You are an AUTOMATED RETROSPECTIVE GENERATOR. Your ONLY output should be a structured retrospective report wrapped in extraction markers. Do NOT use party-mode dialogue. Do NOT wait for user input. Do NOT write files. Generate the complete retrospective in ONE response.
</critical>

<critical>
  DOCUMENT OUTPUT: Retrospective analysis. Concise insights, lessons learned, action items. User skill level (expert) affects conversation style ONLY, not retrospective content.
</critical>

<workflow>

<critical>AUTOMATED MODE: This retrospective runs WITHOUT user interaction.
- Analyze all provided context (epic, stories, sprint-status, previous retro)
- Generate a SINGLE structured retrospective report
- Wrap output in extraction markers
- Do NOT use party-mode dialogue format
- Do NOT wait for user input
- Do NOT save files directly</critical>

<step n="1" goal="Epic Discovery - Find Completed Epic with Priority Logic">

<!-- managed programmatically by bmad-assist -->

<!-- managed programmatically by bmad-assist -->
<action>Read ALL development_status entries</action>
<action>Find the highest epic number with at least one story marked "done"</action>
<action>Extract epic number from keys like "epic-X-retrospective" or story keys like "X-Y-story-name"</action>
<action>Set {{detected_epic}} = highest epic number found with completed stories</action>

<check if="{{detected_epic}} found">
  <action>Set {{epic_number}} = {{detected_epic}}</action>
</check>
<action>Once {{epic_number}} is determined, verify epic completion status</action>

<!-- managed programmatically by bmad-assist -->

<action>Count total stories found for this epic</action>
<action>Count stories with status = "done"</action>
<action>Collect list of pending story keys (status != "done")</action>
<action>Determine if complete: true if all stories are done, false otherwise</action>

<check if="epic is not complete">
<action>Set {{partial_retrospective}} = true</action>
<action>Document incomplete stories for retrospective report</action>
</check>

<check if="epic is complete">
<action>Set {{partial_retrospective}} = false</action>
</check>

</step>

<step n="0.5" goal="Discover and load project documents"><!-- input discovery handled by compiler --><note>After discovery, these content variables are available: {epics_content} (selective load for this epic), {architecture_content}, {prd_content}, {document_project_content}</note>
</step>

<step n="2" goal="Deep Story Analysis - Extract Lessons from Implementation">

<action>For each story in epic {{epic_number}}, read the complete story file from /home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/implementation-artifacts/{{epic_number}}-{{story_num}}-\*.md</action>

<action>Extract and analyze from each story:</action>

**Dev Notes and Struggles:**

- Look for sections like "## Dev Notes", "## Implementation Notes", "## Challenges", "## Development Log"
- Identify where developers struggled or made mistakes
- Note unexpected complexity or gotchas discovered
- Record technical decisions that didn't work out as planned
- Track where estimates were way off (too high or too low)

**Review Feedback Patterns:**

- Look for "## Review", "## Code Review", "## SM Review", "## Scrum Master Review" sections
- Identify recurring feedback themes across stories
- Note which types of issues came up repeatedly
- Track quality concerns or architectural misalignments
- Document praise or exemplary work called out in reviews

**Lessons Learned:**

- Look for "## Lessons Learned", "## Retrospective Notes", "## Takeaways" sections within stories
- Extract explicit lessons documented during development
- Identify "aha moments" or breakthroughs
- Note what would be done differently
- Track successful experiments or approaches

**Technical Debt Incurred:**

- Look for "## Technical Debt", "## TODO", "## Known Issues", "## Future Work" sections
- Document shortcuts taken and why
- Track debt items that affect next epic
- Note severity and priority of debt items

**Testing and Quality Insights:**

- Look for "## Testing", "## QA Notes", "## Test Results" sections
- Note testing challenges or surprises
- Track bug patterns or regression issues
- Document test coverage gaps

<action>Synthesize patterns across all stories:</action>

**Common Struggles:**

- Identify issues that appeared in 2+ stories (e.g., "3 out of 5 stories had API authentication issues")
- Note areas where team consistently struggled
- Track where complexity was underestimated

**Recurring Review Feedback:**

- Identify feedback themes (e.g., "Error handling was flagged in every review")
- Note quality patterns (positive and negative)
- Track areas where team improved over the course of epic

**Breakthrough Moments:**

- Document key discoveries (e.g., "Story 3 discovered the caching pattern we used for rest of epic")
- Note when team velocity improved dramatically
- Track innovative solutions worth repeating

**Velocity Patterns:**

- Calculate average completion time per story
- Note velocity trends (e.g., "First 2 stories took 3x longer than estimated")
- Identify which types of stories went faster/slower

**Team Collaboration Highlights:**

- Note moments of excellent collaboration mentioned in stories
- Track where pair programming or mob programming was effective
- Document effective problem-solving sessions

<action>Store this synthesis - these patterns will drive the retrospective analysis</action>

</step>

<step n="3" goal="Load and Integrate Previous Epic Retrospective">

<action>Calculate previous epic number:  = {{epic_number}} - 1</action>

<check if=" >= 1">
  <action>Search for previous retrospective using pattern: /home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/implementation-artifacts/epic--retro-*.md</action>

  <check if="previous retro found">
    <action>Read the complete previous retrospective file</action>

    <action>Extract key elements:</action>
    - **Action items committed**: What did the team agree to improve?
    - **Lessons learned**: What insights were captured?
    - **Process improvements**: What changes were agreed upon?
    - **Technical debt flagged**: What debt was documented?
    - **Team agreements**: What commitments were made?
    - **Preparation tasks**: What was needed for this epic?

    <action>Cross-reference with current epic execution:</action>

    **Action Item Follow-Through:**
    - For each action item from Epic  retro, check if it was completed
    - Look for evidence in current epic's story records
    - Mark each action item: ✅ Completed, ⏳ In Progress, ❌ Not Addressed

    **Lessons Applied:**
    - For each lesson from Epic , check if team applied it in Epic {{epic_number}}
    - Look for evidence in dev notes, review feedback, or outcomes
    - Document successes and missed opportunities

    **Process Improvements Effectiveness:**
    - For each process change agreed to in Epic , assess if it helped
    - Did the change improve velocity, quality, or team satisfaction?
    - Should we keep, modify, or abandon the change?

    **Technical Debt Status:**
    - For each debt item from Epic , check if it was addressed
    - Did unaddressed debt cause problems in Epic {{epic_number}}?
    - Did the debt grow or shrink?

    <action>Prepare "continuity insights" for the retrospective report</action>

    <action>Identify wins where previous lessons were applied successfully:</action>
    - Document specific examples of applied learnings
    - Note positive impact on Epic {{epic_number}} outcomes
    - Celebrate team growth and improvement

    <action>Identify missed opportunities where previous lessons were ignored:</action>
    - Document where team repeated previous mistakes
    - Note impact of not applying lessons (without blame)
    - Explore barriers that prevented application

  </check>

  <check if="no previous retro found">
<action>Set {{first_retrospective}} = true</action>
</check>
</check>

<check if=" < 1">
<action>Set {{first_retrospective}} = true</action>
</check>

</step>

<step n="4" goal="Preview Next Epic with Change Detection">

<action>Calculate next epic number: 2 = {{epic_number}} + 1</action>

<action>Attempt to load next epic using selective loading strategy:</action>

**Try sharded first (more specific):**
<action>Check if file exists: /home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/planning-artifacts/epic\*/epic-2.md</action>

<check if="sharded epic file found">
  <action>Load /home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/planning-artifacts/*epic*/epic-2.md</action>
  <action>Set {{next_epic_source}} = "sharded"</action>
</check>

**Fallback to whole document:**
<check if="sharded epic not found">
<action>Check if file exists: /home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/planning-artifacts/epic\*.md</action>

  <check if="whole epic file found">
    <action>Load entire epics document</action>
    <action>Extract Epic 2 section</action>
    <action>Set {{next_epic_source}} = "whole"</action>
  </check>
</check>

<check if="next epic found">
  <action>Analyze next epic for:</action>
  - Epic title and objectives
  - Planned stories and complexity estimates
  - Dependencies on Epic {{epic_number}} work
  - New technical requirements or capabilities needed
  - Potential risks or unknowns
  - Business goals and success criteria

<action>Identify dependencies on completed work:</action>

- What components from Epic {{epic_number}} does Epic 2 rely on?
- Are all prerequisites complete and stable?
- Any incomplete work that creates blocking dependencies?

<action>Note potential gaps or preparation needed:</action>

- Technical setup required (infrastructure, tools, libraries)
- Knowledge gaps to fill (research, training, spikes)
- Refactoring needed before starting next epic
- Documentation or specifications to create

<action>Check for technical prerequisites:</action>

- APIs or integrations that must be ready
- Data migrations or schema changes needed
- Testing infrastructure requirements
- Deployment or environment setup

<action>Set {{next_epic_exists}} = true</action>
</check>

<check if="next epic NOT found">
<action>Set {{next_epic_exists}} = false</action>
</check>

</step>

<step n="5" goal="Initialize Retrospective Analysis with Rich Context">

<action>Load agent configurations from {agent_manifest}</action>
<action>Identify which agents participated in Epic {{epic_number}} based on story records</action>
<action>Ensure key roles present: Product Owner, Scrum Master (facilitating), Devs, Testing/QA, Architect</action>

<action>Compile epic summary metrics:</action>
- Completed stories count and percentage
- Velocity metrics
- Blocker count
- Technical debt items
- Test coverage info
- Production incidents
- Goals achieved
- Success criteria status

</step>

<step n="6" goal="Epic Review Analysis - What Went Well, What Didn't">

<action>Analyze successes from story records and patterns discovered in Step 2</action>

<action>Identify key success themes:</action>
- Technical wins and breakthroughs
- Quality improvements
- Collaboration highlights
- Process improvements that worked

<action>Analyze challenges from story records and patterns discovered in Step 2</action>

<action>Identify key challenge themes:</action>
- Recurring blockers
- Quality issues
- Communication gaps
- Process problems
- Technical struggles

<action>Synthesize themes from patterns discovered across all stories</action>

<check if="previous retrospective exists">
<action>Analyze action item follow-through from Epic  retro</action>
<action>Document which items were completed, in progress, or not addressed</action>
<action>Identify impact of following or not following previous lessons</action>
</check>

<action>Create summary of successes, challenges, and key insights</action>

</step>

<step n="7" goal="Next Epic Preparation Analysis">

<check if="{{next_epic_exists}} == false">
  <action>Skip preparation analysis - no next epic defined</action>
  <action>Proceed to Step 8</action>
</check>

<check if="{{next_epic_exists}} == true">

<action>Analyze preparation needs across all dimensions:</action>

- Dependencies on Epic {{epic_number}} work
- Technical setup and infrastructure
- Knowledge gaps and research needs
- Documentation or specification work
- Testing infrastructure
- Refactoring or debt reduction
- External dependencies (APIs, integrations, etc.)

<action>Categorize preparation items:</action>

**CRITICAL PREPARATION (Must complete before epic starts):**
- Items that would block Story 1
- Unresolved technical debt that affects next epic
- Missing infrastructure or tooling

**PARALLEL PREPARATION (Can happen during early stories):**
- Items that only affect later stories
- Non-blocking improvements

**NICE-TO-HAVE PREPARATION (Would help but not blocking):**
- Optimizations
- Documentation improvements
- Nice-to-have tooling

</check>

</step>

<step n="8" goal="Synthesize Action Items with Significant Change Detection">

<action>Synthesize themes from Epic {{epic_number}} review analysis into actionable improvements</action>

<action>Create specific action items with:</action>

- Clear description of the action
- Assigned owner (specific agent or role)
- Category (process, technical, documentation, team, etc.)
- Success criteria (how we'll know it's done)

<action>Ensure action items are SMART:</action>

- Specific: Clear and unambiguous
- Measurable: Can verify completion
- Achievable: Realistic given constraints
- Relevant: Addresses real issues from retro

<action>CRITICAL ANALYSIS - Detect if discoveries require epic updates</action>

<action>Check if any of the following are true based on retrospective analysis:</action>

- Architectural assumptions from planning proven wrong during Epic {{epic_number}}
- Major scope changes or descoping occurred that affects next epic
- Technical approach needs fundamental change for Epic 2
- Dependencies discovered that Epic 2 doesn't account for
- User needs significantly different than originally understood
- Performance/scalability concerns that affect Epic 2 design
- Security or compliance issues discovered that change approach
- Integration assumptions proven incorrect
- Team capacity or skill gaps more severe than planned
- Technical debt level unsustainable without intervention

<check if="significant discoveries detected">
<action>Document significant changes and their impact</action>
<action>Set {{epic_update_needed}} = true</action>
<action>Identify specific updates needed for Epic 2</action>
</check>

<check if="no significant discoveries">
<action>Set {{epic_update_needed}} = false</action>
</check>

</step>

<step n="9" goal="Critical Readiness Assessment">

<action>Assess testing and quality state:</action>
- What verification has been done?
- Are there testing gaps?
- Is Epic {{epic_number}} production-ready from a quality perspective?

<action>Assess deployment and release status:</action>
- Is the work deployed?
- What's the deployment timeline?

<action>Assess stakeholder acceptance:</action>
- Have stakeholders seen and accepted deliverables?
- Is feedback pending?

<action>Assess technical health and stability:</action>
- Is the codebase stable and maintainable?
- Are there lurking concerns?

<action>Identify unresolved blockers:</action>
- Are there blockers from Epic {{epic_number}} carrying forward?
- How do they affect Epic 2?

<action>Synthesize readiness assessment with status for each area</action>

</step>

<step n="10" goal="Compile Final Retrospective Data">

<action>Compile all analysis into structured retrospective data:</action>

- Epic summary and metrics
- Team participants
- Successes and strengths identified
- Challenges and growth areas
- Key insights and learnings
- Previous retro follow-through analysis (if applicable)
- Next epic preview and dependencies
- Action items with owners
- Preparation tasks for next epic
- Critical path items
- Significant discoveries and epic update recommendations (if any)
- Readiness assessment
- Commitments and next steps

</step>

<step n="11" goal="Generate Retrospective Report">

<action>Generate comprehensive retrospective report with all compiled data</action>

<action>Output the complete retrospective wrapped in extraction markers:</action>

<!-- RETROSPECTIVE_REPORT_START -->
# Epic {{epic_number}} Retrospective

**Date:** system-generated
**Epic:** {{epic_number}} - {{epic_title}}
**Status:** {{#if partial_retrospective}}Partial ({{pending_count}} stories incomplete){{else}}Complete{{/if}}

## Executive Summary

{{executive_summary}}

## Epic Metrics

| Metric | Value |
|--------|-------|
| Stories Completed | {{completed_stories}}/{{total_stories}} ({{completion_percentage}}%) |
| Velocity | {{actual_points}} story points |
| Blockers Encountered | {{blocker_count}} |
| Technical Debt Items | {{debt_count}} |
| Production Incidents | {{incident_count}} |

## Team Participants

{{list_participating_agents}}

## What Went Well

{{#each success_themes}}
### {{this.title}}
{{this.description}}
{{#if this.examples}}
**Examples:**
{{#each this.examples}}
- {{this}}
{{/each}}
{{/if}}
{{/each}}

## Challenges and Growth Areas

{{#each challenge_themes}}
### {{this.title}}
{{this.description}}
{{#if this.root_cause}}
**Root Cause:** {{this.root_cause}}
{{/if}}
{{#if this.impact}}
**Impact:** {{this.impact}}
{{/if}}
{{/each}}

## Key Insights

{{#each key_insights}}
{{@index}}. {{this}}
{{/each}}

{{#if previous_retro_exists}}
## Previous Retrospective Follow-Through

**Epic  Action Items:**

| Action Item | Status | Notes |
|-------------|--------|-------|
{{#each prev_action_items}}
| {{this.description}} | {{this.status}} | {{this.notes}} |
{{/each}}

**Lessons Applied:**
{{#each lessons_applied}}
- ✅ {{this}}
{{/each}}

**Missed Opportunities:**
{{#each missed_opportunities}}
- ❌ {{this}}
{{/each}}
{{/if}}

{{#if next_epic_exists}}
## Next Epic Preview

**Epic 2:** {{next_epic_title}}

### Dependencies on Epic {{epic_number}}
{{#each dependencies}}
- {{this}}
{{/each}}

### Preparation Needed

**Critical (Before Epic Starts):**
{{#each critical_prep}}
- [ ] {{this.description}} - Owner: {{this.owner}}
{{/each}}

**Parallel (During Early Stories):**
{{#each parallel_prep}}
- [ ] {{this.description}} - Owner: {{this.owner}}
{{/each}}

**Nice-to-Have:**
{{#each nice_to_have_prep}}
- [ ] {{this.description}}
{{/each}}
{{/if}}

## Action Items

### Process Improvements
{{#each process_action_items}}
{{@index}}. **{{this.description}}**
   - Owner: {{this.owner}}
   - Success Criteria: {{this.criteria}}
{{/each}}

### Technical Debt
{{#each debt_action_items}}
{{@index}}. **{{this.description}}**
   - Owner: {{this.owner}}
   - Priority: {{this.priority}}
{{/each}}

### Documentation
{{#each doc_action_items}}
{{@index}}. **{{this.description}}**
   - Owner: {{this.owner}}
{{/each}}

### Team Agreements
{{#each team_agreements}}
- {{this}}
{{/each}}

{{#if epic_update_needed}}
## ⚠️ Significant Discoveries - Epic Update Required

The following discoveries from Epic {{epic_number}} require updates to Epic 2:

{{#each significant_changes}}
### {{this.title}}
**Discovery:** {{this.description}}
**Impact:** {{this.impact}}
**Recommended Action:** {{this.recommended_action}}
{{/each}}

**IMPORTANT:** Do NOT start Epic 2 until planning review is complete.
{{/if}}

## Readiness Assessment

| Area | Status | Notes |
|------|--------|-------|
| Testing & Quality | {{quality_status}} | {{quality_notes}} |
| Deployment | {{deployment_status}} | {{deployment_notes}} |
| Stakeholder Acceptance | {{acceptance_status}} | {{acceptance_notes}} |
| Technical Health | {{stability_status}} | {{stability_notes}} |
| Unresolved Blockers | {{blocker_status}} | {{blocker_notes}} |

## Next Steps

1. Review this retrospective summary
2. {{#if epic_update_needed}}Schedule Epic 2 planning review session{{else}}Execute preparation tasks{{/if}}
3. Complete critical path items before Epic 2
4. Review action items in next standup
5. {{#if epic_update_needed}}Update Epic 2 based on discoveries{{else}}Begin Epic 2 when preparation complete{{/if}}

---

*Generated by BMAD Retrospective Workflow*
<!-- RETROSPECTIVE_REPORT_END -->

</step>

<step n="12" goal="Final Summary">

<action>Retrospective generation complete</action>
<action>Report is wrapped in extraction markers for orchestrator to parse</action>

</step>

</workflow>

<facilitation-guidelines>
<guideline>Generate structured report only - no dialogue format</guideline>
<guideline>Focus on systems and processes, not individual performance</guideline>
<guideline>Encourage specific examples over general statements</guideline>
<guideline>Balance celebration of wins with honest assessment of challenges</guideline>
<guideline>Action items must be specific, achievable, and owned</guideline>
<guideline>Forward-looking mindset - how do we improve for next epic?</guideline>
<guideline>Deep story analysis provides rich material for report</guideline>
<guideline>Previous retro integration creates accountability and continuity</guideline>
<guideline>Significant change detection prevents epic misalignment</guideline>
<guideline>Critical verification prevents starting next epic prematurely</guideline>
<guideline>Two-part structure ensures both reflection AND preparation</guideline>
<guideline>Output is complete retrospective in single response</guideline>
</facilitation-guidelines>]]></instructions>
<output-template></output-template>
</compiled-workflow>