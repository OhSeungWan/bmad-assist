<?xml version="1.0" encoding="UTF-8"?>
<!-- BMAD Prompt Run Metadata -->
<!-- Epic: 2 -->
<!-- Story: 2.1 -->
<!-- Phase: create-story -->
<!-- Timestamp: 20260121T181105Z -->
<compiled-workflow>
<mission><![CDATA[Create the next user story from epics+stories with enhanced context analysis and direct ready-for-dev marking

Target: Story 2.1 - css-design-tokens-and-typography
Create comprehensive developer context and implementation-ready story.]]></mission>
<context>
<file id="git-intel" path="[git-intelligence]"><![CDATA[<git-intelligence>
This project is not under git version control.
Do NOT attempt to run git commands - they will fail.
Focus on embedded context and file reading instead.

</git-intelligence>]]></file>
<file id="11c89e12" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/docs/project_context.md"><![CDATA[# Project Context: Alex Chen Photography Portfolio

## Overview

Static portfolio website for freelance photographer. Pure HTML/CSS, no JavaScript.

## File Structure

```
index.html    # Single page, semantic HTML5
styles.css    # All styles, BEM naming
```

## Coding Standards

### HTML Rules

- Use semantic elements: `<header>`, `<main>`, `<section>`, `<article>`, `<footer>`
- Proper heading hierarchy: single `<h1>`, then `<h2>`, `<h3>` as needed
- 2-space indentation
- Double quotes for attributes
- Self-closing tags for void elements: `<img />`, `<br />`
- Always include `alt` attribute on images

### CSS Rules

- **BEM naming convention:**
  - Block: `.hero`, `.projects`
  - Element: `.hero__title`, `.projects__card`
  - Modifier: `.hero__cta--primary`, `.projects__card--featured`
- 2-space indentation
- One property per line
- Opening brace on same line as selector
- Blank line between rule sets
- Properties ordered: positioning → display → box model → typography → visual → misc

### CSS Custom Properties

Define all design tokens in `:root`:

```css
:root {
  /* Colors */
  --color-primary: #1a1a2e;
  --color-accent: #e94560;
  --color-background: #ffffff;
  --color-text: #333333;
  --color-text-light: #666666;

  /* Typography */
  --font-heading: 'Georgia', serif;
  --font-body: 'Arial', sans-serif;
  --font-size-base: 16px;
  --font-size-lg: 1.25rem;
  --font-size-xl: 2rem;
  --font-size-xxl: 3rem;

  /* Spacing */
  --spacing-xs: 0.5rem;
  --spacing-sm: 1rem;
  --spacing-md: 2rem;
  --spacing-lg: 4rem;

  /* Layout */
  --max-width: 1200px;
  --border-radius: 8px;
}
```

### Responsive Design

- Mobile-first approach
- Single breakpoint: `768px`
- Use `min-width` media queries only

```css
/* Mobile styles (default) */
.projects__grid {
  display: grid;
  grid-template-columns: 1fr;
}

/* Desktop styles */
@media (min-width: 768px) {
  .projects__grid {
    grid-template-columns: repeat(3, 1fr);
  }
}
```

## Component Structure

### Hero Section

```html
<header class="hero">
  <h1 class="hero__name">Alex Chen</h1>
  <p class="hero__tagline">Capturing moments that last forever</p>
  <a href="#contact" class="hero__cta">Get in Touch</a>
</header>
```

### Projects Section

```html
<main>
  <section class="projects">
    <h2 class="projects__title">Portfolio</h2>
    <div class="projects__grid">
      <article class="projects__card">
        <div class="projects__card-image"></div>
        <h3 class="projects__card-title">Wedding</h3>
        <p class="projects__card-description">...</p>
      </article>
      <!-- Repeat for Portrait, Landscape -->
    </div>
  </section>
</main>
```

## Constraints

- No JavaScript
- No external dependencies
- No CSS preprocessors
- No build tools
- Maximum 2 files (index.html + styles.css)

## Testing Verification

Verify implementation by checking:

1. **Hero section:** `<header class="hero">` exists with `<h1>`, tagline `<p>`, and CTA `<a>`
2. **Projects section:** `<section class="projects">` with exactly 3 `<article class="projects__card">`
3. **CSS variables:** `:root` block defines `--color-*`, `--font-*`, `--spacing-*`
4. **Responsive:** `@media (min-width: 768px)` present in styles.css
5. **BEM naming:** All classes follow `block__element--modifier` pattern
]]></file>
<file id="bda659bb" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/docs/prd.md"><![CDATA[# Product Requirements Document: Alex Chen Photography Portfolio

## Overview

**Product Name:** Alex Chen Photography Portfolio
**Version:** 1.0
**Author:** John (Product Manager)
**Date:** 2025-12-11

## Problem Statement

Alex Chen is a freelance photographer who needs a simple, professional online presence to showcase work to potential clients. Current solution (social media) lacks professionalism and doesn't provide a dedicated space for portfolio presentation.

## Goals

1. Establish professional online presence
2. Showcase photography portfolio effectively
3. Provide clear call-to-action for client inquiries
4. Ensure accessibility across devices

## Target Audience

- Potential clients seeking photography services (weddings, portraits, landscapes)
- Industry peers and collaborators
- Anyone discovering Alex through referrals

## Functional Requirements

### FR-001: Hero Section with Branding

**Description:** The landing page must feature a prominent hero section that establishes brand identity.

**Acceptance Criteria:**
- Display photographer name "Alex Chen" as primary heading
- Include professional tagline communicating photography focus
- Provide clear call-to-action button for contact/inquiry
- Hero section spans full viewport width

### FR-002: Projects Gallery Section

**Description:** A dedicated section showcasing photography projects with visual cards.

**Acceptance Criteria:**
- Display exactly 3 project cards (Wedding, Portrait, Landscape)
- Each card contains: image placeholder, project title, brief description
- Cards arranged in responsive grid layout
- Semantic HTML structure using article elements

### FR-003: Consistent Visual Design System

**Description:** Implement cohesive visual design using CSS custom properties.

**Acceptance Criteria:**
- Define color palette via CSS custom properties in :root
- Establish typography scale (headings, body, captions)
- Consistent spacing using CSS variables
- BEM naming convention for all CSS classes

### FR-004: Mobile-Responsive Layout

**Description:** Ensure optimal viewing experience across device sizes.

**Acceptance Criteria:**
- Mobile-first CSS approach
- Breakpoint at 768px for tablet/desktop layouts
- Hero section adapts to viewport
- Project cards stack vertically on mobile, grid on desktop
- All interactive elements have appropriate touch targets

## Non-Functional Requirements

### NFR-001: Performance
- No JavaScript dependencies
- Single CSS file under 10KB
- Page loads in under 1 second on 3G

### NFR-002: Maintainability
- Semantic HTML5 elements
- Well-commented CSS sections
- BEM methodology for scalable styles

### NFR-003: Accessibility
- Proper heading hierarchy (h1 > h2 > h3)
- Sufficient color contrast ratios
- Focus states for interactive elements

## Out of Scope

- Contact form functionality
- Image gallery lightbox
- CMS integration
- Multi-page navigation
- JavaScript interactions

## Success Metrics

- Clean, valid HTML5 markup
- CSS passes linting with no errors
- Responsive design works on mobile and desktop viewports
- All acceptance criteria met for FR-001 through FR-004
]]></file>
<file id="07a30897" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/docs/ux-spec.md"><![CDATA[# UX Specification: Alex Chen Photography Portfolio

## Overview

**Project:** Alex Chen Photography Portfolio
**UX Designer:** Sally
**Date:** 2025-12-11
**Status:** Approved

## User Persona

### Primary Persona: Potential Client

**Name:** Sarah Mitchell
**Age:** 28-45
**Context:** Planning a wedding, looking for a photographer

**Goals:**
- Quickly assess photographer's style and quality
- See relevant work samples (wedding photography)
- Easy way to make contact

**Behaviors:**
- Browses on mobile during commute (60% mobile traffic expected)
- Makes decisions based on visual first impression
- Scans, doesn't read - needs clear visual hierarchy
- Will leave if page loads slowly or looks unprofessional

**Pain Points:**
- Cluttered portfolios with too many options
- Slow-loading image galleries
- Unclear how to get in touch
- Sites that don't work on mobile

### Secondary Persona: Industry Peer

**Name:** Marcus Rivera
**Context:** Fellow photographer, potential collaborator

**Goals:**
- Evaluate Alex's style for collaboration fit
- Quick overview of specialties

## Visual Direction

### Mood & Tone

**Keywords:** Elegant, Professional, Minimal, Gallery-like

**Concept:** The website should feel like walking into a high-end photography gallery - clean walls, focused lighting, art speaks for itself.

**Visual Metaphor:** White-cube gallery meets premium magazine layout.

### Color Psychology

| Color | Token | Hex | Rationale |
|-------|-------|-----|-----------|
| Deep Navy | `--color-primary` | #1a1a2e | Sophisticated, timeless, makes photos "pop" |
| Coral Accent | `--color-accent` | #e94560 | Warm, inviting, draws eye to CTA |
| Clean White | `--color-background` | #ffffff | Gallery-like, maximizes photo contrast |
| Charcoal | `--color-text` | #333333 | Easy reading, softer than pure black |
| Muted Gray | `--color-text-light` | #666666 | Secondary info, doesn't compete |

**Why Dark Hero + Light Content:**
- Hero section uses `--color-primary` background → dramatic first impression
- Projects section uses `--color-background` → photos are the focus
- This contrast creates natural visual sections without heavy borders

### Typography Rationale

| Element | Font | Token | Rationale |
|---------|------|-------|-----------|
| Headings | Georgia | `--font-heading` | Serif = elegance, timelessness, art-world feel |
| Body | Arial | `--font-body` | Sans-serif = clarity, modern, easy scanning |

**Type Scale:**
- Hero name: `--font-size-xxl` (3rem) - Commanding presence
- Section titles: `--font-size-xl` (2rem) - Clear hierarchy
- Card titles: `--font-size-lg` (1.25rem) - Scannable
- Body: `--font-size-base` (16px) - Comfortable reading

## Layout Design

### Information Architecture

```
┌─────────────────────────────────────┐
│             HERO                    │  ← Emotional hook (3 seconds)
│   Name + Tagline + CTA              │
└─────────────────────────────────────┘
┌─────────────────────────────────────┐
│           PORTFOLIO                 │  ← Proof of work
│   [Wedding] [Portrait] [Landscape]  │
└─────────────────────────────────────┘
```

**Why this order:**
1. Hero creates emotional connection first
2. Portfolio proves capability second
3. No navigation needed - single scroll journey

### Wireframes

**Mobile Layout (< 768px):**

```
┌──────────────────────┐
│                      │
│     ALEX CHEN        │
│                      │
│  Capturing moments   │
│  that last forever   │
│                      │
│   [ Get in Touch ]   │
│                      │
├──────────────────────┤
│      Portfolio       │
├──────────────────────┤
│  ┌────────────────┐  │
│  │   [  image  ]  │  │
│  │    Wedding     │  │
│  │  description   │  │
│  └────────────────┘  │
│  ┌────────────────┐  │
│  │   [  image  ]  │  │
│  │    Portrait    │  │
│  │  description   │  │
│  └────────────────┘  │
│  ┌────────────────┐  │
│  │   [  image  ]  │  │
│  │   Landscape    │  │
│  │  description   │  │
│  └────────────────┘  │
└──────────────────────┘
```

**Desktop Layout (≥ 768px):**

```
┌────────────────────────────────────────────────────┐
│                                                    │
│                    ALEX CHEN                       │
│          Capturing moments that last forever       │
│                                                    │
│                  [ Get in Touch ]                  │
│                                                    │
├────────────────────────────────────────────────────┤
│                     Portfolio                      │
├────────────────────────────────────────────────────┤
│  ┌──────────────┐ ┌──────────────┐ ┌──────────────┐│
│  │   [image]    │ │   [image]    │ │   [image]    ││
│  │   Wedding    │ │   Portrait   │ │  Landscape   ││
│  │ description  │ │ description  │ │ description  ││
│  └──────────────┘ └──────────────┘ └──────────────┘│
└────────────────────────────────────────────────────┘
```

## Interaction Design

### CTA Button States

| State | Visual Treatment |
|-------|------------------|
| Default | `--color-accent` background, white text |
| Hover | Slightly darker accent, subtle scale (1.02) |
| Focus | Visible outline for accessibility |
| Active | Darker accent, scale down (0.98) |

### Project Card States

| State | Visual Treatment |
|-------|------------------|
| Default | Subtle shadow, white background |
| Hover | Elevated shadow, slight lift effect |
| Focus | Visible outline around card |

**Note:** All hover effects use CSS transitions (0.2s ease) for smooth feel.

### Touch Targets

- CTA button: minimum 48x48px tap area
- Cards: entire card is tappable area on mobile
- Adequate spacing between interactive elements (min 8px)

## Accessibility Considerations

### Color Contrast

All text meets WCAG AA standards:
- `--color-text` (#333) on `--color-background` (#fff) = 12.6:1 ✓
- White text on `--color-primary` (#1a1a2e) = 15.1:1 ✓
- White text on `--color-accent` (#e94560) = 4.5:1 ✓

### Focus Indicators

- All interactive elements have visible focus states
- Focus outline uses `--color-accent` for consistency
- Never remove focus outline without replacement

### Motion

- Respect `prefers-reduced-motion` media query
- Hover animations are subtle (no jarring movements)

## Design Token Mapping

How UX decisions map to CSS custom properties:

| UX Goal | Design Token | Value |
|---------|--------------|-------|
| Sophisticated first impression | `--color-primary` | #1a1a2e |
| Draw attention to contact | `--color-accent` | #e94560 |
| Clean gallery feel | `--color-background` | #ffffff |
| Readable content | `--color-text` | #333333 |
| Elegant headings | `--font-heading` | Georgia, serif |
| Clear body text | `--font-body` | Arial, sans-serif |
| Consistent rhythm | `--spacing-*` | 0.5/1/2/4rem scale |
| Professional cards | `--border-radius` | 8px |

## Success Metrics

UX goals verification:

1. **First Impression (3 sec test):** User can identify "photographer portfolio" within 3 seconds
2. **Scannability:** All three project types visible without scrolling on desktop
3. **Mobile Usability:** Full journey completable with thumb-only navigation
4. **CTA Visibility:** Contact button visible in hero without scrolling
5. **Load Performance:** Perceived instant load (no layout shift)
]]></file>
<file id="2e55b2e3" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/docs/architecture.md"><![CDATA[# Architecture Document: Alex Chen Photography Portfolio

## Overview

**Project:** Alex Chen Photography Portfolio
**Architect:** Winston
**Date:** 2025-12-11
**Status:** Approved

## Architecture Philosophy

This is a deliberately simple, static website. We embrace "boring technology" - proven HTML and CSS patterns that require no build tools, no frameworks, and no JavaScript. The architecture prioritizes maintainability and performance over sophistication.

## Technology Decisions

### ADR-001: Pure HTML/CSS Stack

**Decision:** Use vanilla HTML5 and CSS3 only. No JavaScript.

**Context:** Portfolio is purely presentational. No dynamic functionality required.

**Rationale:**
- Zero runtime dependencies
- No build pipeline needed
- Maximum browser compatibility
- Fastest possible load times
- Easy to maintain and modify

**Consequences:**
- No interactive features (acceptable per PRD scope)
- Contact requires mailto: link or external form service

### ADR-002: Single Page Architecture

**Decision:** Entire portfolio on one `index.html` page.

**Context:** Only 2 content sections needed (hero + projects).

**Rationale:**
- Simpler navigation (scroll-based)
- Single HTTP request for HTML
- No routing complexity
- Easier testing and verification

**Consequences:**
- Must use anchor links if navigation added later
- Page weight grows with content (acceptable for 2 sections)

### ADR-003: CSS Custom Properties for Theming

**Decision:** Define all design tokens as CSS custom properties in `:root`.

**Context:** Need consistent colors, typography, and spacing.

**Rationale:**
- Single source of truth for design values
- Easy theme modifications
- Native browser support (no preprocessor)
- Runtime flexibility for future enhancements

**Implementation:**
```css
:root {
  --color-primary: #1a1a2e;
  --color-accent: #e94560;
  --color-background: #ffffff;
  --color-text: #333333;
  --font-heading: 'Georgia', serif;
  --font-body: 'Arial', sans-serif;
  --spacing-unit: 1rem;
}
```

### ADR-004: BEM Naming Convention

**Decision:** Use Block__Element--Modifier pattern for all CSS classes.

**Context:** Need scalable, predictable CSS architecture.

**Rationale:**
- Self-documenting class names
- Avoids specificity conflicts
- Clear component boundaries
- Industry standard, widely understood

**Examples:**
- `.hero` (block)
- `.hero__title` (element)
- `.hero__cta--primary` (modifier)
- `.projects__card` (element)

### ADR-005: Mobile-First Responsive Design

**Decision:** Base styles target mobile, media queries enhance for larger screens.

**Context:** Significant mobile traffic expected for portfolio viewing.

**Rationale:**
- Progressive enhancement philosophy
- Smaller devices get minimal CSS
- Easier to scale up than scale down
- Better performance on constrained devices

**Breakpoints:**
- Base: 0-767px (mobile)
- Desktop: 768px+ (tablet and above)

### ADR-006: Semantic HTML5 Structure

**Decision:** Use semantic elements over generic divs.

**Context:** Need accessible, well-structured markup.

**Rationale:**
- Built-in accessibility benefits
- Better SEO signals
- Self-documenting structure
- Screen reader friendly

**Element Mapping:**
| Content | Element |
|---------|---------|
| Page header with hero | `<header>` |
| Main content area | `<main>` |
| Hero section | `<section class="hero">` |
| Projects section | `<section class="projects">` |
| Individual project | `<article class="projects__card">` |
| Page footer | `<footer>` |

## File Structure

```
portfolio-project/
├── index.html          # Single HTML page
├── styles.css          # All styles
├── docs/
│   ├── prd.md
│   ├── architecture.md
│   ├── project_context.md
│   └── epics.md
└── bmad-assist.yaml
```

## Performance Budget

| Metric | Target |
|--------|--------|
| HTML size | < 5KB |
| CSS size | < 10KB |
| Total page weight | < 20KB (excluding images) |
| First Contentful Paint | < 1s on 3G |

## Security Considerations

- No user input handling (no forms)
- No external scripts
- No cookies or local storage
- Static hosting compatible (no server-side logic)

## Future Considerations

If requirements expand:
- Contact form: Consider external service (Formspree, Netlify Forms)
- Image optimization: Add srcset for responsive images
- Analytics: Add privacy-respecting solution (Plausible, Fathom)
- Multi-page: Consider static site generator

These are explicitly out of scope for v1.0.
]]></file>
<file id="d95c5b57" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/docs/epics.md"><![CDATA[# Epics and Stories: Alex Chen Photography Portfolio

## Epic Overview

| Epic | Title | Stories | Story Points |
|------|-------|---------|--------------|
| E1 | Core Page Structure | 2 | 5 |
| E2 | Visual Design System | 2 | 5 |
| **Total** | | **4** | **10** |

---

# Epic 1: Core Page Structure

**Goal:** Build the foundational HTML structure for the portfolio with semantic markup and content sections.

**Dependencies:** None
**PRD Coverage:** FR-001, FR-002

---

## Story 1.1: Hero Section Implementation

**Title:** Implement hero section with branding and call-to-action

**Description:** As a visitor, I want to see a prominent hero section when I land on the page so that I immediately understand who Alex Chen is and how to contact them.

**Story Points:** 3
**Priority:** High
**Status:** backlog

**Acceptance Criteria:**

- [ ] **AC-1.1.1:** Page contains `<header>` element with class `hero`
- [ ] **AC-1.1.2:** Hero contains `<h1>` with text "Alex Chen"
- [ ] **AC-1.1.3:** Hero contains `<p>` element with class `hero__tagline` containing photography-related tagline
- [ ] **AC-1.1.4:** Hero contains `<a>` element with class `hero__cta` linking to contact action
- [ ] **AC-1.1.5:** HTML is valid and uses semantic elements
- [ ] **AC-1.1.6:** Basic CSS exists to make hero section visible (minimal styling acceptable)

**Technical Notes:**
- Follow BEM naming: `hero`, `hero__name`, `hero__tagline`, `hero__cta`
- Use `mailto:` link or `#contact` anchor for CTA href
- Refer to `project_context.md` for HTML structure template

---

## Story 1.2: Projects Gallery Section

**Title:** Implement projects gallery with three portfolio cards

**Description:** As a visitor, I want to see Alex's photography projects organized in cards so that I can understand the types of photography services offered.

**Story Points:** 2
**Priority:** High
**Status:** backlog

**Acceptance Criteria:**

- [ ] **AC-1.2.1:** Page contains `<main>` element wrapping content below hero
- [ ] **AC-1.2.2:** Main contains `<section>` with class `projects`
- [ ] **AC-1.2.3:** Projects section contains `<h2>` with title "Portfolio"
- [ ] **AC-1.2.4:** Projects section contains exactly 3 `<article>` elements with class `projects__card`
- [ ] **AC-1.2.5:** Each card contains: image placeholder div, `<h3>` title, `<p>` description
- [ ] **AC-1.2.6:** Card titles are: "Wedding", "Portrait", "Landscape"
- [ ] **AC-1.2.7:** Cards are wrapped in container with class `projects__grid`
- [ ] **AC-1.2.8:** HTML validates without errors

**Technical Notes:**
- Image placeholders use `<div class="projects__card-image">` with background color
- Follow BEM: `projects`, `projects__title`, `projects__grid`, `projects__card`, `projects__card-title`, `projects__card-description`
- Descriptions should be 1-2 sentences describing photography style

---

# Epic 2: Visual Design System

**Goal:** Implement consistent visual styling using CSS custom properties and ensure responsive behavior across devices.

**Dependencies:** Epic 1 (HTML structure must exist)
**PRD Coverage:** FR-003, FR-004

---

## Story 2.1: CSS Design Tokens and Typography

**Title:** Implement CSS custom properties and typography system

**Description:** As a developer, I want a centralized design token system so that visual consistency is maintained and future changes are easy.

**Story Points:** 3
**Priority:** High
**Status:** backlog

**Acceptance Criteria:**

- [ ] **AC-2.1.1:** `styles.css` contains `:root` selector with CSS custom properties
- [ ] **AC-2.1.2:** Color tokens defined: `--color-primary`, `--color-accent`, `--color-background`, `--color-text`
- [ ] **AC-2.1.3:** Typography tokens defined: `--font-heading`, `--font-body`, `--font-size-base`
- [ ] **AC-2.1.4:** Spacing tokens defined: `--spacing-sm`, `--spacing-md`, `--spacing-lg`
- [ ] **AC-2.1.5:** `<h1>` uses `--font-heading` font family
- [ ] **AC-2.1.6:** Body text uses `--font-body` font family
- [ ] **AC-2.1.7:** Hero section has visible styling (background color, padding, centered text)
- [ ] **AC-2.1.8:** Project cards have visible styling (border or shadow, padding, background)
- [ ] **AC-2.1.9:** All CSS classes follow BEM naming convention

**Technical Notes:**
- Refer to `project_context.md` for exact token names and values
- Use `var(--token-name)` syntax throughout stylesheet
- Apply CSS reset or normalize for consistent baseline

---

## Story 2.2: Mobile-First Responsive Layout

**Title:** Implement responsive layout with mobile-first approach

**Description:** As a mobile user, I want the portfolio to display correctly on my device so that I can browse Alex's work comfortably.

**Story Points:** 2
**Priority:** High
**Status:** backlog

**Acceptance Criteria:**

- [ ] **AC-2.2.1:** Base styles (no media query) display single-column layout
- [ ] **AC-2.2.2:** `styles.css` contains `@media (min-width: 768px)` query
- [ ] **AC-2.2.3:** On mobile (<768px): project cards stack vertically in single column
- [ ] **AC-2.2.4:** On desktop (≥768px): project cards display in 3-column grid
- [ ] **AC-2.2.5:** Hero section text is readable on mobile (appropriate font sizes)
- [ ] **AC-2.2.6:** CTA button has minimum touch target of 44x44 pixels on mobile
- [ ] **AC-2.2.7:** No horizontal scrolling occurs on mobile viewport (320px minimum)
- [ ] **AC-2.2.8:** Grid uses CSS Grid or Flexbox for layout

**Technical Notes:**
- Use `grid-template-columns: 1fr` for mobile, `repeat(3, 1fr)` for desktop
- Test at 320px, 768px, and 1200px viewport widths
- Ensure `box-sizing: border-box` is applied globally

---

## Story Dependency Graph

```
Story 1.1 (Hero) ─────┐
                      ├──► Story 2.1 (Design Tokens) ──► Story 2.2 (Responsive)
Story 1.2 (Projects) ─┘
```

Epic 1 stories can be done in parallel.
Epic 2 stories depend on Epic 1 completion.
Story 2.2 can start after 2.1 establishes the design system.

---

## Definition of Done

A story is complete when:

1. All acceptance criteria are checked off
2. HTML validates (no errors in W3C validator)
3. CSS follows BEM naming throughout
4. Code is committed with descriptive message
5. Manual visual verification passes
]]></file>
</context>
<variables>
<var name="architecture_file" description="Architecture (fallback - epics file should have relevant sections)" />
<var name="author">BMad</var>
<var name="communication_language">English</var>
<var name="date">2026-01-21</var>
<var name="default_output_file">/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/implementation-artifacts/2-1-css-design-tokens-and-typography.md</var>
<var name="description">Create the next user story from epics+stories with enhanced context analysis and direct ready-for-dev marking</var>
<var name="document_output_language">English</var>
<var name="epic_num">2</var>
<var name="epics_file" description="Enhanced epics+stories file with BDD and source hints" />
<var name="implementation_artifacts">/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/implementation-artifacts</var>
<var name="name">create-story</var>
<var name="output_folder">/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/implementation-artifacts</var>
<var name="planning_artifacts">/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/planning-artifacts</var>
<var name="prd_file" description="PRD (fallback - epics file should have most content)" />
<var name="project_context">none</var>
<var name="project_knowledge">/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/docs</var>
<var name="project_name">simple-portfolio</var>
<var name="sprint_status">/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/implementation-artifacts/sprint-status.yaml</var>
<var name="story_dir">/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/implementation-artifacts</var>
<var name="story_id">2.1</var>
<var name="story_key">2-1-css-design-tokens-and-typography</var>
<var name="story_num">1</var>
<var name="story_title">css-design-tokens-and-typography</var>
<var name="timestamp">20260121_1911</var>
<var name="user_name">User</var>
<var name="user_skill_level">expert</var>
<var name="ux_file" description="UX design (fallback - epics file should have relevant sections)" />
</variables>
<file-index>
<entry id="2e55b2e3" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/docs/architecture.md" />
<entry id="d95c5b57" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/docs/epics.md" />
<entry id="bda659bb" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/docs/prd.md" />
<entry id="11c89e12" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/docs/project_context.md" />
<entry id="07a30897" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/docs/ux-spec.md" />
</file-index>
<instructions><workflow>
  <critical>🚫 SCOPE LIMITATION: Your ONLY task is to create the story markdown file. Do NOT read, modify, or update any sprint tracking files - that is handled programmatically by bmad-assist.</critical>
<critical>You MUST have already loaded and processed: the &lt;workflow-yaml&gt; section embedded above</critical>
  <critical>Communicate all responses in English and generate all documents in English</critical>

  <critical>🔥 CRITICAL MISSION: You are creating the ULTIMATE story context engine that prevents LLM developer mistakes, omissions or
    disasters! 🔥</critical>
  <critical>Your purpose is NOT to copy from epics - it's to create a comprehensive, optimized story file that gives the DEV agent
    EVERYTHING needed for flawless implementation</critical>
  <critical>COMMON LLM MISTAKES TO PREVENT: reinventing wheels, wrong libraries, wrong file locations, breaking regressions, ignoring UX,
    vague implementations, lying about completion, not learning from past work</critical>
  <critical>🚨 EXHAUSTIVE ANALYSIS REQUIRED: You must thoroughly analyze ALL artifacts to extract critical context - do NOT be lazy or skim!
    This is the most important function in the entire development process!</critical>
  <critical>🔬 UTILIZE SUBPROCESSES AND SUBAGENTS: Use research subagents, subprocesses or parallel processing if available to thoroughly
    analyze different artifacts simultaneously and thoroughly</critical>
  <critical>❓ SAVE QUESTIONS: If you think of questions or clarifications during analysis, save them for the end after the complete story is
    written</critical>
  <critical>🎯 ZERO USER INTERVENTION: Process should be fully automated except for initial epic/story selection or missing documents</critical>
  <critical>Git Intelligence is EMBEDDED in &lt;git-intelligence&gt; at the start of the prompt - do NOT run git commands yourself, use the embedded data instead</critical>

  <step n="1" goal="Architecture analysis for developer guardrails">
    <critical>🏗️ ARCHITECTURE INTELLIGENCE - Extract everything the developer MUST follow!</critical> **ARCHITECTURE DOCUMENT ANALYSIS:** <action>Systematically
    analyze architecture content for story-relevant requirements:</action>

    <!-- Load architecture - single file or sharded -->
    <check if="architecture file is single file">
      <action>Load complete {architecture_content}</action>
    </check>
    <check if="architecture is sharded to folder">
      <action>Load architecture index and scan all architecture files</action>
    </check> **CRITICAL ARCHITECTURE EXTRACTION:** <action>For
    each architecture section, determine if relevant to this story:</action> - **Technical Stack:** Languages, frameworks, libraries with
    versions - **Code Structure:** Folder organization, naming conventions, file patterns - **API Patterns:** Service structure, endpoint
    patterns, data contracts - **Database Schemas:** Tables, relationships, constraints relevant to story - **Security Requirements:**
    Authentication patterns, authorization rules - **Performance Requirements:** Caching strategies, optimization patterns - **Testing
    Standards:** Testing frameworks, coverage expectations, test patterns - **Deployment Patterns:** Environment configurations, build
    processes - **Integration Patterns:** External service integrations, data flows <action>Extract any story-specific requirements that the
    developer MUST follow</action>
    <action>Identify any architectural decisions that override previous patterns</action>
  </step>

  <step n="2" goal="Web research for latest technical specifics">
    <critical>🌐 ENSURE LATEST TECH KNOWLEDGE - Prevent outdated implementations!</critical> **WEB INTELLIGENCE:** <action>Identify specific
    technical areas that require latest version knowledge:</action>

    <!-- Check for libraries/frameworks mentioned in architecture -->
    <action>From architecture analysis, identify specific libraries, APIs, or
    frameworks</action>
    <action>For each critical technology, research latest stable version and key changes:
      - Latest API documentation and breaking changes
      - Security vulnerabilities or updates
      - Performance improvements or deprecations
      - Best practices for current version
    </action>
    **EXTERNAL CONTEXT INCLUSION:** <action>Include in story any critical latest information the developer needs:
      - Specific library versions and why chosen
      - API endpoints with parameters and authentication
      - Recent security patches or considerations
      - Performance optimization techniques
      - Migration considerations if upgrading
    </action>
  </step>

  <step n="3" goal="Create comprehensive story file">
    <critical>📝 CREATE ULTIMATE STORY FILE - The developer's master implementation guide!</critical>

    <action>Create file using the output-template format at: /home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/implementation-artifacts/2-1-css-design-tokens-and-typography.md</action>
    <!-- Story foundation from epics analysis -->
    <!-- Developer context section - MOST IMPORTANT PART -->
    <!-- Previous story intelligence -->
    <!-- Git intelligence -->
    <!-- Latest technical specifics -->
    <!-- Project context reference -->
    <!-- Final status update -->
    <!-- CRITICAL: Set status to ready-for-dev -->
    <action>Set story Status to: "ready-for-dev"</action>
    <action>Add completion note: "Ultimate
    context engine analysis completed - comprehensive developer guide created"</action>
  </step>

  <step n="4" goal="Finalize and validate">
    <!-- checklist validation is separate workflow -->
    <action>Save story document unconditionally</action>

    <action>Report completion</action>
    </step>

</workflow></instructions>
<output-template><![CDATA[# Story {{epic_num}}.{{story_num}}: {{story_title}}

Status: ready-for-dev

<!-- Note: Validation is optional. Run validate-create-story for quality check before dev-story. -->

## Story

As a {{role}},
I want {{action}},
so that {{benefit}}.

## Acceptance Criteria

1. [Add acceptance criteria from epics/PRD]

## Tasks / Subtasks

- [ ] Task 1 (AC: #)
  - [ ] Subtask 1.1
- [ ] Task 2 (AC: #)
  - [ ] Subtask 2.1

## Dev Notes

- Relevant architecture patterns and constraints
- Source tree components to touch
- Testing standards summary

### Project Structure Notes

- Alignment with unified project structure (paths, modules, naming)
- Detected conflicts or variances (with rationale)

### References

- Cite all technical details with source paths and sections, e.g. [Source: docs/<file>.md#Section]

## Dev Agent Record

### Agent Model Used

{{agent_model_name_version}}

### Debug Log References

### Completion Notes List

### File List]]></output-template>
</compiled-workflow>