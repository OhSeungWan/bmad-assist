<!-- BMAD Prompt Run Metadata -->
<!-- Epic: 1 -->
<!-- Story: 1.1 -->
<!-- Phase: create-story -->
<!-- Timestamp: 20260121T172406Z -->

/bmad:bmm:workflows:create-story 1.1

<instructions>
  Story output: docs/sprint-artifacts/1-1-{story_title}.md
</instructions>