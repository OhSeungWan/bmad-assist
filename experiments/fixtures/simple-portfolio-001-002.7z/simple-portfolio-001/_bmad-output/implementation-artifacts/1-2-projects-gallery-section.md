# Story 1.2: projects-gallery-section

Status: ready-for-review

<!-- Note: Validation is optional. Run validate-create-story for quality check before dev-story. -->

## Story

As a visitor to Alex Chen's photography portfolio,
I want to see Alex's photography projects organized in cards,
so that I can understand the types of photography services offered.

## Acceptance Criteria

1. **AC-1.2.1:** Page contains `<main>` element wrapping content below hero
2. **AC-1.2.2:** Main contains `<section>` with class `projects`
3. **AC-1.2.3:** Projects section contains `<h2>` with title "Portfolio"
4. **AC-1.2.4:** Projects section contains exactly 3 `<article>` elements with class `projects__card`
5. **AC-1.2.5:** Each card contains: image placeholder div (`projects__card-image`), `<h3>` title (`projects__card-title`), `<p>` description (`projects__card-description`) with 5-15 words describing the photography specialty
6. **AC-1.2.6:** Card titles are: "Wedding", "Portrait", "Landscape"
7. **AC-1.2.7:** Cards are wrapped in container with class `projects__grid`
8. **AC-1.2.8:** HTML validates without errors
9. **AC-1.2.9:** Image placeholders have visible height using aspect-ratio (4/3) and neutral background color (#e0e0e0)
10. **AC-1.2.10:** Cards have hover effect with elevated shadow and subtle lift (respects `prefers-reduced-motion`)
11. **AC-1.2.11:** Cards have visible focus state with outline for keyboard accessibility

## Tasks / Subtasks

- [x] Task 1: Add `<main>` element to HTML structure (AC: 1.2.1)
  - [x] Insert `<main>` element after closing `</header>` tag
  - [x] Ensure `<main>` wraps all content below hero section

- [x] Task 2: Create projects section structure (AC: 1.2.2, 1.2.3, 1.2.7)
  - [x] Add `<section class="projects">` inside `<main>`
  - [x] Add `<h2 class="projects__title">Portfolio</h2>` as first child
  - [x] Add `<div class="projects__grid">` container for cards

- [x] Task 3: Implement three project cards (AC: 1.2.4, 1.2.5, 1.2.6)
  - [x] Create Wedding card with `<article class="projects__card">`
    - [x] Add `<div class="projects__card-image"></div>` placeholder
    - [x] Add `<h3 class="projects__card-title">Wedding</h3>`
    - [x] Add `<p class="projects__card-description">` with 1-2 sentence description
  - [x] Create Portrait card with same structure
  - [x] Create Landscape card with same structure

- [x] Task 4: Add CSS styles for projects section (AC: 1.2.9, 1.2.10, 1.2.11)
  - [x] Style `.projects` section (background, padding, centered content)
  - [x] Style `.projects__title` (typography using design tokens approach)
  - [x] Style `.projects__grid` (single column for mobile, gap: 2rem)
  - [x] Style `.projects__card` (background #fff, border-radius 8px, box-shadow, padding)
  - [x] Style `.projects__card-image` (aspect-ratio: 4/3, background-color: #e0e0e0)
  - [x] Style `.projects__card-title` and `.projects__card-description`
  - [x] Add `.projects__card:hover` (elevated shadow, translateY(-2px), transition 0.2s ease)
  - [x] Add `.projects__card:focus-visible` (outline: 2px solid #e94560, outline-offset: 2px)
  - [x] Extend `@media (prefers-reduced-motion: reduce)` to disable card transitions

- [x] Task 5: Validate HTML (AC: 1.2.8)
  - [x] Manual validation (no automated validator available)
  - [x] Verified proper structure, nesting, and closing tags

## Dev Notes

### Architecture Patterns & Constraints

**Technology Stack** [Source: docs/architecture.md#ADR-001]
- Pure HTML5 and CSS3 only - NO JavaScript
- No build tools, preprocessors, or external dependencies
- Single page architecture (ADR-002)

**Semantic HTML Requirements** [Source: docs/architecture.md#ADR-006]
- Use `<main>` for main content area
- Use `<section>` for the projects section
- Use `<article>` for each individual project card (self-contained content)
- Proper heading hierarchy: `<h1>` (hero) → `<h2>` (section) → `<h3>` (cards)

**CSS Architecture** [Source: docs/architecture.md#ADR-004]
- **BEM Naming Convention (MANDATORY):**
  - Block: `.projects`
  - Elements: `.projects__title`, `.projects__grid`, `.projects__card`, `.projects__card-image`, `.projects__card-title`, `.projects__card-description`
- NO generic class names

**Performance Budget** [Source: docs/architecture.md#Performance Budget]
- HTML size: < 5KB total
- CSS size: < 10KB total
- Current CSS is ~88 lines, plenty of room

### UX Design Specifications

**Visual Direction** [Source: docs/ux-spec.md#Visual Direction]
- Projects section uses light background (`--color-background: #ffffff`)
- Photos should be the focus (gallery-like feel)
- Clean, minimal aesthetic

**Layout Wireframe - Mobile** [Source: docs/ux-spec.md#Wireframes]
```
├──────────────────────┤
│      Portfolio       │
├──────────────────────┤
│  ┌────────────────┐  │
│  │   [  image  ]  │  │
│  │    Wedding     │  │
│  │  description   │  │
│  └────────────────┘  │
│  ┌────────────────┐  │
│  │   [  image  ]  │  │
│  │    Portrait    │  │
│  │  description   │  │
│  └────────────────┘  │
│  ┌────────────────┐  │
│  │   [  image  ]  │  │
│  │   Landscape    │  │
│  │  description   │  │
│  └────────────────┘  │
└──────────────────────┘
```

**Layout Wireframe - Desktop** [Source: docs/ux-spec.md#Wireframes]
```
├────────────────────────────────────────────────────┤
│                     Portfolio                      │
├────────────────────────────────────────────────────┤
│  ┌──────────────┐ ┌──────────────┐ ┌──────────────┐│
│  │   [image]    │ │   [image]    │ │   [image]    ││
│  │   Wedding    │ │   Portrait   │ │  Landscape   ││
│  │ description  │ │ description  │ │ description  ││
│  └──────────────┘ └──────────────┘ └──────────────┘│
└────────────────────────────────────────────────────┘
```

**Card Interaction States** [Source: docs/ux-spec.md#Project Card States]
- Default: Subtle shadow (`box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1)`), white background
- Hover: Elevated shadow (`box-shadow: 0 8px 16px rgba(0, 0, 0, 0.15)`), slight lift (`transform: translateY(-2px)`)
- Focus: Visible outline (`outline: 2px solid #e94560; outline-offset: 2px`)
- Transitions: `transition: box-shadow 0.2s ease, transform 0.2s ease`

**Color Tokens** [Source: docs/project_context.md#CSS Custom Properties]
```css
--color-primary: #1a1a2e;     /* For text accents if needed */
--color-accent: #e94560;       /* Not used in cards typically */
--color-background: #ffffff;   /* Card and section background */
--color-text: #333333;         /* Card text */
--color-text-light: #666666;   /* Description text */
```

**Typography Tokens** [Source: docs/project_context.md#CSS Custom Properties]
```css
--font-heading: 'Georgia', serif;    /* For h2 section title */
--font-body: 'Arial', sans-serif;    /* For card content */
--font-size-lg: 1.25rem;             /* Card titles */
--font-size-xl: 2rem;                /* Section title */
```

**Spacing Tokens** [Source: docs/project_context.md#CSS Custom Properties]
```css
--spacing-xs: 0.5rem;
--spacing-sm: 1rem;
--spacing-md: 2rem;
--spacing-lg: 4rem;
```

### Project Structure Notes

**Current File State:**
- `index.html` - Contains hero section, needs `<main>` and projects section added
- `styles.css` - Contains CSS reset and hero styles, needs projects styles added

**HTML Structure to Add** [Source: docs/project_context.md#Component Structure]
```html
<main>
  <section class="projects">
    <h2 class="projects__title">Portfolio</h2>
    <div class="projects__grid">
      <article class="projects__card">
        <div class="projects__card-image"></div>
        <h3 class="projects__card-title">Wedding</h3>
        <p class="projects__card-description">Elegant moments captured with timeless style.</p>
      </article>
      <article class="projects__card">
        <div class="projects__card-image"></div>
        <h3 class="projects__card-title">Portrait</h3>
        <p class="projects__card-description">Revealing personality through professional portraiture.</p>
      </article>
      <article class="projects__card">
        <div class="projects__card-image"></div>
        <h3 class="projects__card-title">Landscape</h3>
        <p class="projects__card-description">Nature's beauty through an artistic lens.</p>
      </article>
    </div>
  </section>
</main>
```

**CSS Grid Pattern** [Source: docs/project_context.md#Responsive Design]
```css
/* Mobile styles (default) */
.projects__grid {
  display: grid;
  grid-template-columns: 1fr;
}

/* Desktop styles */
@media (min-width: 768px) {
  .projects__grid {
    grid-template-columns: repeat(3, 1fr);
  }
}
```

**Note:** Responsive behavior will be fully implemented in Story 2.2. For THIS story, focus on the base single-column layout. The grid CSS should be written mobile-first but desktop media query styles can be minimal/placeholder.

### Previous Story Intelligence

**Story 1.1 Implementation Patterns to Follow:**
- CSS reset and box-sizing already established - do NOT duplicate
- Use same CSS comment section headers format
- Follow same property ordering in CSS rules
- `prefers-reduced-motion` media query pattern already exists
- Transition timing: `0.2s ease` for hover effects

**Files Modified in Story 1.1:**
- `index.html` (lines 1-17) - Insert `<main>` before `</body>`
- `styles.css` (lines 1-87) - Add projects styles after hero section

### Coding Standards

**HTML Rules** [Source: docs/project_context.md#HTML Rules]
- 2-space indentation
- Double quotes for attributes
- Semantic elements only

**CSS Rules** [Source: docs/project_context.md#CSS Rules]
- 2-space indentation
- One property per line
- Opening brace on same line as selector
- Blank line between rule sets
- Property order: positioning → display → box model → typography → visual → misc

**Image Placeholder Implementation:**
- Use `<div class="projects__card-image">` with CSS background color
- Set aspect ratio using padding-bottom trick or aspect-ratio property
- Background color: use a neutral gray like `#e0e0e0` or `--color-text-light`

### Testing Verification

**Manual Verification Checklist:**
1. ✓ `<main>` element exists wrapping content below hero
2. ✓ `<section class="projects">` exists inside main
3. ✓ `<h2>` with "Portfolio" text present
4. ✓ Exactly 3 `<article class="projects__card">` elements
5. ✓ Each card has image placeholder, h3 title, p description (5-15 words)
6. ✓ Card titles are "Wedding", "Portrait", "Landscape"
7. ✓ Cards wrapped in `<div class="projects__grid">`
8. ✓ HTML validates with no errors
9. ✓ Image placeholders have aspect-ratio 4/3 and #e0e0e0 background
10. ✓ Cards have hover effect (elevated shadow + slight lift)
11. ✓ Cards have visible focus state (outline) for keyboard navigation
12. ✓ All classes follow BEM naming
13. ✓ Cards display vertically stacked on mobile
14. ✓ Hover/focus transitions disabled when prefers-reduced-motion is set

**Browser Testing:**
- Open index.html in Chrome, Firefox, Safari
- Verify projects section displays below hero
- Verify all 3 cards are visible and properly styled
- Test at mobile width (375px) - cards should stack

### Implementation Warnings

🚨 **CRITICAL MISTAKES TO AVOID:**
1. **DO NOT** modify the hero section - only ADD new content
2. **DO NOT** use generic class names like `.card`, `.grid`, `.title`
3. **DO NOT** duplicate CSS reset - it already exists
4. **DO NOT** add JavaScript
5. **DO NOT** add responsive media queries for 3-column layout yet (that's Story 2.2)
6. **DO NOT** use `<img>` tags - use div placeholders with background
7. **DO NOT** skip the `<main>` wrapper - it's required for accessibility
8. **DO NOT** break heading hierarchy - must be h1 → h2 → h3

### Dependencies & Next Steps

**Dependencies:** Story 1.1 (Hero Section) - COMPLETED ✓

**Next Stories:**
- Story 2.1 (CSS Design Tokens) - Will refactor hardcoded colors to CSS variables
- Story 2.2 (Responsive Layout) - Will add 3-column grid for desktop

**Preparation for Story 2.1:**
- Use hardcoded color values that match the token values for now
- Comment sections clearly so refactoring is easy

### References

- [Architecture: Technology Stack] docs/architecture.md#ADR-001
- [Architecture: Single Page] docs/architecture.md#ADR-002
- [Architecture: BEM Naming] docs/architecture.md#ADR-004
- [Architecture: Semantic HTML] docs/architecture.md#ADR-006
- [PRD: Projects Gallery] docs/prd.md#FR-002
- [UX: Layout Wireframes] docs/ux-spec.md#Wireframes
- [UX: Card States] docs/ux-spec.md#Project Card States
- [Project Context: CSS Properties] docs/project_context.md#CSS Custom Properties
- [Project Context: Component Structure] docs/project_context.md#Component Structure
- [Project Context: Responsive] docs/project_context.md#Responsive Design
- [Epics: Story 1.2] docs/epics.md#Story 1.2

### Success Definition

Story is complete when:
1. All 11 acceptance criteria checked off
2. HTML validates with W3C validator (no errors)
3. CSS follows BEM naming throughout
4. Projects section displays below hero
5. All 3 cards visible with proper content
6. Manual browser testing passes
7. Code committed with message: "feat: implement projects gallery with three portfolio cards"

## Dev Agent Record

### Agent Model Used

claude-opus-4-5-20251101

### Debug Log References

No issues encountered during implementation.

### Completion Notes List

- Added `<main>` element wrapping projects section after hero
- Created projects section with semantic HTML5 structure (section, article elements)
- Implemented 3 project cards (Wedding, Portrait, Landscape) with BEM class naming
- Each card has image placeholder, h3 title, and p description (8-9 words each)
- Added CSS styles following existing patterns from Story 1.1
- Implemented hover state with elevated shadow and translateY transform
- Added focus-visible state with accent-colored outline for keyboard accessibility
- Extended prefers-reduced-motion media query to disable card transitions
- All colors use hardcoded values matching design tokens (prep for Story 2.1)
- Grid layout uses single column (mobile-first, desktop layout in Story 2.2)

**Code Review Synthesis Fixes (2026-01-21):**
- Added `tabindex="0"` to all 3 `<article class="projects__card">` elements to enable keyboard focus (AC-1.2.11 fix)
- Fixed self-closing void elements (`<meta>`, `<link>`) to match project_context.md HTML convention

### File List

- `index.html` - Added main element and projects section with 3 cards (lines 16-37), keyboard accessibility fix
- `styles.css` - Added projects section styles (lines 74-160)

### Change Log

| Date | Change | Reason |
|------|--------|--------|
| 2026-01-21 | Story created | Initial story creation with comprehensive dev context |
| 2026-01-21 | Implementation complete | All 11 ACs satisfied, ready for review |
| 2026-01-21 | Code review synthesis fixes | Added tabindex="0" for keyboard accessibility, fixed self-closing tags |
