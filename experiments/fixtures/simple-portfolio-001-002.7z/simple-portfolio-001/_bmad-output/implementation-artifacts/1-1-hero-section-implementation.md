# Story 1.1: hero-section-implementation

Status: Ready for Review

<!-- Note: Validation is optional. Run validate-create-story for quality check before dev-story. -->

## Story

As a visitor to Alex Chen's photography portfolio,
I want to see a prominent hero section when I land on the page,
so that I immediately understand who Alex Chen is and how to contact them.

## Acceptance Criteria

1. **AC-1.1.1:** Page contains `<header>` element with class `hero`
2. **AC-1.1.2:** Hero contains `<h1 class="hero__name">` with text "Alex Chen"
3. **AC-1.1.3:** Hero contains `<p>` element with class `hero__tagline` with text "Capturing moments that last forever"
4. **AC-1.1.4:** Hero contains `<a href="#contact" class="hero__cta">` element with "Get in Touch" text
5. **AC-1.1.5:** HTML is valid and uses semantic elements
6. **AC-1.1.6:** Hero section has dark background (#1a1a2e), white text, centered content, and CTA with accent background (#e94560)
7. **AC-1.1.7:** CTA link has visible focus state for keyboard accessibility

## Tasks / Subtasks

- [x] Task 1: Create HTML structure for hero section (AC: 1.1.1, 1.1.2, 1.1.3, 1.1.4, 1.1.5)
  - [x] Create `index.html` with HTML5 doctype and semantic structure
  - [x] Add `<header class="hero">` element
  - [x] Add `<h1 class="hero__name">` with "Alex Chen"
  - [x] Add `<p class="hero__tagline">` with tagline text
  - [x] Add `<a class="hero__cta">` with contact link
  - [x] Validate HTML using W3C validator or similar

- [x] Task 2: Create CSS for hero section styling (AC: 1.1.6, 1.1.7)
  - [x] Create `styles.css` file
  - [x] Link stylesheet in HTML `<head>`
  - [x] Add hero section styling (dark background #1a1a2e, white text, centered content)
  - [x] Style CTA button with accent background (#e94560) and white text
  - [x] Add visible focus state to CTA link for keyboard accessibility

## Dev Notes

### Architecture Patterns & Constraints

**Technology Stack** [Source: docs/architecture.md#Technology Decisions]
- Pure HTML5 and CSS3 only - NO JavaScript (ADR-001)
- No build tools, preprocessors, or external dependencies
- Single page architecture (ADR-002)
- Maximum browser compatibility required

**Semantic HTML Requirements** [Source: docs/architecture.md#ADR-006]
- Use `<header>` for page header with hero content
- Proper heading hierarchy: single `<h1>` on page
- All elements must be semantic (no generic divs for structural elements)
- Screen reader friendly markup

**CSS Architecture** [Source: docs/architecture.md#ADR-004]
- **BEM Naming Convention (MANDATORY):** Block__Element--Modifier pattern
- Block: `.hero`
- Elements: `.hero__name`, `.hero__tagline`, `.hero__cta`
- NO generic class names like `.title` or `.button`

**File Structure** [Source: docs/architecture.md#File Structure]
```
portfolio-project/
├── index.html          # Create this file
├── styles.css          # Create this file
```

### UX Design Specifications

**Visual Direction** [Source: docs/ux-spec.md#Visual Direction]
- Mood: Elegant, Professional, Minimal, Gallery-like
- Hero section uses dark background (`--color-primary: #1a1a2e`)
- White text on dark background for dramatic first impression
- Clean, sophisticated aesthetic

**Typography** [Source: docs/ux-spec.md#Typography Rationale]
- Hero name: Georgia serif font, `3rem` size for commanding presence
- Tagline: Arial sans-serif, clear and modern
- Text must be centered in hero section

**Layout Wireframe** [Source: docs/ux-spec.md#Wireframes]
```
┌──────────────────────┐
│                      │
│     ALEX CHEN        │
│                      │
│  Capturing moments   │
│  that last forever   │
│                      │
│   [ Get in Touch ]   │
│                      │
└──────────────────────┘
```

**Interaction Design** [Source: docs/ux-spec.md#Interaction Design]
- CTA button must use `--color-accent` (#e94560) background with white text
- Minimum touch target: 48x48px for mobile accessibility
- Hero section spans full viewport width

### Coding Standards

**HTML Rules** [Source: docs/project_context.md#HTML Rules]
- 2-space indentation
- Double quotes for attributes
- Self-closing tags for void elements: `<img />`, `<br />`
- Always include `alt` attribute on images (if any added later)

**CSS Rules** [Source: docs/project_context.md#CSS Rules]
- 2-space indentation
- One property per line
- Opening brace on same line as selector
- Blank line between rule sets
- Properties ordered: positioning → display → box model → typography → visual → misc

**CSS Custom Properties Setup** [Source: docs/project_context.md#CSS Custom Properties]
While full design tokens will be implemented in Story 2.1, basic hero styling for THIS story should prepare for token usage:

```css
/* Minimal inline values for Story 1.1 - will be replaced with tokens in 2.1 */
.hero {
  background-color: #1a1a2e;  /* Will become var(--color-primary) */
  color: #ffffff;
  /* ... other basic styles ... */
}

.hero__cta {
  background-color: #e94560;  /* Will become var(--color-accent) */
  color: #ffffff;
  /* ... button styles ... */
}

.hero__cta:focus {
  outline: 2px solid #e94560;
  outline-offset: 2px;
}
```

### Project Structure Notes

**Current State:** Empty project - no files exist yet

**Files to Create:**
1. `index.html` - Root HTML file (single page architecture)
2. `styles.css` - All CSS styles

**HTML Structure Template** [Source: docs/project_context.md#Component Structure]
```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Alex Chen Photography</title>
  <link rel="stylesheet" href="styles.css">
</head>
<body>
  <header class="hero">
    <h1 class="hero__name">Alex Chen</h1>
    <p class="hero__tagline">Capturing moments that last forever</p>
    <a href="#contact" class="hero__cta">Get in Touch</a>
  </header>

  <!-- Projects section will be added in Story 1.2 -->
</body>
</html>
```

**CTA Link Behavior** [Source: docs/architecture.md#ADR-001]
- Use `#contact` anchor link for CTA href (contact form out of scope for v1.0)
- Alternative: `mailto:` link if preferred

### Performance Considerations

**Performance Budget** [Source: docs/architecture.md#Performance Budget]
- HTML size: < 5KB (hero section will be minimal)
- CSS size: < 10KB (basic styling should be ~1-2KB for this story)
- First Contentful Paint: < 1s on 3G

### Testing Verification

**Manual Verification Checklist:**
1. ✓ `<header class="hero">` exists in index.html
2. ✓ `<h1>` contains "Alex Chen"
3. ✓ Tagline `<p>` with class `hero__tagline` present
4. ✓ CTA `<a>` with class `hero__cta` present
5. ✓ HTML validates with no errors (use https://validator.w3.org/)
6. ✓ Hero section visible with dark background
7. ✓ Text is white and readable on dark background
8. ✓ CTA button has coral/accent background color
9. ✓ All classes follow BEM naming (no violations)
10. ✓ CTA has visible focus state when tabbed to (keyboard accessibility)
11. ✓ Page displays correctly in browser

**Browser Testing:**
- Open index.html in Chrome, Firefox, Safari
- Verify hero section displays correctly
- Verify text is readable and CTA is visible

### Implementation Warnings

🚨 **CRITICAL MISTAKES TO AVOID:**
1. **DO NOT** use generic class names like `.title`, `.button`, `.header` - MUST use BEM (`.hero__name`, `.hero__cta`)
2. **DO NOT** add JavaScript - this is a pure HTML/CSS project
3. **DO NOT** use CSS preprocessors (Sass, Less) - vanilla CSS only
4. **DO NOT** add multiple `<h1>` tags - only one per page
5. **DO NOT** skip semantic elements - use `<header>`, not `<div class="header">`
6. **DO NOT** add features beyond AC scope (e.g., animations, extra sections)
7. **DO NOT** create multiple HTML files - single page architecture only

### Dependencies & Next Steps

**Dependencies:** None - this is the first story

**Next Story:** Story 1.2 (Projects Gallery Section) depends on this story
- Will add `<main>` section below hero
- Will reuse CSS file created here
- Hero structure must not be modified in 1.2

**Future Enhancements:** Story 2.1 will refactor CSS to use custom properties
- Current inline color values will be replaced with CSS variables
- BEM structure must remain intact for easy refactoring

### References

- [Architecture: Technology Stack] docs/architecture.md#ADR-001
- [Architecture: Single Page Architecture] docs/architecture.md#ADR-002
- [Architecture: BEM Naming] docs/architecture.md#ADR-004
- [Architecture: Semantic HTML] docs/architecture.md#ADR-006
- [PRD: Hero Section Requirements] docs/prd.md#FR-001
- [UX: Visual Direction] docs/ux-spec.md#Visual Direction
- [UX: Typography] docs/ux-spec.md#Typography Rationale
- [UX: Hero Wireframe] docs/ux-spec.md#Wireframes
- [Project Context: HTML Rules] docs/project_context.md#HTML Rules
- [Project Context: CSS Rules] docs/project_context.md#CSS Rules
- [Project Context: Hero Structure] docs/project_context.md#Component Structure

### Success Definition

Story is complete when:
1. All 7 acceptance criteria checked off
2. HTML validates with W3C validator (no errors)
3. CSS follows BEM naming (verified by code review)
4. Hero section visually matches wireframe intent
5. Manual browser testing passes
6. Code committed with message: "feat: implement hero section with branding and CTA"

## Dev Agent Record

### Agent Model Used

Claude Opus 4.5 (claude-opus-4-5-20251101)

### Debug Log References

N/A - Implementation completed without errors.

### Completion Notes List

- Created `index.html` with semantic HTML5 structure following project conventions
- Implemented hero section with `<header class="hero">` containing name, tagline, and CTA
- Created `styles.css` with BEM-compliant class naming (`.hero`, `.hero__name`, `.hero__tagline`, `.hero__cta`)
- Applied dark background (#1a1a2e), white text, flexbox centering per UX spec
- Styled CTA with accent color (#e94560), min 48x48px touch target, visible focus state
- All 7 acceptance criteria verified and satisfied

**Code Review Synthesis Fixes (2026-01-21):**
- Added CSS reset (box-sizing, body margin) to prevent cross-browser inconsistencies
- Added `min-height: 100dvh` fallback for iOS Safari viewport issues
- Improved focus indicator visibility: changed outline from #e94560 to #ffffff (3px)
- Added `@media (prefers-reduced-motion: reduce)` for accessibility compliance
- Added meta description for SEO
- Removed internal sprint comment from HTML

### File List

- `index.html` (created, updated by synthesis) - Single-page HTML structure with hero section
- `styles.css` (created, updated by synthesis) - Hero section styles with BEM naming

### Change Log

| Date | Change | Reason |
|------|--------|--------|
| 2026-01-21 | Created index.html and styles.css | Initial hero section implementation per Story 1.1 |
| 2026-01-21 | Applied code review synthesis fixes | Added CSS reset, 100dvh fallback, improved focus visibility, prefers-reduced-motion support, meta description |