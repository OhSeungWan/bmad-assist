import { defineConfig, devices } from '@playwright/test';
import path from 'path';

/**
 * Playwright configuration for Alex Chen Photography Portfolio
 *
 * Environment variables:
 * - TEST_ENV: Environment to test against (default: local)
 * - BASE_URL: Override base URL for tests
 *
 * @see https://playwright.dev/docs/test-configuration
 */
export default defineConfig({
  testDir: path.resolve(__dirname, './tests/e2e'),
  outputDir: path.resolve(__dirname, './test-results'),

  // Run tests in parallel
  fullyParallel: true,

  // Fail CI if .only() is accidentally committed
  forbidOnly: !!process.env.CI,

  // Retry failed tests in CI
  retries: process.env.CI ? 2 : 0,

  // Worker configuration: 1 in CI for stability, auto locally
  workers: process.env.CI ? 1 : undefined,

  // Reporters: HTML for debugging, JUnit for CI, list for console
  reporter: [
    ['html', { outputFolder: 'playwright-report', open: 'never' }],
    ['junit', { outputFile: 'test-results/results.xml' }],
    ['list'],
  ],

  use: {
    // Base URL for page.goto() calls
    baseURL: process.env.BASE_URL || 'http://localhost:8080',

    // Standardized timeouts
    actionTimeout: 15000,
    navigationTimeout: 30000,

    // Capture artifacts on failure
    trace: 'on-first-retry',
    screenshot: 'only-on-failure',
    video: 'retain-on-failure',
  },

  // Global test timeout: 60 seconds
  timeout: 60000,

  // Expect assertion timeout: 10 seconds
  expect: {
    timeout: 10000,
  },

  // Projects for cross-browser testing
  projects: [
    {
      name: 'chromium',
      use: { ...devices['Desktop Chrome'] },
    },
    {
      name: 'firefox',
      use: { ...devices['Desktop Firefox'] },
    },
    {
      name: 'webkit',
      use: { ...devices['Desktop Safari'] },
    },
    {
      name: 'mobile-chrome',
      use: { ...devices['Pixel 5'] },
    },
    {
      name: 'mobile-safari',
      use: { ...devices['iPhone 13'] },
    },
  ],

  // Start a local server before tests (serves static files)
  webServer: {
    command: 'npx serve . -l 8080',
    url: 'http://localhost:8080',
    reuseExistingServer: !process.env.CI,
    timeout: 30000,
  },
});
