/**
 * Test Fixtures for Alex Chen Photography Portfolio
 *
 * Provides custom fixtures for consistent test utilities.
 *
 * @see https://playwright.dev/docs/test-fixtures
 */
import { test as base, expect } from '@playwright/test';

// Define custom fixture types
type CustomFixtures = {
  log: {
    step: (message: string) => Promise<void>;
  };
  networkErrorMonitor: {
    getErrors: () => { url: string; status: number }[];
  };
};

// Extend base test with custom fixtures
export const test = base.extend<CustomFixtures>({
  log: async ({}, use) => {
    await use({
      step: async (message: string) => {
        // Simple step logging for test clarity
        console.log(`  → ${message}`);
      },
    });
  },

  networkErrorMonitor: async ({ page }, use) => {
    const errors: { url: string; status: number }[] = [];

    // Monitor network responses for HTTP errors
    page.on('response', (response) => {
      const status = response.status();
      if (status >= 400) {
        errors.push({ url: response.url(), status });
      }
    });

    await use({
      getErrors: () => errors,
    });
  },
});

export { expect };
