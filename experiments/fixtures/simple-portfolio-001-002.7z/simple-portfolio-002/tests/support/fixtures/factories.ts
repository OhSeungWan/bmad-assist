/**
 * Data Factories for Alex Chen Photography Portfolio
 *
 * Even for a static site, factories provide consistent test data patterns.
 * These are primarily used for generating test assertions and viewport configurations.
 */
import { faker } from '@faker-js/faker';

/**
 * Portfolio project card data (mirrors the static content structure)
 */
export type ProjectCard = {
  id: string;
  title: string;
  description: string;
  category: 'wedding' | 'portrait' | 'landscape';
};

/**
 * Create a project card with defaults and overrides
 */
export const createProjectCard = (overrides: Partial<ProjectCard> = {}): ProjectCard => ({
  id: faker.string.uuid(),
  title: faker.lorem.words(2),
  description: faker.lorem.sentence(),
  category: faker.helpers.arrayElement(['wedding', 'portrait', 'landscape']),
  ...overrides,
});

/**
 * Viewport configuration for responsive testing
 */
export type ViewportConfig = {
  name: string;
  width: number;
  height: number;
  isMobile: boolean;
};

/**
 * Predefined viewport configurations matching project_context.md breakpoints
 */
export const viewports: Record<string, ViewportConfig> = {
  mobile: {
    name: 'Mobile',
    width: 375,
    height: 667,
    isMobile: true,
  },
  tablet: {
    name: 'Tablet',
    width: 768,
    height: 1024,
    isMobile: false,
  },
  desktop: {
    name: 'Desktop',
    width: 1280,
    height: 800,
    isMobile: false,
  },
} as const;

/**
 * Create a custom viewport configuration
 */
export const createViewport = (overrides: Partial<ViewportConfig> = {}): ViewportConfig => ({
  name: 'Custom',
  width: faker.number.int({ min: 320, max: 1920 }),
  height: faker.number.int({ min: 480, max: 1080 }),
  isMobile: false,
  ...overrides,
});
