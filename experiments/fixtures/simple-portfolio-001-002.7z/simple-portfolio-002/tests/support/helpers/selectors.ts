/**
 * Selector Helpers for Alex Chen Photography Portfolio
 *
 * Uses data-testid strategy for resilient selectors.
 * Falls back to semantic selectors for accessibility testing.
 */

/**
 * Get a selector by data-testid attribute
 */
export const byTestId = (id: string): string => `[data-testid="${id}"]`;

/**
 * Hero section selectors
 */
export const heroSelectors = {
  section: '.hero',
  name: '.hero__name',
  tagline: '.hero__tagline',
  cta: '.hero__cta',
} as const;

/**
 * Projects section selectors
 */
export const projectsSelectors = {
  section: '.projects',
  title: '.projects__title',
  grid: '.projects__grid',
  card: '.projects__card',
  cardImage: '.projects__card-image',
  cardTitle: '.projects__card-title',
  cardDescription: '.projects__card-description',
} as const;
