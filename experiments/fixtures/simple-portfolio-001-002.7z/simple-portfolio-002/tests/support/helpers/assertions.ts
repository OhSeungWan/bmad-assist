/**
 * Custom Assertion Helpers for Alex Chen Photography Portfolio
 *
 * Provides reusable assertion patterns for common UI verifications.
 */
import { Page, expect } from '@playwright/test';
import { heroSelectors, projectsSelectors } from './selectors';

/**
 * Assert hero section is properly rendered
 */
export async function assertHeroSection(page: Page): Promise<void> {
  const heroSection = page.locator(heroSelectors.section);
  await expect(heroSection).toBeVisible();

  await expect(page.locator(heroSelectors.name)).toBeVisible();
  await expect(page.locator(heroSelectors.tagline)).toBeVisible();
  await expect(page.locator(heroSelectors.cta)).toBeVisible();
}

/**
 * Assert projects section is properly rendered with expected card count
 */
export async function assertProjectsSection(page: Page, expectedCardCount = 3): Promise<void> {
  const projectsSection = page.locator(projectsSelectors.section);
  await expect(projectsSection).toBeVisible();

  await expect(page.locator(projectsSelectors.title)).toBeVisible();

  const cards = page.locator(projectsSelectors.card);
  await expect(cards).toHaveCount(expectedCardCount);
}

/**
 * Assert page has proper semantic structure
 */
export async function assertSemanticStructure(page: Page): Promise<void> {
  // Check for single h1
  const h1Elements = page.locator('h1');
  await expect(h1Elements).toHaveCount(1);

  // Check for main content area (may be empty during epic 1)
  const mainElement = page.locator('main');
  await expect(mainElement).toHaveCount(1);

  // Check for header element
  const headerElement = page.locator('header');
  await expect(headerElement).toBeVisible();
}

/**
 * Assert CSS custom properties are defined
 */
export async function assertCSSCustomProperties(page: Page): Promise<void> {
  // Check that CSS variables are properly loaded by testing computed styles
  const body = page.locator('body');

  const primaryColor = await body.evaluate((el) => getComputedStyle(el).getPropertyValue('--color-primary'));

  // Variable should be defined (non-empty)
  expect(primaryColor.trim()).not.toBe('');
}
