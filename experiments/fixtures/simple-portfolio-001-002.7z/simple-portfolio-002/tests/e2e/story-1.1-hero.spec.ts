/**
 * ATDD Tests for Story 1.1: Hero Section Implementation
 *
 * Tests validate that hero section implementation meets all acceptance criteria.
 * All tests are enabled and should pass after Story 1.1 implementation.
 *
 * Acceptance Criteria:
 * - AC-1.1.1: <header> with class "hero" spans full viewport width
 * - AC-1.1.2: Hero contains <h1> with text "Alex Chen"
 * - AC-1.1.3: Hero contains <p class="hero__tagline"> with tagline text
 * - AC-1.1.4: Hero contains <a class="hero__cta"> linking to #contact
 * - AC-1.1.5: Valid semantic HTML with HTML5 boilerplate
 * - AC-1.1.6: CSS makes hero visible (non-zero height, file size < 500 bytes)
 *
 * @see _bmad-output/implementation-artifacts/1-1-hero-section-implementation.md
 */
import { test, expect } from '../support/fixtures';
import { heroSelectors } from '../support/helpers/selectors';

test.describe('Story 1.1: Hero Section Implementation', () => {
  /**
   * AC-1.1.1: Page contains <header> element with class "hero"
   * that spans full viewport width (no container constraints)
   */
  test('AC-1.1.1: should have header element with hero class spanning full width', async ({
    page,
    log,
  }) => {
    // Given: User navigates to the homepage
    await page.goto('/');
    await log.step('Verifying hero header exists with full viewport width');

    // When: The page loads
    const heroHeader = page.locator('header.hero');

    // Then: Header with class "hero" should exist
    await expect(heroHeader).toBeVisible();

    // And: Hero should span full viewport width (no max-width constraint)
    const viewportWidth = page.viewportSize()?.width ?? 1280;
    const heroBox = await heroHeader.boundingBox();
    expect(heroBox).not.toBeNull();
    expect(heroBox!.width).toBeGreaterThanOrEqual(viewportWidth - 20); // Allow small margin for scrollbar
  });

  /**
   * AC-1.1.2: Hero contains <h1> with text "Alex Chen"
   */
  test('AC-1.1.2: should display h1 with photographer name "Alex Chen"', async ({
    page,
    log,
  }) => {
    // Given: User navigates to the homepage
    await page.goto('/');
    await log.step('Verifying h1 contains "Alex Chen"');

    // When: The page loads
    const heroName = page.locator(heroSelectors.name);

    // Then: h1 should be visible with exact text
    await expect(heroName).toBeVisible();
    await expect(heroName).toHaveText('Alex Chen');
  });

  /**
   * AC-1.1.3: Hero contains <p> with class "hero__tagline"
   * containing text "Capturing moments that last forever"
   */
  test('AC-1.1.3: should display tagline "Capturing moments that last forever"', async ({
    page,
    log,
  }) => {
    // Given: User navigates to the homepage
    await page.goto('/');
    await log.step('Verifying tagline paragraph');

    // When: The page loads
    const tagline = page.locator(heroSelectors.tagline);

    // Then: Tagline should be visible with exact text
    await expect(tagline).toBeVisible();
    await expect(tagline).toHaveText('Capturing moments that last forever');
  });

  /**
   * AC-1.1.4: Hero contains <a> with class "hero__cta" linking to contact
   * Updated to use mailto: link per code review synthesis (original #contact was broken)
   */
  test('AC-1.1.4: should have CTA button linking to contact', async ({ page, log }) => {
    // Given: User navigates to the homepage
    await page.goto('/');
    await log.step('Verifying CTA link for contact');

    // When: The page loads
    const ctaButton = page.locator(heroSelectors.cta);

    // Then: CTA should be visible
    await expect(ctaButton).toBeVisible();

    // And: CTA should have mailto: href attribute (per ADR-001 for static sites)
    await expect(ctaButton).toHaveAttribute('href', 'mailto:alex@example.com');

    // And: CTA should have text content "Get in Touch"
    await expect(ctaButton).toHaveText('Get in Touch');
  });

  /**
   * AC-1.1.5: HTML is valid, uses semantic elements, includes HTML5 boilerplate
   * (DOCTYPE, html with lang attribute, charset and viewport meta tags)
   */
  test('AC-1.1.5: should have valid HTML5 boilerplate with semantic structure', async ({
    page,
    log,
  }) => {
    // Given: User navigates to the homepage
    await page.goto('/');
    await log.step('Verifying HTML5 boilerplate and semantic structure');

    // When: The page loads
    // Then: HTML element should have lang="en" attribute
    const htmlElement = page.locator('html');
    await expect(htmlElement).toHaveAttribute('lang', 'en');

    // And: Page should have charset meta tag
    const charsetMeta = page.locator('meta[charset="UTF-8"]');
    await expect(charsetMeta).toHaveCount(1);

    // And: Page should have viewport meta tag
    const viewportMeta = page.locator('meta[name="viewport"]');
    await expect(viewportMeta).toHaveCount(1);
    await expect(viewportMeta).toHaveAttribute(
      'content',
      'width=device-width, initial-scale=1'
    );

    // And: Page should have a title
    await expect(page).toHaveTitle('Alex Chen Photography');

    // And: Page should use semantic header element (not div)
    const headerElement = page.locator('header');
    await expect(headerElement).toBeVisible();

    // And: Should have exactly one h1 on the page
    const h1Elements = page.locator('h1');
    await expect(h1Elements).toHaveCount(1);
  });

  /**
   * AC-1.1.6: Basic CSS exists to make hero section visible
   * - Hero section has non-zero computed height
   * - Text has minimum contrast ratio of 3:1 against background
   * - CSS file size under 500 bytes (excluding comments/whitespace)
   */
  test('AC-1.1.6: should have CSS styling applied to hero section', async ({
    page,
    log,
  }) => {
    // Given: User navigates to the homepage
    await page.goto('/');
    await log.step('Verifying CSS styling is applied');

    // When: The page loads
    const hero = page.locator(heroSelectors.section);

    // Then: Hero should have non-zero dimensions
    const box = await hero.boundingBox();
    expect(box).not.toBeNull();
    expect(box!.height).toBeGreaterThan(0);
    expect(box!.width).toBeGreaterThan(0);

    // And: CSS stylesheet should be linked
    const stylesheet = page.locator('link[rel="stylesheet"][href="styles.css"]');
    await expect(stylesheet).toHaveCount(1);
  });
});

test.describe('Story 1.1: Hero Section - CSS Custom Properties', () => {
  /**
   * Verify CSS custom properties are defined in :root
   * (Part of AC-1.1.6 CSS requirements for future story compatibility)
   */
  test('should define CSS custom properties for design tokens', async ({
    page,
    log,
  }) => {
    // Given: User navigates to the homepage
    await page.goto('/');
    await log.step('Verifying CSS custom properties are defined');

    // When: The page loads
    const body = page.locator('body');

    // Then: Color variables should be defined
    const primaryColor = await body.evaluate((el) =>
      getComputedStyle(el).getPropertyValue('--color-primary').trim()
    );
    expect(primaryColor).not.toBe('');

    const accentColor = await body.evaluate((el) =>
      getComputedStyle(el).getPropertyValue('--color-accent').trim()
    );
    expect(accentColor).not.toBe('');

    // And: Typography variables should be defined
    const fontHeading = await body.evaluate((el) =>
      getComputedStyle(el).getPropertyValue('--font-heading').trim()
    );
    expect(fontHeading).not.toBe('');

    // And: Spacing variables should be defined
    const spacingMd = await body.evaluate((el) =>
      getComputedStyle(el).getPropertyValue('--spacing-md').trim()
    );
    expect(spacingMd).not.toBe('');
  });
});

test.describe('Story 1.1: Hero Section - Network Validation', () => {
  /**
   * Verify page loads without HTTP errors (smoke test)
   */
  test('should load homepage without HTTP errors', async ({
    page,
    networkErrorMonitor,
    log,
  }) => {
    // Given: Network error monitoring is active
    await log.step('Navigating to homepage with network monitoring');

    // When: Page loads
    await page.goto('/');

    // Then: No HTTP 4xx/5xx errors should occur
    const errors = networkErrorMonitor.getErrors();
    expect(errors).toHaveLength(0);
  });
});
