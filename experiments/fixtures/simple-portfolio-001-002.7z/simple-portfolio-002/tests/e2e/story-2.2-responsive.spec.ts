/**
 * ATDD Tests for Story 2.2: Mobile-First Responsive Layout
 *
 * TDD GREEN PHASE: All tests passing after implementing responsive media query
 * in styles.css with @media (min-width: 768px).
 *
 * Acceptance Criteria:
 * - AC-2.2.1: Base styles display single-column layout for .projects__grid
 * - AC-2.2.2: styles.css contains @media (min-width: 768px) query
 * - AC-2.2.3: Mobile (<768px): project cards stack vertically in single column
 * - AC-2.2.4: Desktop (>=768px): project cards display in 3-column grid with gap
 * - AC-2.2.5: Hero text renders without overflow at 320px viewport
 * - AC-2.2.6: CTA touch target >= 48x48px (per UX spec accessibility standards)
 * - AC-2.2.7: No horizontal scrolling at 320px minimum width
 * - AC-2.2.8: CSS Grid used for layout (verify preserved from Story 2.1)
 *
 * @see _bmad-output/implementation-artifacts/2-2-mobile-first-responsive-layout.md
 */
import { test, expect } from '../support/fixtures';
import { heroSelectors, projectsSelectors } from '../support/helpers/selectors';
import * as fs from 'fs';
import * as path from 'path';

/**
 * Mobile viewport tests (320px width - minimum supported)
 */
test.describe('Story 2.2: Mobile Layout (320px)', () => {
  test.beforeEach(async ({ page }) => {
    // Set mobile viewport before each test
    await page.setViewportSize({ width: 320, height: 568 });
  });

  /**
   * AC-2.2.1: Base styles (no media query) display single-column layout
   * AC-2.2.3: Mobile (<768px): project cards stack vertically in single column
   *
   * GREEN PHASE: This test verifies the grid is single-column on mobile.
   * Implementation has no grid-template-columns, which correctly defaults to 1 column.
   */
  test('AC-2.2.1/3: projects grid should display single column on mobile', async ({
    page,
    log,
  }) => {
    // Given: User views the portfolio on a mobile device (320px width)
    await page.goto('/');
    await log.step('Verifying single-column layout on mobile');

    // When: The page loads
    const grid = page.locator(projectsSelectors.grid);

    // Then: Grid should use CSS Grid
    const display = await grid.evaluate((el) => getComputedStyle(el).display);
    expect(display).toBe('grid');

    // And: Grid should have single column (no explicit columns = 1 column)
    const gridTemplateColumns = await grid.evaluate(
      (el) => getComputedStyle(el).gridTemplateColumns
    );
    // On mobile, should be a single column value (e.g., "288px" or similar single value)
    // NOT "repeat(3, 1fr)" or multiple values
    // Use regex split to handle browser whitespace normalization
    const columnCount = gridTemplateColumns.trim().split(/\s+/).filter(v => v.length > 0).length;
    expect(columnCount).toBe(1);
  });

  /**
   * AC-2.2.5: Hero text renders without overflow at 320px viewport
   *
   * GREEN PHASE: Verifies hero section text does not cause horizontal overflow.
   */
  test('AC-2.2.5: hero text should not overflow at 320px viewport', async ({
    page,
    log,
  }) => {
    // Given: User views the portfolio on a narrow mobile device (320px)
    await page.goto('/');
    await log.step('Verifying hero text does not overflow');

    // When: Checking the hero section
    const heroName = page.locator(heroSelectors.name);
    const heroTagline = page.locator(heroSelectors.tagline);

    // Then: Hero name should not overflow horizontally
    const nameOverflow = await heroName.evaluate((el) => {
      return el.scrollWidth > el.clientWidth;
    });
    expect(nameOverflow).toBe(false);

    // And: Hero tagline should not overflow horizontally
    const taglineOverflow = await heroTagline.evaluate((el) => {
      return el.scrollWidth > el.clientWidth;
    });
    expect(taglineOverflow).toBe(false);

    // And: Hero name should be visible within viewport
    const nameBox = await heroName.boundingBox();
    expect(nameBox).not.toBeNull();
    expect(nameBox!.x).toBeGreaterThanOrEqual(0);
    expect(nameBox!.x + nameBox!.width).toBeLessThanOrEqual(320);
  });

  /**
   * AC-2.2.6: CTA touch target >= 48x48px (per UX spec accessibility standards)
   *
   * GREEN PHASE: CTA has minimum 48x48px touch target for mobile accessibility.
   * Implementation: padding 16px 32px + 24px line-height = 56px height.
   */
  test('AC-2.2.6: CTA should have minimum 48x48px touch target', async ({
    page,
    log,
  }) => {
    // Given: User views the portfolio on a mobile device
    await page.goto('/');
    await log.step('Verifying CTA touch target size');

    // When: Measuring the CTA button
    const ctaButton = page.locator(heroSelectors.cta);
    const boundingBox = await ctaButton.boundingBox();

    // Then: CTA should be at least 48px tall (touch target height)
    expect(boundingBox).not.toBeNull();
    expect(boundingBox!.height).toBeGreaterThanOrEqual(48);

    // And: CTA should be at least 48px wide (touch target width)
    expect(boundingBox!.width).toBeGreaterThanOrEqual(48);
  });

  /**
   * AC-2.2.7: No horizontal scrolling at 320px minimum width
   *
   * GREEN PHASE: Page does not have horizontal scroll at minimum viewport.
   */
  test('AC-2.2.7: page should not have horizontal scroll at 320px', async ({
    page,
    log,
  }) => {
    // Given: User views the portfolio on minimum width device (320px)
    await page.goto('/');
    await log.step('Verifying no horizontal scroll');

    // When: Checking for horizontal overflow
    const hasHorizontalScroll = await page.evaluate(() => {
      return document.documentElement.scrollWidth > document.documentElement.clientWidth;
    });

    // Then: Page should not have horizontal scrollbar
    expect(hasHorizontalScroll).toBe(false);

    // And: Body should not exceed viewport width
    const bodyWidth = await page.evaluate(() => {
      return document.body.scrollWidth;
    });
    expect(bodyWidth).toBeLessThanOrEqual(320);
  });
});

/**
 * Desktop viewport tests (768px width - breakpoint threshold)
 */
test.describe('Story 2.2: Desktop Layout (768px)', () => {
  test.beforeEach(async ({ page }) => {
    // Set desktop viewport at breakpoint threshold
    await page.setViewportSize({ width: 768, height: 1024 });
  });

  /**
   * AC-2.2.4: Desktop (>=768px): project cards display in 3-column grid with gap
   *
   * GREEN PHASE: This test PASSES now that @media (min-width: 768px) is added
   * with grid-template-columns: repeat(3, 1fr).
   */
  test('AC-2.2.4: projects grid should display 3 columns on desktop', async ({
    page,
    log,
  }) => {
    // Given: User views the portfolio on a desktop/tablet (768px width)
    await page.goto('/');
    await log.step('Verifying 3-column layout on desktop');

    // When: The page loads
    const grid = page.locator(projectsSelectors.grid);

    // Then: Grid should use CSS Grid
    const display = await grid.evaluate((el) => getComputedStyle(el).display);
    expect(display).toBe('grid');

    // And: Grid should have 3 columns
    const gridTemplateColumns = await grid.evaluate(
      (el) => getComputedStyle(el).gridTemplateColumns
    );
    // Should be 3 equal column values (e.g., "224px 224px 224px" or similar)
    // Use regex split to handle browser whitespace normalization
    const columnValues = gridTemplateColumns.trim().split(/\s+/).filter(v => v.length > 0);
    expect(columnValues.length).toBe(3);

    // And: Gap should be preserved (--spacing-md = 2rem = 32px)
    const gap = await grid.evaluate((el) => getComputedStyle(el).gap);
    expect(gap).toBe('32px');
  });

  /**
   * AC-2.2.4 (continued): Verify cards are laid out horizontally
   *
   * GREEN PHASE: Cards are side-by-side on desktop.
   */
  test('AC-2.2.4: project cards should be laid out horizontally on desktop', async ({
    page,
    log,
  }) => {
    // Given: User views the portfolio on desktop (768px)
    await page.goto('/');
    await log.step('Verifying horizontal card layout');

    // When: Getting card positions
    const cards = page.locator(projectsSelectors.card);
    const cardCount = await cards.count();
    expect(cardCount).toBe(3);

    // Then: All cards should have approximately the same Y position (same row)
    const firstCard = await cards.nth(0).boundingBox();
    const secondCard = await cards.nth(1).boundingBox();
    const thirdCard = await cards.nth(2).boundingBox();

    expect(firstCard).not.toBeNull();
    expect(secondCard).not.toBeNull();
    expect(thirdCard).not.toBeNull();

    // Cards should be on the same row (Y positions within 1px tolerance for grid alignment)
    expect(Math.abs(firstCard!.y - secondCard!.y)).toBeLessThanOrEqual(1);
    expect(Math.abs(secondCard!.y - thirdCard!.y)).toBeLessThanOrEqual(1);

    // And: Cards should be side-by-side (X positions increasing)
    expect(secondCard!.x).toBeGreaterThan(firstCard!.x);
    expect(thirdCard!.x).toBeGreaterThan(secondCard!.x);
  });
});

/**
 * Large desktop viewport tests (1200px - verify layout stability)
 */
test.describe('Story 2.2: Large Desktop Layout (1200px)', () => {
  test.beforeEach(async ({ page }) => {
    // Set large desktop viewport
    await page.setViewportSize({ width: 1200, height: 800 });
  });

  /**
   * Verify 3-column layout remains stable at larger viewports
   *
   * GREEN PHASE: Layout is consistent at 1200px.
   */
  test('layout should remain stable at 1200px viewport', async ({
    page,
    log,
  }) => {
    // Given: User views the portfolio on a large desktop (1200px)
    await page.goto('/');
    await log.step('Verifying layout stability at 1200px');

    // When: Checking the grid
    const grid = page.locator(projectsSelectors.grid);

    // Then: Grid should still have 3 columns
    const gridTemplateColumns = await grid.evaluate(
      (el) => getComputedStyle(el).gridTemplateColumns
    );
    // Use regex split to handle browser whitespace normalization
    const columnValues = gridTemplateColumns.trim().split(/\s+/).filter(v => v.length > 0);
    expect(columnValues.length).toBe(3);

    // And: Cards should still be laid out horizontally
    const cards = page.locator(projectsSelectors.card);
    const firstCard = await cards.nth(0).boundingBox();
    const thirdCard = await cards.nth(2).boundingBox();

    expect(firstCard).not.toBeNull();
    expect(thirdCard).not.toBeNull();
    expect(Math.abs(firstCard!.y - thirdCard!.y)).toBeLessThan(5);
  });
});

/**
 * CSS Static Analysis Tests
 */
test.describe('Story 2.2: CSS Structure', () => {
  /**
   * AC-2.2.2: styles.css contains @media (min-width: 768px) query
   *
   * GREEN PHASE: This test PASSES now that the media query is added to styles.css.
   */
  test('AC-2.2.2: CSS should contain responsive media query', async ({ log }) => {
    await log.step('Verifying responsive media query in CSS');

    // Read styles.css file directly
    const stylesPath = path.resolve(__dirname, '../../styles.css');
    const cssContent = fs.readFileSync(stylesPath, 'utf-8');

    // Then: CSS should contain the responsive breakpoint media query
    expect(cssContent).toContain('@media (min-width: 768px)');

    // And: Media query should contain grid-template-columns for 3-column layout
    const mediaQueryMatch = cssContent.match(
      /@media\s*\(\s*min-width:\s*768px\s*\)\s*\{([^}]+)\}/s
    );
    expect(mediaQueryMatch).not.toBeNull();

    const mediaQueryContent = mediaQueryMatch![1];
    expect(mediaQueryContent).toContain('.projects__grid');
    expect(mediaQueryContent).toContain('grid-template-columns');
    expect(mediaQueryContent).toContain('repeat(3, 1fr)');
  });

  /**
   * AC-2.2.8: CSS Grid used for layout (verify preserved)
   *
   * GREEN PHASE: Verify Grid implementation from Story 2.1 is preserved.
   */
  test('AC-2.2.8: CSS should use Grid for projects layout', async ({ log }) => {
    await log.step('Verifying CSS Grid usage');

    // Read styles.css file directly
    const stylesPath = path.resolve(__dirname, '../../styles.css');
    const cssContent = fs.readFileSync(stylesPath, 'utf-8');

    // Then: .projects__grid should use display: grid
    expect(cssContent).toMatch(/\.projects__grid\s*\{[^}]*display:\s*grid/s);

    // And: Gap should use CSS custom property
    expect(cssContent).toMatch(/\.projects__grid\s*\{[^}]*gap:\s*var\(--spacing-md\)/s);
  });

  /**
   * Verify CSS follows mobile-first approach (no max-width media queries)
   *
   * GREEN PHASE: Per ADR-005, only min-width media queries are used.
   */
  test('CSS should use mobile-first approach (min-width only)', async ({ log }) => {
    await log.step('Verifying mobile-first media query approach');

    // Read styles.css file directly
    const stylesPath = path.resolve(__dirname, '../../styles.css');
    const cssContent = fs.readFileSync(stylesPath, 'utf-8');

    // Then: CSS should NOT contain max-width media queries
    expect(cssContent).not.toMatch(/@media\s*\([^)]*max-width/);

    // And: Any responsive (viewport-based) media queries should use min-width
    const mediaQueries = cssContent.match(/@media\s*\([^)]+\)/g) || [];
    // Filter out non-viewport media queries (preference queries, hover queries)
    const responsiveQueries = mediaQueries.filter(
      (q) => !q.includes('prefers-reduced-motion') && !q.includes('hover:')
    );

    responsiveQueries.forEach((query) => {
      expect(query).toContain('min-width');
    });
  });

  /**
   * Verify CSS has Responsive Layout section comment
   */
  test('CSS should have Responsive Layout section comment', async ({ log }) => {
    await log.step('Verifying CSS organization');

    // Read styles.css file directly
    const stylesPath = path.resolve(__dirname, '../../styles.css');
    const cssContent = fs.readFileSync(stylesPath, 'utf-8');

    // Then: CSS should have section comment for responsive layout
    expect(cssContent).toContain('/* Responsive Layout */');
  });
});

/**
 * Cross-viewport responsive behavior tests
 */
test.describe('Story 2.2: Responsive Transitions', () => {
  /**
   * Verify layout changes correctly at breakpoint boundary
   *
   * GREEN PHASE: Tests responsive behavior at exact breakpoint.
   */
  test('layout should transition from 1-column to 3-column at 768px', async ({
    page,
    log,
  }) => {
    // Given: Start at mobile viewport (767px - just below breakpoint)
    await page.setViewportSize({ width: 767, height: 1024 });
    await page.goto('/');
    await log.step('Testing layout at 767px (below breakpoint)');

    const grid = page.locator(projectsSelectors.grid);

    // Then: Should have single column at 767px
    let gridTemplateColumns = await grid.evaluate(
      (el) => getComputedStyle(el).gridTemplateColumns
    );
    let columnCount = gridTemplateColumns.trim().split(/\s+/).filter(v => v.length > 0).length;
    expect(columnCount).toBe(1);

    // When: Viewport expands to 768px (at breakpoint)
    await page.setViewportSize({ width: 768, height: 1024 });
    await log.step('Testing layout at 768px (at breakpoint)');

    // Then: Should have 3 columns at 768px
    gridTemplateColumns = await grid.evaluate(
      (el) => getComputedStyle(el).gridTemplateColumns
    );
    columnCount = gridTemplateColumns.trim().split(/\s+/).filter(v => v.length > 0).length;
    expect(columnCount).toBe(3);
  });
});
