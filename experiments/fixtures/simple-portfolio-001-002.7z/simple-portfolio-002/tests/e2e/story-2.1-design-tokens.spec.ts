/**
 * ATDD Tests for Story 2.1: CSS Design Tokens and Typography
 *
 * Acceptance Criteria:
 * - AC-2.1.1: h1 uses --font-heading font family AND --font-size-xxl
 * - AC-2.1.2: Body text uses --font-body font family with line-height: 1.5
 * - AC-2.1.3: Hero CTA button styled with accent background, white text, padding, border-radius
 * - AC-2.1.4: Hero CTA button has hover, focus, and active states
 * - AC-2.1.5: Hero tagline uses --font-size-lg for typography scale
 * - AC-2.1.6: Project cards have box-shadow for depth
 * - AC-2.1.7: Project cards have elevated shadow on hover
 * - AC-2.1.8: Project cards have white background contrasting with page
 * - AC-2.1.9: CSS includes @media (prefers-reduced-motion: reduce) query
 * - AC-2.1.10: All new CSS classes follow BEM naming convention
 * - AC-2.1.11: All CSS uses var(--token-name) syntax, no hardcoded values
 *
 * @see _bmad-output/implementation-artifacts/2-1-css-design-tokens-and-typography.md
 */
import { test, expect } from '../support/fixtures';
import { heroSelectors, projectsSelectors } from '../support/helpers/selectors';
import * as fs from 'fs';
import * as path from 'path';

test.describe('Story 2.1: CSS Design Tokens and Typography', () => {
  /**
   * AC-2.1.1: h1 uses --font-heading font family AND --font-size-xxl
   * Expected: .hero__name has font-family containing "Georgia" and font-size of 3rem (48px at 16px base)
   */
  test('AC-2.1.1: h1 should use --font-heading and --font-size-xxl via .hero__name', async ({
    page,
    log,
  }) => {
    // Given: User navigates to the homepage
    await page.goto('/');
    await log.step('Verifying h1 typography tokens');

    // When: The page loads
    const heroName = page.locator(heroSelectors.name);

    // Then: h1 should use --font-heading (Georgia, serif)
    const fontFamily = await heroName.evaluate((el) =>
      getComputedStyle(el).fontFamily
    );
    expect(fontFamily.toLowerCase()).toContain('georgia');

    // And: h1 should use --font-size-xxl (3rem = 48px at 16px base)
    const fontSize = await heroName.evaluate((el) =>
      getComputedStyle(el).fontSize
    );
    expect(fontSize).toBe('48px');
  });

  /**
   * AC-2.1.2: Body text uses --font-body font family with line-height: 1.5
   * Expected: body has font-family containing "Arial" and line-height of 1.5 (24px at 16px base)
   */
  test('AC-2.1.2: body should use --font-body with line-height 1.5', async ({
    page,
    log,
  }) => {
    // Given: User navigates to the homepage
    await page.goto('/');
    await log.step('Verifying body typography');

    // When: The page loads
    const body = page.locator('body');

    // Then: body should use --font-body (Arial, sans-serif)
    const fontFamily = await body.evaluate((el) =>
      getComputedStyle(el).fontFamily
    );
    expect(fontFamily.toLowerCase()).toContain('arial');

    // And: body should have line-height of 1.5 (24px at 16px base)
    const lineHeight = await body.evaluate((el) =>
      getComputedStyle(el).lineHeight
    );
    // Line-height can be computed as "24px" or "normal" depending on implementation
    // At 16px base, 1.5 = 24px
    expect(lineHeight).toBe('24px');

    // And: body should use --font-size-base (16px)
    const fontSize = await body.evaluate((el) =>
      getComputedStyle(el).fontSize
    );
    expect(fontSize).toBe('16px');

    // And: body should use --color-text (#333333)
    const color = await body.evaluate((el) =>
      getComputedStyle(el).color
    );
    // RGB equivalent of #333 or #333333
    expect(color).toBe('rgb(51, 51, 51)');

    // And: body should use --color-background (#ffffff)
    const backgroundColor = await body.evaluate((el) =>
      getComputedStyle(el).backgroundColor
    );
    expect(backgroundColor).toBe('rgb(255, 255, 255)');
  });

  /**
   * AC-2.1.3: Hero CTA button styled with accent background, white text, padding, border-radius
   * Expected: .hero__cta has specific styling from design tokens
   */
  test('AC-2.1.3: hero CTA should have accent background, white text, padding, and border-radius', async ({
    page,
    log,
  }) => {
    // Given: User navigates to the homepage
    await page.goto('/');
    await log.step('Verifying CTA button styling');

    // When: The page loads
    const ctaButton = page.locator(heroSelectors.cta);

    // Then: CTA should have --color-accent background (#e94560)
    const backgroundColor = await ctaButton.evaluate((el) =>
      getComputedStyle(el).backgroundColor
    );
    expect(backgroundColor).toBe('rgb(233, 69, 96)');

    // And: CTA should have white text (--color-background)
    const color = await ctaButton.evaluate((el) =>
      getComputedStyle(el).color
    );
    expect(color).toBe('rgb(255, 255, 255)');

    // And: CTA should have padding (--spacing-sm --spacing-md = 1rem 2rem)
    const paddingTop = await ctaButton.evaluate((el) =>
      getComputedStyle(el).paddingTop
    );
    const paddingLeft = await ctaButton.evaluate((el) =>
      getComputedStyle(el).paddingLeft
    );
    expect(paddingTop).toBe('16px'); // 1rem
    expect(paddingLeft).toBe('32px'); // 2rem

    // And: CTA should have border-radius (--border-radius = 8px)
    const borderRadius = await ctaButton.evaluate((el) =>
      getComputedStyle(el).borderRadius
    );
    expect(borderRadius).toBe('8px');

    // And: CTA should be display inline-block
    const display = await ctaButton.evaluate((el) =>
      getComputedStyle(el).display
    );
    expect(display).toBe('inline-block');

    // And: CTA should have no text decoration
    const textDecoration = await ctaButton.evaluate((el) =>
      getComputedStyle(el).textDecorationLine
    );
    expect(textDecoration).toBe('none');

    // And: CTA should use --font-body
    const fontFamily = await ctaButton.evaluate((el) =>
      getComputedStyle(el).fontFamily
    );
    expect(fontFamily.toLowerCase()).toContain('arial');

    // And: CTA should have bold font weight
    const fontWeight = await ctaButton.evaluate((el) =>
      getComputedStyle(el).fontWeight
    );
    // 700 or "bold"
    expect(parseInt(fontWeight)).toBeGreaterThanOrEqual(700);
  });

  /**
   * AC-2.1.4: Hero CTA button has hover, focus, and active states
   * Expected: CTA changes appearance on hover (brightness/scale), has focus outline, active state
   * Note: Hover state tests only on desktop (@media (hover: hover) prevents sticky hover on mobile)
   */
  test('AC-2.1.4: hero CTA should have hover, focus, and active states', async ({
    page,
    log,
  }) => {
    // Skip on mobile devices that don't support hover
    const isMobile = await page.evaluate(() =>
      window.matchMedia('(hover: none)').matches
    );
    if (isMobile) {
      test.skip();
    }

    // Given: User navigates to the homepage
    await page.goto('/');
    await log.step('Verifying CTA interaction states');

    const ctaButton = page.locator(heroSelectors.cta);

    // When: User hovers over CTA
    await ctaButton.hover();
    await log.step('Testing hover state');

    // Then: CTA should have transform scale (1.02) on hover
    const hoverTransform = await ctaButton.evaluate((el) =>
      getComputedStyle(el).transform
    );
    // Transform matrix for scale(1.02) contains ~1.02 values
    expect(hoverTransform).not.toBe('none');
    expect(hoverTransform).toContain('matrix');

    // And: CTA should have filter applied (brightness)
    const hoverFilter = await ctaButton.evaluate((el) =>
      getComputedStyle(el).filter
    );
    expect(hoverFilter).toContain('brightness');

    // Clear hover state before testing focus
    await page.mouse.click(0, 0);

    // When: User focuses CTA (keyboard navigation)
    await ctaButton.focus();
    await log.step('Testing focus-visible state');

    // Then: CTA should have visible outline
    const outline = await ctaButton.evaluate((el) =>
      getComputedStyle(el).outline
    );
    // Outline should include accent color and be visible (not "none" or "0px")
    expect(outline).not.toBe('none');
    expect(outline).not.toMatch(/^0px/);

    // And: CTA should have outline-offset
    const outlineOffset = await ctaButton.evaluate((el) =>
      getComputedStyle(el).outlineOffset
    );
    expect(outlineOffset).toBe('2px');

    // When: User activates CTA (active state)
    await ctaButton.dispatchEvent('mousedown');
    await log.step('Testing active state');

    // Then: CTA should have darker brightness on active
    const activeFilter = await ctaButton.evaluate((el) =>
      getComputedStyle(el).filter
    );
    expect(activeFilter).toContain('brightness');

    // And: CTA should scale down on active
    const activeTransform = await ctaButton.evaluate((el) =>
      getComputedStyle(el).transform
    );
    expect(activeTransform).not.toBe('none');
  });

  /**
   * AC-2.1.5: Hero tagline uses --font-size-lg for typography scale
   * Expected: .hero__tagline has font-size of 1.25rem (20px at 16px base)
   */
  test('AC-2.1.5: hero tagline should use --font-size-lg', async ({
    page,
    log,
  }) => {
    // Given: User navigates to the homepage
    await page.goto('/');
    await log.step('Verifying tagline typography');

    // When: The page loads
    const tagline = page.locator(heroSelectors.tagline);

    // Then: Tagline should use --font-size-lg (1.25rem = 20px at 16px base)
    const fontSize = await tagline.evaluate((el) =>
      getComputedStyle(el).fontSize
    );
    expect(fontSize).toBe('20px');
  });

  /**
   * AC-2.1.6: Project cards have box-shadow for depth
   * Expected: .projects__card has box-shadow "0 2px 8px rgba(0, 0, 0, 0.1)"
   */
  test('AC-2.1.6: project cards should have box-shadow for depth', async ({
    page,
    log,
  }) => {
    // Given: User navigates to the homepage
    await page.goto('/');
    await log.step('Verifying card shadow');

    // When: The page loads
    const card = page.locator(projectsSelectors.card).first();

    // Then: Card should have subtle box-shadow
    const boxShadow = await card.evaluate((el) =>
      getComputedStyle(el).boxShadow
    );
    // Expected: rgba(0, 0, 0, 0.1) 0px 2px 8px 0px
    expect(boxShadow).not.toBe('none');
    expect(boxShadow).toContain('rgba(0, 0, 0');
    expect(boxShadow).toContain('2px');
    expect(boxShadow).toContain('8px');
  });

  /**
   * AC-2.1.7: Project cards have elevated shadow on hover
   * Expected: .projects__card:hover has box-shadow "0 4px 16px rgba(0, 0, 0, 0.15)"
   * Note: Hover state tests only on desktop (@media (hover: hover) prevents sticky hover on mobile)
   */
  test('AC-2.1.7: project cards should have elevated shadow on hover', async ({
    page,
    log,
  }) => {
    // Skip on mobile devices that don't support hover
    const isMobile = await page.evaluate(() =>
      window.matchMedia('(hover: none)').matches
    );
    if (isMobile) {
      test.skip();
    }

    // Given: User navigates to the homepage
    await page.goto('/');
    await log.step('Verifying card hover shadow');

    const card = page.locator(projectsSelectors.card).first();

    // When: User hovers over card
    await card.hover();
    // Wait for transition to complete - verify shadow changed
    await expect(async () => {
      const shadow = await card.evaluate(el => getComputedStyle(el).boxShadow);
      expect(shadow).toContain('16px'); // Hover shadow has 16px blur
    }).toPass({ timeout: 500 });
    await log.step('Testing card hover state');

    // Then: Card should have elevated shadow with larger blur
    const hoverShadow = await card.evaluate((el) =>
      getComputedStyle(el).boxShadow
    );
    // Expected: rgba(0, 0, 0, 0.15) 0px 4px 16px 0px
    expect(hoverShadow).not.toBe('none');
    expect(hoverShadow).toContain('rgba(0, 0, 0');
    expect(hoverShadow).toContain('4px');
    expect(hoverShadow).toContain('16px');

    // And: Card should lift slightly (translateY)
    const transform = await card.evaluate((el) =>
      getComputedStyle(el).transform
    );
    expect(transform).not.toBe('none');
  });

  /**
   * AC-2.1.8: Project cards have white background
   * Expected: .projects__card has background-color of #ffffff (--color-background)
   */
  test('AC-2.1.8: project cards should have white background', async ({
    page,
    log,
  }) => {
    // Given: User navigates to the homepage
    await page.goto('/');
    await log.step('Verifying card background');

    // When: The page loads
    const card = page.locator(projectsSelectors.card).first();

    // Then: Card should have white background (--color-background)
    const backgroundColor = await card.evaluate((el) =>
      getComputedStyle(el).backgroundColor
    );
    expect(backgroundColor).toBe('rgb(255, 255, 255)');
  });

  /**
   * AC-2.1.9: CSS includes @media (prefers-reduced-motion: reduce) query
   * Expected: styles.css contains the accessibility media query
   */
  test('AC-2.1.9: CSS should include prefers-reduced-motion media query', async ({
    log,
  }) => {
    await log.step('Verifying reduced motion media query in CSS');

    // Read styles.css file directly
    const stylesPath = path.resolve(__dirname, '../../styles.css');
    const cssContent = fs.readFileSync(stylesPath, 'utf-8');

    // Then: CSS should contain prefers-reduced-motion media query
    expect(cssContent).toContain('@media (prefers-reduced-motion: reduce)');

    // And: It should disable transitions/animations
    const reducedMotionMatch = cssContent.match(
      /@media\s*\(\s*prefers-reduced-motion:\s*reduce\s*\)\s*\{([^}]+)\}/s
    );
    expect(reducedMotionMatch).not.toBeNull();

    // Verify it targets transitions or animations
    const mediaQueryContent = reducedMotionMatch![1];
    const hasTransitionRule = mediaQueryContent.includes('transition-duration') ||
      mediaQueryContent.includes('transition:');
    const hasAnimationRule = mediaQueryContent.includes('animation-duration') ||
      mediaQueryContent.includes('animation:') ||
      mediaQueryContent.includes('animation-iteration-count');

    expect(hasTransitionRule || hasAnimationRule).toBe(true);
  });

  /**
   * AC-2.1.10: All new CSS classes follow BEM naming convention
   * Expected: No non-BEM class names in styles.css
   */
  test('AC-2.1.10: all CSS classes should follow BEM naming convention', async ({
    log,
  }) => {
    await log.step('Verifying BEM naming convention');

    // Read styles.css file directly
    const stylesPath = path.resolve(__dirname, '../../styles.css');
    const cssContent = fs.readFileSync(stylesPath, 'utf-8');

    // Extract all class selectors (excluding pseudo-classes/elements)
    const classMatches = cssContent.match(/\.[\w-]+(?=\s*[,{:]|\s*\[)/g) || [];
    const uniqueClasses = [...new Set(classMatches.map(c => c.slice(1)))]; // Remove leading dot

    // BEM pattern: block, block__element, block--modifier, block__element--modifier
    // Element and modifier names can contain hyphens (e.g., card-image, card-title)
    const bemPattern = /^[a-z][a-z0-9-]*(?:__[a-z][a-z0-9-]*)?(?:--[a-z][a-z0-9-]*)?$/;

    // Allowed non-BEM (reset/base selectors)
    const allowedNonBem = ['body', 'html', '*'];

    const nonBemClasses = uniqueClasses.filter(className => {
      // Skip allowed base selectors
      if (allowedNonBem.includes(className)) return false;
      // Check BEM pattern
      return !bemPattern.test(className);
    });

    expect(nonBemClasses).toEqual([]);
  });

  /**
   * AC-2.1.11: All CSS uses var(--token-name) syntax, no hardcoded colors/fonts/pixels
   * Expected: No hardcoded hex colors, font names, or design token values in property values
   */
  test('AC-2.1.11: all CSS should use var(--token) syntax for design tokens', async ({
    log,
  }) => {
    await log.step('Verifying CSS custom property usage');

    // Read styles.css file directly
    const stylesPath = path.resolve(__dirname, '../../styles.css');
    const cssContent = fs.readFileSync(stylesPath, 'utf-8');

    // Remove :root block (custom property definitions are allowed there)
    const cssWithoutRoot = cssContent.replace(/:root\s*\{[^}]+\}/gs, '');

    // Remove comments
    const cssWithoutComments = cssWithoutRoot.replace(/\/\*[\s\S]*?\*\//g, '');

    // Check for hardcoded hex colors (should use var(--color-*))
    // Allow rgba() for shadows which are acceptable
    const hexColorPattern = /#[0-9a-fA-F]{3,6}(?![0-9a-fA-F])/g;
    const hexMatches = cssWithoutComments.match(hexColorPattern) || [];
    expect(hexMatches).toEqual([]);

    // Check for hardcoded font families (should use var(--font-*))
    // Pattern matches font-family declarations with literal font names
    const hardcodedFonts = cssWithoutComments.match(
      /font-family:\s*(?!var\()[^;]+(?:Georgia|Arial|serif|sans-serif)/gi
    );
    expect(hardcodedFonts || []).toEqual([]);

    // Check for hardcoded pixel values for spacing/sizing (should use var(--spacing-*))
    // Allow specific exceptions: box-shadow offsets, outline-offset, 0px
    // This is a simplified check - we look for padding/margin with px values
    const hardcodedSpacing = cssWithoutComments.match(
      /(?:padding|margin)(?:-(?:top|right|bottom|left))?:\s*(?!var\()(?!0)\d+px/gi
    );
    expect(hardcodedSpacing || []).toEqual([]);
  });
});

test.describe('Story 2.1: CSS Organization', () => {
  /**
   * Verify CSS file has section comments for organization (NFR-002)
   */
  test('should have organized CSS with section comments', async ({
    log,
  }) => {
    await log.step('Verifying CSS organization');

    // Read styles.css file directly
    const stylesPath = path.resolve(__dirname, '../../styles.css');
    const cssContent = fs.readFileSync(stylesPath, 'utf-8');

    // Then: CSS should have section comments
    expect(cssContent).toContain('/* CSS Custom Properties */');
    expect(cssContent).toContain('/* Global Typography */');
    expect(cssContent).toContain('/* Hero Section */');
    expect(cssContent).toContain('/* Projects Section */');
    expect(cssContent).toContain('/* Accessibility */');
  });

  /**
   * Verify CSS has box-sizing reset
   */
  test('should have box-sizing border-box reset', async ({
    page,
    log,
  }) => {
    await log.step('Verifying box-sizing reset');

    // Given: User navigates to the homepage
    await page.goto('/');

    // When: Checking any element
    const body = page.locator('body');

    // Then: Elements should use border-box
    const boxSizing = await body.evaluate((el) =>
      getComputedStyle(el).boxSizing
    );
    expect(boxSizing).toBe('border-box');
  });

  /**
   * Verify headings have reset margins
   */
  test('should have heading margin resets with spacing token', async ({
    page,
    log,
  }) => {
    await log.step('Verifying heading margin reset');

    // Given: User navigates to the homepage
    await page.goto('/');

    // When: Checking h1 element
    const h1 = page.locator('h1').first();

    // Then: h1 should have margin-top of 0
    const marginTop = await h1.evaluate((el) =>
      getComputedStyle(el).marginTop
    );
    expect(marginTop).toBe('0px');

    // And: h1 should have margin-bottom from --spacing-sm (1rem = 16px)
    const marginBottom = await h1.evaluate((el) =>
      getComputedStyle(el).marginBottom
    );
    expect(marginBottom).toBe('16px');
  });
});

test.describe('Story 2.1: CTA Transition', () => {
  /**
   * Verify CTA has transition property for smooth hover effects
   */
  test('should have transition property on CTA for smooth state changes', async ({
    page,
    log,
  }) => {
    await log.step('Verifying CTA transition');

    // Given: User navigates to the homepage
    await page.goto('/');

    // When: Checking CTA element
    const ctaButton = page.locator(heroSelectors.cta);

    // Then: CTA should have transition defined
    const transition = await ctaButton.evaluate((el) =>
      getComputedStyle(el).transition
    );
    expect(transition).not.toBe('all 0s ease 0s');
    expect(transition).toContain('transform');
  });
});

test.describe('Story 2.1: Card Transition', () => {
  /**
   * Verify cards have transition property for smooth hover effects
   */
  test('should have transition property on cards for smooth hover', async ({
    page,
    log,
  }) => {
    await log.step('Verifying card transition');

    // Given: User navigates to the homepage
    await page.goto('/');

    // When: Checking card element
    const card = page.locator(projectsSelectors.card).first();

    // Then: Card should have transition defined
    const transition = await card.evaluate((el) =>
      getComputedStyle(el).transition
    );
    expect(transition).not.toBe('all 0s ease 0s');
    expect(transition).toContain('box-shadow');
  });
});
