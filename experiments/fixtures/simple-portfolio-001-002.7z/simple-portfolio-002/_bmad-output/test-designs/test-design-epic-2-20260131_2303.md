I'll execute this test-design workflow for Story 2.2 (Mobile-First Responsive Layout) in Epic-Level mode.

## Step 1: Detect Mode & Prerequisites

**Mode Detection:**
- The `workflow_mode` variable is set to `c` (Create mode)
- Story file exists at `_bmad-output/implementation-artifacts/2-2-mobile-first-responsive-layout.md`
- This is **Epic-Level Mode (Phase 4)** - we have epic/story requirements with acceptance criteria

**Prerequisites Check for Epic-Level Mode:**
- ✅ Epic and story requirements with acceptance criteria (Story 2.2 has 8 ACs)
- ✅ Architecture context available (architecture.md loaded)
- ✅ PRD available (prd.md loaded)
- ✅ Project context available (project_context.md loaded)

**Mode Confirmed:** Epic-Level test design for Story 2.2: Mobile-First Responsive Layout

---

## Step 2: Load Context & Knowledge Base

**Configuration:**
- `tea_use_playwright_utils`: True
- `tea_use_mcp_enhancements`: True

**Project Artifacts Loaded:**
- **Story 2.2:** 8 acceptance criteria covering responsive layout
- **Tech Stack:** Pure HTML/CSS, no JavaScript (ADR-001)
- **Architecture:** Mobile-first responsive design (ADR-005), single 768px breakpoint
- **NFRs:** CSS < 10KB, page loads < 1s on 3G, touch targets ≥ 48px

**Testable Requirements Extracted:**
1. AC-2.2.1: Base styles single-column layout
2. AC-2.2.2: Media query at 768px exists
3. AC-2.2.3: Mobile cards stack vertically
4. AC-2.2.4: Desktop 3-column grid with gap
5. AC-2.2.5: Hero text no overflow at 320px
6. AC-2.2.6: CTA touch target ≥ 48x48px
7. AC-2.2.7: No horizontal scrolling at 320px
8. AC-2.2.8: CSS Grid used for layout

**Existing Test Coverage Analysis:**
- Tests exist at `tests/e2e/story-2.2-responsive.spec.ts` (12 tests)
- Story status is **done** with all tests passing (47 total)

---

## Step 3: Testability & Risk Assessment

### Risk Assessment Matrix

| Risk ID | Category | Description | Probability | Impact | Score | Mitigation | Owner |
|---------|----------|-------------|-------------|--------|-------|------------|-------|
| R-001 | PERF | CSS file exceeds 10KB budget | 1 | 2 | 2 | Monitor file size in CI | Dev |
| R-002 | BUS | Horizontal scroll on narrow devices (320px) | 2 | 2 | 4 | Test at 320px minimum | QA |
| R-003 | BUS | Touch targets too small for mobile users | 2 | 2 | 4 | Verify 48px minimum | QA |
| R-004 | TECH | Media query breakpoint incorrect | 1 | 2 | 2 | CSS parsing test | QA |
| R-005 | BUS | Grid layout breaks at edge viewports | 1 | 2 | 2 | Test at 767px/768px boundary | QA |

**Risk Summary:**
- No high-priority risks (score ≥6)
- 2 medium-priority risks (score 3-4): horizontal scroll and touch targets
- 3 low-priority risks (score 1-2): performance, breakpoint, edge cases

---

## Step 4: Coverage Plan & Execution Strategy

### Coverage Matrix

| AC | Requirement | Test Level | Risk Link | Priority | Test Count |
|----|-------------|------------|-----------|----------|------------|
| AC-2.2.1 | Base single-column layout | E2E | - | P1 | 1 |
| AC-2.2.2 | Media query exists at 768px | E2E | R-004 | P0 | 1 |
| AC-2.2.3 | Mobile vertical stacking | E2E | - | P1 | 2 |
| AC-2.2.4 | Desktop 3-column grid | E2E | R-005 | P1 | 2 |
| AC-2.2.5 | Hero text no overflow | E2E | R-002 | P0 | 1 |
| AC-2.2.6 | CTA touch target ≥48px | E2E | R-003 | P0 | 1 |
| AC-2.2.7 | No horizontal scroll | E2E | R-002 | P0 | 2 |
| AC-2.2.8 | CSS Grid used | E2E | - | P1 | 2 |

### Priority Breakdown

- **P0 (Critical):** 5 tests - media query, hero overflow, touch target, horizontal scroll
- **P1 (High):** 7 tests - layout verification at various viewports

### Execution Strategy

- **PR:** All 12 tests (~30 seconds total for static HTML/CSS)
- **Nightly:** N/A (no long-running tests for static site)

### Resource Estimates

- P0: ~2-3 hours (already implemented)
- P1: ~3-4 hours (already implemented)
- **Total:** 5-7 hours (complete)

### Quality Gates

- P0 pass rate: 100%
- P1 pass rate: ≥95%
- CSS file size: < 10KB (currently 3.4KB ✅)

---

## Step 5: Generate Output

Now I'll write the test design document:## Completion Report

**Mode Used:** Epic-Level (Phase 4)

**Output File:** `_bmad-output/implementation-artifacts/test-design-2-2.md`

**Key Findings:**

| Metric | Value |
|--------|-------|
| Total risks | 5 |
| High-priority risks (≥6) | 0 |
| Medium-priority risks (3-4) | 2 (horizontal scroll, touch targets) |
| P0 tests | 5 |
| P1 tests | 7 |
| Total tests | 12 (all passing) |

**Quality Gates:**
- P0 pass rate: 100% ✅
- P1 pass rate: 100% ✅
- CSS file size: 3.4KB (under 10KB limit) ✅

**Status:** Story 2.2 is complete with comprehensive test coverage. All acceptance criteria are verified through ATDD tests. No additional test design work required.## Completion Report

**Mode Used:** Epic-Level (Phase 4)

**Output File:** `_bmad-output/implementation-artifacts/test-design-2-2.md`

**Key Findings:**

| Metric | Value |
|--------|-------|
| Total risks | 5 |
| High-priority risks (≥6) | 0 |
| Medium-priority risks (3-4) | 2 (horizontal scroll, touch targets) |
| P0 tests | 5 |
| P1 tests | 7 |
| Total tests | 12 (all passing) |

**Quality Gates:**
- P0 pass rate: 100% ✅
- P1 pass rate: 100% ✅
- CSS file size: 3.4KB (under 10KB limit) ✅

**Status:** Story 2.2 is complete with comprehensive test coverage. All acceptance criteria are verified through ATDD tests. No additional test design work required.