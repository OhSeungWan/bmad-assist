# Epic 1 - Code Antipatterns

> **WARNING: ANTI-PATTERNS**
> The issues below were MISTAKES found during code review of previous stories.
> DO NOT repeat these patterns. Learn from them and avoid similar errors.
> These represent implementation mistakes (race conditions, missing tests, weak assertions, etc.)

## Story 1-1 (2026-01-31)

| Severity | Issue | Fix |
|----------|-------|-----|
| high | Hardcoded CSS values instead of using defined custom properties (violates ADR-003) | Changed `background: #1a1a2e; color: #fff;` to `background: var(--color-primary); color: var(--color-background);` |
| medium | Empty `<main>` element causes visibility test failure | Changed `await expect(mainElement).toBeVisible()` to `await expect(mainElement).toHaveCount(1)` - empty elements have zero height and fail Playwright's visibility check |
| medium | Stale TDD RED PHASE comment misleads about test state | Updated comment from "TDD RED PHASE: All tests are marked with test.skip()" to accurate description reflecting active tests |
| low | CTA link lacks explicit color for accessibility contrast | Added `.hero__cta { color: var(--color-background); }` rule to ensure CTA is readable against dark background (AC-1.1.6 requires 3:1 contrast ratio) |
