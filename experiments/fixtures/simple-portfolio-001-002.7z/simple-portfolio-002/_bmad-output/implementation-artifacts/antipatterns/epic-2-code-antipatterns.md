# Epic 2 - Code Antipatterns

> **WARNING: ANTI-PATTERNS**
> The issues below were MISTAKES found during code review of previous stories.
> DO NOT repeat these patterns. Learn from them and avoid similar errors.
> These represent implementation mistakes (race conditions, missing tests, weak assertions, etc.)

## Story 2-2 (2026-01-31)

| Severity | Issue | Fix |
|----------|-------|-----|
| high | Brittle `.split(' ')` for parsing computed grid values causes cross-browser test failures | Changed all instances to use `.trim().split(/\s+/).filter(v => v.length > 0)` pattern |
| high | Missing explicit `min-width: 48px; min-height: 48px` on CTA button makes touch target dependent on content length | Added `min-width: 48px; min-height: 48px;` to `.hero__cta` rule |
| high | Missing `overflow-wrap: break-word` and `word-wrap: break-word` on hero text elements | Added `max-width: 100%; overflow-wrap: break-word; word-wrap: break-word;` to `.hero__name` and `.hero__tagline` |
| low | Hardcoded transition duration `0.2s` and shadow values violate ADR-003 design token principle | Added `--transition-duration`, `--shadow-sm`, `--shadow-md` tokens to `:root` |
| low | 5px tolerance in card positioning test is too permissive for grid alignment | Changed `toBeLessThan(5)` to `toBeLessThanOrEqual(1)` |
