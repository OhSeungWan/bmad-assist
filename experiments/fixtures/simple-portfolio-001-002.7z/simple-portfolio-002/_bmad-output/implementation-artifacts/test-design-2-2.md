# Test Design: Epic 2 - Story 2.2 Mobile-First Responsive Layout

**Date:** 2026-01-31
**Author:** TEA Agent
**Status:** Approved

---

## Executive Summary

**Scope:** Epic-level test design for Story 2.2

**Risk Summary:**

- Total risks identified: 5
- High-priority risks (≥6): 0
- Critical categories: BUS (2), TECH (1), PERF (1)

**Coverage Summary:**

- P0 scenarios: 5 (2-3 hours)
- P1 scenarios: 7 (3-4 hours)
- P2/P3 scenarios: 0 (0 hours)
- **Total effort**: 5-7 hours (~1 day) - COMPLETE

---

## Risk Assessment

### Medium-Priority Risks (Score 3-4)

| Risk ID | Category | Description | Probability | Impact | Score | Mitigation | Owner |
|---------|----------|-------------|-------------|--------|-------|------------|-------|
| R-002 | BUS | Horizontal scroll on narrow devices (320px) | 2 | 2 | 4 | Test at 320px minimum viewport | QA |
| R-003 | BUS | Touch targets too small for mobile users | 2 | 2 | 4 | Verify 48x48px minimum CTA size | QA |

### Low-Priority Risks (Score 1-2)

| Risk ID | Category | Description | Probability | Impact | Score | Action |
|---------|----------|-------------|-------------|--------|-------|--------|
| R-001 | PERF | CSS file exceeds 10KB budget | 1 | 2 | 2 | Monitor |
| R-004 | TECH | Media query breakpoint incorrect | 1 | 2 | 2 | Monitor |
| R-005 | BUS | Grid layout breaks at edge viewports | 1 | 2 | 2 | Monitor |

### Risk Category Legend

- **TECH**: Technical/Architecture (flaws, integration, scalability)
- **PERF**: Performance (SLA violations, degradation, resource limits)
- **BUS**: Business Impact (UX harm, logic errors, revenue)

---

## Test Coverage Plan

### P0 (Critical) - Run on every commit

**Criteria**: Blocks core journey + High risk (≥6) + No workaround

| Requirement | Test Level | Risk Link | Test Count | Owner | Notes |
|-------------|------------|-----------|------------|-------|-------|
| AC-2.2.2: Media query at 768px | E2E | R-004 | 1 | QA | CSS contains `@media (min-width: 768px)` |
| AC-2.2.5: Hero text no overflow | E2E | R-002 | 1 | QA | No text clipping at 320px |
| AC-2.2.6: CTA touch target | E2E | R-003 | 1 | QA | Min 48x48px per UX spec |
| AC-2.2.7: No horizontal scroll | E2E | R-002 | 2 | QA | documentElement.scrollWidth ≤ clientWidth |

**Total P0**: 5 tests, 2-3 hours

### P1 (High) - Run on PR to main

**Criteria**: Important features + Medium risk (3-4) + Common workflows

| Requirement | Test Level | Risk Link | Test Count | Owner | Notes |
|-------------|------------|-----------|------------|-------|-------|
| AC-2.2.1: Base single-column | E2E | - | 1 | QA | No grid-template-columns in base |
| AC-2.2.3: Mobile vertical stack | E2E | - | 2 | QA | Cards stack at <768px |
| AC-2.2.4: Desktop 3-column | E2E | R-005 | 2 | QA | `repeat(3, 1fr)` at ≥768px |
| AC-2.2.8: CSS Grid used | E2E | - | 2 | QA | `display: grid` on .projects__grid |

**Total P1**: 7 tests, 3-4 hours

---

## Execution Order

### Smoke Tests (<5 sec)

**Purpose**: Fast feedback, catch build-breaking issues

- [x] Page loads at 320px viewport (1s)
- [x] Page loads at 768px viewport (1s)
- [x] CSS file parseable (1s)

**Total**: 3 scenarios

### P0 Tests (<10 sec)

**Purpose**: Critical path validation

- [x] Media query exists in CSS (E2E)
- [x] Hero renders without overflow at 320px (E2E)
- [x] CTA button meets 48px touch target (E2E)
- [x] No horizontal scrollbar at 320px (E2E)
- [x] No horizontal scrollbar at 375px (E2E)

**Total**: 5 scenarios

### P1 Tests (<30 sec)

**Purpose**: Important feature coverage

- [x] Grid defaults to single column (E2E)
- [x] Cards stack vertically at 320px (E2E)
- [x] Cards stack vertically at 767px (E2E)
- [x] Cards in 3-column grid at 768px (E2E)
- [x] Cards in 3-column grid at 1200px (E2E)
- [x] Grid uses display: grid (E2E)
- [x] Gap preserved in media query (E2E)

**Total**: 7 scenarios

---

## Resource Estimates

### Test Development Effort

| Priority | Count | Hours/Test | Total Hours | Notes |
|----------|-------|------------|-------------|-------|
| P0 | 5 | 0.5 | 2-3 | Simple viewport/CSS checks |
| P1 | 7 | 0.5 | 3-4 | Layout verification |
| P2 | 0 | - | 0 | N/A |
| P3 | 0 | - | 0 | N/A |
| **Total** | **12** | **-** | **5-7** | **~1 day - COMPLETE** |

### Prerequisites

**Test Data:**
- Static HTML/CSS files (no factories needed)
- Playwright fixtures for viewport configuration

**Tooling:**
- Playwright for E2E testing
- CSS parsing for media query verification

**Environment:**
- Local file serving (file:// or localhost)
- Multiple viewport sizes (320px, 375px, 767px, 768px, 1200px)

---

## Quality Gate Criteria

### Pass/Fail Thresholds

- **P0 pass rate**: 100% (no exceptions)
- **P1 pass rate**: ≥95% (waivers required for failures)
- **CSS file size**: < 10KB (currently 3.4KB ✅)

### Coverage Targets

- **Responsive breakpoints**: 100% (768px tested)
- **Viewport range**: 100% (320px - 1200px covered)
- **Touch accessibility**: 100% (48px verified)

### Non-Negotiable Requirements

- [x] All P0 tests pass
- [x] No horizontal scroll at minimum viewport (320px)
- [x] Touch targets meet UX spec (48x48px)
- [x] Media query correctly placed at 768px

---

## Mitigation Plans

### R-002: Horizontal scroll on narrow devices (Score: 4)

**Mitigation Strategy:** Test at 320px minimum viewport width, verify `documentElement.scrollWidth <= documentElement.clientWidth`
**Owner:** QA
**Timeline:** Complete
**Status:** Complete
**Verification:** E2E test in story-2.2-responsive.spec.ts

### R-003: Touch targets too small (Score: 4)

**Mitigation Strategy:** Measure CTA button computed size, verify height and width ≥ 48px
**Owner:** QA
**Timeline:** Complete
**Status:** Complete
**Verification:** E2E test verifies button dimensions

---

## Assumptions and Dependencies

### Assumptions

1. Playwright correctly measures CSS computed styles
2. Viewport emulation accurately represents real devices
3. Story 2.1 prerequisites remain intact (CSS variables, typography)

### Dependencies

1. Story 2.1 completion - Required (complete)
2. Playwright test infrastructure - Required (complete)

---

## Current Test Status

**All tests implemented and passing:**

```
tests/e2e/story-2.2-responsive.spec.ts (12 tests)
├── Mobile viewport tests (320px)
│   ├── displays single-column layout ✅
│   ├── cards stack vertically ✅
│   └── no horizontal scroll ✅
├── Tablet/Desktop viewport tests (768px+)
│   ├── displays 3-column grid ✅
│   ├── maintains gap between cards ✅
│   └── preserves layout at 1200px ✅
├── Breakpoint boundary tests
│   ├── single column at 767px ✅
│   └── 3-column at 768px ✅
├── Touch accessibility
│   └── CTA button >= 48x48px ✅
├── CSS verification
│   ├── media query exists ✅
│   └── uses CSS Grid ✅
└── Hero section
    └── no text overflow at 320px ✅
```

**Total: 47 tests passing (12 Story 2.2 + 35 existing)**

---

## Follow-on Workflows (Manual)

- ✅ ATDD tests already generated and passing
- ✅ No additional automation needed for this story

---

## Approval

**Test Design Approved By:**

- [x] TEA Agent Date: 2026-01-31

**Comments:**
Story 2.2 is complete with comprehensive test coverage. All 12 ATDD tests pass. CSS file size (3.4KB) is well under the 10KB budget. No high-priority risks identified.

---

## Appendix

### Knowledge Base References

- `risk-governance.md` - Risk classification framework
- `probability-impact.md` - Risk scoring methodology
- `test-levels-framework.md` - Test level selection
- `test-priorities-matrix.md` - P0-P3 prioritization

### Related Documents

- PRD: docs/prd.md
- Architecture: docs/architecture.md
- Project Context: docs/project_context.md
- Story: _bmad-output/implementation-artifacts/2-2-mobile-first-responsive-layout.md

---

**Generated by**: BMad TEA Agent - Test Architect Module
**Workflow**: `testarch/test-design`
**Mode**: Epic-Level (Phase 4)
