# ATDD Checklist - Epic 2, Story 2: Mobile-First Responsive Layout

**Date:** 2026-01-31
**Primary Test Level:** E2E

---

## Story Summary

Implement mobile-first responsive layout for the portfolio, ensuring project cards stack vertically on mobile devices (<768px) and display in a 3-column grid on desktop (>=768px).

**As a** mobile user
**I want** the portfolio to display correctly on my device
**So that** I can browse Alex's work comfortably regardless of screen size

---

## Acceptance Criteria

1. **AC-2.2.1:** Base styles (no media query) display single-column layout for `.projects__grid`
2. **AC-2.2.2:** `styles.css` contains `@media (min-width: 768px)` query
3. **AC-2.2.3:** On mobile (<768px): project cards stack vertically in single column
4. **AC-2.2.4:** On desktop (>=768px): project cards display in 3-column grid with gap preserved
5. **AC-2.2.5:** Hero section text renders without overflow at 320px viewport
6. **AC-2.2.6:** CTA button has minimum touch target of 48x48 pixels on mobile
7. **AC-2.2.7:** No horizontal scrolling occurs on mobile viewport (320px minimum width)
8. **AC-2.2.8:** Grid uses CSS Grid for layout (verify preserved)

---

## Failing Tests Created (RED Phase)

### E2E Tests (12 tests)

**File:** `tests/e2e/story-2.2-responsive.spec.ts` (410 lines)

#### Mobile Layout Tests (320px)

- **Test:** `AC-2.2.1/3: projects grid should display single column on mobile`
  - **Status:** RED - test.skip() active
  - **Verifies:** Grid has single column on mobile viewport
  - **Expected Failure:** Grid template columns = 1 column value

- **Test:** `AC-2.2.5: hero text should not overflow at 320px viewport`
  - **Status:** RED - test.skip() active
  - **Verifies:** Hero name and tagline fit within 320px without overflow
  - **Expected Failure:** scrollWidth <= clientWidth for hero elements

- **Test:** `AC-2.2.6: CTA should have minimum 48x48px touch target`
  - **Status:** RED - test.skip() active
  - **Verifies:** CTA button meets accessibility touch target requirements
  - **Expected Failure:** boundingBox height/width >= 48px (likely passes already)

- **Test:** `AC-2.2.7: page should not have horizontal scroll at 320px`
  - **Status:** RED - test.skip() active
  - **Verifies:** No horizontal scrollbar at minimum viewport
  - **Expected Failure:** scrollWidth <= clientWidth

#### Desktop Layout Tests (768px)

- **Test:** `AC-2.2.4: projects grid should display 3 columns on desktop`
  - **Status:** RED - test.skip() active
  - **Verifies:** Grid has 3 columns at breakpoint
  - **Expected Failure:** Media query doesn't exist yet

- **Test:** `AC-2.2.4: project cards should be laid out horizontally on desktop`
  - **Status:** RED - test.skip() active
  - **Verifies:** Cards are side-by-side (same Y position)
  - **Expected Failure:** Cards will stack without media query

#### Large Desktop Tests (1200px)

- **Test:** `layout should remain stable at 1200px viewport`
  - **Status:** RED - test.skip() active
  - **Verifies:** 3-column layout remains at larger viewports
  - **Expected Failure:** Depends on media query implementation

#### CSS Static Analysis Tests

- **Test:** `AC-2.2.2: CSS should contain responsive media query`
  - **Status:** RED - test.skip() active
  - **Verifies:** `@media (min-width: 768px)` exists with correct content
  - **Expected Failure:** Media query doesn't exist in styles.css

- **Test:** `AC-2.2.8: CSS should use Grid for projects layout`
  - **Status:** RED - test.skip() active
  - **Verifies:** `display: grid` and `gap: var(--spacing-md)` preserved
  - **Expected Failure:** Should pass (already implemented in Story 2.1)

- **Test:** `CSS should use mobile-first approach (min-width only)`
  - **Status:** RED - test.skip() active
  - **Verifies:** No `max-width` media queries (per ADR-005)
  - **Expected Failure:** Should pass after correct implementation

- **Test:** `CSS should have Responsive Layout section comment`
  - **Status:** RED - test.skip() active
  - **Verifies:** CSS organization follows project standards
  - **Expected Failure:** Section comment doesn't exist yet

#### Responsive Transition Tests

- **Test:** `layout should transition from 1-column to 3-column at 768px`
  - **Status:** RED - test.skip() active
  - **Verifies:** Breakpoint behavior at exact 767px vs 768px
  - **Expected Failure:** Layout doesn't change without media query

---

## Existing Test Infrastructure Used

### Fixtures

**File:** `tests/support/fixtures/index.ts`

- `log` - Step logging for test clarity
- `networkErrorMonitor` - HTTP error tracking (not needed for this story)

### Selectors

**File:** `tests/support/helpers/selectors.ts`

- `heroSelectors.name` - `.hero__name`
- `heroSelectors.tagline` - `.hero__tagline`
- `heroSelectors.cta` - `.hero__cta`
- `projectsSelectors.grid` - `.projects__grid`
- `projectsSelectors.card` - `.projects__card`

---

## Mock Requirements

None - this story tests CSS behavior only (no external services).

---

## Required CSS Changes

### Implementation Guidance

Add to `styles.css` after the `/* Accessibility */` section:

```css
/* Responsive Layout */
@media (min-width: 768px) {
  .projects__grid {
    grid-template-columns: repeat(3, 1fr);
  }
}
```

**Note:** Gap (`var(--spacing-md)`) is already defined in base `.projects__grid` styles and will be preserved.

---

## Implementation Checklist

### Test: AC-2.2.2 - CSS should contain responsive media query

**File:** `tests/e2e/story-2.2-responsive.spec.ts`

**Tasks to make this test pass:**

- [ ] Add `/* Responsive Layout */` section comment after `/* Accessibility */`
- [ ] Add `@media (min-width: 768px)` media query
- [ ] Inside media query, add `.projects__grid { grid-template-columns: repeat(3, 1fr); }`
- [ ] Remove `test.skip()` from test
- [ ] Run test: `npx playwright test story-2.2 --grep "responsive media query"`
- [ ] Test passes (green phase)

**Estimated Effort:** 15 minutes

---

### Test: AC-2.2.4 - projects grid should display 3 columns on desktop

**File:** `tests/e2e/story-2.2-responsive.spec.ts`

**Tasks to make this test pass:**

- [ ] Ensure media query contains `grid-template-columns: repeat(3, 1fr)`
- [ ] Remove `test.skip()` from test
- [ ] Run test: `npx playwright test story-2.2 --grep "3 columns on desktop"`
- [ ] Test passes (green phase)

**Estimated Effort:** 5 minutes (if media query added above)

---

### Test: AC-2.2.4 - project cards should be laid out horizontally on desktop

**File:** `tests/e2e/story-2.2-responsive.spec.ts`

**Tasks to make this test pass:**

- [ ] Verify 3-column layout makes cards horizontal
- [ ] Remove `test.skip()` from test
- [ ] Run test: `npx playwright test story-2.2 --grep "laid out horizontally"`
- [ ] Test passes (green phase)

**Estimated Effort:** 5 minutes

---

### Test: AC-2.2.1/3 - projects grid should display single column on mobile

**File:** `tests/e2e/story-2.2-responsive.spec.ts`

**Tasks to make this test pass:**

- [ ] Verify base styles have no `grid-template-columns` (single column default)
- [ ] Remove `test.skip()` from test
- [ ] Run test: `npx playwright test story-2.2 --grep "single column on mobile"`
- [ ] Test passes (green phase)

**Estimated Effort:** 5 minutes

---

### Test: AC-2.2.5 - hero text should not overflow at 320px viewport

**File:** `tests/e2e/story-2.2-responsive.spec.ts`

**Tasks to make this test pass:**

- [ ] Verify hero text doesn't overflow (likely passes already)
- [ ] If overflow occurs, adjust hero padding or font sizing
- [ ] Remove `test.skip()` from test
- [ ] Run test: `npx playwright test story-2.2 --grep "not overflow"`
- [ ] Test passes (green phase)

**Estimated Effort:** 5-15 minutes (depending on overflow issues)

---

### Test: AC-2.2.6 - CTA should have minimum 48x48px touch target

**File:** `tests/e2e/story-2.2-responsive.spec.ts`

**Tasks to make this test pass:**

- [ ] Verify CTA meets touch target (padding 16px 32px + 24px line = 56px height)
- [ ] Remove `test.skip()` from test
- [ ] Run test: `npx playwright test story-2.2 --grep "touch target"`
- [ ] Test passes (green phase)

**Estimated Effort:** 5 minutes

---

### Test: AC-2.2.7 - page should not have horizontal scroll at 320px

**File:** `tests/e2e/story-2.2-responsive.spec.ts`

**Tasks to make this test pass:**

- [ ] Verify no horizontal overflow at 320px
- [ ] If overflow occurs, add `max-width: 100%` to problematic elements
- [ ] Remove `test.skip()` from test
- [ ] Run test: `npx playwright test story-2.2 --grep "horizontal scroll"`
- [ ] Test passes (green phase)

**Estimated Effort:** 5-15 minutes

---

### Test: AC-2.2.8 - CSS should use Grid for projects layout

**File:** `tests/e2e/story-2.2-responsive.spec.ts`

**Tasks to make this test pass:**

- [ ] Verify `.projects__grid` has `display: grid` (from Story 2.1)
- [ ] Remove `test.skip()` from test
- [ ] Run test: `npx playwright test story-2.2 --grep "use Grid"`
- [ ] Test passes (green phase)

**Estimated Effort:** 5 minutes

---

### Remaining Tests

- [ ] CSS should use mobile-first approach (min-width only)
- [ ] CSS should have Responsive Layout section comment
- [ ] layout should remain stable at 1200px viewport
- [ ] layout should transition from 1-column to 3-column at 768px

**Estimated Effort:** 10 minutes (all should pass with correct implementation)

---

## Running Tests

```bash
# Run all Story 2.2 tests (currently skipped - will show 0 failures)
npx playwright test story-2.2

# Run specific test file
npx playwright test tests/e2e/story-2.2-responsive.spec.ts

# Run tests in headed mode (see browser)
npx playwright test story-2.2 --headed

# Debug specific test
npx playwright test story-2.2 --debug

# Run tests with coverage
npx playwright test story-2.2 --reporter=html

# After implementation: Remove test.skip() and run
npx playwright test story-2.2 --project=chromium
```

---

## Red-Green-Refactor Workflow

### RED Phase (Complete)

**TEA Agent Responsibilities:**

- All 12 tests written with `test.skip()`
- Tests assert expected behavior (not placeholders)
- Existing fixtures and selectors reused
- CSS implementation guidance documented

**Verification:**

- All tests are skipped (will show as "skipped" not "failed")
- Once `test.skip()` removed, tests will fail due to missing media query

---

### GREEN Phase (DEV Team - Next Steps)

**DEV Agent Responsibilities:**

1. Add `/* Responsive Layout */` section and media query to `styles.css`
2. Remove `test.skip()` from one test at a time
3. Run that test to verify it passes
4. Repeat for all 12 tests

**Key Principles:**

- Minimal CSS addition (~5 lines)
- No JavaScript required
- Single breakpoint (768px) per project spec
- Mobile-first approach (min-width only)

---

### REFACTOR Phase

- Verify CSS organization follows project standards
- Ensure no hardcoded values (use CSS custom properties)
- Confirm BEM naming preserved
- Check CSS file size still under 10KB

---

## Next Steps

1. **Review this checklist** with dev workflow
2. **Run skipped tests** to confirm they're registered: `npx playwright test story-2.2`
3. **Implement CSS changes** (add media query)
4. **Remove test.skip()** from tests one at a time
5. **Verify tests pass** (green phase)
6. **Update story status** to 'done' in sprint-status.yaml

---

## Knowledge Base References Applied

- **test-quality.md** - Given-When-Then structure, one assertion focus per test
- **selector-resilience.md** - Used existing BEM class selectors from selectors.ts
- **fixture-architecture.md** - Extended existing log fixture for step logging
- **timing-debugging.md** - Viewport changes with setViewportSize before assertions

---

## Test Execution Evidence

### Initial Test Run (RED Phase Verification)

**Command:** `npx playwright test story-2.2`

**Expected Results:**

```
Running 12 tests using 1 worker

  Story 2.2: Mobile Layout (320px)
    - AC-2.2.1/3: projects grid should display single column on mobile [skipped]
    - AC-2.2.5: hero text should not overflow at 320px viewport [skipped]
    - AC-2.2.6: CTA should have minimum 48x48px touch target [skipped]
    - AC-2.2.7: page should not have horizontal scroll at 320px [skipped]

  Story 2.2: Desktop Layout (768px)
    - AC-2.2.4: projects grid should display 3 columns on desktop [skipped]
    - AC-2.2.4: project cards should be laid out horizontally on desktop [skipped]

  Story 2.2: Large Desktop Layout (1200px)
    - layout should remain stable at 1200px viewport [skipped]

  Story 2.2: CSS Structure
    - AC-2.2.2: CSS should contain responsive media query [skipped]
    - AC-2.2.8: CSS should use Grid for projects layout [skipped]
    - CSS should use mobile-first approach (min-width only) [skipped]
    - CSS should have Responsive Layout section comment [skipped]

  Story 2.2: Responsive Transitions
    - layout should transition from 1-column to 3-column at 768px [skipped]

  12 skipped
```

**Status:** RED phase verified (all tests skipped, ready for implementation)

---

## Notes

- Story 2.2 builds on Story 2.1's CSS design tokens and grid setup
- The current grid already defaults to single column (no explicit columns)
- Only ~5 lines of CSS need to be added for this story
- CTA touch target likely already passes (56px height from current padding)
- Horizontal overflow tests may reveal edge cases at 320px

---

**Generated by BMad TEA Agent** - 2026-01-31
