# ATDD Checklist - Epic 1, Story 1.1: Hero Section Implementation

**Date:** 2026-01-31
**Author:** TEA Agent
**Primary Test Level:** E2E

---

## Story Summary

Implement the hero section of Alex Chen's photography portfolio with proper HTML5 structure and basic CSS styling.

**As a** visitor
**I want** to see a prominent hero section when I land on the page
**So that** I immediately understand who Alex Chen is and how to contact them

---

## Acceptance Criteria

1. **AC-1.1.1:** Page contains `<header>` element with class `hero` that spans full viewport width
2. **AC-1.1.2:** Hero contains `<h1>` with text "Alex Chen"
3. **AC-1.1.3:** Hero contains `<p>` with class `hero__tagline` containing "Capturing moments that last forever"
4. **AC-1.1.4:** Hero contains `<a>` with class `hero__cta` linking to `#contact`
5. **AC-1.1.5:** HTML is valid with HTML5 boilerplate (DOCTYPE, lang attribute, meta tags)
6. **AC-1.1.6:** Basic CSS exists (non-zero hero height, stylesheet linked)

---

## Failing Tests Created (RED Phase)

### E2E Tests (8 tests)

**File:** `tests/e2e/story-1.1-hero.spec.ts` (175 lines)

All tests use `test.skip()` and assert expected behavior. They will fail until implementation exists.

- **Test:** `AC-1.1.1: should have header element with hero class spanning full width`
  - **Status:** RED - `index.html` does not exist
  - **Verifies:** Header element with `.hero` class spans full viewport width

- **Test:** `AC-1.1.2: should display h1 with photographer name "Alex Chen"`
  - **Status:** RED - `index.html` does not exist
  - **Verifies:** h1 element contains exact text "Alex Chen"

- **Test:** `AC-1.1.3: should display tagline "Capturing moments that last forever"`
  - **Status:** RED - `index.html` does not exist
  - **Verifies:** Tagline paragraph with correct class and text

- **Test:** `AC-1.1.4: should have CTA button linking to #contact`
  - **Status:** RED - `index.html` does not exist
  - **Verifies:** CTA link with correct href and text "Get in Touch"

- **Test:** `AC-1.1.5: should have valid HTML5 boilerplate with semantic structure`
  - **Status:** RED - `index.html` does not exist
  - **Verifies:** HTML5 DOCTYPE, lang="en", charset, viewport meta, title, semantic elements

- **Test:** `AC-1.1.6: should have CSS styling applied to hero section`
  - **Status:** RED - `styles.css` does not exist
  - **Verifies:** Hero has non-zero dimensions, stylesheet is linked

- **Test:** `should define CSS custom properties for design tokens`
  - **Status:** RED - CSS custom properties not defined
  - **Verifies:** `:root` CSS variables for colors, typography, spacing

- **Test:** `should load homepage without HTTP errors`
  - **Status:** RED - `index.html` does not exist
  - **Verifies:** No 4xx/5xx HTTP errors during page load

### API Tests (0 tests)

Not applicable - this is a static HTML/CSS project with no backend.

---

## Data Factories Created

None required for this story - static HTML content only.

---

## Fixtures Used

**File:** `tests/support/fixtures/index.ts`

Existing fixtures from `@seontechnologies/playwright-utils`:
- `log` - Structured test step logging
- `recurse` - Retry utilities
- `networkErrorMonitor` - HTTP error detection

---

## Mock Requirements

None required - this is a static site with no external service dependencies.

---

## Required BEM Class Selectors

### Hero Section

From `tests/support/helpers/selectors.ts`:

- `.hero` - Hero section container (header element)
- `.hero__name` - Photographer name (h1 element)
- `.hero__tagline` - Tagline text (p element)
- `.hero__cta` - Call-to-action button (a element)

**Implementation Example:**

```html
<header class="hero">
  <h1 class="hero__name">Alex Chen</h1>
  <p class="hero__tagline">Capturing moments that last forever</p>
  <a href="#contact" class="hero__cta">Get in Touch</a>
</header>
```

---

## Implementation Checklist

### Test: AC-1.1.1 - Hero header with full width

**File:** `tests/e2e/story-1.1-hero.spec.ts`

**Tasks to make this test pass:**

- [ ] Create `index.html` with `<!DOCTYPE html>` declaration
- [ ] Add `<header class="hero">` element in body
- [ ] Ensure no max-width constraint on hero (full viewport width)
- [ ] Remove `test.skip()` from test
- [ ] Run test: `npx playwright test story-1.1-hero --grep "AC-1.1.1"`
- [ ] Verify test passes (green phase)

---

### Test: AC-1.1.2 - h1 with "Alex Chen"

**File:** `tests/e2e/story-1.1-hero.spec.ts`

**Tasks to make this test pass:**

- [ ] Add `<h1 class="hero__name">Alex Chen</h1>` inside hero
- [ ] Remove `test.skip()` from test
- [ ] Run test: `npx playwright test story-1.1-hero --grep "AC-1.1.2"`
- [ ] Verify test passes (green phase)

---

### Test: AC-1.1.3 - Tagline paragraph

**File:** `tests/e2e/story-1.1-hero.spec.ts`

**Tasks to make this test pass:**

- [ ] Add `<p class="hero__tagline">Capturing moments that last forever</p>` inside hero
- [ ] Remove `test.skip()` from test
- [ ] Run test: `npx playwright test story-1.1-hero --grep "AC-1.1.3"`
- [ ] Verify test passes (green phase)

---

### Test: AC-1.1.4 - CTA link to #contact

**File:** `tests/e2e/story-1.1-hero.spec.ts`

**Tasks to make this test pass:**

- [ ] Add `<a href="#contact" class="hero__cta">Get in Touch</a>` inside hero
- [ ] Remove `test.skip()` from test
- [ ] Run test: `npx playwright test story-1.1-hero --grep "AC-1.1.4"`
- [ ] Verify test passes (green phase)

---

### Test: AC-1.1.5 - HTML5 boilerplate

**File:** `tests/e2e/story-1.1-hero.spec.ts`

**Tasks to make this test pass:**

- [ ] Add `<!DOCTYPE html>` at top of file
- [ ] Add `<html lang="en">` opening tag
- [ ] Add `<meta charset="UTF-8">` in head
- [ ] Add `<meta name="viewport" content="width=device-width, initial-scale=1">` in head
- [ ] Add `<title>Alex Chen Photography</title>` in head
- [ ] Remove `test.skip()` from test
- [ ] Run test: `npx playwright test story-1.1-hero --grep "AC-1.1.5"`
- [ ] Verify test passes (green phase)

---

### Test: AC-1.1.6 - CSS styling applied

**File:** `tests/e2e/story-1.1-hero.spec.ts`

**Tasks to make this test pass:**

- [ ] Create `styles.css` file
- [ ] Add `<link rel="stylesheet" href="styles.css">` in head
- [ ] Add `.hero { padding: 2rem; }` (or similar) to give non-zero dimensions
- [ ] Remove `test.skip()` from test
- [ ] Run test: `npx playwright test story-1.1-hero --grep "AC-1.1.6"`
- [ ] Verify test passes (green phase)

---

### Test: CSS Custom Properties

**File:** `tests/e2e/story-1.1-hero.spec.ts`

**Tasks to make this test pass:**

- [ ] Add `:root` block in styles.css with CSS custom properties
- [ ] Define `--color-primary`, `--color-accent` (colors)
- [ ] Define `--font-heading` (typography)
- [ ] Define `--spacing-md` (spacing)
- [ ] Remove `test.skip()` from test
- [ ] Run test: `npx playwright test story-1.1-hero --grep "CSS custom properties"`
- [ ] Verify test passes (green phase)

---

### Test: Network Validation

**File:** `tests/e2e/story-1.1-hero.spec.ts`

**Tasks to make this test pass:**

- [ ] Ensure index.html exists and is valid
- [ ] Ensure styles.css exists and is linked correctly
- [ ] Remove `test.skip()` from test
- [ ] Run test: `npx playwright test story-1.1-hero --grep "HTTP errors"`
- [ ] Verify test passes (green phase)

---

## Running Tests

```bash
# Run all failing tests for this story
npx playwright test story-1.1-hero

# Run specific test file
npx playwright test tests/e2e/story-1.1-hero.spec.ts

# Run tests in headed mode (see browser)
npx playwright test story-1.1-hero --headed

# Debug specific test
npx playwright test story-1.1-hero --debug

# Run with specific project
npx playwright test story-1.1-hero --project=chromium

# Run and show report
npx playwright test story-1.1-hero && npx playwright show-report
```

---

## Red-Green-Refactor Workflow

### RED Phase (Complete)

**TEA Agent Responsibilities:**

- [x] All 8 tests written and failing (with `test.skip()`)
- [x] Existing fixtures and selectors reused
- [x] BEM class requirements documented
- [x] Implementation checklist created

**Verification:**

- All tests run and skip as expected
- Test assertions check expected behavior (not placeholders)
- Tests will fail when `test.skip()` is removed (feature not implemented)

---

### GREEN Phase (DEV Team - Next Steps)

**DEV Agent Responsibilities:**

1. **Create `index.html`** with HTML5 boilerplate (Task 1 from story)
2. **Add hero section markup** (Task 2 from story)
3. **Create `styles.css`** with minimal styling (Task 3 from story)
4. **Remove `test.skip()`** from tests one at a time
5. **Run tests** to verify they pass
6. **Check off tasks** in implementation checklist

**Key Principles:**

- One test at a time (don't try to fix all at once)
- Minimal implementation (exactly what the test expects)
- Run tests frequently for immediate feedback

---

### REFACTOR Phase (After All Tests Pass)

**DEV Agent Responsibilities:**

1. Verify all 8 tests pass (green phase complete)
2. Review HTML/CSS for quality (semantic elements, BEM naming)
3. Ensure code follows `project_context.md` standards
4. Verify CSS file size under 500 bytes
5. Run all tests to ensure no regressions

---

## Next Steps

1. **Review this checklist** with team
2. **Run failing tests** to confirm RED phase: `npx playwright test story-1.1-hero`
3. **Begin implementation** using checklist as guide
4. **Work one test at a time** (remove `test.skip()`, implement, verify)
5. **When all tests pass**, mark story as done

---

## Knowledge Base References Applied

- **selector-resilience.md** - BEM class selectors for stability
- **test-quality.md** - Given-When-Then format, one assertion per test
- **timing-debugging.md** - Proper async/await patterns
- **fixtures-composition.md** - Merged fixtures with playwright-utils

---

## Traceability Matrix

| AC ID | Acceptance Criteria | Test Name | Status |
|-------|---------------------|-----------|--------|
| AC-1.1.1 | `<header>` with class `hero` | `AC-1.1.1: should have header element...` | RED |
| AC-1.1.2 | `<h1>` with "Alex Chen" | `AC-1.1.2: should display h1...` | RED |
| AC-1.1.3 | `<p class="hero__tagline">` | `AC-1.1.3: should display tagline...` | RED |
| AC-1.1.4 | `<a class="hero__cta">` | `AC-1.1.4: should have CTA button...` | RED |
| AC-1.1.5 | Valid semantic HTML | `AC-1.1.5: should have valid HTML5...` | RED |
| AC-1.1.6 | Basic CSS exists | `AC-1.1.6: should have CSS styling...` | RED |

---

**Generated by BMad TEA Agent** - 2026-01-31
