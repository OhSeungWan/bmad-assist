# Test Design: Epic 1 - Core Page Structure (Story 1.1)

**Date:** 2026-01-31
**Author:** User
**Status:** Draft

---

## Executive Summary

**Scope:** Epic-level test design for Story 1.1 - Hero Section Implementation

**Risk Summary:**

- Total risks identified: 6
- High-priority risks (≥6): 1
- Critical categories: BUS (business), TECH (technical)

**Coverage Summary:**

- P0 scenarios: 4 (~2 hours)
- P1 scenarios: 2 (~1 hour)
- P2/P3 scenarios: 0 (0 hours)
- **Total effort**: ~3 hours (~0.5 days)

---

## Risk Assessment

### High-Priority Risks (Score ≥6)

| Risk ID | Category | Description | Probability | Impact | Score | Mitigation | Owner | Timeline |
|---------|----------|-------------|-------------|--------|-------|------------|-------|----------|
| R-002 | BUS | Hero section missing required content (name, tagline, CTA) | 2 | 3 | 6 | P0 tests for all 6 acceptance criteria | QA | Sprint 1 |

### Medium-Priority Risks (Score 3-4)

| Risk ID | Category | Description | Probability | Impact | Score | Mitigation | Owner |
|---------|----------|-------------|-------------|--------|-------|------------|-------|
| R-001 | TECH | BEM class naming inconsistency breaks selectors | 2 | 2 | 4 | Selector constants in helpers, validate against project_context.md | Dev |
| R-005 | BUS | CTA link malformed or broken | 2 | 2 | 4 | P0 test for href attribute validation | QA |
| R-004 | OPS | CSS file missing or not linked | 1 | 3 | 3 | P0 test for CSS load verification | QA |

### Low-Priority Risks (Score 1-2)

| Risk ID | Category | Description | Probability | Impact | Score | Action |
|---------|----------|-------------|-------------|--------|-------|--------|
| R-003 | TECH | HTML validation errors (invalid markup) | 1 | 2 | 2 | Monitor |
| R-006 | TECH | h1 heading not unique (accessibility violation) | 1 | 2 | 2 | Monitor |

### Risk Category Legend

- **TECH**: Technical/Architecture (flaws, integration, scalability)
- **SEC**: Security (access controls, auth, data exposure)
- **PERF**: Performance (SLA violations, degradation, resource limits)
- **DATA**: Data Integrity (loss, corruption, inconsistency)
- **BUS**: Business Impact (UX harm, logic errors, revenue)
- **OPS**: Operations (deployment, config, monitoring)

---

## Test Coverage Plan

### P0 (Critical) - Run on every commit

**Criteria**: Blocks core journey + High risk (≥6) + No workaround

| AC ID | Requirement | Test Level | Risk Link | Test | Owner | Notes |
|-------|-------------|------------|-----------|------|-------|-------|
| AC-1.1.1 | Page contains `<header>` element with class `hero` | E2E | R-002 | `homepage.spec.ts` | QA | Existing coverage via `assertHeroSection()` |
| AC-1.1.2 | Hero contains `<h1>` with text "Alex Chen" | E2E | R-002 | `homepage.spec.ts` | QA | Existing coverage with `toContainText` |
| AC-1.1.3 | Hero contains `<p>` with class `hero__tagline` | E2E | R-002 | `homepage.spec.ts` | QA | Existing coverage via selectors |
| AC-1.1.4 | Hero contains `<a>` with class `hero__cta` linking to contact | E2E | R-002, R-005 | `homepage.spec.ts` | QA | Existing coverage, href validation |

**Total P0**: 4 scenarios, ~2 hours

### P1 (High) - Run on PR to main

**Criteria**: Important features + Medium risk (3-4) + Common workflows

| AC ID | Requirement | Test Level | Risk Link | Test | Owner | Notes |
|-------|-------------|------------|-----------|------|-------|-------|
| AC-1.1.5 | HTML is valid and uses semantic elements | E2E | R-003 | `homepage.spec.ts` | QA | Existing `assertSemanticStructure()` |
| AC-1.1.6 | Basic CSS exists to make hero section visible | E2E | R-004 | NEW | QA | Verify computed styles non-empty |

**Total P1**: 2 scenarios, ~1 hour

### P2/P3 - N/A for this story

No P2/P3 scenarios identified. Story is small and focused.

---

## Execution Order

### Smoke Tests (<30s)

**Purpose**: Fast feedback, catch build-breaking issues

- [x] Page loads without HTTP errors (`networkErrorMonitor`)
- [x] Hero section visible (`.hero` exists)

**Total**: 2 scenarios

### P0 Tests (<2 min)

**Purpose**: Critical path validation - all acceptance criteria

- [x] AC-1.1.1: Hero header exists (E2E)
- [x] AC-1.1.2: h1 contains "Alex Chen" (E2E)
- [x] AC-1.1.3: Tagline visible (E2E)
- [x] AC-1.1.4: CTA link valid (E2E)

**Total**: 4 scenarios

### P1 Tests (<3 min)

**Purpose**: Extended validation

- [x] AC-1.1.5: Semantic structure (E2E)
- [ ] AC-1.1.6: CSS styling applied (E2E) - **NEW TEST NEEDED**

**Total**: 2 scenarios

---

## Existing Test Coverage Analysis

### Already Covered by `homepage.spec.ts`

| Test | ACs Covered | Status |
|------|-------------|--------|
| `should display hero section with photographer name and tagline` | AC-1.1.1, AC-1.1.2, AC-1.1.3 | ✅ |
| `should have CTA button linking to contact section` | AC-1.1.4 | ✅ |
| `should have proper semantic HTML structure` | AC-1.1.5 (partial) | ✅ |

### Already Covered by `accessibility.spec.ts`

| Test | ACs Covered | Status |
|------|-------------|--------|
| `should have proper heading hierarchy` | AC-1.1.2 (h1 uniqueness) | ✅ |

### Gap: AC-1.1.6 (CSS Styling)

**New test needed** to verify basic CSS is applied:

```typescript
test('should have CSS styling applied to hero section', async ({ page, log }) => {
  // Given: User navigates to homepage
  await page.goto('/');
  await log.step('Verifying hero section styling');

  // When: Page loads
  const hero = page.locator('.hero');

  // Then: Hero should have visible styling (non-zero dimensions, background or text color)
  const box = await hero.boundingBox();
  expect(box).not.toBeNull();
  expect(box!.height).toBeGreaterThan(0);

  // Verify CSS custom properties are loaded
  await assertCSSCustomProperties(page);
});
```

---

## Resource Estimates

### Test Development Effort

| Priority | Count | Hours/Test | Total Hours | Notes |
|----------|-------|------------|-------------|-------|
| P0 | 4 | 0.5 | 2 | Already exists |
| P1 | 2 | 0.5 | 1 | 1 new test needed |
| **Total** | **6** | - | **~3 hours** | **~0.5 days** |

### Prerequisites

**Test Framework:**
- Playwright with `@seontechnologies/playwright-utils`
- Fixtures: `log`, `networkErrorMonitor`, `recurse`

**Selectors:**
- `heroSelectors` (defined in `tests/support/helpers/selectors.ts`)
- `projectsSelectors` (defined, not needed for Story 1.1)

**Assertions:**
- `assertHeroSection()` - validates hero structure
- `assertSemanticStructure()` - validates HTML5 elements
- `assertCSSCustomProperties()` - validates CSS variables

---

## Quality Gate Criteria

### Pass/Fail Thresholds

- **P0 pass rate**: 100% (no exceptions)
- **P1 pass rate**: ≥95% (waivers required for failures)
- **High-risk mitigations**: 100% complete

### Coverage Targets

- **Acceptance criteria coverage**: 100% (6/6 ACs)
- **Risk mitigation coverage**: 100% for R-002

### Non-Negotiable Requirements

- [x] All P0 tests pass
- [x] No high-risk (≥6) items unmitigated
- [x] Hero section displays correctly in chromium
- [ ] AC-1.1.6 test added (CSS styling)

---

## Mitigation Plans

### R-002: Hero content missing (Score: 6)

**Mitigation Strategy:** Comprehensive E2E test coverage for all 6 acceptance criteria
**Owner:** QA
**Timeline:** Sprint 1
**Status:** In Progress
**Verification:** All P0 tests passing, AC traceability matrix complete

---

## Assumptions and Dependencies

### Assumptions

1. Static HTML file will be served via simple HTTP server for tests
2. BEM naming convention will be followed per `project_context.md`
3. No JavaScript means no async loading concerns

### Dependencies

1. `index.html` created with hero section markup - Required before tests run
2. `styles.css` linked in HTML - Required for AC-1.1.6

### Risks to Plan

- **Risk**: Implementation not started yet
  - **Impact**: Tests will fail initially (expected for ATDD)
  - **Contingency**: Tests designed to fail gracefully with clear error messages

---

## Follow-on Workflows (Manual)

- Run `*atdd` to generate failing P0 tests (if not already covered)
- Run `*automate` for broader coverage once implementation exists
- Run `*trace` to generate traceability matrix after implementation

---

## Traceability Matrix

| AC ID | Acceptance Criteria | Test File | Test Name | Status |
|-------|---------------------|-----------|-----------|--------|
| AC-1.1.1 | `<header>` with class `hero` | `homepage.spec.ts` | `assertHeroSection()` | ✅ Covered |
| AC-1.1.2 | `<h1>` with "Alex Chen" | `homepage.spec.ts` | `toContainText('Alex Chen')` | ✅ Covered |
| AC-1.1.3 | `<p class="hero__tagline">` | `homepage.spec.ts` | `heroSelectors.tagline` | ✅ Covered |
| AC-1.1.4 | `<a class="hero__cta">` | `homepage.spec.ts` | `ctaButton.getAttribute('href')` | ✅ Covered |
| AC-1.1.5 | Valid semantic HTML | `homepage.spec.ts` | `assertSemanticStructure()` | ✅ Covered |
| AC-1.1.6 | Basic CSS exists | NEW | `assertCSSCustomProperties()` | ⚠️ Needs Test |

---

## Approval

**Test Design Approved By:**

- [ ] Product Manager: _______ Date: _______
- [ ] Tech Lead: _______ Date: _______
- [ ] QA Lead: _______ Date: _______

**Comments:**

---

## Appendix

### Knowledge Base References

- `risk-governance.md` - Risk classification framework
- `probability-impact.md` - Risk scoring methodology
- `test-levels-framework.md` - Test level selection
- `test-priorities-matrix.md` - P0-P3 prioritization

### Related Documents

- PRD: `docs/prd.md` (FR-001)
- Epic: `docs/epics.md` (Epic 1, Story 1.1)
- Architecture: `docs/architecture.md` (ADR-001 to ADR-006)
- Project Context: `docs/project_context.md`

---

**Generated by**: BMad TEA Agent - Test Architect Module
**Workflow**: `testarch/test-design`
**Version**: 4.0 (BMad v6)
