# Story 2.2: Mobile-First Responsive Layout

Status: done

<!-- Note: Validation is optional. Run validate-create-story for quality check before dev-story. -->

## Story

As a **mobile user**,
I want the **portfolio to display correctly on my device**,
so that **I can browse Alex's work comfortably regardless of screen size**.

## Prerequisites (Pre-existing from Story 2.1)

The following must be verified before implementation:
- CSS custom properties defined in `:root` (colors, fonts, spacing, border-radius)
- Typography tokens applied (body, headings, tagline)
- Hero section styling complete (background, padding, CTA button)
- Project card styling complete (shadows, hover states, focus states)
- `prefers-reduced-motion` media query exists
- `index.html` contains `<meta name="viewport" content="width=device-width, initial-scale=1">` in `<head>` section

## Acceptance Criteria

1. **AC-2.2.1:** Verify that base styles (without media queries) result in single-column layout for `.projects__grid` (mobile < 768px)
2. **AC-2.2.2:** On desktop (>= 768px): project cards display in 3-column grid via `@media (min-width: 768px)` query
3. **AC-2.2.3:** Hero section text (name and tagline) renders without overflow at 320px viewport (iPhone SE and older mobile devices)
4. **AC-2.2.4:** CTA button has minimum touch target of 48x48 pixels on mobile (VERIFICATION ONLY - CTA from Story 2.1 already meets this requirement)
5. **AC-2.2.5:** No horizontal scrolling occurs at 320px minimum viewport width
6. **AC-2.2.6:** `index.html` contains `<meta name="viewport" content="width=device-width, initial-scale=1">` in `<head>` section (required for responsive scaling)

## Tasks / Subtasks

- [x] Task 0: Verify prerequisites from Story 2.1 (AC: Prerequisites)
  - [x] 0.1: Confirm Story 2.1 artifacts intact: CSS tokens, Typography, Hero/Card styling, viewport meta tag, `prefers-reduced-motion` query

- [x] Task 1: Verify mobile-first base styles (AC: 1)
  - [x] 1.1: Confirm `.projects__grid` does NOT have `grid-template-columns` in base styles (defaults to single column)

- [x] Task 2: Add responsive breakpoint media query (AC: 2)
  - [x] 2.1: Add `/* Responsive Layout */` section comment after `/* Accessibility */` section
  - [x] 2.2: Add `@media (min-width: 768px)` media query with `grid-template-columns: repeat(3, 1fr)` for `.projects__grid`

- [x] Task 3: Verify CTA touch target (AC: 4)
  - [x] 3.1: Verify CTA meets 48x48px minimum (Dev Notes confirm 56px height - no changes needed)

- [x] Task 4: Prevent horizontal overflow (AC: 5)
  - [x] 4.1: Verify `.hero` and `.projects` don't cause horizontal scroll at 320px

- [x] Task 5: Create ATDD test file (AC: all)
  - [x] 5.1: Create `tests/e2e/story-2.2-responsive.spec.ts`
  - [x] 5.2: Add test for single-column layout at 320px mobile viewport
  - [x] 5.3: Add test for 3-column layout at 768px+ desktop viewport
  - [x] 5.4: Add test for CTA touch target (minimum 48x48px per UX spec)
  - [x] 5.5: Add test for no horizontal scrollbar at 320px
  - [x] 5.6: Add test verifying `@media (min-width: 768px)` exists in CSS file
  - [x] 5.7: Add test verifying viewport meta tag exists in index.html

- [x] Task 6: Verify implementation (all AC)
  - [x] 6.1: Visual test at 320px viewport - single column layout, no horizontal scroll
  - [x] 6.2: Visual test at 768px viewport - 3-column grid layout
  - [x] 6.3: Visual test at 1200px viewport - layout stable
  - [x] 6.4: Run all Playwright tests (existing + new Story 2.2 tests)
  - [x] 6.5: Verify CSS file size still under 10KB

## Dev Notes

### Architecture Constraints

**From ADR-001 (Pure HTML/CSS Stack):**
- NO JavaScript - responsive layout must use CSS only
- NO external dependencies or build tools
- Vanilla CSS3 media queries only

**From ADR-005 (Mobile-First Responsive Design):**
- Base styles target mobile (smallest viewports)
- Media queries enhance for larger screens using `min-width`
- Single breakpoint at 768px per project specification
- NEVER use `max-width` media queries

**From NFR-001 (Performance):**
- CSS file must remain under 10KB
- Page loads in under 1 second on 3G

**From NFR-003 (Accessibility):**
- Touch targets minimum 48x48px for mobile (per UX spec, exceeds WCAG 2.1 AA minimum)
- Respect `prefers-reduced-motion` (already implemented in Story 2.1)

### Current CSS State (from Story 2.1 completion)

The `.projects__grid` currently has:
```css
.projects__grid {
  display: grid;
  gap: var(--spacing-md);
}
```

**NOTE:** No `grid-template-columns` is defined, which means CSS Grid defaults to single column. This is already mobile-first compliant! The task is to ADD the desktop breakpoint, not modify base styles.

### Required CSS Addition

Add after the `/* Accessibility */` section:

```css
/* Responsive Layout */
@media (min-width: 768px) {
  .projects__grid {
    grid-template-columns: repeat(3, 1fr);
  }
}
```
**Note:** The `gap: var(--spacing-md)` from base styles is automatically preserved.

### CSS Property Ordering Standard

From `project_context.md`, properties ordered:
1. **Positioning**: position, top, right, bottom, left, z-index
2. **Display**: display, flex, grid, align, justify
3. **Box model**: width, height, margin, padding, border
4. **Typography**: font-family, font-size, font-weight, line-height, text-align, color
5. **Visual**: background, box-shadow, opacity, filter
6. **Misc**: transition, animation, cursor, outline

### CTA Button Touch Target Analysis

Current CTA styling (from `styles.css:69-78`):
```css
.hero__cta {
  display: inline-block;
  padding: var(--spacing-sm) var(--spacing-md);  /* 16px 32px */
  ...
  font-size: var(--font-size-base);  /* inherited - 16px */
}
```

**Calculation:**
- Font size: 16px (inherited from body)
- Line height: 1.5 (from body) = 24px
- Vertical padding: 16px + 16px = 32px
- Total height: 24px + 32px = 56px (exceeds 48px requirement)
- Horizontal: 32px + content + 32px (exceeds 48px requirement)

**Verdict:** CTA already meets 48x48px touch target. No changes needed.

### Viewport Testing Widths

Per UX spec and epics.md:
- **320px**: Minimum mobile width (iPhone SE, older devices)
- **768px**: Breakpoint threshold (tablet)
- **1200px**: Desktop (verify layout stability)

### Horizontal Scroll Prevention

Potential causes of horizontal scroll:
1. Fixed-width elements exceeding viewport
2. Padding/margin causing overflow
3. Images or media without `max-width: 100%`

Current implementation is safe because:
- `.hero` uses `width: 100%` and padding tokens
- `.projects` uses padding tokens
- No fixed-width elements exist

**Note:** Avoid using `overflow-x: hidden` as a first solution - it can hide genuine layout bugs. Fix root cause instead.

### Antipatterns to AVOID (from Epic 1 Code Reviews)

| Antipattern | Fix | Source |
|-------------|-----|--------|
| Hardcoded CSS values | Use `var(--token-name)` for all design tokens | Story 1.1 antipatterns |
| Missing media query comment | Add `/* Responsive Layout */` section header | CSS organization standard |
| `max-width` media queries | Use `min-width` only (mobile-first) | ADR-005 |
| Multiple breakpoints | Single 768px breakpoint per spec | Project Context |

### Test File Structure

Create `tests/e2e/story-2.2-responsive.spec.ts`:

```typescript
/**
 * ATDD Tests for Story 2.2: Mobile-First Responsive Layout
 *
 * Acceptance Criteria:
 * - AC-2.2.1: Base styles result in single-column layout (mobile < 768px)
 * - AC-2.2.2: Desktop (>=768px): 3-column grid via @media (min-width: 768px)
 * - AC-2.2.3: Hero text renders without overflow at 320px viewport
 * - AC-2.2.4: CTA touch target >= 48x48px (verification only)
 * - AC-2.2.5: No horizontal scroll at 320px
 * - AC-2.2.6: Viewport meta tag exists in index.html
 */
```

Use Playwright viewport configuration:
```typescript
// Mobile viewport
test.use({ viewport: { width: 320, height: 568 } });

// Tablet/Desktop viewport
test.use({ viewport: { width: 768, height: 1024 } });
```

Or within individual tests:
```typescript
await page.setViewportSize({ width: 320, height: 568 });
```

### What NOT To Do

- Do NOT modify HTML structure (Epic 1 complete, viewport meta tag should already exist)
- Do NOT add additional breakpoints beyond 768px
- Do NOT use JavaScript for responsive behavior
- Do NOT use `max-width` media queries
- Do NOT add footer or contact sections (out of scope)
- Do NOT modify existing hover/focus states from Story 2.1
- Do NOT touch the `prefers-reduced-motion` media query
- Do NOT use `overflow-x: hidden` as first solution - fix root cause of horizontal scroll instead

### File Locations

| File | Path | Action |
|------|------|--------|
| styles.css | `/styles.css` (project root) | MODIFY (add media query) |
| index.html | `/index.html` (project root) | VERIFY (check viewport meta tag exists) |
| story-2.2-responsive.spec.ts | `/tests/e2e/story-2.2-responsive.spec.ts` | CREATE (ATDD tests) |

### Test Fixture Usage

Import from existing test infrastructure:
```typescript
import { test, expect } from '../support/fixtures';
import { heroSelectors, projectsSelectors } from '../support/helpers/selectors';
```

### Performance Budget

From Architecture:
- CSS size: < 10KB (current ~3.2KB, adding ~100 bytes acceptable)
- Total page weight: < 20KB (excluding images)

### Definition of Done (from epics.md)

1. All acceptance criteria are checked off
2. HTML validates (no changes expected)
3. CSS follows BEM naming throughout
4. Code is committed with descriptive message
5. Manual visual verification passes at 320px, 768px, 1200px
6. All Playwright tests pass (existing + new)

### UX Design Reference

From `docs/ux-spec.md`:

**Mobile Layout (< 768px):**
```
┌──────────────────────┐
│     ALEX CHEN        │
│  Capturing moments   │
│  that last forever   │
│   [ Get in Touch ]   │
├──────────────────────┤
│      Portfolio       │
├──────────────────────┤
│  ┌────────────────┐  │
│  │    Wedding     │  │
│  └────────────────┘  │
│  ┌────────────────┐  │
│  │    Portrait    │  │
│  └────────────────┘  │
│  ┌────────────────┐  │
│  │   Landscape    │  │
│  └────────────────┘  │
└──────────────────────┘
```

**Desktop Layout (>= 768px):**
```
┌────────────────────────────────────────────────────┐
│                    ALEX CHEN                       │
│          Capturing moments that last forever       │
│                  [ Get in Touch ]                  │
├────────────────────────────────────────────────────┤
│                     Portfolio                      │
├────────────────────────────────────────────────────┤
│  ┌──────────────┐ ┌──────────────┐ ┌──────────────┐│
│  │   Wedding    │ │   Portrait   │ │  Landscape   ││
│  └──────────────┘ └──────────────┘ └──────────────┘│
└────────────────────────────────────────────────────┘
```

### Project Structure Notes

**Alignment with unified project structure:**
- Single `styles.css` file in project root (no partials/imports)
- All styles use CSS custom properties from `:root`
- BEM naming convention maintained
- Single 768px breakpoint per project specification

**Detected conflicts or variances:** None - this story completes the responsive design system.

### References

- [Source: docs/project_context.md#Responsive Design]
- [Source: docs/architecture.md#ADR-005 Mobile-First Responsive Design]
- [Source: docs/prd.md#FR-004: Mobile-Responsive Layout]
- [Source: docs/ux-spec.md#Layout Design (wireframes)]
- [Source: docs/ux-spec.md#Touch Targets]
- [Source: docs/epics.md#Story 2.2: Mobile-First Responsive Layout]
- [Source: _bmad-output/implementation-artifacts/2-1-css-design-tokens-and-typography.md]
- [Source: _bmad-output/implementation-artifacts/retrospectives/epic-1-retro-20260131.md]
- [Source: _bmad-output/implementation-artifacts/antipatterns/epic-1-code-antipatterns.md]

## Dev Agent Record

### Agent Model Used

claude-opus-4-5-20251101

### Debug Log References

N/A - Implementation proceeded without errors

<!-- CODE_REVIEW_SYNTHESIS_START -->
## Synthesis Summary

Synthesis of 7 independent code review findings for Story 2.2 (Mobile-First Responsive Layout). The implementation correctly fulfills all acceptance criteria with responsive layout working at 320px, 768px, and 1200px viewports. Reviewers identified 5 valid issues (3 high, 2 low severity) that were addressed, and 7 false positives that were dismissed.

**Summary:**
- Issues verified: 5 (3 high priority, 2 low priority)
- False positives dismissed: 7
- Source code fixes applied: 2 files modified (tests/e2e/story-2.2-responsive.spec.ts, styles.css)
- Test results: 12/12 Chromium tests passing

## Validations Quality

| Reviewer | Score | Assessment |
|----------|-------|------------|
| A | 6/10 | Found 2 valid issues (overflow-wrap, missing min-width) but also raised false positives about focusability and max-width reset |
| B | 5/10 | Correctly identified brittle `.split(' ')` test issue but incorrectly flagged universal selector as critical performance problem |
| C | 4/10 | Focus on documentation inconsistencies rather than actual code issues |
| D | 8/10 | Practical feedback on hardcoded values and fs.readFileSync usage |
| E | 7/10 | Correctly identified the `.split(' ')` brittleness issue affecting cross-browser compatibility |
| F | 3/10 | Claimed "lying tests" that were actually working correctly; suggested tablet breakpoint violating ADR-005 |
| G | 7/10 | Identified design token opportunities and practical UX concerns (some out of scope) |

**Overall assessment:** Reviewers A, B, D, and E provided the most actionable feedback. Reviewers F and G raised issues outside the scope of this story (tablet breakpoints, tappable cards).

## Issues Verified (by severity)

### High

- **Issue**: Brittle `.split(' ')` for parsing computed grid values causes cross-browser test failures | **Source**: Reviewers B, E, F | **File**: `tests/e2e/story-2.2-responsive.spec.ts` | **Fix**: Changed all instances to use `.trim().split(/\s+/).filter(v => v.length > 0)` pattern to handle browser whitespace normalization

- **Issue**: Missing explicit `min-width: 48px; min-height: 48px` on CTA button makes touch target dependent on content length | **Source**: Reviewers A, F, C | **File**: `styles.css` | **Fix**: Added `min-width: 48px; min-height: 48px;` to `.hero__cta` rule for WCAG 2.1 AA compliance

- **Issue**: Missing `overflow-wrap: break-word` and `word-wrap: break-word` on hero text elements | **Source**: Reviewers A, F | **File**: `styles.css` | **Fix**: Added `max-width: 100%; overflow-wrap: break-word; word-wrap: break-word;` to `.hero__name` and `.hero__tagline`

### Low

- **Issue**: Hardcoded transition duration `0.2s` and shadow values violate ADR-003 design token principle | **Source**: Reviewers B, D | **File**: `styles.css` | **Fix**: Added `--transition-duration: 0.2s;`, `--shadow-sm: 0 2px 8px rgba(0, 0, 0, 0.1);`, `--shadow-md: 0 4px 16px rgba(0, 0, 0, 0.15);` to `:root` and updated selectors to use tokens

- **Issue**: 5px tolerance in card positioning test is too permissive for grid alignment | **Source**: Reviewer F | **File**: `tests/e2e/story-2.2-responsive.spec.ts` | **Fix**: Changed `toBeLessThan(5)` to `toBeLessThanOrEqual(1)` for stricter grid alignment verification

## Issues Dismissed

- **Claimed Issue**: Project cards not keyboard accessible (missing `tabindex="0"`) | **Raised by**: Reviewer A | **Dismissal Reason**: Cards are decorative placeholders per project scope. Real images would be `<a>` wrapped or have explicit links in production. Focus-visible styles exist for future interactivity.

- **Claimed Issue**: Missing `img { max-width: 100% }` reset will cause overflow with real images | **Raised by**: Reviewer A | **Dismissal Reason**: No `<img>` tags exist - using `div` placeholders with `role="img"`. Out of scope for v1 per architecture document.

- **Claimed Issue**: Universal selector `*` in `prefers-reduced-motion` causes performance overhead | **Raised by**: Reviewer B | **Dismissal Reason**: The universal selector with `!important` is a well-established accessibility pattern for ensuring reduced motion preferences override all animations. The performance impact is negligible for a static 3.5KB CSS file.

- **Claimed Issue**: Story "lies" about creating tests (tests were pre-existing) | **Raised by**: Reviewer C | **Dismissal Reason**: Task wording inconsistency (Create vs Enable), not a functional issue. Completion Notes clarify tests were enabled. Minor documentation-only concern.

- **Claimed Issue**: `@media (hover: hover)` violates "single breakpoint" architecture | **Raised by**: Reviewers B, D | **Dismissal Reason**: ADR-005 specifically refers to viewport breakpoints (768px). Interaction media queries (`hover:`, `prefers-reduced-motion`) are separate architectural concerns.

- **Claimed Issue**: Hero background "boxed" by `max-width` creating white gutters | **Raised by**: Reviewer G | **Dismissal Reason**: Centered layout with `max-width: 1200px` is intentional per project context. Full-width background is not specified in requirements.

- **Claimed Issue**: Cards should be tappable/linked per UX spec | **Raised by**: Reviewer G | **Dismissal Reason**: Out of scope for Story 2.2 (responsive layout only). Card linking would be a separate feature story.

- **Claimed Issue**: `x >= 0` assertion is too weak for hero position test | **Raised by**: Reviewer B | **Dismissal Reason**: For viewport overflow testing, `x >= 0` validates the element starts within viewport. Combined with `x + width <= viewport`, it provides complete boundary verification.

## Changes Applied

**File**: `tests/e2e/story-2.2-responsive.spec.ts`
**Change**: Fixed brittle `.split(' ')` column counting and improved positioning test tolerance

**Before** (5 locations - lines 61, 191, 265, 395, 406):
```typescript
const columnCount = gridTemplateColumns.split(' ').length;
expect(columnCount).toBe(1);
```

**After**:
```typescript
// Use regex split to handle browser whitespace normalization
const columnCount = gridTemplateColumns.trim().split(/\s+/).filter(v => v.length > 0).length;
expect(columnCount).toBe(1);
```

**Before** (lines 227-228):
```typescript
expect(Math.abs(firstCard!.y - secondCard!.y)).toBeLessThan(5);
expect(Math.abs(secondCard!.y - thirdCard!.y)).toBeLessThan(5);
```

**After**:
```typescript
expect(Math.abs(firstCard!.y - secondCard!.y)).toBeLessThanOrEqual(1);
expect(Math.abs(secondCard!.y - thirdCard!.y)).toBeLessThanOrEqual(1);
```

---

**File**: `styles.css`
**Change**: Added overflow protection for hero text and explicit touch target for CTA

**Before** (`.hero__name`, `.hero__tagline`):
```css
.hero__name {
  font-family: var(--font-heading);
  font-size: var(--font-size-xxl);
}

.hero__tagline {
  font-size: var(--font-size-lg);
}
```

**After**:
```css
.hero__name {
  font-family: var(--font-heading);
  font-size: var(--font-size-xxl);
  max-width: 100%;
  overflow-wrap: break-word;
  word-wrap: break-word;
}

.hero__tagline {
  font-size: var(--font-size-lg);
  max-width: 100%;
  overflow-wrap: break-word;
  word-wrap: break-word;
}
```

**Before** (`.hero__cta`):
```css
.hero__cta {
  display: inline-block;
  padding: var(--spacing-sm) var(--spacing-md);
  border-radius: var(--border-radius);
  /* ... */
  transition: transform 0.2s ease, filter 0.2s ease;
}
```

**After**:
```css
.hero__cta {
  display: inline-block;
  padding: var(--spacing-sm) var(--spacing-md);
  min-width: 48px;
  min-height: 48px;
  border-radius: var(--border-radius);
  /* ... */
  transition: transform var(--transition-duration) ease, filter var(--transition-duration) ease;
}
```

---

**File**: `styles.css`
**Change**: Added design tokens for transitions and shadows per ADR-003

**Before** (`:root`):
```css
:root {
  --color-primary: #1a1a2e;
  /* ... existing tokens ... */
  --card-image-height: 200px;
}
```

**After**:
```css
:root {
  --color-primary: #1a1a2e;
  /* ... existing tokens ... */
  --card-image-height: 200px;
  --transition-duration: 0.2s;
  --shadow-sm: 0 2px 8px rgba(0, 0, 0, 0.1);
  --shadow-md: 0 4px 16px rgba(0, 0, 0, 0.15);
}
```

**Before** (`.projects__card`):
```css
.projects__card {
  /* ... */
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  transition: box-shadow 0.2s ease, transform 0.2s ease;
}
```

**After**:
```css
.projects__card {
  /* ... */
  box-shadow: var(--shadow-sm);
  transition: box-shadow var(--transition-duration) ease, transform var(--transition-duration) ease;
}
```

**Before** (`.projects__card:hover`):
```css
.projects__card:hover {
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.15);
  transform: translateY(-2px);
}
```

**After**:
```css
.projects__card:hover {
  box-shadow: var(--shadow-md);
  transform: translateY(-2px);
}
```

## Files Modified

- styles.css
- tests/e2e/story-2.2-responsive.spec.ts

## Suggested Future Improvements

- **Scope**: Replace `fs.readFileSync` with browser-based CSS inspection in E2E tests | **Rationale**: Direct file system access couples tests to file structure; using `page.evaluate()` to access `document.styleSheets` would be more idiomatic for E2E | **Effort**: Medium (requires refactoring CSS static analysis tests)

- **Scope**: Add tablet-specific breakpoint (768px-1024px) with 2-column layout | **Rationale**: Current 3-column layout at 768px creates cramped cards (~200px wide). 2 columns would improve tablet UX. | **Effort**: Low (one additional media query) - *Note: This would require updating ADR-005 which specifies single 768px breakpoint*

- **Scope**: Consider `img` tags instead of `div` placeholders for project images | **Rationale**: Using actual `<img>` with `alt` attributes would better align with semantic HTML standards and accessibility | **Effort**: Low (HTML change + add `img { max-width: 100% }` reset)

## Test Results

Chromium project: 12 passed (3.4s)
- All Story 2.2 responsive layout tests passing
- Cross-browser (Firefox, WebKit) tests fail pre-existing to this synthesis (fixture project in larger repo)

Note: The CSS file size increased from 3,470 bytes to approximately 3,580 bytes after adding design tokens and overflow protection - still well under the 10KB performance budget.

<!-- CODE_REVIEW_SYNTHESIS_END -->

<!-- METRICS_JSON_START -->
{
  "quality": {
    "actionable_ratio": 0.714,
    "specificity_score": 0.857,
    "evidence_quality": 0.724,
    "follows_template": true,
    "internal_consistency": 0.857
  },
  "consensus": {
    "agreed_findings": 3,
    "unique_findings": 7,
    "disputed_findings": 2,
    "missed_findings": 0,
    "agreement_score": 0.25,
    "false_positive_count": 7
  }
}
<!-- METRICS_JSON_END -->

### Completion Notes List

1. **Prerequisites verified**: All Story 2.1 outputs confirmed intact - CSS custom properties, typography tokens, hero/card styling, `prefers-reduced-motion` media query, and viewport meta tag all present.

2. **Mobile-first base styles verified**: `.projects__grid` has `display: grid` and `gap: var(--spacing-md)` without `grid-template-columns`, correctly defaulting to single column on mobile.

3. **Responsive media query added**: Added `/* Responsive Layout */` section with `@media (min-width: 768px)` containing `grid-template-columns: repeat(3, 1fr)` per ADR-005 mobile-first approach.

4. **CTA touch target verified and hardened**: Added explicit `min-width: 48px; min-height: 48px;` to `.hero__cta` for guaranteed WCAG 2.1 AA compliance regardless of content.

5. **Horizontal overflow verified**: No horizontal scroll at 320px viewport - `.hero` uses `width: 100%` and both sections use padding tokens. Added `overflow-wrap` protection for longer text.

6. **ATDD tests enabled and hardened**: Converted all 12 tests in `story-2.2-responsive.spec.ts` from `test.skip()` to `test()`. Fixed brittle `.split(' ')` column counting to use regex pattern for cross-browser compatibility.

7. **Test results**: 12/12 Chromium tests passing after synthesis fixes.

8. **Performance budget**: CSS file size is ~3.58KB, well under 10KB limit.

9. **Design tokens added**: Extended `:root` with `--transition-duration`, `--shadow-sm`, and `--shadow-md` per ADR-003 requirements.

10. **Code review synthesis applied**: Fixed 5 verified issues from 7 reviewer reports, dismissed 7 false positives. All fixes maintain backward compatibility.

### Change Log

| Date | Author | Change |
|------|--------|--------|
| 2026-01-31 | BMad | Story created with comprehensive developer context from create-story workflow |
| 2026-01-31 | claude-opus-4-5 | Implemented responsive media query, enabled ATDD tests, all 47 tests passing |
| 2026-01-31 | claude-opus-4-5 | Fixed test filter in `CSS should use mobile-first approach` to exclude `hover:` media queries alongside `prefers-reduced-motion` |
| 2026-01-31 | synthesis-master | Applied code review synthesis: fixed brittle `.split(' ')` tests, added CTA min-width/height, added hero text overflow protection, added design tokens for transitions and shadows, tightened card positioning tolerance |

### File List

| File | Action | Description |
|------|--------|-------------|
| styles.css | MODIFIED | Added `/* Responsive Layout */` section with `@media (min-width: 768px)` media query containing 3-column grid for `.projects__grid`; added `overflow-wrap` and `word-wrap` to hero text; added `min-width` and `min-height` to CTA; added design tokens `--transition-duration`, `--shadow-sm`, `--shadow-md` |
| tests/e2e/story-2.2-responsive.spec.ts | MODIFIED | Enabled all 12 ATDD tests; fixed mobile-first test filter to exclude `hover:` media queries; fixed brittle `.split(' ')` column counting to use `.trim().split(/\s+/).filter(v => v.length > 0)`; tightened card positioning tolerance from 5px to 1px |
