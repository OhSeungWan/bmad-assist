# ATDD Checklist - Epic 2, Story 1: CSS Design Tokens and Typography

**Date:** 2026-01-31
**Author:** TEA Agent (Claude Opus 4.5)
**Primary Test Level:** E2E (Playwright)

---

## Story Summary

Apply CSS design tokens to typography, hero section CTA, and project cards. Implement hover states, focus states, and accessibility features including prefers-reduced-motion support.

**As a** developer
**I want** a centralized design token system using CSS custom properties
**So that** visual consistency is maintained and future changes are easy

---

## Acceptance Criteria

1. **AC-2.1.1:** `<h1>` uses `--font-heading` font family AND `--font-size-xxl` (via `.hero__name` selector)
2. **AC-2.1.2:** Body text uses `--font-body` font family with `line-height: 1.5` (global `body` selector)
3. **AC-2.1.3:** Hero CTA button styled with `--color-accent` background, white text, padding, border-radius
4. **AC-2.1.4:** Hero CTA button has hover, focus, and active states (brightness + scale transforms)
5. **AC-2.1.5:** Hero tagline uses `--font-size-lg` for typography scale
6. **AC-2.1.6:** Project cards have box-shadow `0 2px 8px rgba(0, 0, 0, 0.1)` for depth
7. **AC-2.1.7:** Project cards have elevated shadow `0 4px 16px rgba(0, 0, 0, 0.15)` on hover
8. **AC-2.1.8:** Project cards have white background contrasting with page background
9. **AC-2.1.9:** CSS includes `@media (prefers-reduced-motion: reduce)` query disabling transitions
10. **AC-2.1.10:** All new CSS classes follow BEM naming convention
11. **AC-2.1.11:** All CSS uses `var(--token-name)` syntax, no hardcoded colors/fonts/pixels

---

## Failing Tests Created (RED Phase)

### E2E Tests (16 tests)

**File:** `tests/e2e/story-2.1-design-tokens.spec.ts` (559 lines)

| Test | Status | Verifies |
|------|--------|----------|
| AC-2.1.1: h1 should use --font-heading and --font-size-xxl via .hero__name | RED | `.hero__name` has `font-family: Georgia` and `font-size: 48px` (3rem) |
| AC-2.1.2: body should use --font-body with line-height 1.5 | RED | `body` has `font-family: Arial`, `line-height: 24px`, `font-size: 16px`, `color: rgb(51,51,51)`, `background: white` |
| AC-2.1.3: hero CTA should have accent background, white text, padding, and border-radius | RED | `.hero__cta` has `background: rgb(233,69,96)`, `color: white`, `padding: 16px 32px`, `border-radius: 8px`, `display: inline-block`, `font-weight: bold` |
| AC-2.1.4: hero CTA should have hover, focus, and active states | RED | CTA hover has `transform: scale(1.02)` + `filter: brightness()`, focus has outline with 2px offset |
| AC-2.1.5: hero tagline should use --font-size-lg | RED | `.hero__tagline` has `font-size: 20px` (1.25rem) |
| AC-2.1.6: project cards should have box-shadow for depth | RED | `.projects__card` has `box-shadow` containing `2px 8px` |
| AC-2.1.7: project cards should have elevated shadow on hover | RED | `.projects__card:hover` has shadow with `4px 16px` + transform |
| AC-2.1.8: project cards should have white background | RED | `.projects__card` has `background: rgb(255,255,255)` |
| AC-2.1.9: CSS should include prefers-reduced-motion media query | RED | `styles.css` contains `@media (prefers-reduced-motion: reduce)` |
| AC-2.1.10: all CSS classes should follow BEM naming convention | RED | No non-BEM class names in styles.css |
| AC-2.1.11: all CSS should use var(--token) syntax for design tokens | RED | No hardcoded hex colors, font names, or pixel spacing values |
| should have organized CSS with section comments | RED | CSS has section comments per NFR-002 |
| should have box-sizing border-box reset | RED | `body` has `box-sizing: border-box` |
| should have heading margin resets with spacing token | RED | `h1` has `margin-top: 0`, `margin-bottom: 16px` |
| should have transition property on CTA for smooth state changes | RED | `.hero__cta` has `transition` including `transform` |
| should have transition property on cards for smooth hover | RED | `.projects__card` has `transition` including `box-shadow` |

---

## Implementation Checklist

### Task 1: Apply typography tokens globally (AC: 2.1.1, 2.1.2)

**Tasks to make tests pass:**

- [ ] Add `body { font-family: var(--font-body); font-size: var(--font-size-base); line-height: 1.5; color: var(--color-text); background-color: var(--color-background); }`
- [ ] Add `.hero__name { font-family: var(--font-heading); font-size: var(--font-size-xxl); }`
- [ ] Run test: `npx playwright test tests/e2e/story-2.1-design-tokens.spec.ts -g "AC-2.1.1" --project=chromium`
- [ ] Run test: `npx playwright test tests/e2e/story-2.1-design-tokens.spec.ts -g "AC-2.1.2" --project=chromium`

---

### Task 2: Style hero tagline (AC: 2.1.5)

**Tasks to make tests pass:**

- [ ] Add `.hero__tagline { font-size: var(--font-size-lg); }`
- [ ] Run test: `npx playwright test tests/e2e/story-2.1-design-tokens.spec.ts -g "AC-2.1.5" --project=chromium`

---

### Task 3: Style hero CTA button (AC: 2.1.3, 2.1.4)

**Tasks to make tests pass:**

- [ ] Update `.hero__cta`:
  ```css
  .hero__cta {
    display: inline-block;
    padding: var(--spacing-sm) var(--spacing-md);
    background: var(--color-accent);
    color: var(--color-background);
    text-decoration: none;
    border-radius: var(--border-radius);
    font-family: var(--font-body);
    font-weight: bold;
    transition: transform 0.2s ease, filter 0.2s ease;
  }
  ```
- [ ] Add hover state:
  ```css
  .hero__cta:hover {
    filter: brightness(0.9);
    transform: scale(1.02);
  }
  ```
- [ ] Add focus state:
  ```css
  .hero__cta:focus-visible {
    outline: 3px solid var(--color-accent);
    outline-offset: 2px;
  }
  ```
- [ ] Add active state:
  ```css
  .hero__cta:active {
    filter: brightness(0.8);
    transform: scale(0.98);
  }
  ```
- [ ] Run test: `npx playwright test tests/e2e/story-2.1-design-tokens.spec.ts -g "AC-2.1.3" --project=chromium`
- [ ] Run test: `npx playwright test tests/e2e/story-2.1-design-tokens.spec.ts -g "AC-2.1.4" --project=chromium`

---

### Task 4: Style project cards with shadows (AC: 2.1.6, 2.1.7, 2.1.8)

**Tasks to make tests pass:**

- [ ] Update `.projects__card`:
  ```css
  .projects__card {
    /* existing properties */
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    transition: box-shadow 0.2s ease, transform 0.2s ease;
  }
  ```
- [ ] Add hover state:
  ```css
  .projects__card:hover {
    box-shadow: 0 4px 16px rgba(0, 0, 0, 0.15);
    transform: translateY(-2px);
  }
  ```
- [ ] Verify card background is white (already set via `--color-background`)
- [ ] Run test: `npx playwright test tests/e2e/story-2.1-design-tokens.spec.ts -g "AC-2.1.6" --project=chromium`
- [ ] Run test: `npx playwright test tests/e2e/story-2.1-design-tokens.spec.ts -g "AC-2.1.7" --project=chromium`
- [ ] Run test: `npx playwright test tests/e2e/story-2.1-design-tokens.spec.ts -g "AC-2.1.8" --project=chromium`

---

### Task 5: Add CSS reset and organization (NFR-002)

**Tasks to make tests pass:**

- [ ] Add `* { box-sizing: border-box; }` universal reset
- [ ] Add heading margin reset: `h1, h2, h3, h4, h5, h6 { margin: 0; margin-bottom: var(--spacing-sm); }`
- [ ] Add section comments:
  - `/* CSS Custom Properties */`
  - `/* Global Typography */`
  - `/* Hero Section */`
  - `/* Projects Section */`
  - `/* Accessibility */`
- [ ] Run test: `npx playwright test tests/e2e/story-2.1-design-tokens.spec.ts -g "box-sizing" --project=chromium`
- [ ] Run test: `npx playwright test tests/e2e/story-2.1-design-tokens.spec.ts -g "heading margin" --project=chromium`
- [ ] Run test: `npx playwright test tests/e2e/story-2.1-design-tokens.spec.ts -g "section comments" --project=chromium`

---

### Task 6: Add prefers-reduced-motion support (AC: 2.1.9)

**Tasks to make tests pass:**

- [ ] Add accessibility media query:
  ```css
  @media (prefers-reduced-motion: reduce) {
    *,
    *::before,
    *::after {
      animation-duration: 0.01ms !important;
      animation-iteration-count: 1 !important;
      transition-duration: 0.01ms !important;
    }
  }
  ```
- [ ] Run test: `npx playwright test tests/e2e/story-2.1-design-tokens.spec.ts -g "AC-2.1.9" --project=chromium`

---

### Task 7: Verify BEM and token compliance (AC: 2.1.10, 2.1.11)

**Tasks to make tests pass:**

- [ ] Review all CSS classes - ensure BEM naming (`block__element--modifier`)
- [ ] Verify no hardcoded hex colors outside `:root`
- [ ] Verify no hardcoded font families outside `:root`
- [ ] Verify no hardcoded spacing pixel values (except box-shadow offsets)
- [ ] Run test: `npx playwright test tests/e2e/story-2.1-design-tokens.spec.ts -g "AC-2.1.10" --project=chromium`
- [ ] Run test: `npx playwright test tests/e2e/story-2.1-design-tokens.spec.ts -g "AC-2.1.11" --project=chromium`

---

## Running Tests

```bash
# Run all failing tests for this story (16 tests × 5 browsers = 80 total)
npx playwright test tests/e2e/story-2.1-design-tokens.spec.ts

# Run tests on single browser (faster for development)
npx playwright test tests/e2e/story-2.1-design-tokens.spec.ts --project=chromium

# Run specific acceptance criterion test
npx playwright test tests/e2e/story-2.1-design-tokens.spec.ts -g "AC-2.1.1" --project=chromium

# Run tests in headed mode (see browser)
npx playwright test tests/e2e/story-2.1-design-tokens.spec.ts --headed --project=chromium

# Debug specific test
npx playwright test tests/e2e/story-2.1-design-tokens.spec.ts -g "AC-2.1.1" --debug

# Run all tests including existing Story 1.1 (regression check)
npx playwright test --project=chromium
```

---

## Red-Green-Refactor Workflow

### RED Phase (Complete) ✅

**TEA Agent Responsibilities:**

- ✅ All 16 tests written and skipped (`test.skip()`)
- ✅ Tests assert expected behavior (not placeholder assertions)
- ✅ Implementation checklist created with specific CSS patterns
- ✅ Test commands documented

**Verification:**

```
16 skipped
```

All tests are properly skipped and will fail once `test.skip()` is removed.

---

### GREEN Phase (DEV Team - Next Steps)

**DEV Agent Responsibilities:**

1. **Pick one failing test** from implementation checklist (start with Task 1)
2. **Remove `test.skip()`** from that specific test
3. **Run the test** - verify it fails (red)
4. **Implement minimal CSS** to make the test pass
5. **Run the test** - verify it passes (green)
6. **Move to next test** and repeat

**Key Principles:**

- One test at a time (don't try to fix all at once)
- Minimal implementation (only what the test requires)
- Run tests frequently (immediate feedback)
- Use implementation checklist as roadmap

**Progress Tracking:**

Check off tasks as you complete them in this checklist.

---

### REFACTOR Phase (After All Tests Pass)

**DEV Agent Responsibilities:**

1. **Verify all 16 tests pass** (green phase complete)
2. **Review CSS for organization** (section comments per NFR-002)
3. **Verify property ordering** (positioning → display → box model → typography → visual → misc)
4. **Ensure tests still pass** after each refactor
5. **Run full regression** including Story 1.1 tests

**Completion:**

- All 16 Story 2.1 tests pass
- All 8 Story 1.1 tests pass (no regression)
- CSS organized with section comments
- Ready for code review

---

## CSS Property Ordering Reference

From `project_context.md`, properties MUST be ordered:

1. **Positioning:** position, top, right, bottom, left, z-index
2. **Display:** display, flex, grid, align, justify
3. **Box model:** width, height, margin, padding, border
4. **Typography:** font-family, font-size, font-weight, line-height, text-align, color
5. **Visual:** background, box-shadow, opacity, filter
6. **Misc:** transition, animation, cursor, outline

---

## Expected CSS Structure After Implementation

```css
/* CSS Custom Properties */
:root {
  /* ... existing tokens ... */
}

/* Global Typography */
* {
  box-sizing: border-box;
}

body {
  margin: 0;
  font-family: var(--font-body);
  font-size: var(--font-size-base);
  line-height: 1.5;
  color: var(--color-text);
  background-color: var(--color-background);
}

h1, h2, h3, h4, h5, h6 {
  margin: 0;
  margin-bottom: var(--spacing-sm);
}

/* Hero Section */
.hero { /* ... */ }
.hero__name { font-family: var(--font-heading); font-size: var(--font-size-xxl); }
.hero__tagline { font-size: var(--font-size-lg); }
.hero__cta { /* full button styles */ }
.hero__cta:hover { /* hover state */ }
.hero__cta:focus-visible { /* focus state */ }
.hero__cta:active { /* active state */ }

/* Projects Section */
.projects { /* ... */ }
.projects__card { box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1); transition: ...; }
.projects__card:hover { box-shadow: 0 4px 16px rgba(0, 0, 0, 0.15); transform: translateY(-2px); }
/* ... other card styles ... */

/* Accessibility */
@media (prefers-reduced-motion: reduce) {
  *, *::before, *::after {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
  }
}
```

---

## Next Steps

1. **Review this checklist** before starting implementation
2. **Run failing tests** to confirm RED phase: `npx playwright test tests/e2e/story-2.1-design-tokens.spec.ts --project=chromium`
3. **Begin implementation** using implementation checklist as guide
4. **Work one test at a time** (remove `test.skip()` → implement → verify green)
5. **When all tests pass**, refactor CSS for organization
6. **When refactoring complete**, run full test suite including Story 1.1
7. **Manually update story status** to 'in-progress' then 'done' in sprint-status.yaml

---

## Knowledge Base References Applied

This ATDD workflow consulted the following patterns:

- **fixture-architecture.md** - Test fixture patterns with `test.extend()`
- **component-tdd.md** - Component test strategies with computed style verification
- **test-quality.md** - Test design principles (Given-When-Then, determinism, isolation)
- **selector-resilience.md** - Using BEM class selectors for stability

---

## Test Execution Evidence

### Initial Test Run (RED Phase Verification)

**Command:** `npx playwright test tests/e2e/story-2.1-design-tokens.spec.ts --project=chromium`

**Results:**

```
Running 16 tests using 6 workers

  -   1 [chromium] › story-2.1-design-tokens.spec.ts:32:8 › AC-2.1.1: h1 should use --font-heading...
  -   2 [chromium] › story-2.1-design-tokens.spec.ts:60:8 › AC-2.1.2: body should use --font-body...
  ...
  -  16 [chromium] › story-2.1-design-tokens.spec.ts:539:8 › Card Transition › should have transition...

  16 skipped
```

**Summary:**

- Total tests: 16
- Passing: 0 (expected)
- Failing: 0 (all skipped)
- Skipped: 16 (TDD red phase)
- Status: ✅ RED phase verified

---

## Notes

- All tests use `test.skip()` per TDD red phase requirements
- Tests verify computed styles via `getComputedStyle()` for accuracy
- Tests reading CSS file directly use `fs.readFileSync()` for pattern validation
- Card background test (AC-2.1.8) may already pass if existing CSS is correct

---

**Generated by BMad TEA Agent** - 2026-01-31
