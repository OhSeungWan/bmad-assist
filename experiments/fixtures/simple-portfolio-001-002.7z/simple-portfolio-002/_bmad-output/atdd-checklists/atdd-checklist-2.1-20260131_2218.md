I'll analyze this ATDD workflow request and execute it step by step.

## Step 1: Preflight & Context Loading

Let me verify prerequisites and load all required inputs.Let me also check the current styles.css to understand what exists:## Step 1 - Preflight Summary ✅

**Prerequisites Verified:**
- ✅ Story 2.1 approved with 11 clear acceptance criteria
- ✅ Test framework configured (`playwright.config.ts` with cross-browser support)
- ✅ Development environment available (static serve on port 8080)

**Story Context Loaded:**
- Story: CSS Design Tokens and Typography (Story 2.1)
- 11 Acceptance Criteria (AC-2.1.1 through AC-2.1.11)
- Prerequisites from Epic 1 already implemented (`:root` CSS variables exist)

**Framework & Existing Patterns:**
- Playwright with custom fixtures (`test.extend()` pattern)
- Selector helpers using BEM classes (`heroSelectors`, `projectsSelectors`)
- Existing Story 1.1 tests show the pattern to follow (Given-When-Then)

**TEA Config Flags:**
- `tea_use_playwright_utils`: True
- `tea_use_mcp_enhancements`: True

---

## Step 2: Generation Mode Selection

**Mode Selected: AI Generation** ✓

Rationale:
- Acceptance criteria are clear and CSS-focused (computed styles, hover states, media queries)
- Scenarios are standard (CSS property verification, visual states)
- No complex UI interactions requiring recording

---

## Step 3: Test Strategy### Acceptance Criteria → Test Mapping

| AC | Description | Test Level | Priority | Test Scenario |
|----|-------------|-----------|----------|---------------|
| AC-2.1.1 | h1 uses `--font-heading` and `--font-size-xxl` | E2E | P0 | Verify computed font-family and font-size on `.hero__name` |
| AC-2.1.2 | Body uses `--font-body` with `line-height: 1.5` | E2E | P0 | Verify body computed styles |
| AC-2.1.3 | CTA styled with accent background, white text, padding, border-radius | E2E | P0 | Verify CTA computed styles |
| AC-2.1.4 | CTA hover/focus/active states | E2E | P1 | Verify state changes via hover/focus |
| AC-2.1.5 | Hero tagline uses `--font-size-lg` | E2E | P0 | Verify tagline computed font-size |
| AC-2.1.6 | Project cards have box-shadow | E2E | P1 | Verify card box-shadow |
| AC-2.1.7 | Project cards have elevated shadow on hover | E2E | P1 | Verify hover state shadow change |
| AC-2.1.8 | Project cards have white background | E2E | P0 | Verify card background color |
| AC-2.1.9 | CSS includes `prefers-reduced-motion` query | E2E | P1 | Check stylesheet contains media query |
| AC-2.1.10 | All CSS classes follow BEM naming | E2E | P2 | Verify no non-BEM classes added |
| AC-2.1.11 | All CSS uses `var(--token)` syntax | E2E | P2 | Lint CSS for hardcoded values |

**Primary Test Level: E2E** - This story is CSS-focused with no API; all tests verify computed styles via Playwright.

---

## Step 4: Generate Failing E2E Tests (TDD Red Phase)Now I'll generate the failing test file for Story 2.1:Let me fix those unused variable warnings:There are syntax errors. Let me check the file:Let me check the end of the file:The file looks OK. Let me verify by running the TypeScript compiler:These aren't syntax errors - they're TypeScript config issues related to target version. Let me check the existing tsconfig:The tests parse correctly. Now let me run them to verify they're properly skipped (TDD red phase):All 16 tests are skipped as expected. Now let me generate the ATDD checklist:## Step 5: Validation & Completion

### Validation Checklist

| Requirement | Status |
|-------------|--------|
| Story approved with clear acceptance criteria | ✅ 11 ACs |
| Test framework configured | ✅ Playwright with fixtures |
| Test files created correctly | ✅ `story-2.1-design-tokens.spec.ts` (559 lines) |
| All tests use `test.skip()` (TDD red phase) | ✅ 16/16 skipped |
| Checklist matches acceptance criteria | ✅ All 11 ACs covered |
| Tests designed to fail before implementation | ✅ Assert expected behavior |
| No placeholder assertions | ✅ Real style verifications |

---

## Completion Summary---

## ✅ ATDD Test Generation Complete (TDD RED PHASE)

### 🔴 TDD Red Phase: Failing Tests Generated

**📊 Summary:**

| Metric | Value |
|--------|-------|
| Total Tests | 16 (all with `test.skip()`) |
| Test Level | E2E (Playwright) |
| Browsers | Chromium, Firefox, WebKit, Mobile Chrome, Mobile Safari |
| Acceptance Criteria Covered | 11/11 (100%) |

### 📂 Generated Files:

| File | Path | Lines |
|------|------|-------|
| Test File | `tests/e2e/story-2.1-design-tokens.spec.ts` | 559 |
| ATDD Checklist | `_bmad-output/implementation-artifacts/atdd-checklist-2.1.md` | 340+ |

### ✅ Acceptance Criteria Coverage:

- **AC-2.1.1:** h1 typography tokens (font-family, font-size)
- **AC-2.1.2:** Body typography (font-family, line-height, color, background)
- **AC-2.1.3:** CTA button styling (background, color, padding, border-radius)
- **AC-2.1.4:** CTA interaction states (hover, focus, active)
- **AC-2.1.5:** Tagline font-size
- **AC-2.1.6:** Card box-shadow
- **AC-2.1.7:** Card hover shadow
- **AC-2.1.8:** Card white background
- **AC-2.1.9:** prefers-reduced-motion media query
- **AC-2.1.10:** BEM naming compliance
- **AC-2.1.11:** CSS custom property usage (no hardcoded values)

### 📝 Next Steps:

1. **Run `/bmad:bmm:workflows:dev-story`** to implement the CSS changes
2. During implementation, **remove `test.skip()`** from tests one at a time
3. **Verify each test passes** (green phase) after implementing its CSS
4. When all 16 tests pass, run full regression: `npx playwright test --project=chromium`

### 🔬 Verify RED Phase:

```bash
npx playwright test tests/e2e/story-2.1-design-tokens.spec.ts --project=chromium
# Expected: 16 skipped
```---

## ✅ ATDD Test Generation Complete (TDD RED PHASE)

### 🔴 TDD Red Phase: Failing Tests Generated

**📊 Summary:**

| Metric | Value |
|--------|-------|
| Total Tests | 16 (all with `test.skip()`) |
| Test Level | E2E (Playwright) |
| Browsers | Chromium, Firefox, WebKit, Mobile Chrome, Mobile Safari |
| Acceptance Criteria Covered | 11/11 (100%) |

### 📂 Generated Files:

| File | Path | Lines |
|------|------|-------|
| Test File | `tests/e2e/story-2.1-design-tokens.spec.ts` | 559 |
| ATDD Checklist | `_bmad-output/implementation-artifacts/atdd-checklist-2.1.md` | 340+ |

### ✅ Acceptance Criteria Coverage:

- **AC-2.1.1:** h1 typography tokens (font-family, font-size)
- **AC-2.1.2:** Body typography (font-family, line-height, color, background)
- **AC-2.1.3:** CTA button styling (background, color, padding, border-radius)
- **AC-2.1.4:** CTA interaction states (hover, focus, active)
- **AC-2.1.5:** Tagline font-size
- **AC-2.1.6:** Card box-shadow
- **AC-2.1.7:** Card hover shadow
- **AC-2.1.8:** Card white background
- **AC-2.1.9:** prefers-reduced-motion media query
- **AC-2.1.10:** BEM naming compliance
- **AC-2.1.11:** CSS custom property usage (no hardcoded values)

### 📝 Next Steps:

1. **Run `/bmad:bmm:workflows:dev-story`** to implement the CSS changes
2. During implementation, **remove `test.skip()`** from tests one at a time
3. **Verify each test passes** (green phase) after implementing its CSS
4. When all 16 tests pass, run full regression: `npx playwright test --project=chromium`

### 🔬 Verify RED Phase:

```bash
npx playwright test tests/e2e/story-2.1-design-tokens.spec.ts --project=chromium
# Expected: 16 skipped
```