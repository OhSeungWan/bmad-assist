I'll execute this test-design workflow for Story 1.1 of the simple-portfolio project. Let me work through each step systematically.

## Step 1: Detect Mode & Prerequisites

Based on the context provided:
- This is a **simple static portfolio website** (HTML/CSS only)
- The workflow indicates **Mode: Create** and **Target: Story 1.1**
- The `workflow_mode` variable is set to `c` (create)
- Epic number is `1`, story is `1.1`

**Mode Detection:** This is **Epic-Level Mode** (Phase 4) because:
1. We have a specific story target (1.1)
2. The `implementation_artifacts` pattern suggests we're in implementation phase
3. Variables indicate epic/story context

**Prerequisite Check for Epic-Level Mode:**
- ✅ Project context document loaded (project_context.md)
- ✅ Requirements are clear: static HTML/CSS portfolio with hero section, projects section
- ✅ Acceptance criteria defined in project_context.md under "Testing Verification"

Let me load the epic and story files to get full requirements.Let me read the epics file and PRD to get the full requirements for Epic 1 and Story 1.1.Now let me check for existing test coverage and any implementation artifacts.Let me read the existing test files to understand current coverage.Now let me check the output folder path and existing outputs.Now I have all the context I need. Let me write a task tracking list and proceed with the test design.## Step 2 Summary: Context Loaded

**Configuration:**
- `tea_use_playwright_utils`: True
- `output_folder`: `_bmad-output`

**Project Artifacts Loaded:**
- PRD: FR-001 (Hero), FR-002 (Projects), FR-003 (Design System), FR-004 (Responsive)
- Architecture: ADR-001 to ADR-006 (Pure HTML/CSS, Single Page, CSS Custom Properties, BEM, Mobile-First, Semantic HTML5)
- Epic 1 with Story 1.1 (Hero Section Implementation)

**Existing Test Coverage Analysis:**
- ✅ Test framework: Playwright with `@seontechnologies/playwright-utils`
- ✅ 2 spec files: `homepage.spec.ts` (6 tests), `accessibility.spec.ts` (5 tests)
- ✅ Support structure: fixtures, selectors, assertions helpers
- ✅ BEM-based selectors defined for hero and projects sections

**Coverage Gaps Identified for Story 1.1:**
- Tests exist but are general - not specific to Story 1.1 ACs
- Missing direct validation of AC-1.1.2 (h1 text "Alex Chen" exact match)
- Missing AC-1.1.5 (HTML validity check)
- Missing AC-1.1.6 (minimal CSS existence check)

---

## Step 3: Risk & Testability Assessment

### Testability Assessment (Story 1.1)

**Controllability: GOOD**
- Static HTML/CSS site - fully deterministic
- No server-side state to manage
- No JavaScript - behavior is purely structural

**Observability: GOOD**
- BEM class names provide stable selectors
- Semantic HTML allows accessibility assertions
- CSS custom properties can be queried via JS

**Reliability: EXCELLENT**
- No network dependencies in tests (local file or simple server)
- No race conditions (no JS)
- Tests are inherently isolated

### Risk Assessment Matrix for Story 1.1

| Risk ID | Category | Description | Probability | Impact | Score | Mitigation | Owner |
|---------|----------|-------------|-------------|--------|-------|------------|-------|
| R-001 | TECH | BEM class naming inconsistency breaks selectors | 2 | 2 | 4 | Selector constants in helpers, validate against project_context.md | Dev |
| R-002 | BUS | Hero section missing required content (name, tagline, CTA) | 2 | 3 | 6 | P0 tests for all 6 acceptance criteria | QA |
| R-003 | TECH | HTML validation errors (invalid markup) | 1 | 2 | 2 | Manual W3C validator check, AC-1.1.5 | Dev |
| R-004 | OPS | CSS file missing or not linked | 1 | 3 | 3 | P0 test for CSS load verification | QA |
| R-005 | BUS | CTA link malformed or broken | 2 | 2 | 4 | P0 test for href attribute validation | QA |
| R-006 | TECH | h1 heading not unique (accessibility violation) | 1 | 2 | 2 | Accessibility tests already cover | QA |

**High-Priority Risks (≥6):**
- **R-002**: Hero content completeness is business-critical (Score: 6)

**Mitigation Focus:**
- Ensure all 6 acceptance criteria have direct test coverage
- Existing tests partially cover but need explicit AC mapping## Step 4: Coverage Plan & Execution Strategy

### Test Coverage Matrix for Story 1.1

| AC ID | Requirement | Test Level | Risk Link | Priority | Status |
|-------|-------------|------------|-----------|----------|--------|
| AC-1.1.1 | `<header>` with class `hero` exists | E2E | R-002 | P0 | Covered |
| AC-1.1.2 | `<h1>` contains "Alex Chen" | E2E | R-002 | P0 | Covered |
| AC-1.1.3 | `<p class="hero__tagline">` exists | E2E | R-002 | P0 | Covered |
| AC-1.1.4 | `<a class="hero__cta">` with valid href | E2E | R-002, R-005 | P0 | Covered |
| AC-1.1.5 | HTML is valid, semantic elements used | E2E | R-003 | P1 | Partially Covered |
| AC-1.1.6 | Basic CSS exists for hero visibility | E2E | R-004 | P1 | Not Covered |

### Priority Breakdown

**P0 (Critical) - 4 scenarios**
- Hero header element exists with correct class
- h1 contains photographer name
- Tagline paragraph exists
- CTA link exists with valid href

**P1 (High) - 2 scenarios**
- Semantic HTML structure (header, main)
- CSS loads and hero is styled

### Execution Strategy

**PR Pipeline (< 2 min):**
- All P0 + P1 tests run on every commit
- Single browser (chromium) for speed

**Nightly:**
- Full cross-browser (chromium, firefox, webkit)
- Mobile viewport testing

### Resource Estimates

| Priority | Tests | Hours/Test | Total |
|----------|-------|------------|-------|
| P0 | 4 | 0.5 | ~2 hours |
| P1 | 2 | 0.5 | ~1 hour |
| **Total** | **6** | - | **~3 hours** |

### Quality Gates

- P0 pass rate: 100%
- P1 pass rate: ≥95%
- Coverage target: 100% of acceptance criteria## Step 5: Generate Test Design Document

Now I'll generate the test design document for Story 1.1.## Completion Report

**Mode Used:** Epic-Level (Phase 4) Test Design

**Output File:** `_bmad-output/implementation-artifacts/test-design-epic-1-story-1.1.md`

### Summary

| Metric | Value |
|--------|-------|
| Risks Identified | 6 |
| High-Priority Risks | 1 (R-002: Hero content completeness) |
| Test Scenarios | 6 total (4 P0, 2 P1) |
| Existing Coverage | 5/6 ACs covered |
| Gap | 1 new test needed (AC-1.1.6: CSS styling) |
| Estimated Effort | ~3 hours |

### Key Findings

1. **Existing test framework is well-structured** - Playwright with `playwright-utils`, BEM selectors, reusable assertion helpers
2. **Most acceptance criteria already covered** - 5 of 6 ACs have existing test coverage in `homepage.spec.ts`
3. **One gap identified** - AC-1.1.6 (basic CSS exists) needs a new test to verify styling is applied
4. **Low overall risk** - Static HTML/CSS site is highly testable with no async/JS concerns

### Quality Gates

- P0 pass rate required: 100%
- P1 pass rate required: ≥95%
- All 6 acceptance criteria must have test coverage

### Open Assumptions

- Implementation has not started yet (tests designed for ATDD approach)
- BEM naming will follow `project_context.md` specifications## Completion Report

**Mode Used:** Epic-Level (Phase 4) Test Design

**Output File:** `_bmad-output/implementation-artifacts/test-design-epic-1-story-1.1.md`

### Summary

| Metric | Value |
|--------|-------|
| Risks Identified | 6 |
| High-Priority Risks | 1 (R-002: Hero content completeness) |
| Test Scenarios | 6 total (4 P0, 2 P1) |
| Existing Coverage | 5/6 ACs covered |
| Gap | 1 new test needed (AC-1.1.6: CSS styling) |
| Estimated Effort | ~3 hours |

### Key Findings

1. **Existing test framework is well-structured** - Playwright with `playwright-utils`, BEM selectors, reusable assertion helpers
2. **Most acceptance criteria already covered** - 5 of 6 ACs have existing test coverage in `homepage.spec.ts`
3. **One gap identified** - AC-1.1.6 (basic CSS exists) needs a new test to verify styling is applied
4. **Low overall risk** - Static HTML/CSS site is highly testable with no async/JS concerns

### Quality Gates

- P0 pass rate required: 100%
- P1 pass rate required: ≥95%
- All 6 acceptance criteria must have test coverage

### Open Assumptions

- Implementation has not started yet (tests designed for ATDD approach)
- BEM naming will follow `project_context.md` specifications