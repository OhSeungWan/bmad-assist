<?xml version="1.0" encoding="UTF-8"?>
<!-- BMAD Prompt Run Metadata -->
<!-- Epic: 2 -->
<!-- Story: 2.2 -->
<!-- Phase: create-story -->
<!-- Timestamp: 20260131T220319Z -->
<compiled-workflow>
<mission><![CDATA[Create the next user story from epics+stories with enhanced context analysis and direct ready-for-dev marking

Target: Story 2.2 - mobile-first-responsive-layout
Create comprehensive developer context and implementation-ready story.]]></mission>
<context>
<file id="git-intel" path="[git-intelligence]"><![CDATA[<git-intelligence>
This project is not under git version control.
Do NOT attempt to run git commands - they will fail.
Focus on embedded context and file reading instead.

</git-intelligence>]]></file>
<file id="11c89e12" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/docs/project_context.md"><![CDATA[# Project Context: Alex Chen Photography Portfolio

## Overview

Static portfolio website for freelance photographer. Pure HTML/CSS, no JavaScript.

## File Structure

```
index.html    # Single page, semantic HTML5
styles.css    # All styles, BEM naming
```

## Coding Standards

### HTML Rules

- Use semantic elements: `<header>`, `<main>`, `<section>`, `<article>`, `<footer>`
- Proper heading hierarchy: single `<h1>`, then `<h2>`, `<h3>` as needed
- 2-space indentation
- Double quotes for attributes
- Self-closing tags for void elements: `<img />`, `<br />`
- Always include `alt` attribute on images

### CSS Rules

- **BEM naming convention:**
  - Block: `.hero`, `.projects`
  - Element: `.hero__title`, `.projects__card`
  - Modifier: `.hero__cta--primary`, `.projects__card--featured`
- 2-space indentation
- One property per line
- Opening brace on same line as selector
- Blank line between rule sets
- Properties ordered: positioning → display → box model → typography → visual → misc

### CSS Custom Properties

Define all design tokens in `:root`:

```css
:root {
  /* Colors */
  --color-primary: #1a1a2e;
  --color-accent: #e94560;
  --color-background: #ffffff;
  --color-text: #333333;
  --color-text-light: #666666;

  /* Typography */
  --font-heading: 'Georgia', serif;
  --font-body: 'Arial', sans-serif;
  --font-size-base: 16px;
  --font-size-lg: 1.25rem;
  --font-size-xl: 2rem;
  --font-size-xxl: 3rem;

  /* Spacing */
  --spacing-xs: 0.5rem;
  --spacing-sm: 1rem;
  --spacing-md: 2rem;
  --spacing-lg: 4rem;

  /* Layout */
  --max-width: 1200px;
  --border-radius: 8px;
}
```

### Responsive Design

- Mobile-first approach
- Single breakpoint: `768px`
- Use `min-width` media queries only

```css
/* Mobile styles (default) */
.projects__grid {
  display: grid;
  grid-template-columns: 1fr;
}

/* Desktop styles */
@media (min-width: 768px) {
  .projects__grid {
    grid-template-columns: repeat(3, 1fr);
  }
}
```

## Component Structure

### Hero Section

```html
<header class="hero">
  <h1 class="hero__name">Alex Chen</h1>
  <p class="hero__tagline">Capturing moments that last forever</p>
  <a href="#contact" class="hero__cta">Get in Touch</a>
</header>
```

### Projects Section

```html
<main>
  <section class="projects">
    <h2 class="projects__title">Portfolio</h2>
    <div class="projects__grid">
      <article class="projects__card">
        <div class="projects__card-image"></div>
        <h3 class="projects__card-title">Wedding</h3>
        <p class="projects__card-description">...</p>
      </article>
      <!-- Repeat for Portrait, Landscape -->
    </div>
  </section>
</main>
```

## Constraints

- No JavaScript
- No external dependencies
- No CSS preprocessors
- No build tools
- Maximum 2 files (index.html + styles.css)

## Testing Verification

Verify implementation by checking:

1. **Hero section:** `<header class="hero">` exists with `<h1>`, tagline `<p>`, and CTA `<a>`
2. **Projects section:** `<section class="projects">` with exactly 3 `<article class="projects__card">`
3. **CSS variables:** `:root` block defines `--color-*`, `--font-*`, `--spacing-*`
4. **Responsive:** `@media (min-width: 768px)` present in styles.css
5. **BEM naming:** All classes follow `block__element--modifier` pattern
]]></file>
<file id="bda659bb" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/docs/prd.md"><![CDATA[# Product Requirements Document: Alex Chen Photography Portfolio

## Overview

**Product Name:** Alex Chen Photography Portfolio
**Version:** 1.0
**Author:** John (Product Manager)
**Date:** 2025-12-11

## Problem Statement

Alex Chen is a freelance photographer who needs a simple, professional online presence to showcase work to potential clients. Current solution (social media) lacks professionalism and doesn't provide a dedicated space for portfolio presentation.

## Goals

1. Establish professional online presence
2. Showcase photography portfolio effectively
3. Provide clear call-to-action for client inquiries
4. Ensure accessibility across devices

## Target Audience

- Potential clients seeking photography services (weddings, portraits, landscapes)
- Industry peers and collaborators
- Anyone discovering Alex through referrals

## Functional Requirements

### FR-001: Hero Section with Branding

**Description:** The landing page must feature a prominent hero section that establishes brand identity.

**Acceptance Criteria:**
- Display photographer name "Alex Chen" as primary heading
- Include professional tagline communicating photography focus
- Provide clear call-to-action button for contact/inquiry
- Hero section spans full viewport width

### FR-002: Projects Gallery Section

**Description:** A dedicated section showcasing photography projects with visual cards.

**Acceptance Criteria:**
- Display exactly 3 project cards (Wedding, Portrait, Landscape)
- Each card contains: image placeholder, project title, brief description
- Cards arranged in responsive grid layout
- Semantic HTML structure using article elements

### FR-003: Consistent Visual Design System

**Description:** Implement cohesive visual design using CSS custom properties.

**Acceptance Criteria:**
- Define color palette via CSS custom properties in :root
- Establish typography scale (headings, body, captions)
- Consistent spacing using CSS variables
- BEM naming convention for all CSS classes

### FR-004: Mobile-Responsive Layout

**Description:** Ensure optimal viewing experience across device sizes.

**Acceptance Criteria:**
- Mobile-first CSS approach
- Breakpoint at 768px for tablet/desktop layouts
- Hero section adapts to viewport
- Project cards stack vertically on mobile, grid on desktop
- All interactive elements have appropriate touch targets

## Non-Functional Requirements

### NFR-001: Performance
- No JavaScript dependencies
- Single CSS file under 10KB
- Page loads in under 1 second on 3G

### NFR-002: Maintainability
- Semantic HTML5 elements
- Well-commented CSS sections
- BEM methodology for scalable styles

### NFR-003: Accessibility
- Proper heading hierarchy (h1 > h2 > h3)
- Sufficient color contrast ratios
- Focus states for interactive elements

## Out of Scope

- Contact form functionality
- Image gallery lightbox
- CMS integration
- Multi-page navigation
- JavaScript interactions

## Success Metrics

- Clean, valid HTML5 markup
- CSS passes linting with no errors
- Responsive design works on mobile and desktop viewports
- All acceptance criteria met for FR-001 through FR-004
]]></file>
<file id="07a30897" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/docs/ux-spec.md"><![CDATA[# UX Specification: Alex Chen Photography Portfolio

## Overview

**Project:** Alex Chen Photography Portfolio
**UX Designer:** Sally
**Date:** 2025-12-11
**Status:** Approved

## User Persona

### Primary Persona: Potential Client

**Name:** Sarah Mitchell
**Age:** 28-45
**Context:** Planning a wedding, looking for a photographer

**Goals:**
- Quickly assess photographer's style and quality
- See relevant work samples (wedding photography)
- Easy way to make contact

**Behaviors:**
- Browses on mobile during commute (60% mobile traffic expected)
- Makes decisions based on visual first impression
- Scans, doesn't read - needs clear visual hierarchy
- Will leave if page loads slowly or looks unprofessional

**Pain Points:**
- Cluttered portfolios with too many options
- Slow-loading image galleries
- Unclear how to get in touch
- Sites that don't work on mobile

### Secondary Persona: Industry Peer

**Name:** Marcus Rivera
**Context:** Fellow photographer, potential collaborator

**Goals:**
- Evaluate Alex's style for collaboration fit
- Quick overview of specialties

## Visual Direction

### Mood & Tone

**Keywords:** Elegant, Professional, Minimal, Gallery-like

**Concept:** The website should feel like walking into a high-end photography gallery - clean walls, focused lighting, art speaks for itself.

**Visual Metaphor:** White-cube gallery meets premium magazine layout.

### Color Psychology

| Color | Token | Hex | Rationale |
|-------|-------|-----|-----------|
| Deep Navy | `--color-primary` | #1a1a2e | Sophisticated, timeless, makes photos "pop" |
| Coral Accent | `--color-accent` | #e94560 | Warm, inviting, draws eye to CTA |
| Clean White | `--color-background` | #ffffff | Gallery-like, maximizes photo contrast |
| Charcoal | `--color-text` | #333333 | Easy reading, softer than pure black |
| Muted Gray | `--color-text-light` | #666666 | Secondary info, doesn't compete |

**Why Dark Hero + Light Content:**
- Hero section uses `--color-primary` background → dramatic first impression
- Projects section uses `--color-background` → photos are the focus
- This contrast creates natural visual sections without heavy borders

### Typography Rationale

| Element | Font | Token | Rationale |
|---------|------|-------|-----------|
| Headings | Georgia | `--font-heading` | Serif = elegance, timelessness, art-world feel |
| Body | Arial | `--font-body` | Sans-serif = clarity, modern, easy scanning |

**Type Scale:**
- Hero name: `--font-size-xxl` (3rem) - Commanding presence
- Section titles: `--font-size-xl` (2rem) - Clear hierarchy
- Card titles: `--font-size-lg` (1.25rem) - Scannable
- Body: `--font-size-base` (16px) - Comfortable reading

## Layout Design

### Information Architecture

```
┌─────────────────────────────────────┐
│             HERO                    │  ← Emotional hook (3 seconds)
│   Name + Tagline + CTA              │
└─────────────────────────────────────┘
┌─────────────────────────────────────┐
│           PORTFOLIO                 │  ← Proof of work
│   [Wedding] [Portrait] [Landscape]  │
└─────────────────────────────────────┘
```

**Why this order:**
1. Hero creates emotional connection first
2. Portfolio proves capability second
3. No navigation needed - single scroll journey

### Wireframes

**Mobile Layout (< 768px):**

```
┌──────────────────────┐
│                      │
│     ALEX CHEN        │
│                      │
│  Capturing moments   │
│  that last forever   │
│                      │
│   [ Get in Touch ]   │
│                      │
├──────────────────────┤
│      Portfolio       │
├──────────────────────┤
│  ┌────────────────┐  │
│  │   [  image  ]  │  │
│  │    Wedding     │  │
│  │  description   │  │
│  └────────────────┘  │
│  ┌────────────────┐  │
│  │   [  image  ]  │  │
│  │    Portrait    │  │
│  │  description   │  │
│  └────────────────┘  │
│  ┌────────────────┐  │
│  │   [  image  ]  │  │
│  │   Landscape    │  │
│  │  description   │  │
│  └────────────────┘  │
└──────────────────────┘
```

**Desktop Layout (≥ 768px):**

```
┌────────────────────────────────────────────────────┐
│                                                    │
│                    ALEX CHEN                       │
│          Capturing moments that last forever       │
│                                                    │
│                  [ Get in Touch ]                  │
│                                                    │
├────────────────────────────────────────────────────┤
│                     Portfolio                      │
├────────────────────────────────────────────────────┤
│  ┌──────────────┐ ┌──────────────┐ ┌──────────────┐│
│  │   [image]    │ │   [image]    │ │   [image]    ││
│  │   Wedding    │ │   Portrait   │ │  Landscape   ││
│  │ description  │ │ description  │ │ description  ││
│  └──────────────┘ └──────────────┘ └──────────────┘│
└────────────────────────────────────────────────────┘
```

## Interaction Design

### CTA Button States

| State | Visual Treatment |
|-------|------------------|
| Default | `--color-accent` background, white text |
| Hover | Slightly darker accent, subtle scale (1.02) |
| Focus | Visible outline for accessibility |
| Active | Darker accent, scale down (0.98) |

### Project Card States

| State | Visual Treatment |
|-------|------------------|
| Default | Subtle shadow, white background |
| Hover | Elevated shadow, slight lift effect |
| Focus | Visible outline around card |

**Note:** All hover effects use CSS transitions (0.2s ease) for smooth feel.

### Touch Targets

- CTA button: minimum 48x48px tap area
- Cards: entire card is tappable area on mobile
- Adequate spacing between interactive elements (min 8px)

## Accessibility Considerations

### Color Contrast

All text meets WCAG AA standards:
- `--color-text` (#333) on `--color-background` (#fff) = 12.6:1 ✓
- White text on `--color-primary` (#1a1a2e) = 15.1:1 ✓
- White text on `--color-accent` (#e94560) = 4.5:1 ✓

### Focus Indicators

- All interactive elements have visible focus states
- Focus outline uses `--color-accent` for consistency
- Never remove focus outline without replacement

### Motion

- Respect `prefers-reduced-motion` media query
- Hover animations are subtle (no jarring movements)

## Design Token Mapping

How UX decisions map to CSS custom properties:

| UX Goal | Design Token | Value |
|---------|--------------|-------|
| Sophisticated first impression | `--color-primary` | #1a1a2e |
| Draw attention to contact | `--color-accent` | #e94560 |
| Clean gallery feel | `--color-background` | #ffffff |
| Readable content | `--color-text` | #333333 |
| Elegant headings | `--font-heading` | Georgia, serif |
| Clear body text | `--font-body` | Arial, sans-serif |
| Consistent rhythm | `--spacing-*` | 0.5/1/2/4rem scale |
| Professional cards | `--border-radius` | 8px |

## Success Metrics

UX goals verification:

1. **First Impression (3 sec test):** User can identify "photographer portfolio" within 3 seconds
2. **Scannability:** All three project types visible without scrolling on desktop
3. **Mobile Usability:** Full journey completable with thumb-only navigation
4. **CTA Visibility:** Contact button visible in hero without scrolling
5. **Load Performance:** Perceived instant load (no layout shift)
]]></file>
<file id="2e55b2e3" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/docs/architecture.md"><![CDATA[# Architecture Document: Alex Chen Photography Portfolio

## Overview

**Project:** Alex Chen Photography Portfolio
**Architect:** Winston
**Date:** 2025-12-11
**Status:** Approved

## Architecture Philosophy

This is a deliberately simple, static website. We embrace "boring technology" - proven HTML and CSS patterns that require no build tools, no frameworks, and no JavaScript. The architecture prioritizes maintainability and performance over sophistication.

## Technology Decisions

### ADR-001: Pure HTML/CSS Stack

**Decision:** Use vanilla HTML5 and CSS3 only. No JavaScript.

**Context:** Portfolio is purely presentational. No dynamic functionality required.

**Rationale:**
- Zero runtime dependencies
- No build pipeline needed
- Maximum browser compatibility
- Fastest possible load times
- Easy to maintain and modify

**Consequences:**
- No interactive features (acceptable per PRD scope)
- Contact requires mailto: link or external form service

### ADR-002: Single Page Architecture

**Decision:** Entire portfolio on one `index.html` page.

**Context:** Only 2 content sections needed (hero + projects).

**Rationale:**
- Simpler navigation (scroll-based)
- Single HTTP request for HTML
- No routing complexity
- Easier testing and verification

**Consequences:**
- Must use anchor links if navigation added later
- Page weight grows with content (acceptable for 2 sections)

### ADR-003: CSS Custom Properties for Theming

**Decision:** Define all design tokens as CSS custom properties in `:root`.

**Context:** Need consistent colors, typography, and spacing.

**Rationale:**
- Single source of truth for design values
- Easy theme modifications
- Native browser support (no preprocessor)
- Runtime flexibility for future enhancements

**Implementation:**
```css
:root {
  --color-primary: #1a1a2e;
  --color-accent: #e94560;
  --color-background: #ffffff;
  --color-text: #333333;
  --font-heading: 'Georgia', serif;
  --font-body: 'Arial', sans-serif;
  --spacing-unit: 1rem;
}
```

### ADR-004: BEM Naming Convention

**Decision:** Use Block__Element--Modifier pattern for all CSS classes.

**Context:** Need scalable, predictable CSS architecture.

**Rationale:**
- Self-documenting class names
- Avoids specificity conflicts
- Clear component boundaries
- Industry standard, widely understood

**Examples:**
- `.hero` (block)
- `.hero__title` (element)
- `.hero__cta--primary` (modifier)
- `.projects__card` (element)

### ADR-005: Mobile-First Responsive Design

**Decision:** Base styles target mobile, media queries enhance for larger screens.

**Context:** Significant mobile traffic expected for portfolio viewing.

**Rationale:**
- Progressive enhancement philosophy
- Smaller devices get minimal CSS
- Easier to scale up than scale down
- Better performance on constrained devices

**Breakpoints:**
- Base: 0-767px (mobile)
- Desktop: 768px+ (tablet and above)

### ADR-006: Semantic HTML5 Structure

**Decision:** Use semantic elements over generic divs.

**Context:** Need accessible, well-structured markup.

**Rationale:**
- Built-in accessibility benefits
- Better SEO signals
- Self-documenting structure
- Screen reader friendly

**Element Mapping:**
| Content | Element |
|---------|---------|
| Page header with hero | `<header>` |
| Main content area | `<main>` |
| Hero section | `<section class="hero">` |
| Projects section | `<section class="projects">` |
| Individual project | `<article class="projects__card">` |
| Page footer | `<footer>` |

## File Structure

```
portfolio-project/
├── index.html          # Single HTML page
├── styles.css          # All styles
├── docs/
│   ├── prd.md
│   ├── architecture.md
│   ├── project_context.md
│   └── epics.md
└── bmad-assist.yaml
```

## Performance Budget

| Metric | Target |
|--------|--------|
| HTML size | < 5KB |
| CSS size | < 10KB |
| Total page weight | < 20KB (excluding images) |
| First Contentful Paint | < 1s on 3G |

## Security Considerations

- No user input handling (no forms)
- No external scripts
- No cookies or local storage
- Static hosting compatible (no server-side logic)

## Future Considerations

If requirements expand:
- Contact form: Consider external service (Formspree, Netlify Forms)
- Image optimization: Add srcset for responsive images
- Analytics: Add privacy-respecting solution (Plausible, Fathom)
- Multi-page: Consider static site generator

These are explicitly out of scope for v1.0.
]]></file>
<file id="d95c5b57" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/docs/epics.md"><![CDATA[# Epics and Stories: Alex Chen Photography Portfolio

## Epic Overview

| Epic | Title | Stories | Story Points |
|------|-------|---------|--------------|
| E1 | Core Page Structure | 2 | 5 |
| E2 | Visual Design System | 2 | 5 |
| **Total** | | **4** | **10** |

---

# Epic 1: Core Page Structure

**Goal:** Build the foundational HTML structure for the portfolio with semantic markup and content sections.

**Dependencies:** None
**PRD Coverage:** FR-001, FR-002

---

## Story 1.1: Hero Section Implementation

**Title:** Implement hero section with branding and call-to-action

**Description:** As a visitor, I want to see a prominent hero section when I land on the page so that I immediately understand who Alex Chen is and how to contact them.

**Story Points:** 3
**Priority:** High
**Status:** backlog

**Acceptance Criteria:**

- [ ] **AC-1.1.1:** Page contains `<header>` element with class `hero`
- [ ] **AC-1.1.2:** Hero contains `<h1>` with text "Alex Chen"
- [ ] **AC-1.1.3:** Hero contains `<p>` element with class `hero__tagline` containing photography-related tagline
- [ ] **AC-1.1.4:** Hero contains `<a>` element with class `hero__cta` linking to contact action
- [ ] **AC-1.1.5:** HTML is valid and uses semantic elements
- [ ] **AC-1.1.6:** Basic CSS exists to make hero section visible (minimal styling acceptable)

**Technical Notes:**
- Follow BEM naming: `hero`, `hero__name`, `hero__tagline`, `hero__cta`
- Use `mailto:` link or `#contact` anchor for CTA href
- Refer to `project_context.md` for HTML structure template

---

## Story 1.2: Projects Gallery Section

**Title:** Implement projects gallery with three portfolio cards

**Description:** As a visitor, I want to see Alex's photography projects organized in cards so that I can understand the types of photography services offered.

**Story Points:** 2
**Priority:** High
**Status:** backlog

**Acceptance Criteria:**

- [ ] **AC-1.2.1:** Page contains `<main>` element wrapping content below hero
- [ ] **AC-1.2.2:** Main contains `<section>` with class `projects`
- [ ] **AC-1.2.3:** Projects section contains `<h2>` with title "Portfolio"
- [ ] **AC-1.2.4:** Projects section contains exactly 3 `<article>` elements with class `projects__card`
- [ ] **AC-1.2.5:** Each card contains: image placeholder div, `<h3>` title, `<p>` description
- [ ] **AC-1.2.6:** Card titles are: "Wedding", "Portrait", "Landscape"
- [ ] **AC-1.2.7:** Cards are wrapped in container with class `projects__grid`
- [ ] **AC-1.2.8:** HTML validates without errors

**Technical Notes:**
- Image placeholders use `<div class="projects__card-image">` with background color
- Follow BEM: `projects`, `projects__title`, `projects__grid`, `projects__card`, `projects__card-title`, `projects__card-description`
- Descriptions should be 1-2 sentences describing photography style

---

# Epic 2: Visual Design System

**Goal:** Implement consistent visual styling using CSS custom properties and ensure responsive behavior across devices.

**Dependencies:** Epic 1 (HTML structure must exist)
**PRD Coverage:** FR-003, FR-004

---

## Story 2.1: CSS Design Tokens and Typography

**Title:** Implement CSS custom properties and typography system

**Description:** As a developer, I want a centralized design token system so that visual consistency is maintained and future changes are easy.

**Story Points:** 3
**Priority:** High
**Status:** backlog

**Acceptance Criteria:**

- [ ] **AC-2.1.1:** `styles.css` contains `:root` selector with CSS custom properties
- [ ] **AC-2.1.2:** Color tokens defined: `--color-primary`, `--color-accent`, `--color-background`, `--color-text`
- [ ] **AC-2.1.3:** Typography tokens defined: `--font-heading`, `--font-body`, `--font-size-base`
- [ ] **AC-2.1.4:** Spacing tokens defined: `--spacing-sm`, `--spacing-md`, `--spacing-lg`
- [ ] **AC-2.1.5:** `<h1>` uses `--font-heading` font family
- [ ] **AC-2.1.6:** Body text uses `--font-body` font family
- [ ] **AC-2.1.7:** Hero section has visible styling (background color, padding, centered text)
- [ ] **AC-2.1.8:** Project cards have visible styling (border or shadow, padding, background)
- [ ] **AC-2.1.9:** All CSS classes follow BEM naming convention

**Technical Notes:**
- Refer to `project_context.md` for exact token names and values
- Use `var(--token-name)` syntax throughout stylesheet
- Apply CSS reset or normalize for consistent baseline

---

## Story 2.2: Mobile-First Responsive Layout

**Title:** Implement responsive layout with mobile-first approach

**Description:** As a mobile user, I want the portfolio to display correctly on my device so that I can browse Alex's work comfortably.

**Story Points:** 2
**Priority:** High
**Status:** backlog

**Acceptance Criteria:**

- [ ] **AC-2.2.1:** Base styles (no media query) display single-column layout
- [ ] **AC-2.2.2:** `styles.css` contains `@media (min-width: 768px)` query
- [ ] **AC-2.2.3:** On mobile (<768px): project cards stack vertically in single column
- [ ] **AC-2.2.4:** On desktop (≥768px): project cards display in 3-column grid
- [ ] **AC-2.2.5:** Hero section text is readable on mobile (appropriate font sizes)
- [ ] **AC-2.2.6:** CTA button has minimum touch target of 44x44 pixels on mobile
- [ ] **AC-2.2.7:** No horizontal scrolling occurs on mobile viewport (320px minimum)
- [ ] **AC-2.2.8:** Grid uses CSS Grid or Flexbox for layout

**Technical Notes:**
- Use `grid-template-columns: 1fr` for mobile, `repeat(3, 1fr)` for desktop
- Test at 320px, 768px, and 1200px viewport widths
- Ensure `box-sizing: border-box` is applied globally

---

## Story Dependency Graph

```
Story 1.1 (Hero) ─────┐
                      ├──► Story 2.1 (Design Tokens) ──► Story 2.2 (Responsive)
Story 1.2 (Projects) ─┘
```

Epic 1 stories can be done in parallel.
Epic 2 stories depend on Epic 1 completion.
Story 2.2 can start after 2.1 establishes the design system.

---

## Definition of Done

A story is complete when:

1. All acceptance criteria are checked off
2. HTML validates (no errors in W3C validator)
3. CSS follows BEM naming throughout
4. Code is committed with descriptive message
5. Manual visual verification passes
]]></file>
<file id="a68b9042" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/implementation-artifacts/2-1-css-design-tokens-and-typography.md"><![CDATA[# Story 2.1: CSS Design Tokens and Typography

Status: done

<!-- Note: Validation is optional. Run validate-create-story for quality check before dev-story. -->

## Story

As a **developer**,
I want a **centralized design token system using CSS custom properties**,
so that **visual consistency is maintained and future changes are easy**.

## Prerequisites (Pre-existing from Epic 1)

The following criteria were completed in Story 1.1 and 1.2. Verify they remain intact:
- `:root` selector with CSS custom properties exists
- Color tokens: `--color-primary`, `--color-accent`, `--color-background`, `--color-text`, `--color-text-light`
- Typography tokens: `--font-heading`, `--font-body`, `--font-size-base`, `--font-size-lg`, `--font-size-xl`, `--font-size-xxl`
- Spacing tokens: `--spacing-xs`, `--spacing-sm`, `--spacing-md`, `--spacing-lg`

## Acceptance Criteria

1. **AC-2.1.1:** `<h1>` uses `--font-heading` font family AND `--font-size-xxl` (via `.hero__name` selector)
2. **AC-2.1.2:** Body text uses `--font-body` font family with `line-height: 1.5` (global `body` selector)
3. **AC-2.1.3:** Hero CTA button styled with `--color-accent` background, white text, padding, border-radius
4. **AC-2.1.4:** Hero CTA button has hover, focus, and active states (brightness + scale transforms)
5. **AC-2.1.5:** Hero tagline uses `--font-size-lg` for typography scale
6. **AC-2.1.6:** Project cards have box-shadow `0 2px 8px rgba(0, 0, 0, 0.1)` for depth
7. **AC-2.1.7:** Project cards have elevated shadow `0 4px 16px rgba(0, 0, 0, 0.15)` on hover
8. **AC-2.1.8:** Project cards have white background contrasting with page background
9. **AC-2.1.9:** CSS includes `@media (prefers-reduced-motion: reduce)` query disabling transitions
10. **AC-2.1.10:** All new CSS classes follow BEM naming convention
11. **AC-2.1.11:** All CSS uses `var(--token-name)` syntax, no hardcoded colors/fonts/pixels

## Tasks / Subtasks

- [x] Task 0: Verify pre-existing CSS state (Prerequisites)
  - [x] 0.1: Verify `:root` contains all color tokens with correct values
  - [x] 0.2: Verify `:root` contains all typography tokens
  - [x] 0.3: Verify `:root` contains all spacing tokens

- [x] Task 1: Apply typography tokens globally (AC: 1, 2)
  - [x] 1.1: Add `body { font-family: var(--font-body); font-size: var(--font-size-base); line-height: 1.5; color: var(--color-text); margin: 0; background-color: var(--color-background); }`
  - [x] 1.2: Add `.hero__name { font-family: var(--font-heading); font-size: var(--font-size-xxl); }`
  - [x] 1.3: Verify `<h1>` renders in Georgia serif font (--font-heading)

- [x] Task 2: Apply design tokens to hero section (AC: 3, 4, 5)
  - [x] 2.1: Add `.hero__tagline { font-size: var(--font-size-lg); }` for typography scale
  - [x] 2.2: Style `.hero__cta` button with accent color, padding, border-radius
  - [x] 2.3: Add hover state: filter brightness(0.9), scale(1.02)
  - [x] 2.4: Add focus-visible state: outline 3px solid accent, offset 2px
  - [x] 2.5: Add active state: filter brightness(0.8), scale(0.98)

- [x] Task 3: Enhance project card styling (AC: 6, 7, 8)
  - [x] 3.1: Add box-shadow `0 2px 8px rgba(0, 0, 0, 0.1)` to `.projects__card`
  - [x] 3.2: Add hover state: shadow `0 4px 16px rgba(0, 0, 0, 0.15)`, translateY(-2px)
  - [x] 3.3: Verify card background is white (--color-background)

- [x] Task 4: Add CSS reset/normalize baseline and organize CSS file
  - [x] 4.1: Add section comments to organize CSS: `/* CSS Custom Properties */`, `/* Global Typography */`, `/* Hero Section */`, `/* Projects Section */`, `/* Accessibility */`
  - [x] 4.2: Add `* { box-sizing: border-box; }`
  - [x] 4.3: Reset heading margins: `h1, h2, h3, h4, h5, h6 { margin: 0; margin-bottom: var(--spacing-sm); }`

- [x] Task 5: Add accessibility-focused styles (NFR-003) (AC: 9)
  - [x] 5.1: Add `@media (prefers-reduced-motion: reduce)` query to disable transitions

- [x] Task 6: Verify implementation (all AC)
  - [x] 6.1: Visual inspection: Hero has dark background, white text, styled CTA button
  - [x] 6.2: Visual inspection: Cards have shadows, hover effects
  - [x] 6.3: Run Playwright tests to verify no regressions
  - [x] 6.4: Verify all CSS uses `var(--token-name)` syntax, no hardcoded values

## Dev Notes

### Architecture Constraints

**From ADR-001 (Pure HTML/CSS Stack):**
- NO JavaScript - this is a hard requirement
- NO external dependencies, CSS preprocessors, or build tools
- Vanilla CSS3 only - use native CSS custom properties

**From ADR-003 (CSS Custom Properties for Theming):**
- ALL design values MUST use CSS custom properties via `var(--token-name)`
- NEVER use hardcoded hex colors, font names, or pixel values for design tokens
- This is a HIGH PRIORITY antipattern fix from Epic 1

**From ADR-004 (BEM Naming Convention):**
- All classes follow Block__Element--Modifier pattern
- New styles should extend existing BEM structure, not replace

**From ADR-005 (Mobile-First):**
- Base styles are for mobile
- Responsive breakpoints added in Story 2.2 (NOT this story)
- Do NOT add `@media (min-width: 768px)` in this story (layout queries only - accessibility queries are required)

**From NFR-002 (Maintainability):**
- CSS must be organized with clear section comments
- Use comments like `/* CSS Custom Properties */`, `/* Global Typography */`, `/* Hero Section */`, `/* Accessibility */`

**From NFR-003 (Accessibility):**
- All interactive elements must have visible focus states
- Respect `prefers-reduced-motion` for users who prefer no animation
- Color contrast must meet WCAG AA standards (already verified in design tokens)

### 🚨 CRITICAL: Antipatterns to AVOID (from Epic 1 Code Reviews)

| Antipattern | Fix | Source |
|-------------|-----|--------|
| Hardcoded CSS values instead of custom properties | Use `var(--color-primary)` not `#1a1a2e` | Story 1.1 antipatterns |
| Missing `prefers-reduced-motion` | Add media query for animations/transitions | Story 1.2 code review |
| CSS property ordering violations | Follow: positioning → display → box model → typography → visual → misc | Story 1.2 code review |

### Current CSS State (from Story 1.2 completion)

The `:root` CSS custom properties already exist:

```css
:root {
  --color-primary: #1a1a2e;
  --color-accent: #e94560;
  --color-background: #fff;
  --color-text: #333;
  --color-text-light: #666;
  --font-heading: Georgia, serif;
  --font-body: Arial, sans-serif;
  --font-size-base: 16px;
  --font-size-lg: 1.25rem;
  --font-size-xl: 2rem;
  --font-size-xxl: 3rem;
  --spacing-xs: 0.5rem;
  --spacing-sm: 1rem;
  --spacing-md: 2rem;
  --spacing-lg: 4rem;
  --max-width: 1200px;
  --border-radius: 8px;
}
```

**Existing hero styles:**
- `.hero` has `padding: var(--spacing-md)`, `background: var(--color-primary)`, centered text
- `.hero__cta` has `color: var(--color-background)` (white text)

**Existing projects styles:**
- `.projects` has padding with spacing tokens
- `.projects__title` uses `--font-heading` and `--font-size-xl`
- `.projects__card` has padding, border-radius, background
- `.projects__card-image` has height and background color
- `.projects__card-title` uses `--font-heading`
- `.projects__card-description` uses `--font-body`

### What This Story ADDS

This story is about **completing** the design token application, not starting from scratch:

1. **Typography on `body` element** - Global font stack not yet applied
2. **Typography on `.hero__name`** - The `<h1>` needs explicit `--font-heading` styling
3. **CTA button styling** - Currently only has color, needs full button treatment
4. **Hover/focus states** - UX spec requires interaction states
5. **Card shadows** - UX spec requires depth via shadows
6. **`prefers-reduced-motion`** - Accessibility requirement from NFR-003

### UX Design Token Reference

From `docs/ux-spec.md`:

| UX Goal | Token | Value | Notes |
|---------|-------|-------|-------|
| Sophisticated first impression | `--color-primary` | #1a1a2e | Dark navy hero background |
| Draw attention to contact | `--color-accent` | #e94560 | CTA button background |
| Clean gallery feel | `--color-background` | #ffffff | Card and page background |
| Readable content | `--color-text` | #333333 | Main body text |
| Elegant headings | `--font-heading` | Georgia, serif | h1, h2, h3 |
| Clear body text | `--font-body` | Arial, sans-serif | Paragraphs, descriptions |
| Consistent rhythm | `--spacing-*` | 0.5/1/2/4rem scale | All spacing |
| Professional cards | `--border-radius` | 8px | Card corners |

### CTA Button Styling (from UX spec)

| State | Visual Treatment |
|-------|------------------|
| Default | `--color-accent` background, white text, padding, border-radius |
| Hover | Slightly darker accent (filter: brightness), subtle scale (1.02) |
| Focus | Visible outline for accessibility (use accent color) |
| Active | Darker accent, scale down (0.98) |

**CSS Pattern:**
```css
.hero__cta {
  display: inline-block;
  padding: var(--spacing-sm) var(--spacing-md);
  background: var(--color-accent);
  color: var(--color-background);
  text-decoration: none;
  border-radius: var(--border-radius);
  font-family: var(--font-body);
  font-weight: bold;
  transition: transform 0.2s ease, filter 0.2s ease;
}

.hero__cta:hover {
  filter: brightness(0.9);
  transform: scale(1.02);
}

.hero__cta:focus-visible {
  outline: 3px solid var(--color-accent);
  outline-offset: 2px;
}

.hero__cta:active {
  filter: brightness(0.8);
  transform: scale(0.98);
}
```

### Project Card Styling (from UX spec)

| State | Visual Treatment |
|-------|------------------|
| Default | Subtle shadow, white background |
| Hover | Elevated shadow, slight lift effect |
| Focus | Visible outline around card |

**CSS Pattern:**
```css
.projects__card {
  /* existing box model properties first */
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  transition: box-shadow 0.2s ease, transform 0.2s ease;
}

.projects__card:hover {
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.15);
  transform: translateY(-2px);
}
```

### Accessibility Requirements (from NFR-003 + UX spec)

1. **Color Contrast:**
   - `--color-text` (#333) on white = 12.6:1 ✓
   - White on `--color-primary` (#1a1a2e) = 15.1:1 ✓
   - White on `--color-accent` (#e94560) = 4.5:1 ✓

2. **Focus States:**
   - All interactive elements MUST have visible focus states
   - Use `--color-accent` for focus outline consistency
   - NEVER use `outline: none` without replacement

3. **Motion:**
   - Respect `prefers-reduced-motion` media query
   - Disable transitions/transforms for users who prefer no motion

**CSS Pattern:**
```css
@media (prefers-reduced-motion: reduce) {
  *,
  *::before,
  *::after {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
  }
}
```

### File Locations

| File | Path | Status |
|------|------|--------|
| styles.css | `/styles.css` (project root) | MODIFY (enhance existing rules) |
| index.html | `/index.html` (project root) | NO CHANGES (HTML complete from Epic 1) |

**Constraint:** Maximum 2 files total for entire project.

### CSS Property Ordering Standard

From `project_context.md`, properties MUST be ordered:

1. **Positioning**: position, top, right, bottom, left, z-index
2. **Display**: display, flex, grid, align, justify
3. **Box model**: width, height, margin, padding, border
4. **Typography**: font-family, font-size, font-weight, line-height, text-align, color
5. **Visual**: background, box-shadow, opacity, filter
6. **Misc**: transition, animation, cursor, outline

**Note on line-height:** Use `line-height: 1.5` (unitless), NOT `1.5em` or `1.5rem`. Unitless values multiply the element's font-size and don't compound through nested elements, which is the correct CSS best practice for consistent vertical rhythm.

### What NOT To Do

- ❌ Do NOT add responsive media queries (Story 2.2 scope)
- ❌ Do NOT add `@media (min-width: 768px)` breakpoint (layout media queries only)
- ❌ Do NOT modify HTML structure (Epic 1 complete)
- ❌ Do NOT use hardcoded hex colors, font names, or px values for design tokens
- ❌ Do NOT use `outline: none` without providing alternative focus indicator
- ❌ Do NOT add new HTML elements or classes
- ❌ Do NOT add footer or contact sections (out of scope)
- ❌ Do NOT mix 6-digit and 3-digit hex formats - use existing format in styles.css

### Media Query Clarification

The "No media queries" constraint in ADR-005 applies to **layout/responsive** breakpoints (e.g., `@media (min-width: 768px)`). **Accessibility** media queries like `@media (prefers-reduced-motion: reduce)` are REQUIRED per NFR-003.

### Testing Verification

Run Playwright tests after implementation to ensure no regressions:

```bash
npx playwright test
```

Expected: All 38 tests pass (test count should remain 38 - no new tests required for this story)

**Visual Verification Checklist:**
1. Hero: Dark navy background, white text, coral CTA button with hover effect
2. Hero: CTA button has visible focus ring when tabbed
3. Cards: Have subtle shadow, shadow elevates on hover
4. Typography: Headings in Georgia serif, body in Arial sans-serif
5. No layout shifts or visual regressions from Epic 1

**Performance Check:**
```bash
# Verify CSS file size is under 10KB
wc -c styles.css
# Output should be < 10240 bytes
```

### Project Structure Notes

**Alignment with unified project structure:**
- Single `styles.css` file in project root
- All styles use CSS custom properties from `:root`
- BEM naming convention maintained

**Detected conflicts or variances:** None - this story extends Epic 1 patterns.

### Performance Budget

From Architecture:
- CSS size: < 10KB (current ~500 bytes, adding ~1KB acceptable)
- Total page weight: < 20KB (excluding images)

### Definition of Done (from epics.md)

1. All acceptance criteria are checked off
2. HTML validates (no changes expected, should still pass)
3. CSS follows BEM naming throughout
4. CSS is organized with section comments per NFR-002
5. All Playwright tests pass (38/38)
6. Manual visual verification passes
7. CSS file size under 10KB

### References

- [Source: docs/project_context.md#CSS Custom Properties]
- [Source: docs/project_context.md#CSS Rules (property ordering)]
- [Source: docs/architecture.md#ADR-003 CSS Custom Properties for Theming]
- [Source: docs/architecture.md#ADR-005 Mobile-First Responsive Design]
- [Source: docs/prd.md#FR-003: Consistent Visual Design System]
- [Source: docs/prd.md#NFR-003: Accessibility]
- [Source: docs/ux-spec.md#Design Token Mapping]
- [Source: docs/ux-spec.md#Interaction Design]
- [Source: docs/ux-spec.md#Accessibility Considerations]
- [Source: docs/epics.md#Story 2.1: CSS Design Tokens and Typography]
- [Source: _bmad-output/implementation-artifacts/antipatterns/epic-1-code-antipatterns.md]
- [Source: _bmad-output/implementation-artifacts/retrospectives/epic-1-retro-20260131.md]

## Dev Agent Record

### Agent Model Used

Claude Opus 4.5 (claude-opus-4-5-20251101)

### Debug Log References

N/A - No debug logs required for this implementation.

### Completion Notes List

1. **Prerequisites verified**: All CSS custom properties from Epic 1 confirmed present in `:root`
2. **Global typography applied**: Body element now uses `--font-body`, `--font-size-base`, `line-height: 1.5`, `--color-text`, and `--color-background`
3. **Hero section enhanced**:
   - `.hero__name` uses `--font-heading` and `--font-size-xxl`
   - `.hero__tagline` uses `--font-size-lg`
   - `.hero__cta` fully styled with accent background, padding, border-radius, and interaction states (hover/focus-visible/active)
4. **Project cards enhanced**: Box-shadow added for depth, hover state with elevated shadow and translateY transform
5. **CSS organization**: Section comments added (`/* CSS Custom Properties */`, `/* Global Typography */`, `/* Hero Section */`, `/* Projects Section */`, `/* Accessibility */`)
6. **CSS reset applied**: `box-sizing: border-box` universal selector, heading margin resets
7. **Accessibility**: `@media (prefers-reduced-motion: reduce)` media query disables transitions
8. **All 11 acceptance criteria satisfied**
9. **All 16 Playwright tests pass** for Story 2.1
10. **CSS file size**: 3,175 bytes (well under 10KB budget)
11. **Test fixes**: Updated AC-2.1.7 test to wait for transition completion, fixed AC-2.1.10 BEM regex to allow hyphens in element names
12. **Code Review Synthesis (2026-01-31)**: Applied fixes from 7 validator reviews:
    - Added new CSS custom properties: `--outline-width`, `--outline-offset`, `--card-image-height`
    - Standardized hex color format to 6-digit (`#ffffff`, `#333333`, `#666666`)
    - Fixed CSS property ordering in `.hero` (color before background) and `.hero__cta` (border-radius before font-family)
    - Removed redundant `box-sizing: border-box` from `.hero`
    - Replaced hardcoded pixel values with CSS custom properties (outline, card-image-height)
    - Added `.projects__card:focus-visible` for accessibility
    - Fixed hover state leak in AC-2.1.4 test by adding explicit mouse click reset before focus test
    - Added active state test coverage to AC-2.1.4 (missing from original implementation)
    - Replaced `page.waitForTimeout(300)` with `expect().toPass()` pattern for robust transition waiting
    - Updated outdated TDD comment in test file header

### Change Log

| Date | Author | Change |
|------|--------|--------|
| 2026-01-31 | BMad | Story created with comprehensive developer context from create-story workflow |
| 2026-01-31 | BMad | Synthesis improvements: separated Prerequisites from ACs, clarified media query constraint, added CSS organization requirements, improved task specificity |
| 2026-01-31 | Claude Opus 4.5 | Implementation complete: All 11 ACs satisfied, all tasks completed, 35/35 tests pass |
| 2026-01-31 | Code Review Synthesis | Applied 7 validator findings: fixed hex format, property ordering, hardcoded values, missing active state test, hover state leak, replaced waitForTimeout with toPass |

### File List

- `styles.css` (MODIFIED) - Complete CSS implementation with design tokens, typography, CTA styling, card shadows, hover states, prefers-reduced-motion, focus-visible states
- `tests/e2e/story-2.1-design-tokens.spec.ts` (MODIFIED) - Enabled all 16 tests (removed `test.skip`), fixed BEM regex and hover timing issues, added active state test coverage

<!-- CODE_REVIEW_SYNTHESIS_START -->
## Synthesis Summary

Synthesized findings from 7 independent code review validators. Identified 9 verified issues requiring fixes, and dismissed 4 false positives. Applied all critical and high-priority fixes to source code. All 16 Story 2.1 tests pass after fixes.

## Validations Quality

| Reviewer | Score | Assessment |
|----------|-------|------------|
| A | 8/10 | Thorough analysis, correctly identified AC-2.1.11 violations and property ordering issues. One false positive on WCAG contrast (actually passes). |
| B | 6/10 | Found legitimate issues but scored too leniently (-0.2 = APPROVED). Missed the hardcoded value violations that other reviewers caught. |
| C | 7/10 | Good catch on missing card focus-visible state and hardcoded values. Some findings duplicated other reviewers. |
| D | 6/10 | Focused narrowly on outline-offset but missed broader AC-2.1.11 violations. Low issue count (3) indicated less thorough review. |
| E | 8/10 | Excellent catch on hover state leak bug in tests and waitForTimeout anti-pattern. Good test quality analysis. |
| F | 7/10 | Correctly identified hex format inconsistency and hardcoded height. Some findings duplicated others. |
| G | 8/10 | Most comprehensive review (10 issues). Good catch on dead CSS code (animation-iteration-count) and missing active state test. |

## Issues Verified (by severity)

### Critical

**No critical issues identified.** All issues were fixable without security vulnerabilities or data corruption risks.

### High

- **Issue**: Hardcoded pixel values violate AC-2.1.11 requirement
  - **Source**: Reviewers A, C, D, F, G (5/7 consensus)
  - **File**: `styles.css:85-88, 127`
  - **Fix**: Added new CSS custom properties (`--outline-width: 3px`, `--outline-offset: 2px`, `--card-image-height: 200px`) and replaced hardcoded values with `var(--outline-width)`, `var(--outline-offset)`, `var(--card-image-height)`

- **Issue**: Missing active state test coverage for AC-2.1.4
  - **Source**: Reviewers B, E, G (3/7 consensus)
  - **File**: `tests/e2e/story-2.1-design-tokens.spec.ts:178-223`
  - **Fix**: Added active state test with `mousedown` event dispatch and assertions for brightness filter and scale transform

- **Issue**: Hex color format inconsistency (3-digit vs 6-digit)
  - **Source**: Reviewers F, G (2/7)
  - **File**: `styles.css:5-7`
  - **Fix**: Standardized all hex colors to 6-digit format: `#fff` → `#ffffff`, `#333` → `#333333`, `#666` → `#666666`

### Medium

- **Issue**: CSS property ordering violations
  - **Source**: Reviewers A, B, C, D, F (5/7 consensus)
  - **File**: `styles.css:52-57, 69-78`
  - **Fix**: Reordered properties in `.hero` (color before background) and `.hero__cta` (border-radius before font-family) to match project standard: positioning → display → box model → typography → visual → misc

- **Issue**: Brittle `waitForTimeout(300)` in AC-2.1.7 test
  - **Source**: Reviewers B, E (2/7)
  - **File**: `tests/e2e/story-2.1-design-tokens.spec.ts:290`
  - **Fix**: Replaced `await page.waitForTimeout(300)` with `await expect(async () => { ... }).toPass({ timeout: 500 })` pattern that waits for actual style changes

- **Issue**: Hover state leak in AC-2.1.4 focus test
  - **Source**: Reviewer E
  - **File**: `tests/e2e/story-2.1-design-tokens.spec.ts:189-207`
  - **Fix**: Added `await page.mouse.click(0, 0)` before focus test and changed to explicit `await ctaButton.focus()` instead of `page.keyboard.press('Tab')`

- **Issue**: Missing focus-visible state for project cards
  - **Source**: Reviewers C, G (2/7)
  - **File**: `styles.css:123-126`
  - **Fix**: Added `.projects__card:focus-visible` rule with outline styling matching CTA focus pattern

### Low

- **Issue**: Redundant `box-sizing: border-box` declaration
  - **Source**: Reviewers A, D, F (3/7 consensus)
  - **File**: `styles.css:51`
  - **Fix**: Removed redundant `box-sizing: border-box;` from `.hero` selector (already covered by universal `*` selector)

- **Issue**: Outdated TDD comment in test file header
  - **Source**: Reviewer G
  - **File**: `tests/e2e/story-2.1-design-tokens.spec.ts:4-5`
  - **Fix**: Removed outdated "TDD RED PHASE: All tests use test.skip()" comment since all tests are now enabled

## Issues Dismissed

- **Claimed Issue**: WCAG AA contrast failure for `--color-text-light: #666` on white background (3.94:1, below 4.5:1 threshold)
  - **Raised by**: Reviewer A
  - **Dismissal Reason**: FALSE POSITIVE - The claimed contrast ratio is incorrect. Using standard WCAG contrast calculation, `#666` on `#fff` actually achieves approximately 5.8:1, which passes WCAG AA. The reviewer appears to have miscalculated or used an incorrect contrast formula.

- **Claimed Issue**: `!important` in `prefers-reduced-motion` query violates "no hardcoded values" rule
  - **Raised by**: Reviewer E
  - **Dismissal Reason**: FALSE POSITIVE - The `!important` flag in accessibility media queries is a documented exception and best practice. User preference overrides (`prefers-reduced-motion`) should always win, and `!important` ensures this. This is not about "hardcoded values" but about correct accessibility implementation.

- **Claimed Issue**: `animation-iteration-count: 1` is dead code since no `@keyframes` animations exist
  - **Raised by**: Reviewer G
  - **Dismissal Reason**: DISMISSED - While technically true that no animations are currently defined, this is defensive programming. The reduced-motion query follows a standard pattern that would apply if animations were added later. Removing it would create a maintenance burden (remembering to add it when adding animations). Keeping it is harmless and follows accessibility best practices.

- **Claimed Issue**: Test file uses Node.js `fs` module directly instead of provided Read tools
  - **Raised by**: Reviewer D
  - **Dismissal Reason**: NOT APPLICABLE - This is a Playwright test file, not BMAD agent code. Playwright tests running in Node.js environment correctly use `fs.readFileSync()` to read CSS files for static analysis assertions. This is standard Playwright practice and not an issue.

## Changes Applied

**File**: `styles.css`
**Change**: Added new CSS custom properties for outline width/offset and card image height
**Before**:
```css
:root {
  --color-primary: #1a1a2e;
  --color-accent: #e94560;
  --color-background: #fff;
  --color-text: #333;
  --color-text-light: #666;
  ...
  --border-radius: 8px;
}
```
**After**:
```css
:root {
  --color-primary: #1a1a2e;
  --color-accent: #e94560;
  --color-background: #ffffff;
  --color-text: #333333;
  --color-text-light: #666666;
  ...
  --border-radius: 8px;
  --outline-width: 3px;
  --outline-offset: 2px;
  --card-image-height: 200px;
}
```

---

**File**: `styles.css`
**Change**: Fixed property ordering in `.hero` selector
**Before**:
```css
.hero {
  width: 100%;
  box-sizing: border-box;
  padding: var(--spacing-md);
  text-align: center;
  background: var(--color-primary);
  color: var(--color-background);
}
```
**After**:
```css
.hero {
  width: 100%;
  padding: var(--spacing-md);
  text-align: center;
  color: var(--color-background);
  background: var(--color-primary);
}
```

---

**File**: `styles.css`
**Change**: Fixed property ordering in `.hero__cta` and replaced hardcoded outline values
**Before**:
```css
.hero__cta {
  display: inline-block;
  padding: var(--spacing-sm) var(--spacing-md);
  font-family: var(--font-body);
  font-weight: bold;
  color: var(--color-background);
  text-decoration: none;
  background: var(--color-accent);
  border-radius: var(--border-radius);
  ...
}

.hero__cta:focus-visible {
  outline: 3px solid var(--color-accent);
  outline-offset: 2px;
}
```
**After**:
```css
.hero__cta {
  display: inline-block;
  padding: var(--spacing-sm) var(--spacing-md);
  border-radius: var(--border-radius);
  font-family: var(--font-body);
  font-weight: bold;
  color: var(--color-background);
  text-decoration: none;
  background: var(--color-accent);
  ...
}

.hero__cta:focus-visible {
  outline: var(--outline-width) solid var(--color-accent);
  outline-offset: var(--outline-offset);
}
```

---

**File**: `styles.css`
**Change**: Added missing `.projects__card:focus-visible` state
**Before**:
```css
.projects__card:hover {
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.15);
  transform: translateY(-2px);
}

.projects__card-image {
  height: 200px;
  ...
}
```
**After**:
```css
.projects__card:hover {
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.15);
  transform: translateY(-2px);
}

.projects__card:focus-visible {
  outline: var(--outline-width) solid var(--color-accent);
  outline-offset: var(--outline-offset);
}

.projects__card-image {
  height: var(--card-image-height);
  ...
}
```

---

**File**: `tests/e2e/story-2.1-design-tokens.spec.ts`
**Change**: Removed outdated TDD comment
**Before**:
```typescript
/**
 * ATDD Tests for Story 2.1: CSS Design Tokens and Typography
 *
 * TDD RED PHASE: All tests use test.skip() and will fail until feature is implemented.
 * After implementation, remove test.skip() to verify tests pass (GREEN phase).
 *
 * Acceptance Criteria:
 * ...
 */
```
**After**:
```typescript
/**
 * ATDD Tests for Story 2.1: CSS Design Tokens and Typography
 *
 * Acceptance Criteria:
 * ...
 */
```

---

**File**: `tests/e2e/story-2.1-design-tokens.spec.ts`
**Change**: Fixed hover state leak and added active state test
**Before**:
```typescript
    const ctaButton = page.locator(heroSelectors.cta);

    // When: User hovers over CTA
    await ctaButton.hover();
    await log.step('Testing hover state');

    // Then: CTA should have transform scale (1.02) on hover
    ...

    // When: User focuses CTA (keyboard navigation)
    await page.keyboard.press('Tab'); // Focus the CTA
    await log.step('Testing focus-visible state');
```
**After**:
```typescript
    const ctaButton = page.locator(heroSelectors.cta);

    // When: User hovers over CTA
    await ctaButton.hover();
    await log.step('Testing hover state');

    // Then: CTA should have transform scale (1.02) on hover
    ...

    // Clear hover state before testing focus
    await page.mouse.click(0, 0);

    // When: User focuses CTA (keyboard navigation)
    await ctaButton.focus();
    await log.step('Testing focus-visible state');

    ...

    // When: User activates CTA (active state)
    await ctaButton.dispatchEvent('mousedown');
    await log.step('Testing active state');

    // Then: CTA should have darker brightness on active
    const activeFilter = await ctaButton.evaluate((el) =>
      getComputedStyle(el).filter
    );
    expect(activeFilter).toContain('brightness');

    // And: CTA should scale down on active
    const activeTransform = await ctaButton.evaluate((el) =>
      getComputedStyle(el).transform
    );
    expect(activeTransform).not.toBe('none');
```

---

**File**: `tests/e2e/story-2.1-design-tokens.spec.ts`
**Change**: Replaced brittle waitForTimeout with robust toPass pattern
**Before**:
```typescript
    // When: User hovers over card
    await card.hover();
    // Wait for transition to complete (0.2s = 200ms + buffer)
    await page.waitForTimeout(300);
    await log.step('Testing card hover state');
```
**After**:
```typescript
    // When: User hovers over card
    await card.hover();
    // Wait for transition to complete - verify shadow changed
    await expect(async () => {
      const shadow = await card.evaluate(el => getComputedStyle(el).boxShadow);
      expect(shadow).toContain('16px'); // Hover shadow has 16px blur
    }).toPass({ timeout: 500 });
    await log.step('Testing card hover state');
```

## Files Modified

- `styles.css`
- `tests/e2e/story-2.1-design-tokens.spec.ts`
- `_bmad-output/implementation-artifacts/2-1-css-design-tokens-and-typography.md` (story file - Dev Agent Record updated)

## Suggested Future Improvements

- **Scope**: Add performance budget test for CSS file size | **Rationale**: Story claims CSS is under 10KB but no automated test verifies this. Future additions could exceed budget without detection. | **Effort**: Low (single test assertion)

- **Scope**: Consider CSS custom property for `font-weight: bold` | **Rationale**: Current implementation uses hardcoded `font-weight: bold` instead of a token. While minor, a `--font-weight-bold` token would be more consistent with the design token philosophy. | **Effort**: Low (add token, update reference)

- **Scope**: Refactor color assertions in tests to be token-agnostic | **Rationale**: Tests currently use hardcoded `rgb()` values which break if token values change. Could read tokens from CSS and compare computed values against token definitions. | **Effort**: Medium (requires parsing CSS or adding token exposure endpoint)

## Test Results

- Tests passed: 16 (all Story 2.1 tests on Chromium)
- Tests failed: 0

```
npx playwright test tests/e2e/story-2.1-design-tokens.spec.ts --project=chromium --reporter=line

Running 16 tests using 1 worker

  ✓  [chromium] › Story 2.1: CSS Design Tokens and Typography › AC-2.1.1: h1 should use --font-heading and --font-size-xxl via .hero__name
  ✓  [chromium] › Story 2.1: CSS Design Tokens and Typography › AC-2.1.2: body should use --font-body with line-height 1.5
  ✓  [chromium] › Story 2.1: CSS Design Tokens and Typography › AC-2.1.3: hero CTA should have accent background, white text, padding, and border-radius
  ✓  [chromium] › Story 2.1: CSS Design Tokens and Typography › AC-2.1.4: hero CTA should have hover, focus, and active states
  ✓  [chromium] › Story 2.1: CSS Design Tokens and Typography › AC-2.1.5: hero tagline should use --font-size-lg
  ✓  [chromium] › Story 2.1: CSS Design Tokens and Typography › AC-2.1.6: project cards should have box-shadow for depth
  ✓  [chromium] › Story 2.1: CSS Design Tokens and Typography › AC-2.1.7: project cards should have elevated shadow on hover
  ✓  [chromium] › Story 2.1: CSS Design Tokens and Typography › AC-2.1.8: project cards should have white background
  ✓  [chromium] › Story 2.1: CSS Design Tokens and Typography › AC-2.1.9: CSS should include prefers-reduced-motion media query
  ✓  [chromium] › Story 2.1: CSS Design Tokens and Typography › AC-2.1.10: all CSS classes should follow BEM naming convention
  ✓  [chromium] › Story 2.1: CSS Design Tokens and Typography › AC-2.1.11: all CSS should use var(--token) syntax for design tokens
  ✓  [chromium] › Story 2.1: CSS Organization › should have organized CSS with section comments
  ✓  [chromium] › Story 2.1: CSS Organization › should have box-sizing border-box reset
  ✓  [chromium] › Story 2.1: CSS Organization › should have heading margin resets with spacing token
  ✓  [chromium] › Story 2.1: CTA Transition › should have transition property on CTA for smooth state changes
  ✓  [chromium] › Story 2.1: Card Transition › should have transition property on cards for smooth hover

  16 passed (4.2s)
```
<!-- CODE_REVIEW_SYNTHESIS_END -->
]]></file>
<file id="b39ae4c7" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/tests/e2e/story-2.1-design-tokens.spec.ts"><![CDATA[/**
 * ATDD Tests for Story 2.1: CSS Design Tokens and Typography
 *
 * Acceptance Criteria:
 * - AC-2.1.1: h1 uses --font-heading font family AND --font-size-xxl
 * - AC-2.1.2: Body text uses --font-body font family with line-height: 1.5
 * - AC-2.1.3: Hero CTA button styled with accent background, white text, padding, border-radius
 * - AC-2.1.4: Hero CTA button has hover, focus, and active states
 * - AC-2.1.5: Hero tagline uses --font-size-lg for typography scale
 * - AC-2.1.6: Project cards have box-shadow for depth
 * - AC-2.1.7: Project cards have elevated shadow on hover
 * - AC-2.1.8: Project cards have white background contrasting with page
 * - AC-2.1.9: CSS includes @media (prefers-reduced-motion: reduce) query
 * - AC-2.1.10: All new CSS classes follow BEM naming convention
 * - AC-2.1.11: All CSS uses var(--token-name) syntax, no hardcoded values
 *
 * @see _bmad-output/implementation-artifacts/2-1-css-design-tokens-and-typography.md
 */
import { test, expect } from '../support/fixtures';
import { heroSelectors, projectsSelectors } from '../support/helpers/selectors';
import * as fs from 'fs';
import * as path from 'path';

test.describe('Story 2.1: CSS Design Tokens and Typography', () => {
  /**
   * AC-2.1.1: h1 uses --font-heading font family AND --font-size-xxl
   * Expected: .hero__name has font-family containing "Georgia" and font-size of 3rem (48px at 16px base)
   */
  test('AC-2.1.1: h1 should use --font-heading and --font-size-xxl via .hero__name', async ({
    page,
    log,
  }) => {
    // Given: User navigates to the homepage
    await page.goto('/');
    await log.step('Verifying h1 typography tokens');

    // When: The page loads
    const heroName = page.locator(heroSelectors.name);

    // Then: h1 should use --font-heading (Georgia, serif)
    const fontFamily = await heroName.evaluate((el) =>
      getComputedStyle(el).fontFamily
    );
    expect(fontFamily.toLowerCase()).toContain('georgia');

    // And: h1 should use --font-size-xxl (3rem = 48px at 16px base)
    const fontSize = await heroName.evaluate((el) =>
      getComputedStyle(el).fontSize
    );
    expect(fontSize).toBe('48px');
  });

  /**
   * AC-2.1.2: Body text uses --font-body font family with line-height: 1.5
   * Expected: body has font-family containing "Arial" and line-height of 1.5 (24px at 16px base)
   */
  test('AC-2.1.2: body should use --font-body with line-height 1.5', async ({
    page,
    log,
  }) => {
    // Given: User navigates to the homepage
    await page.goto('/');
    await log.step('Verifying body typography');

    // When: The page loads
    const body = page.locator('body');

    // Then: body should use --font-body (Arial, sans-serif)
    const fontFamily = await body.evaluate((el) =>
      getComputedStyle(el).fontFamily
    );
    expect(fontFamily.toLowerCase()).toContain('arial');

    // And: body should have line-height of 1.5 (24px at 16px base)
    const lineHeight = await body.evaluate((el) =>
      getComputedStyle(el).lineHeight
    );
    // Line-height can be computed as "24px" or "normal" depending on implementation
    // At 16px base, 1.5 = 24px
    expect(lineHeight).toBe('24px');

    // And: body should use --font-size-base (16px)
    const fontSize = await body.evaluate((el) =>
      getComputedStyle(el).fontSize
    );
    expect(fontSize).toBe('16px');

    // And: body should use --color-text (#333333)
    const color = await body.evaluate((el) =>
      getComputedStyle(el).color
    );
    // RGB equivalent of #333 or #333333
    expect(color).toBe('rgb(51, 51, 51)');

    // And: body should use --color-background (#ffffff)
    const backgroundColor = await body.evaluate((el) =>
      getComputedStyle(el).backgroundColor
    );
    expect(backgroundColor).toBe('rgb(255, 255, 255)');
  });

  /**
   * AC-2.1.3: Hero CTA button styled with accent background, white text, padding, border-radius
   * Expected: .hero__cta has specific styling from design tokens
   */
  test('AC-2.1.3: hero CTA should have accent background, white text, padding, and border-radius', async ({
    page,
    log,
  }) => {
    // Given: User navigates to the homepage
    await page.goto('/');
    await log.step('Verifying CTA button styling');

    // When: The page loads
    const ctaButton = page.locator(heroSelectors.cta);

    // Then: CTA should have --color-accent background (#e94560)
    const backgroundColor = await ctaButton.evaluate((el) =>
      getComputedStyle(el).backgroundColor
    );
    expect(backgroundColor).toBe('rgb(233, 69, 96)');

    // And: CTA should have white text (--color-background)
    const color = await ctaButton.evaluate((el) =>
      getComputedStyle(el).color
    );
    expect(color).toBe('rgb(255, 255, 255)');

    // And: CTA should have padding (--spacing-sm --spacing-md = 1rem 2rem)
    const paddingTop = await ctaButton.evaluate((el) =>
      getComputedStyle(el).paddingTop
    );
    const paddingLeft = await ctaButton.evaluate((el) =>
      getComputedStyle(el).paddingLeft
    );
    expect(paddingTop).toBe('16px'); // 1rem
    expect(paddingLeft).toBe('32px'); // 2rem

    // And: CTA should have border-radius (--border-radius = 8px)
    const borderRadius = await ctaButton.evaluate((el) =>
      getComputedStyle(el).borderRadius
    );
    expect(borderRadius).toBe('8px');

    // And: CTA should be display inline-block
    const display = await ctaButton.evaluate((el) =>
      getComputedStyle(el).display
    );
    expect(display).toBe('inline-block');

    // And: CTA should have no text decoration
    const textDecoration = await ctaButton.evaluate((el) =>
      getComputedStyle(el).textDecorationLine
    );
    expect(textDecoration).toBe('none');

    // And: CTA should use --font-body
    const fontFamily = await ctaButton.evaluate((el) =>
      getComputedStyle(el).fontFamily
    );
    expect(fontFamily.toLowerCase()).toContain('arial');

    // And: CTA should have bold font weight
    const fontWeight = await ctaButton.evaluate((el) =>
      getComputedStyle(el).fontWeight
    );
    // 700 or "bold"
    expect(parseInt(fontWeight)).toBeGreaterThanOrEqual(700);
  });

  /**
   * AC-2.1.4: Hero CTA button has hover, focus, and active states
   * Expected: CTA changes appearance on hover (brightness/scale), has focus outline, active state
   * Note: Hover state tests only on desktop (@media (hover: hover) prevents sticky hover on mobile)
   */
  test('AC-2.1.4: hero CTA should have hover, focus, and active states', async ({
    page,
    log,
  }) => {
    // Skip on mobile devices that don't support hover
    const isMobile = await page.evaluate(() =>
      window.matchMedia('(hover: none)').matches
    );
    if (isMobile) {
      test.skip();
    }

    // Given: User navigates to the homepage
    await page.goto('/');
    await log.step('Verifying CTA interaction states');

    const ctaButton = page.locator(heroSelectors.cta);

    // When: User hovers over CTA
    await ctaButton.hover();
    await log.step('Testing hover state');

    // Then: CTA should have transform scale (1.02) on hover
    const hoverTransform = await ctaButton.evaluate((el) =>
      getComputedStyle(el).transform
    );
    // Transform matrix for scale(1.02) contains ~1.02 values
    expect(hoverTransform).not.toBe('none');
    expect(hoverTransform).toContain('matrix');

    // And: CTA should have filter applied (brightness)
    const hoverFilter = await ctaButton.evaluate((el) =>
      getComputedStyle(el).filter
    );
    expect(hoverFilter).toContain('brightness');

    // Clear hover state before testing focus
    await page.mouse.click(0, 0);

    // When: User focuses CTA (keyboard navigation)
    await ctaButton.focus();
    await log.step('Testing focus-visible state');

    // Then: CTA should have visible outline
    const outline = await ctaButton.evaluate((el) =>
      getComputedStyle(el).outline
    );
    // Outline should include accent color and be visible (not "none" or "0px")
    expect(outline).not.toBe('none');
    expect(outline).not.toMatch(/^0px/);

    // And: CTA should have outline-offset
    const outlineOffset = await ctaButton.evaluate((el) =>
      getComputedStyle(el).outlineOffset
    );
    expect(outlineOffset).toBe('2px');

    // When: User activates CTA (active state)
    await ctaButton.dispatchEvent('mousedown');
    await log.step('Testing active state');

    // Then: CTA should have darker brightness on active
    const activeFilter = await ctaButton.evaluate((el) =>
      getComputedStyle(el).filter
    );
    expect(activeFilter).toContain('brightness');

    // And: CTA should scale down on active
    const activeTransform = await ctaButton.evaluate((el) =>
      getComputedStyle(el).transform
    );
    expect(activeTransform).not.toBe('none');
  });

  /**
   * AC-2.1.5: Hero tagline uses --font-size-lg for typography scale
   * Expected: .hero__tagline has font-size of 1.25rem (20px at 16px base)
   */
  test('AC-2.1.5: hero tagline should use --font-size-lg', async ({
    page,
    log,
  }) => {
    // Given: User navigates to the homepage
    await page.goto('/');
    await log.step('Verifying tagline typography');

    // When: The page loads
    const tagline = page.locator(heroSelectors.tagline);

    // Then: Tagline should use --font-size-lg (1.25rem = 20px at 16px base)
    const fontSize = await tagline.evaluate((el) =>
      getComputedStyle(el).fontSize
    );
    expect(fontSize).toBe('20px');
  });

  /**
   * AC-2.1.6: Project cards have box-shadow for depth
   * Expected: .projects__card has box-shadow "0 2px 8px rgba(0, 0, 0, 0.1)"
   */
  test('AC-2.1.6: project cards should have box-shadow for depth', async ({
    page,
    log,
  }) => {
    // Given: User navigates to the homepage
    await page.goto('/');
    await log.step('Verifying card shadow');

    // When: The page loads
    const card = page.locator(projectsSelectors.card).first();

    // Then: Card should have subtle box-shadow
    const boxShadow = await card.evaluate((el) =>
      getComputedStyle(el).boxShadow
    );
    // Expected: rgba(0, 0, 0, 0.1) 0px 2px 8px 0px
    expect(boxShadow).not.toBe('none');
    expect(boxShadow).toContain('rgba(0, 0, 0');
    expect(boxShadow).toContain('2px');
    expect(boxShadow).toContain('8px');
  });

  /**
   * AC-2.1.7: Project cards have elevated shadow on hover
   * Expected: .projects__card:hover has box-shadow "0 4px 16px rgba(0, 0, 0, 0.15)"
   * Note: Hover state tests only on desktop (@media (hover: hover) prevents sticky hover on mobile)
   */
  test('AC-2.1.7: project cards should have elevated shadow on hover', async ({
    page,
    log,
  }) => {
    // Skip on mobile devices that don't support hover
    const isMobile = await page.evaluate(() =>
      window.matchMedia('(hover: none)').matches
    );
    if (isMobile) {
      test.skip();
    }

    // Given: User navigates to the homepage
    await page.goto('/');
    await log.step('Verifying card hover shadow');

    const card = page.locator(projectsSelectors.card).first();

    // When: User hovers over card
    await card.hover();
    // Wait for transition to complete - verify shadow changed
    await expect(async () => {
      const shadow = await card.evaluate(el => getComputedStyle(el).boxShadow);
      expect(shadow).toContain('16px'); // Hover shadow has 16px blur
    }).toPass({ timeout: 500 });
    await log.step('Testing card hover state');

    // Then: Card should have elevated shadow with larger blur
    const hoverShadow = await card.evaluate((el) =>
      getComputedStyle(el).boxShadow
    );
    // Expected: rgba(0, 0, 0, 0.15) 0px 4px 16px 0px
    expect(hoverShadow).not.toBe('none');
    expect(hoverShadow).toContain('rgba(0, 0, 0');
    expect(hoverShadow).toContain('4px');
    expect(hoverShadow).toContain('16px');

    // And: Card should lift slightly (translateY)
    const transform = await card.evaluate((el) =>
      getComputedStyle(el).transform
    );
    expect(transform).not.toBe('none');
  });

  /**
   * AC-2.1.8: Project cards have white background
   * Expected: .projects__card has background-color of #ffffff (--color-background)
   */
  test('AC-2.1.8: project cards should have white background', async ({
    page,
    log,
  }) => {
    // Given: User navigates to the homepage
    await page.goto('/');
    await log.step('Verifying card background');

    // When: The page loads
    const card = page.locator(projectsSelectors.card).first();

    // Then: Card should have white background (--color-background)
    const backgroundColor = await card.evaluate((el) =>
      getComputedStyle(el).backgroundColor
    );
    expect(backgroundColor).toBe('rgb(255, 255, 255)');
  });

  /**
   * AC-2.1.9: CSS includes @media (prefers-reduced-motion: reduce) query
   * Expected: styles.css contains the accessibility media query
   */
  test('AC-2.1.9: CSS should include prefers-reduced-motion media query', async ({
    log,
  }) => {
    await log.step('Verifying reduced motion media query in CSS');

    // Read styles.css file directly
    const stylesPath = path.resolve(__dirname, '../../styles.css');
    const cssContent = fs.readFileSync(stylesPath, 'utf-8');

    // Then: CSS should contain prefers-reduced-motion media query
    expect(cssContent).toContain('@media (prefers-reduced-motion: reduce)');

    // And: It should disable transitions/animations
    const reducedMotionMatch = cssContent.match(
      /@media\s*\(\s*prefers-reduced-motion:\s*reduce\s*\)\s*\{([^}]+)\}/s
    );
    expect(reducedMotionMatch).not.toBeNull();

    // Verify it targets transitions or animations
    const mediaQueryContent = reducedMotionMatch![1];
    const hasTransitionRule = mediaQueryContent.includes('transition-duration') ||
      mediaQueryContent.includes('transition:');
    const hasAnimationRule = mediaQueryContent.includes('animation-duration') ||
      mediaQueryContent.includes('animation:') ||
      mediaQueryContent.includes('animation-iteration-count');

    expect(hasTransitionRule || hasAnimationRule).toBe(true);
  });

  /**
   * AC-2.1.10: All new CSS classes follow BEM naming convention
   * Expected: No non-BEM class names in styles.css
   */
  test('AC-2.1.10: all CSS classes should follow BEM naming convention', async ({
    log,
  }) => {
    await log.step('Verifying BEM naming convention');

    // Read styles.css file directly
    const stylesPath = path.resolve(__dirname, '../../styles.css');
    const cssContent = fs.readFileSync(stylesPath, 'utf-8');

    // Extract all class selectors (excluding pseudo-classes/elements)
    const classMatches = cssContent.match(/\.[\w-]+(?=\s*[,{:]|\s*\[)/g) || [];
    const uniqueClasses = [...new Set(classMatches.map(c => c.slice(1)))]; // Remove leading dot

    // BEM pattern: block, block__element, block--modifier, block__element--modifier
    // Element and modifier names can contain hyphens (e.g., card-image, card-title)
    const bemPattern = /^[a-z][a-z0-9-]*(?:__[a-z][a-z0-9-]*)?(?:--[a-z][a-z0-9-]*)?$/;

    // Allowed non-BEM (reset/base selectors)
    const allowedNonBem = ['body', 'html', '*'];

    const nonBemClasses = uniqueClasses.filter(className => {
      // Skip allowed base selectors
      if (allowedNonBem.includes(className)) return false;
      // Check BEM pattern
      return !bemPattern.test(className);
    });

    expect(nonBemClasses).toEqual([]);
  });

  /**
   * AC-2.1.11: All CSS uses var(--token-name) syntax, no hardcoded colors/fonts/pixels
   * Expected: No hardcoded hex colors, font names, or design token values in property values
   */
  test('AC-2.1.11: all CSS should use var(--token) syntax for design tokens', async ({
    log,
  }) => {
    await log.step('Verifying CSS custom property usage');

    // Read styles.css file directly
    const stylesPath = path.resolve(__dirname, '../../styles.css');
    const cssContent = fs.readFileSync(stylesPath, 'utf-8');

    // Remove :root block (custom property definitions are allowed there)
    const cssWithoutRoot = cssContent.replace(/:root\s*\{[^}]+\}/gs, '');

    // Remove comments
    const cssWithoutComments = cssWithoutRoot.replace(/\/\*[\s\S]*?\*\//g, '');

    // Check for hardcoded hex colors (should use var(--color-*))
    // Allow rgba() for shadows which are acceptable
    const hexColorPattern = /#[0-9a-fA-F]{3,6}(?![0-9a-fA-F])/g;
    const hexMatches = cssWithoutComments.match(hexColorPattern) || [];
    expect(hexMatches).toEqual([]);

    // Check for hardcoded font families (should use var(--font-*))
    // Pattern matches font-family declarations with literal font names
    const hardcodedFonts = cssWithoutComments.match(
      /font-family:\s*(?!var\()[^;]+(?:Georgia|Arial|serif|sans-serif)/gi
    );
    expect(hardcodedFonts || []).toEqual([]);

    // Check for hardcoded pixel values for spacing/sizing (should use var(--spacing-*))
    // Allow specific exceptions: box-shadow offsets, outline-offset, 0px
    // This is a simplified check - we look for padding/margin with px values
    const hardcodedSpacing = cssWithoutComments.match(
      /(?:padding|margin)(?:-(?:top|right|bottom|left))?:\s*(?!var\()(?!0)\d+px/gi
    );
    expect(hardcodedSpacing || []).toEqual([]);
  });
});

test.describe('Story 2.1: CSS Organization', () => {
  /**
   * Verify CSS file has section comments for organization (NFR-002)
   */
  test('should have organized CSS with section comments', async ({
    log,
  }) => {
    await log.step('Verifying CSS organization');

    // Read styles.css file directly
    const stylesPath = path.resolve(__dirname, '../../styles.css');
    const cssContent = fs.readFileSync(stylesPath, 'utf-8');

    // Then: CSS should have section comments
    expect(cssContent).toContain('/* CSS Custom Properties */');
    expect(cssContent).toContain('/* Global Typography */');
    expect(cssContent).toContain('/* Hero Section */');
    expect(cssContent).toContain('/* Projects Section */');
    expect(cssContent).toContain('/* Accessibility */');
  });

  /**
   * Verify CSS has box-sizing reset
   */
  test('should have box-sizing border-box reset', async ({
    page,
    log,
  }) => {
    await log.step('Verifying box-sizing reset');

    // Given: User navigates to the homepage
    await page.goto('/');

    // When: Checking any element
    const body = page.locator('body');

    // Then: Elements should use border-box
    const boxSizing = await body.evaluate((el) =>
      getComputedStyle(el).boxSizing
    );
    expect(boxSizing).toBe('border-box');
  });

  /**
   * Verify headings have reset margins
   */
  test('should have heading margin resets with spacing token', async ({
    page,
    log,
  }) => {
    await log.step('Verifying heading margin reset');

    // Given: User navigates to the homepage
    await page.goto('/');

    // When: Checking h1 element
    const h1 = page.locator('h1').first();

    // Then: h1 should have margin-top of 0
    const marginTop = await h1.evaluate((el) =>
      getComputedStyle(el).marginTop
    );
    expect(marginTop).toBe('0px');

    // And: h1 should have margin-bottom from --spacing-sm (1rem = 16px)
    const marginBottom = await h1.evaluate((el) =>
      getComputedStyle(el).marginBottom
    );
    expect(marginBottom).toBe('16px');
  });
});

test.describe('Story 2.1: CTA Transition', () => {
  /**
   * Verify CTA has transition property for smooth hover effects
   */
  test('should have transition property on CTA for smooth state changes', async ({
    page,
    log,
  }) => {
    await log.step('Verifying CTA transition');

    // Given: User navigates to the homepage
    await page.goto('/');

    // When: Checking CTA element
    const ctaButton = page.locator(heroSelectors.cta);

    // Then: CTA should have transition defined
    const transition = await ctaButton.evaluate((el) =>
      getComputedStyle(el).transition
    );
    expect(transition).not.toBe('all 0s ease 0s');
    expect(transition).toContain('transform');
  });
});

test.describe('Story 2.1: Card Transition', () => {
  /**
   * Verify cards have transition property for smooth hover effects
   */
  test('should have transition property on cards for smooth hover', async ({
    page,
    log,
  }) => {
    await log.step('Verifying card transition');

    // Given: User navigates to the homepage
    await page.goto('/');

    // When: Checking card element
    const card = page.locator(projectsSelectors.card).first();

    // Then: Card should have transition defined
    const transition = await card.evaluate((el) =>
      getComputedStyle(el).transition
    );
    expect(transition).not.toBe('all 0s ease 0s');
    expect(transition).toContain('box-shadow');
  });
});
]]></file>
</context>
<variables>
<var name="architecture_file" description="Architecture (fallback - epics file should have relevant sections)" />
<var name="author">BMad</var>
<var name="communication_language">English</var>
<var name="date">2026-01-31</var>
<var name="default_output_file">/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/implementation-artifacts/2-2-mobile-first-responsive-layout.md</var>
<var name="description">Create the next user story from epics+stories with enhanced context analysis and direct ready-for-dev marking</var>
<var name="document_output_language">English</var>
<var name="epic_num">2</var>
<var name="epics_file" description="Enhanced epics+stories file with BDD and source hints" />
<var name="implementation_artifacts">/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/implementation-artifacts</var>
<var name="name">create-story</var>
<var name="output_folder">/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/implementation-artifacts</var>
<var name="planning_artifacts">/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/planning-artifacts</var>
<var name="prd_file" description="PRD (fallback - epics file should have most content)" />
<var name="project_context">none</var>
<var name="project_knowledge">/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/docs</var>
<var name="project_name">simple-portfolio</var>
<var name="sprint_status">/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/implementation-artifacts/sprint-status.yaml</var>
<var name="story_dir">/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/implementation-artifacts</var>
<var name="story_id">2.2</var>
<var name="story_key">2-2-mobile-first-responsive-layout</var>
<var name="story_num">2</var>
<var name="story_title">mobile-first-responsive-layout</var>
<var name="timestamp">20260131_2303</var>
<var name="user_name">User</var>
<var name="user_skill_level">expert</var>
<var name="ux_file" description="UX design (fallback - epics file should have relevant sections)" />
</variables>
<file-index>
<entry id="a68b9042" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/implementation-artifacts/2-1-css-design-tokens-and-typography.md" />
<entry id="2e55b2e3" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/docs/architecture.md" />
<entry id="d95c5b57" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/docs/epics.md" />
<entry id="bda659bb" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/docs/prd.md" />
<entry id="11c89e12" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/docs/project_context.md" />
<entry id="07a30897" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/docs/ux-spec.md" />
<entry id="b39ae4c7" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/tests/e2e/story-2.1-design-tokens.spec.ts" />
</file-index>
<instructions><workflow>
  <critical>🚫 SCOPE LIMITATION: Your ONLY task is to create the story markdown file. Do NOT read, modify, or update any sprint tracking files - that is handled programmatically by bmad-assist.</critical>
<critical>You MUST have already loaded and processed: the &lt;workflow-yaml&gt; section embedded above</critical>
  <critical>Communicate all responses in English and generate all documents in English</critical>

  <critical>🔥 CRITICAL MISSION: You are creating the ULTIMATE story context engine that prevents LLM developer mistakes, omissions or
    disasters! 🔥</critical>
  <critical>Your purpose is NOT to copy from epics - it's to create a comprehensive, optimized story file that gives the DEV agent
    EVERYTHING needed for flawless implementation</critical>
  <critical>COMMON LLM MISTAKES TO PREVENT: reinventing wheels, wrong libraries, wrong file locations, breaking regressions, ignoring UX,
    vague implementations, lying about completion, not learning from past work</critical>
  <critical>🚨 EXHAUSTIVE ANALYSIS REQUIRED: You must thoroughly analyze ALL artifacts to extract critical context - do NOT be lazy or skim!
    This is the most important function in the entire development process!</critical>
  <critical>🔬 UTILIZE SUBPROCESSES AND SUBAGENTS: Use research subagents, subprocesses or parallel processing if available to thoroughly
    analyze different artifacts simultaneously and thoroughly</critical>
  <critical>❓ SAVE QUESTIONS: If you think of questions or clarifications during analysis, save them for the end after the complete story is
    written</critical>
  <critical>🎯 ZERO USER INTERVENTION: Process should be fully automated except for initial epic/story selection or missing documents</critical>
  <critical>📊 Git Intelligence is EMBEDDED in &lt;git-intelligence&gt; at the start of the prompt - do NOT run git commands yourself, use the embedded data instead</critical>

  <step n="1" goal="Architecture analysis for developer guardrails">
    <critical>🏗️ ARCHITECTURE INTELLIGENCE - Extract everything the developer MUST follow!</critical> **ARCHITECTURE DOCUMENT ANALYSIS:** <action>Systematically
    analyze architecture content for story-relevant requirements:</action>

    <!-- Load architecture - single file or sharded -->
    <check if="architecture file is single file">
      <action>Load complete {architecture_content}</action>
    </check>
    <check if="architecture is sharded to folder">
      <action>Load architecture index and scan all architecture files</action>
    </check> **CRITICAL ARCHITECTURE EXTRACTION:** <action>For
    each architecture section, determine if relevant to this story:</action> - **Technical Stack:** Languages, frameworks, libraries with
    versions - **Code Structure:** Folder organization, naming conventions, file patterns - **API Patterns:** Service structure, endpoint
    patterns, data contracts - **Database Schemas:** Tables, relationships, constraints relevant to story - **Security Requirements:**
    Authentication patterns, authorization rules - **Performance Requirements:** Caching strategies, optimization patterns - **Testing
    Standards:** Testing frameworks, coverage expectations, test patterns - **Deployment Patterns:** Environment configurations, build
    processes - **Integration Patterns:** External service integrations, data flows <action>Extract any story-specific requirements that the
    developer MUST follow</action>
    <action>Identify any architectural decisions that override previous patterns</action>
  </step>

  <step n="2" goal="Web research for latest technical specifics">
    <critical>🌐 ENSURE LATEST TECH KNOWLEDGE - Prevent outdated implementations!</critical> **WEB INTELLIGENCE:** <action>Identify specific
    technical areas that require latest version knowledge:</action>

    <!-- Check for libraries/frameworks mentioned in architecture -->
    <action>From architecture analysis, identify specific libraries, APIs, or
    frameworks</action>
    <action>For each critical technology, research latest stable version and key changes:
      - Latest API documentation and breaking changes
      - Security vulnerabilities or updates
      - Performance improvements or deprecations
      - Best practices for current version
    </action>
    **EXTERNAL CONTEXT INCLUSION:** <action>Include in story any critical latest information the developer needs:
      - Specific library versions and why chosen
      - API endpoints with parameters and authentication
      - Recent security patches or considerations
      - Performance optimization techniques
      - Migration considerations if upgrading
    </action>
  </step>

  <step n="3" goal="Create comprehensive story file">
    <critical>📝 CREATE ULTIMATE STORY FILE - The developer's master implementation guide!</critical>

    <action>Create file using the output-template format at: /home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/implementation-artifacts/2-2-mobile-first-responsive-layout.md</action>
    <!-- Story foundation from epics analysis -->
    <!-- Developer context section - MOST IMPORTANT PART -->
    <!-- Previous story intelligence -->
    <!-- Git intelligence -->
    <!-- Latest technical specifics -->
    <!-- Project context reference -->
    <!-- Final status update -->
    <!-- CRITICAL: Set status to ready-for-dev -->
    <action>Set story Status to: "ready-for-dev"</action>
    <action>Add completion note: "Ultimate
    context engine analysis completed - comprehensive developer guide created"</action>
  </step>

  <step n="4" goal="Validate and finalize">
    <!-- checklist validation is separate workflow -->
    <action>Save story document unconditionally</action>

    <action>Report completion</action>
    </step>

</workflow></instructions>
<output-template><![CDATA[# Story {{epic_num}}.{{story_num}}: {{story_title}}

Status: ready-for-dev

<!-- Note: Validation is optional. Run validate-create-story for quality check before dev-story. -->

## Story

As a {{role}},
I want {{action}},
so that {{benefit}}.

## Acceptance Criteria

1. [Add acceptance criteria from epics/PRD]

## Tasks / Subtasks

- [ ] Task 1 (AC: #)
  - [ ] Subtask 1.1
- [ ] Task 2 (AC: #)
  - [ ] Subtask 2.1

## Dev Notes

- Relevant architecture patterns and constraints
- Source tree components to touch
- Testing standards summary

### Project Structure Notes

- Alignment with unified project structure (paths, modules, naming)
- Detected conflicts or variances (with rationale)

### References

- Cite all technical details with source paths and sections, e.g. [Source: docs/<file>.md#Section]

## Dev Agent Record

### Agent Model Used

{{agent_model_name_version}}

### Debug Log References

### Completion Notes List

### File List]]></output-template>
</compiled-workflow>