<?xml version="1.0" encoding="UTF-8"?>
<!-- BMAD Prompt Run Metadata -->
<!-- Epic: 2 -->
<!-- Story: 2 -->
<!-- Phase: tea-test-design -->
<!-- Timestamp: 20260131T220203Z -->
<compiled-workflow>
<mission><![CDATA[Dual-mode workflow: (1) System-level testability review in Solutioning phase, or (2) Epic-level test planning in Implementation phase. Auto-detects mode based on project phase.

Mode: Create
Target: Story 2.2]]></mission>
<context>
<file id="11c89e12" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/docs/project_context.md"><![CDATA[# Project Context: Alex Chen Photography Portfolio

## Overview

Static portfolio website for freelance photographer. Pure HTML/CSS, no JavaScript.

## File Structure

```
index.html    # Single page, semantic HTML5
styles.css    # All styles, BEM naming
```

## Coding Standards

### HTML Rules

- Use semantic elements: `<header>`, `<main>`, `<section>`, `<article>`, `<footer>`
- Proper heading hierarchy: single `<h1>`, then `<h2>`, `<h3>` as needed
- 2-space indentation
- Double quotes for attributes
- Self-closing tags for void elements: `<img />`, `<br />`
- Always include `alt` attribute on images

### CSS Rules

- **BEM naming convention:**
  - Block: `.hero`, `.projects`
  - Element: `.hero__title`, `.projects__card`
  - Modifier: `.hero__cta--primary`, `.projects__card--featured`
- 2-space indentation
- One property per line
- Opening brace on same line as selector
- Blank line between rule sets
- Properties ordered: positioning → display → box model → typography → visual → misc

### CSS Custom Properties

Define all design tokens in `:root`:

```css
:root {
  /* Colors */
  --color-primary: #1a1a2e;
  --color-accent: #e94560;
  --color-background: #ffffff;
  --color-text: #333333;
  --color-text-light: #666666;

  /* Typography */
  --font-heading: 'Georgia', serif;
  --font-body: 'Arial', sans-serif;
  --font-size-base: 16px;
  --font-size-lg: 1.25rem;
  --font-size-xl: 2rem;
  --font-size-xxl: 3rem;

  /* Spacing */
  --spacing-xs: 0.5rem;
  --spacing-sm: 1rem;
  --spacing-md: 2rem;
  --spacing-lg: 4rem;

  /* Layout */
  --max-width: 1200px;
  --border-radius: 8px;
}
```

### Responsive Design

- Mobile-first approach
- Single breakpoint: `768px`
- Use `min-width` media queries only

```css
/* Mobile styles (default) */
.projects__grid {
  display: grid;
  grid-template-columns: 1fr;
}

/* Desktop styles */
@media (min-width: 768px) {
  .projects__grid {
    grid-template-columns: repeat(3, 1fr);
  }
}
```

## Component Structure

### Hero Section

```html
<header class="hero">
  <h1 class="hero__name">Alex Chen</h1>
  <p class="hero__tagline">Capturing moments that last forever</p>
  <a href="#contact" class="hero__cta">Get in Touch</a>
</header>
```

### Projects Section

```html
<main>
  <section class="projects">
    <h2 class="projects__title">Portfolio</h2>
    <div class="projects__grid">
      <article class="projects__card">
        <div class="projects__card-image"></div>
        <h3 class="projects__card-title">Wedding</h3>
        <p class="projects__card-description">...</p>
      </article>
      <!-- Repeat for Portrait, Landscape -->
    </div>
  </section>
</main>
```

## Constraints

- No JavaScript
- No external dependencies
- No CSS preprocessors
- No build tools
- Maximum 2 files (index.html + styles.css)

## Testing Verification

Verify implementation by checking:

1. **Hero section:** `<header class="hero">` exists with `<h1>`, tagline `<p>`, and CTA `<a>`
2. **Projects section:** `<section class="projects">` with exactly 3 `<article class="projects__card">`
3. **CSS variables:** `:root` block defines `--color-*`, `--font-*`, `--spacing-*`
4. **Responsive:** `@media (min-width: 768px)` present in styles.css
5. **BEM naming:** All classes follow `block__element--modifier` pattern
]]></file>
<file id="bda659bb" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/docs/prd.md"><![CDATA[# Product Requirements Document: Alex Chen Photography Portfolio

## Overview

**Product Name:** Alex Chen Photography Portfolio
**Version:** 1.0
**Author:** John (Product Manager)
**Date:** 2025-12-11

## Problem Statement

Alex Chen is a freelance photographer who needs a simple, professional online presence to showcase work to potential clients. Current solution (social media) lacks professionalism and doesn't provide a dedicated space for portfolio presentation.

## Goals

1. Establish professional online presence
2. Showcase photography portfolio effectively
3. Provide clear call-to-action for client inquiries
4. Ensure accessibility across devices

## Target Audience

- Potential clients seeking photography services (weddings, portraits, landscapes)
- Industry peers and collaborators
- Anyone discovering Alex through referrals

## Functional Requirements

### FR-001: Hero Section with Branding

**Description:** The landing page must feature a prominent hero section that establishes brand identity.

**Acceptance Criteria:**
- Display photographer name "Alex Chen" as primary heading
- Include professional tagline communicating photography focus
- Provide clear call-to-action button for contact/inquiry
- Hero section spans full viewport width

### FR-002: Projects Gallery Section

**Description:** A dedicated section showcasing photography projects with visual cards.

**Acceptance Criteria:**
- Display exactly 3 project cards (Wedding, Portrait, Landscape)
- Each card contains: image placeholder, project title, brief description
- Cards arranged in responsive grid layout
- Semantic HTML structure using article elements

### FR-003: Consistent Visual Design System

**Description:** Implement cohesive visual design using CSS custom properties.

**Acceptance Criteria:**
- Define color palette via CSS custom properties in :root
- Establish typography scale (headings, body, captions)
- Consistent spacing using CSS variables
- BEM naming convention for all CSS classes

### FR-004: Mobile-Responsive Layout

**Description:** Ensure optimal viewing experience across device sizes.

**Acceptance Criteria:**
- Mobile-first CSS approach
- Breakpoint at 768px for tablet/desktop layouts
- Hero section adapts to viewport
- Project cards stack vertically on mobile, grid on desktop
- All interactive elements have appropriate touch targets

## Non-Functional Requirements

### NFR-001: Performance
- No JavaScript dependencies
- Single CSS file under 10KB
- Page loads in under 1 second on 3G

### NFR-002: Maintainability
- Semantic HTML5 elements
- Well-commented CSS sections
- BEM methodology for scalable styles

### NFR-003: Accessibility
- Proper heading hierarchy (h1 > h2 > h3)
- Sufficient color contrast ratios
- Focus states for interactive elements

## Out of Scope

- Contact form functionality
- Image gallery lightbox
- CMS integration
- Multi-page navigation
- JavaScript interactions

## Success Metrics

- Clean, valid HTML5 markup
- CSS passes linting with no errors
- Responsive design works on mobile and desktop viewports
- All acceptance criteria met for FR-001 through FR-004
]]></file>
<file id="2e55b2e3" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/docs/architecture.md"><![CDATA[# Architecture Document: Alex Chen Photography Portfolio

## Overview

**Project:** Alex Chen Photography Portfolio
**Architect:** Winston
**Date:** 2025-12-11
**Status:** Approved

## Architecture Philosophy

This is a deliberately simple, static website. We embrace "boring technology" - proven HTML and CSS patterns that require no build tools, no frameworks, and no JavaScript. The architecture prioritizes maintainability and performance over sophistication.

## Technology Decisions

### ADR-001: Pure HTML/CSS Stack

**Decision:** Use vanilla HTML5 and CSS3 only. No JavaScript.

**Context:** Portfolio is purely presentational. No dynamic functionality required.

**Rationale:**
- Zero runtime dependencies
- No build pipeline needed
- Maximum browser compatibility
- Fastest possible load times
- Easy to maintain and modify

**Consequences:**
- No interactive features (acceptable per PRD scope)
- Contact requires mailto: link or external form service

### ADR-002: Single Page Architecture

**Decision:** Entire portfolio on one `index.html` page.

**Context:** Only 2 content sections needed (hero + projects).

**Rationale:**
- Simpler navigation (scroll-based)
- Single HTTP request for HTML
- No routing complexity
- Easier testing and verification

**Consequences:**
- Must use anchor links if navigation added later
- Page weight grows with content (acceptable for 2 sections)

### ADR-003: CSS Custom Properties for Theming

**Decision:** Define all design tokens as CSS custom properties in `:root`.

**Context:** Need consistent colors, typography, and spacing.

**Rationale:**
- Single source of truth for design values
- Easy theme modifications
- Native browser support (no preprocessor)
- Runtime flexibility for future enhancements

**Implementation:**
```css
:root {
  --color-primary: #1a1a2e;
  --color-accent: #e94560;
  --color-background: #ffffff;
  --color-text: #333333;
  --font-heading: 'Georgia', serif;
  --font-body: 'Arial', sans-serif;
  --spacing-unit: 1rem;
}
```

### ADR-004: BEM Naming Convention

**Decision:** Use Block__Element--Modifier pattern for all CSS classes.

**Context:** Need scalable, predictable CSS architecture.

**Rationale:**
- Self-documenting class names
- Avoids specificity conflicts
- Clear component boundaries
- Industry standard, widely understood

**Examples:**
- `.hero` (block)
- `.hero__title` (element)
- `.hero__cta--primary` (modifier)
- `.projects__card` (element)

### ADR-005: Mobile-First Responsive Design

**Decision:** Base styles target mobile, media queries enhance for larger screens.

**Context:** Significant mobile traffic expected for portfolio viewing.

**Rationale:**
- Progressive enhancement philosophy
- Smaller devices get minimal CSS
- Easier to scale up than scale down
- Better performance on constrained devices

**Breakpoints:**
- Base: 0-767px (mobile)
- Desktop: 768px+ (tablet and above)

### ADR-006: Semantic HTML5 Structure

**Decision:** Use semantic elements over generic divs.

**Context:** Need accessible, well-structured markup.

**Rationale:**
- Built-in accessibility benefits
- Better SEO signals
- Self-documenting structure
- Screen reader friendly

**Element Mapping:**
| Content | Element |
|---------|---------|
| Page header with hero | `<header>` |
| Main content area | `<main>` |
| Hero section | `<section class="hero">` |
| Projects section | `<section class="projects">` |
| Individual project | `<article class="projects__card">` |
| Page footer | `<footer>` |

## File Structure

```
portfolio-project/
├── index.html          # Single HTML page
├── styles.css          # All styles
├── docs/
│   ├── prd.md
│   ├── architecture.md
│   ├── project_context.md
│   └── epics.md
└── bmad-assist.yaml
```

## Performance Budget

| Metric | Target |
|--------|--------|
| HTML size | < 5KB |
| CSS size | < 10KB |
| Total page weight | < 20KB (excluding images) |
| First Contentful Paint | < 1s on 3G |

## Security Considerations

- No user input handling (no forms)
- No external scripts
- No cookies or local storage
- Static hosting compatible (no server-side logic)

## Future Considerations

If requirements expand:
- Contact form: Consider external service (Formspree, Netlify Forms)
- Image optimization: Add srcset for responsive images
- Analytics: Add privacy-respecting solution (Plausible, Fathom)
- Multi-page: Consider static site generator

These are explicitly out of scope for v1.0.
]]></file>
<file id="da9a0578" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/implementation-artifacts/2-2-mobile-first-responsive-layout.md"><![CDATA[# Story 2.2: Mobile-First Responsive Layout

Status: done

<!-- Note: Validation is optional. Run validate-create-story for quality check before dev-story. -->

## Story

As a **mobile user**,
I want the **portfolio to display correctly on my device**,
so that **I can browse Alex's work comfortably regardless of screen size**.

## Prerequisites (Pre-existing from Story 2.1)

The following must be verified before implementation:
- CSS custom properties defined in `:root` (colors, fonts, spacing, border-radius)
- Typography tokens applied (body, headings, tagline)
- Hero section styling complete (background, padding, CTA button)
- Project card styling complete (shadows, hover states, focus states)
- `prefers-reduced-motion` media query exists
- `index.html` contains `<meta name="viewport" content="width=device-width, initial-scale=1">` in `<head>` section

## Acceptance Criteria

1. **AC-2.2.1:** Base styles (no media query) display single-column layout for `.projects__grid`
2. **AC-2.2.2:** `styles.css` contains `@media (min-width: 768px)` query
3. **AC-2.2.3:** On mobile (<768px): project cards stack vertically in single column (`grid-template-columns: 1fr`)
4. **AC-2.2.4:** On desktop (>=768px): project cards display in 3-column grid with gap preserved (`grid-template-columns: repeat(3, 1fr)` and `gap: var(--spacing-md)`)
5. **AC-2.2.5:** Hero section text renders without overflow at 320px viewport: hero name (--font-size-xxl: 3rem) and tagline (--font-size-lg: 1.25rem) display correctly without horizontal scrolling
6. **AC-2.2.6:** CTA button has minimum touch target of 48x48 pixels on mobile (per UX spec accessibility standards)
7. **AC-2.2.7:** No horizontal scrolling occurs on mobile viewport (320px minimum width)
8. **AC-2.2.8:** Grid uses CSS Grid for layout (already implemented, verify preserved)

## Tasks / Subtasks

- [x] Task 0: Verify prerequisites from Story 2.1 (AC: Prerequisites)
  - [x] 0.1: Confirm `.projects__grid` has `display: grid` and `gap: var(--spacing-md)`
  - [x] 0.2: Confirm `:root` contains all required CSS custom properties
  - [x] 0.3: Confirm hero and card styling from Story 2.1 is intact
  - [x] 0.4: Confirm index.html contains `<meta name="viewport" content="width=device-width, initial-scale=1">` in `<head>` section

- [x] Task 1: Verify mobile-first base styles (AC: 1, 3)
  - [x] 1.1: Confirm `.projects__grid` does NOT have `grid-template-columns` in base styles (defaults to single column)
  - [x] 1.2: If base styles have multi-column layout, remove/modify to single column default

- [x] Task 2: Add responsive breakpoint media query (AC: 2, 4)
  - [x] 2.1: Add `/* Responsive Layout */` section comment after `/* Accessibility */` section
  - [x] 2.2: Add `@media (min-width: 768px)` media query
  - [x] 2.3: Inside media query, add `.projects__grid { grid-template-columns: repeat(3, 1fr); }`

- [x] Task 3: Verify CTA touch target (AC: 6)
  - [x] 3.1: Measure computed CTA button size (padding + content)
  - [x] 3.2: If < 48px height, increase padding to meet 48x48px minimum (per UX spec)
  - [x] 3.3: CTA currently has `padding: var(--spacing-sm) var(--spacing-md)` (16px 32px) - verify height meets 48px

- [x] Task 4: Prevent horizontal overflow (AC: 7)
  - [x] 4.1: Add `max-width: 100%` to content containers if needed
  - [x] 4.2: Verify `.hero` and `.projects` don't cause horizontal scroll at 320px
  - [x] 4.3: Consider adding `overflow-x: hidden` to body if edge cases exist

- [x] Task 5: Create ATDD test file (AC: all)
  - [x] 5.1: Create `tests/e2e/story-2.2-responsive.spec.ts`
  - [x] 5.2: Add tests for mobile viewport (320px) - single column layout
  - [x] 5.3: Add tests for tablet/desktop viewport (768px+) - 3-column layout
  - [x] 5.4: Add test for CTA touch target (minimum 48x48px per UX spec)
  - [x] 5.5: Add test for no horizontal scrollbar at 320px
  - [x] 5.6: Add test verifying media query exists in CSS file

- [x] Task 6: Verify implementation (all AC)
  - [x] 6.1: Visual test at 320px viewport - cards stack vertically
  - [x] 6.2: Visual test at 768px viewport - cards in 3-column grid
  - [x] 6.3: Visual test at 1200px viewport - layout stable
  - [x] 6.4: Run all Playwright tests (existing + new Story 2.2 tests)
  - [x] 6.5: Verify CSS file size still under 10KB

## Dev Notes

### Architecture Constraints

**From ADR-001 (Pure HTML/CSS Stack):**
- NO JavaScript - responsive layout must use CSS only
- NO external dependencies or build tools
- Vanilla CSS3 media queries only

**From ADR-005 (Mobile-First Responsive Design):**
- Base styles target mobile (smallest viewports)
- Media queries enhance for larger screens using `min-width`
- Single breakpoint at 768px per project specification
- NEVER use `max-width` media queries

**From NFR-001 (Performance):**
- CSS file must remain under 10KB
- Page loads in under 1 second on 3G

**From NFR-003 (Accessibility):**
- Touch targets minimum 48x48px for mobile (per UX spec, exceeds WCAG 2.1 AA minimum)
- Respect `prefers-reduced-motion` (already implemented in Story 2.1)

### Current CSS State (from Story 2.1 completion)

The `.projects__grid` currently has:
```css
.projects__grid {
  display: grid;
  gap: var(--spacing-md);
}
```

**NOTE:** No `grid-template-columns` is defined, which means CSS Grid defaults to single column. This is already mobile-first compliant! The task is to ADD the desktop breakpoint, not modify base styles.

### Required CSS Addition

Add after the `/* Accessibility */` section:

```css
/* Responsive Layout */
@media (min-width: 768px) {
  .projects__grid {
    grid-template-columns: repeat(3, 1fr);
    /* Note: gap: var(--spacing-md) is preserved from base styles */
  }
}
```

### CSS Property Ordering Standard

From `project_context.md`, properties ordered:
1. **Positioning**: position, top, right, bottom, left, z-index
2. **Display**: display, flex, grid, align, justify
3. **Box model**: width, height, margin, padding, border
4. **Typography**: font-family, font-size, font-weight, line-height, text-align, color
5. **Visual**: background, box-shadow, opacity, filter
6. **Misc**: transition, animation, cursor, outline

### CTA Button Touch Target Analysis

Current CTA styling (from `styles.css:69-78`):
```css
.hero__cta {
  display: inline-block;
  padding: var(--spacing-sm) var(--spacing-md);  /* 16px 32px */
  ...
  font-size: var(--font-size-base);  /* inherited - 16px */
}
```

**Calculation:**
- Font size: 16px (inherited from body)
- Line height: 1.5 (from body) = 24px
- Vertical padding: 16px + 16px = 32px
- Total height: 24px + 32px = 56px (exceeds 48px requirement)
- Horizontal: 32px + content + 32px (exceeds 48px requirement)

**Verdict:** CTA already meets 48x48px touch target. No changes needed.

### Viewport Testing Widths

Per UX spec and epics.md:
- **320px**: Minimum mobile width (iPhone SE, older devices)
- **768px**: Breakpoint threshold (tablet)
- **1200px**: Desktop (verify layout stability)

### Horizontal Scroll Prevention

Potential causes of horizontal scroll:
1. Fixed-width elements exceeding viewport
2. Padding/margin causing overflow
3. Images or media without `max-width: 100%`

Current implementation should be safe because:
- `.hero` has `width: 100%` and uses padding tokens
- `.projects` uses padding tokens
- No fixed-width elements exist

If horizontal scroll is detected, add:
```css
html, body {
  overflow-x: hidden;
}
```

**Warning:** Only add this as a fallback. Prefer fixing root cause.

### Antipatterns to AVOID (from Epic 1 Code Reviews)

| Antipattern | Fix | Source |
|-------------|-----|--------|
| Hardcoded CSS values | Use `var(--token-name)` for all design tokens | Story 1.1 antipatterns |
| Missing media query comment | Add `/* Responsive Layout */` section header | CSS organization standard |
| `max-width` media queries | Use `min-width` only (mobile-first) | ADR-005 |
| Multiple breakpoints | Single 768px breakpoint per spec | Project Context |

### Test File Structure

Create `tests/e2e/story-2.2-responsive.spec.ts`:

```typescript
/**
 * ATDD Tests for Story 2.2: Mobile-First Responsive Layout
 *
 * Acceptance Criteria:
 * - AC-2.2.1: Base styles display single-column layout
 * - AC-2.2.2: CSS contains @media (min-width: 768px) query
 * - AC-2.2.3: Mobile (<768px): cards stack vertically
 * - AC-2.2.4: Desktop (>=768px): 3-column grid with gap preserved
 * - AC-2.2.5: Hero text renders without overflow at 320px
 * - AC-2.2.6: CTA touch target >= 48x48px per UX spec
 * - AC-2.2.7: No horizontal scroll at 320px
 * - AC-2.2.8: CSS Grid used for layout
 */
```

Use Playwright viewport configuration:
```typescript
// Mobile viewport
test.use({ viewport: { width: 320, height: 568 } });

// Tablet/Desktop viewport
test.use({ viewport: { width: 768, height: 1024 } });
```

Or within individual tests:
```typescript
await page.setViewportSize({ width: 320, height: 568 });
```

### What NOT To Do

- Do NOT modify HTML structure (Epic 1 complete, viewport meta tag should already exist)
- Do NOT add additional breakpoints beyond 768px
- Do NOT use JavaScript for responsive behavior
- Do NOT use `max-width` media queries
- Do NOT add footer or contact sections (out of scope)
- Do NOT modify existing hover/focus states from Story 2.1
- Do NOT touch the `prefers-reduced-motion` media query
- Do NOT use `overflow-x: hidden` as first solution - fix root cause of horizontal scroll instead

### File Locations

| File | Path | Action |
|------|------|--------|
| styles.css | `/styles.css` (project root) | MODIFY (add media query) |
| index.html | `/index.html` (project root) | VERIFY (check viewport meta tag exists) |
| story-2.2-responsive.spec.ts | `/tests/e2e/story-2.2-responsive.spec.ts` | CREATE (ATDD tests) |

### Test Fixture Usage

Import from existing test infrastructure:
```typescript
import { test, expect } from '../support/fixtures';
import { heroSelectors, projectsSelectors } from '../support/helpers/selectors';
```

### Performance Budget

From Architecture:
- CSS size: < 10KB (current ~3.2KB, adding ~100 bytes acceptable)
- Total page weight: < 20KB (excluding images)

### Definition of Done (from epics.md)

1. All acceptance criteria are checked off
2. HTML validates (no changes expected)
3. CSS follows BEM naming throughout
4. Code is committed with descriptive message
5. Manual visual verification passes at 320px, 768px, 1200px
6. All Playwright tests pass (existing + new)

### UX Design Reference

From `docs/ux-spec.md`:

**Mobile Layout (< 768px):**
```
┌──────────────────────┐
│     ALEX CHEN        │
│  Capturing moments   │
│  that last forever   │
│   [ Get in Touch ]   │
├──────────────────────┤
│      Portfolio       │
├──────────────────────┤
│  ┌────────────────┐  │
│  │    Wedding     │  │
│  └────────────────┘  │
│  ┌────────────────┐  │
│  │    Portrait    │  │
│  └────────────────┘  │
│  ┌────────────────┐  │
│  │   Landscape    │  │
│  └────────────────┘  │
└──────────────────────┘
```

**Desktop Layout (>= 768px):**
```
┌────────────────────────────────────────────────────┐
│                    ALEX CHEN                       │
│          Capturing moments that last forever       │
│                  [ Get in Touch ]                  │
├────────────────────────────────────────────────────┤
│                     Portfolio                      │
├────────────────────────────────────────────────────┤
│  ┌──────────────┐ ┌──────────────┐ ┌──────────────┐│
│  │   Wedding    │ │   Portrait   │ │  Landscape   ││
│  └──────────────┘ └──────────────┘ └──────────────┘│
└────────────────────────────────────────────────────┘
```

### Project Structure Notes

**Alignment with unified project structure:**
- Single `styles.css` file in project root (no partials/imports)
- All styles use CSS custom properties from `:root`
- BEM naming convention maintained
- Single 768px breakpoint per project specification

**Detected conflicts or variances:** None - this story completes the responsive design system.

### References

- 
- 
- 
- 
- 
- 
- 
- 
- 

## Dev Agent Record

### Agent Model Used

claude-opus-4-5-20251101

### Debug Log References

N/A - Implementation proceeded without errors

### Completion Notes List

1. **Prerequisites verified**: All Story 2.1 outputs confirmed intact - CSS custom properties, typography tokens, hero/card styling, `prefers-reduced-motion` media query, and viewport meta tag all present.

2. **Mobile-first base styles verified**: `.projects__grid` has `display: grid` and `gap: var(--spacing-md)` without `grid-template-columns`, correctly defaulting to single column on mobile.

3. **Responsive media query added**: Added `/* Responsive Layout */` section with `@media (min-width: 768px)` containing `grid-template-columns: repeat(3, 1fr)` per ADR-005 mobile-first approach.

4. **CTA touch target verified**: Existing CTA styling (16px padding + 24px line-height = 56px height) exceeds 48x48px minimum requirement. No changes needed.

5. **Horizontal overflow verified**: No horizontal scroll at 320px viewport - `.hero` uses `width: 100%` and both sections use padding tokens. No overflow-x fix required.

6. **ATDD tests enabled**: Converted all 12 tests in `story-2.2-responsive.spec.ts` from `test.skip()` to `test()`. All tests pass.

7. **Test results**: 47 total tests passing (12 Story 2.2 + 35 existing), no regressions detected.

8. **Performance budget**: CSS file size is 3,470 bytes (3.4KB), well under 10KB limit.

### Change Log

| Date | Author | Change |
|------|--------|--------|
| 2026-01-31 | BMad | Story created with comprehensive developer context from create-story workflow |
| 2026-01-31 | claude-opus-4-5 | Implemented responsive media query, enabled ATDD tests, all 47 tests passing |

### File List

| File | Action | Description |
|------|--------|-------------|
| styles.css | MODIFIED | Added `/* Responsive Layout */` section with `@media (min-width: 768px)` media query containing 3-column grid for `.projects__grid` |
| tests/e2e/story-2.2-responsive.spec.ts | MODIFIED | Enabled all 12 ATDD tests (removed `test.skip()`) |
]]></file>
</context>
<variables>
<var name="epic_num">2</var>
<var name="step_01_detect_mode_nextStepFile">/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad/bmm/workflows/testarch/test-design/steps-c/step-02-load-context.md</var>
<var name="step_02_load_context_nextStepFile">/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad/bmm/workflows/testarch/test-design/steps-c/step-03-risk-and-testability.md</var>
<var name="step_03_risk_and_testability_nextStepFile">/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad/bmm/workflows/testarch/test-design/steps-c/step-04-coverage-plan.md</var>
<var name="step_04_coverage_plan_nextStepFile">/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad/bmm/workflows/testarch/test-design/steps-c/step-05-generate-output.md</var>
<var name="story_file" file_id="da9a0578">/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/implementation-artifacts/2-2-mobile-first-responsive-layout.md</var>
<var name="story_id">2.2</var>
<var name="story_num">2</var>
<var name="tea_use_mcp_enhancements">True</var>
<var name="tea_use_playwright_utils">True</var>
<var name="workflow_mode">c</var>
</variables>
<file-index>
<entry id="da9a0578" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/implementation-artifacts/2-2-mobile-first-responsive-layout.md" />
<entry id="2e55b2e3" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/docs/architecture.md" />
<entry id="bda659bb" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/docs/prd.md" />
<entry id="11c89e12" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/docs/project_context.md" />
</file-index>
<instructions><![CDATA[<!-- STEP: step-01-detect-mode -->
# Step 1: Detect Mode & Prerequisites

## STEP GOAL

Determine whether to run **System-Level** or **Epic-Level** test design, and confirm required inputs are available.

## MANDATORY EXECUTION RULES

### Universal Rules

- 📖 Read this entire step file before taking any action
- ✅ Speak in `{communication_language}`
- 🚫 Do not load the next step until this step is complete

### Role Reinforcement

- ✅ You are the **Master Test Architect**
- ✅ You prioritize risk-based, evidence-backed decisions

---

## EXECUTION PROTOCOLS:

- 🎯 Follow the MANDATORY SEQUENCE exactly
- 💾 Record outputs before proceeding
- 📖 Load the next step only when instructed

## CONTEXT BOUNDARIES:

- Available context: config, loaded artifacts, and knowledge fragments
- Focus: this step's goal only
- Limits: do not execute future steps
- Dependencies: prior steps' outputs (if any)

## MANDATORY SEQUENCE

**CRITICAL:** Follow this sequence exactly. Do not skip, reorder, or improvise.

## 1. Mode Detection (Priority Order)

### A) User Intent (Highest Priority)

Use explicit intent if the user already indicates scope:

- **PRD + ADR (no epic/stories)** → **System-Level Mode**
- **Epic + Stories (no PRD/ADR)** → **Epic-Level Mode**
- **Both PRD/ADR + Epic/Stories** → Prefer **System-Level Mode** first

If intent is unclear, ask:

> "Should I create (A) **System-level** test design (PRD + ADR → Architecture + QA docs), or (B) **Epic-level** test design (Epic → single test plan)?"

### B) File-Based Detection (BMad-Integrated)

If user intent is unclear:

- If `{implementation_artifacts}/` exists → **Epic-Level Mode**
- Otherwise → **System-Level Mode**

### C) Ambiguous → Ask

If mode still unclear, ask the user to choose (A) or (B) and **halt** until they respond.

---

## 2. Prerequisite Check (Mode-Specific)

### System-Level Mode Requires:

- PRD (functional + non-functional requirements)
- ADR or architecture decision records
- Architecture or tech-spec document

### Epic-Level Mode Requires:

- Epic and/or story requirements with acceptance criteria
- Architecture context (if available)

### HALT CONDITIONS

If required inputs are missing **and** the user cannot provide them:

- **System-Level**: "Please provide PRD + ADR/architecture docs to proceed."
- **Epic-Level**: "Please provide epic/story requirements or acceptance criteria to proceed."

---

## 3. Confirm Mode

State which mode you will use and why. Then proceed.

Load next step: ``

## 🚨 SYSTEM SUCCESS/FAILURE METRICS:

### ✅ SUCCESS:

- Step completed in full with required outputs

### ❌ SYSTEM FAILURE:

- Skipped sequence steps or missing outputs
  **Master Rule:** Skipping steps is FORBIDDEN.

<!-- STEP: step-02-load-context -->
# Step 2: Load Context & Knowledge Base

## STEP GOAL

Load the required documents, config flags, and knowledge fragments needed to produce accurate test design outputs.

## MANDATORY EXECUTION RULES

- 📖 Read the entire step file before acting
- ✅ Speak in `{communication_language}`
- 🎯 Only load artifacts required for the selected mode

---

## EXECUTION PROTOCOLS:

- 🎯 Follow the MANDATORY SEQUENCE exactly
- 💾 Record outputs before proceeding
- 📖 Load the next step only when instructed

## CONTEXT BOUNDARIES:

- Available context: config, loaded artifacts, and knowledge fragments
- Focus: this step's goal only
- Limits: do not execute future steps
- Dependencies: prior steps' outputs (if any)

## MANDATORY SEQUENCE

**CRITICAL:** Follow this sequence exactly. Do not skip, reorder, or improvise.

## 1. Load Configuration

From `{config_source}`:

- Read `tea_use_playwright_utils`
- Note `output_folder`

---

## 2. Load Project Artifacts (Mode-Specific)

### System-Level Mode (Phase 3)

Load:

- PRD (FRs + NFRs)
- ADRs or architecture decisions
- Architecture / tech-spec document
- Epics (for scope)

Extract:

- Tech stack & dependencies
- Integration points
- NFRs (performance, security, reliability, compliance)

### Epic-Level Mode (Phase 4)

Load:

- Epic and story docs with acceptance criteria
- PRD (if available)
- Architecture / tech-spec (if available)
- Prior system-level test-design outputs (if available)

Extract:

- Testable requirements
- Integration points
- Known coverage gaps

---

## 3. Analyze Existing Test Coverage (Epic-Level)

If epic-level:

- Scan the repository for existing tests (search for `tests/`, `spec`, `e2e`, `api` folders)
- Identify coverage gaps and flaky areas
- Note existing fixture and test patterns

---

## 4. Load Knowledge Base Fragments

Use `<!-- WARNING: knowledgeIndex not resolved -->` to select and load only relevant fragments.

### System-Level Mode (Required)

- `adr-quality-readiness-checklist.md`
- `test-levels-framework.md`
- `risk-governance.md`
- `test-quality.md`

### Epic-Level Mode (Required)

- `risk-governance.md`
- `probability-impact.md`
- `test-levels-framework.md`
- `test-priorities-matrix.md`

---

## 5. Confirm Loaded Inputs

Summarize what was loaded and confirm with the user if anything is missing.

Load next step: ``

## 🚨 SYSTEM SUCCESS/FAILURE METRICS:

### ✅ SUCCESS:

- Step completed in full with required outputs

### ❌ SYSTEM FAILURE:

- Skipped sequence steps or missing outputs
  **Master Rule:** Skipping steps is FORBIDDEN.

<!-- STEP: step-03-risk-and-testability -->
# Step 3: Testability & Risk Assessment

## STEP GOAL

Produce a defensible testability review (system-level) and a risk assessment matrix (all modes).

## MANDATORY EXECUTION RULES

- 📖 Read the entire step file before acting
- ✅ Speak in `{communication_language}`
- 🎯 Base conclusions on evidence from loaded artifacts

---

## EXECUTION PROTOCOLS:

- 🎯 Follow the MANDATORY SEQUENCE exactly
- 💾 Record outputs before proceeding
- 📖 Load the next step only when instructed

## CONTEXT BOUNDARIES:

- Available context: config, loaded artifacts, and knowledge fragments
- Focus: this step's goal only
- Limits: do not execute future steps
- Dependencies: prior steps' outputs (if any)

## MANDATORY SEQUENCE

**CRITICAL:** Follow this sequence exactly. Do not skip, reorder, or improvise.

## 1. System-Level Mode: Testability Review

If **system-level**, evaluate architecture for:

- **Controllability** (state seeding, mockability, fault injection)
- **Observability** (logs, metrics, traces, deterministic assertions)
- **Reliability** (isolation, reproducibility, parallel safety)

**Structure output as:**

1. **🚨 Testability Concerns** (actionable issues first)
2. **✅ Testability Assessment Summary** (what is already strong)

Also identify **ASRs** (Architecturally Significant Requirements):

- Mark each as **ACTIONABLE** or **FYI**

---

## 2. All Modes: Risk Assessment

Using `risk-governance.md` and `probability-impact.md` (if loaded):

- Identify real risks (not just features)
- Classify by category: TECH / SEC / PERF / DATA / BUS / OPS
- Score Probability (1–3) and Impact (1–3)
- Calculate Risk Score (P × I)
- Flag high risks (score ≥ 6)
- Define mitigation, owner, and timeline

---

## 3. Summarize Risk Findings

Summarize the highest risks and their mitigation priorities.

Load next step: ``

## 🚨 SYSTEM SUCCESS/FAILURE METRICS:

### ✅ SUCCESS:

- Step completed in full with required outputs

### ❌ SYSTEM FAILURE:

- Skipped sequence steps or missing outputs
  **Master Rule:** Skipping steps is FORBIDDEN.

<!-- STEP: step-04-coverage-plan -->
# Step 4: Coverage Plan & Execution Strategy

## STEP GOAL

Create the test coverage matrix, prioritize scenarios, and define execution strategy, resource estimates, and quality gates.

## MANDATORY EXECUTION RULES

- 📖 Read the entire step file before acting
- ✅ Speak in `{communication_language}`
- 🚫 Avoid redundant coverage across test levels

---

## EXECUTION PROTOCOLS:

- 🎯 Follow the MANDATORY SEQUENCE exactly
- 💾 Record outputs before proceeding
- 📖 Load the next step only when instructed

## CONTEXT BOUNDARIES:

- Available context: config, loaded artifacts, and knowledge fragments
- Focus: this step's goal only
- Limits: do not execute future steps
- Dependencies: prior steps' outputs (if any)

## MANDATORY SEQUENCE

**CRITICAL:** Follow this sequence exactly. Do not skip, reorder, or improvise.

## 1. Coverage Matrix

For each requirement or risk-driven scenario:

- Decompose into atomic test scenarios
- Select **test level** (E2E / API / Component / Unit) using `test-levels-framework.md`
- Ensure no duplicate coverage across levels
- Assign priorities (P0–P3) using `test-priorities-matrix.md`

**Priority rules:**

- P0: Blocks core functionality + high risk + no workaround
- P1: Critical paths + medium/high risk
- P2: Secondary flows + low/medium risk
- P3: Nice-to-have, exploratory, benchmarks

---

## 2. Execution Strategy (Keep Simple)

Use a **PR / Nightly / Weekly** model:

- **PR**: All functional tests if <15 minutes
- **Nightly/Weekly**: Long-running or expensive suites (perf, chaos, large datasets)
- Avoid re-listing all tests (refer to coverage plan)

---

## 3. Resource Estimates (Ranges Only)

Provide intervals (no false precision):

- P0: e.g., "~25–40 hours"
- P1: e.g., "~20–35 hours"
- P2: e.g., "~10–30 hours"
- P3: e.g., "~2–5 hours"
- Total and timeline as ranges

---

## 4. Quality Gates

Define thresholds:

- P0 pass rate = 100%
- P1 pass rate ≥ 95%
- High-risk mitigations complete before release
- Coverage target ≥ 80% (adjust if justified)

Load next step: ``

## 🚨 SYSTEM SUCCESS/FAILURE METRICS:

### ✅ SUCCESS:

- Step completed in full with required outputs

### ❌ SYSTEM FAILURE:

- Skipped sequence steps or missing outputs
  **Master Rule:** Skipping steps is FORBIDDEN.

<!-- STEP: step-05-generate-output -->
# Step 5: Generate Outputs & Validate

## STEP GOAL

Write the final test-design document(s) using the correct template(s), then validate against the checklist.

## MANDATORY EXECUTION RULES

- 📖 Read the entire step file before acting
- ✅ Speak in `{communication_language}`
- ✅ Use the provided templates and output paths

---

## EXECUTION PROTOCOLS:

- 🎯 Follow the MANDATORY SEQUENCE exactly
- 💾 Record outputs before proceeding
- 📖 Load the next step only when instructed

## CONTEXT BOUNDARIES:

- Available context: config, loaded artifacts, and knowledge fragments
- Focus: this step's goal only
- Limits: do not execute future steps
- Dependencies: prior steps' outputs (if any)

## MANDATORY SEQUENCE

**CRITICAL:** Follow this sequence exactly. Do not skip, reorder, or improvise.

## 1. Select Output Template(s)

### System-Level Mode (Phase 3)

Generate **two** documents:

- `{output_folder}/test-design-architecture.md` using `test-design-architecture-template.md`
- `{output_folder}/test-design-qa.md` using `test-design-qa-template.md`

### Epic-Level Mode (Phase 4)

Generate **one** document:

- `{outputFile}` using `test-design-template.md`
- If `epic_num` is unclear, ask the user

---

## 2. Populate Templates

Ensure the outputs include:

- Risk assessment matrix
- Coverage matrix and priorities
- Execution strategy
- Resource estimates (ranges)
- Quality gate criteria
- Any mode-specific sections required by the template

---

## 3. Validation

Validate the output(s) against:

- `checklist.md` in this workflow folder

If any checklist criteria are missing, fix before completion.

---

## 4. Completion Report

Summarize:

- Mode used
- Output file paths
- Key risks and gate thresholds
- Any open assumptions

## 🚨 SYSTEM SUCCESS/FAILURE METRICS:

### ✅ SUCCESS:

- Step completed in full with required outputs

### ❌ SYSTEM FAILURE:

- Skipped sequence steps or missing outputs
  **Master Rule:** Skipping steps is FORBIDDEN.
]]></instructions>
<output-template><![CDATA[# Test Design: Epic {epic_num} - {epic_title}

**Date:** {date}
**Author:** {user_name}
**Status:** Draft / Approved

---

## Executive Summary

**Scope:** {design_level} test design for Epic {epic_num}

**Risk Summary:**

- Total risks identified: {total_risks}
- High-priority risks (≥6): {high_priority_count}
- Critical categories: {top_categories}

**Coverage Summary:**

- P0 scenarios: {p0_count} ({p0_hours} hours)
- P1 scenarios: {p1_count} ({p1_hours} hours)
- P2/P3 scenarios: {p2p3_count} ({p2p3_hours} hours)
- **Total effort**: {total_hours} hours (~{total_days} days)

---

## Risk Assessment

### High-Priority Risks (Score ≥6)

| Risk ID | Category | Description   | Probability | Impact | Score | Mitigation   | Owner   | Timeline |
| ------- | -------- | ------------- | ----------- | ------ | ----- | ------------ | ------- | -------- |
| R-001   | SEC      | {description} | 2           | 3      | 6     | {mitigation} | {owner} | {date}   |
| R-002   | PERF     | {description} | 3           | 2      | 6     | {mitigation} | {owner} | {date}   |

### Medium-Priority Risks (Score 3-4)

| Risk ID | Category | Description   | Probability | Impact | Score | Mitigation   | Owner   |
| ------- | -------- | ------------- | ----------- | ------ | ----- | ------------ | ------- |
| R-003   | TECH     | {description} | 2           | 2      | 4     | {mitigation} | {owner} |
| R-004   | DATA     | {description} | 1           | 3      | 3     | {mitigation} | {owner} |

### Low-Priority Risks (Score 1-2)

| Risk ID | Category | Description   | Probability | Impact | Score | Action  |
| ------- | -------- | ------------- | ----------- | ------ | ----- | ------- |
| R-005   | OPS      | {description} | 1           | 2      | 2     | Monitor |
| R-006   | BUS      | {description} | 1           | 1      | 1     | Monitor |

### Risk Category Legend

- **TECH**: Technical/Architecture (flaws, integration, scalability)
- **SEC**: Security (access controls, auth, data exposure)
- **PERF**: Performance (SLA violations, degradation, resource limits)
- **DATA**: Data Integrity (loss, corruption, inconsistency)
- **BUS**: Business Impact (UX harm, logic errors, revenue)
- **OPS**: Operations (deployment, config, monitoring)

---

## Test Coverage Plan

### P0 (Critical) - Run on every commit

**Criteria**: Blocks core journey + High risk (≥6) + No workaround

| Requirement   | Test Level | Risk Link | Test Count | Owner | Notes   |
| ------------- | ---------- | --------- | ---------- | ----- | ------- |
| {requirement} | E2E        | R-001     | 3          | QA    | {notes} |
| {requirement} | API        | R-002     | 5          | QA    | {notes} |

**Total P0**: {p0_count} tests, {p0_hours} hours

### P1 (High) - Run on PR to main

**Criteria**: Important features + Medium risk (3-4) + Common workflows

| Requirement   | Test Level | Risk Link | Test Count | Owner | Notes   |
| ------------- | ---------- | --------- | ---------- | ----- | ------- |
| {requirement} | API        | R-003     | 4          | QA    | {notes} |
| {requirement} | Component  | -         | 6          | DEV   | {notes} |

**Total P1**: {p1_count} tests, {p1_hours} hours

### P2 (Medium) - Run nightly/weekly

**Criteria**: Secondary features + Low risk (1-2) + Edge cases

| Requirement   | Test Level | Risk Link | Test Count | Owner | Notes   |
| ------------- | ---------- | --------- | ---------- | ----- | ------- |
| {requirement} | API        | R-004     | 8          | QA    | {notes} |
| {requirement} | Unit       | -         | 15         | DEV   | {notes} |

**Total P2**: {p2_count} tests, {p2_hours} hours

### P3 (Low) - Run on-demand

**Criteria**: Nice-to-have + Exploratory + Performance benchmarks

| Requirement   | Test Level | Test Count | Owner | Notes   |
| ------------- | ---------- | ---------- | ----- | ------- |
| {requirement} | E2E        | 2          | QA    | {notes} |
| {requirement} | Unit       | 8          | DEV   | {notes} |

**Total P3**: {p3_count} tests, {p3_hours} hours

---

## Execution Order

### Smoke Tests (<5 min)

**Purpose**: Fast feedback, catch build-breaking issues

- [ ] {scenario} (30s)
- [ ] {scenario} (45s)
- [ ] {scenario} (1min)

**Total**: {smoke_count} scenarios

### P0 Tests (<10 min)

**Purpose**: Critical path validation

- [ ] {scenario} (E2E)
- [ ] {scenario} (API)
- [ ] {scenario} (API)

**Total**: {p0_count} scenarios

### P1 Tests (<30 min)

**Purpose**: Important feature coverage

- [ ] {scenario} (API)
- [ ] {scenario} (Component)

**Total**: {p1_count} scenarios

### P2/P3 Tests (<60 min)

**Purpose**: Full regression coverage

- [ ] {scenario} (Unit)
- [ ] {scenario} (API)

**Total**: {p2p3_count} scenarios

---

## Resource Estimates

### Test Development Effort

| Priority  | Count             | Hours/Test | Total Hours       | Notes                   |
| --------- | ----------------- | ---------- | ----------------- | ----------------------- |
| P0        | {p0_count}        | 2.0        | {p0_hours}        | Complex setup, security |
| P1        | {p1_count}        | 1.0        | {p1_hours}        | Standard coverage       |
| P2        | {p2_count}        | 0.5        | {p2_hours}        | Simple scenarios        |
| P3        | {p3_count}        | 0.25       | {p3_hours}        | Exploratory             |
| **Total** | **{total_count}** | **-**      | **{total_hours}** | **~{total_days} days**  |

### Prerequisites

**Test Data:**

- {factory_name} factory (faker-based, auto-cleanup)
- {fixture_name} fixture (setup/teardown)

**Tooling:**

- {tool} for {purpose}
- {tool} for {purpose}

**Environment:**

- {env_requirement}
- {env_requirement}

---

## Quality Gate Criteria

### Pass/Fail Thresholds

- **P0 pass rate**: 100% (no exceptions)
- **P1 pass rate**: ≥95% (waivers required for failures)
- **P2/P3 pass rate**: ≥90% (informational)
- **High-risk mitigations**: 100% complete or approved waivers

### Coverage Targets

- **Critical paths**: ≥80%
- **Security scenarios**: 100%
- **Business logic**: ≥70%
- **Edge cases**: ≥50%

### Non-Negotiable Requirements

- [ ] All P0 tests pass
- [ ] No high-risk (≥6) items unmitigated
- [ ] Security tests (SEC category) pass 100%
- [ ] Performance targets met (PERF category)

---

## Mitigation Plans

### R-001: {Risk Description} (Score: 6)

**Mitigation Strategy:** {detailed_mitigation}
**Owner:** {owner}
**Timeline:** {date}
**Status:** Planned / In Progress / Complete
**Verification:** {how_to_verify}

### R-002: {Risk Description} (Score: 6)

**Mitigation Strategy:** {detailed_mitigation}
**Owner:** {owner}
**Timeline:** {date}
**Status:** Planned / In Progress / Complete
**Verification:** {how_to_verify}

---

## Assumptions and Dependencies

### Assumptions

1. {assumption}
2. {assumption}
3. {assumption}

### Dependencies

1. {dependency} - Required by {date}
2. {dependency} - Required by {date}

### Risks to Plan

- **Risk**: {risk_to_plan}
  - **Impact**: {impact}
  - **Contingency**: {contingency}

---

---

## Follow-on Workflows (Manual)

- Run `*atdd` to generate failing P0 tests (separate workflow; not auto-run).
- Run `*automate` for broader coverage once implementation exists.

---

## Approval

**Test Design Approved By:**

- [ ] Product Manager: {name} Date: {date}
- [ ] Tech Lead: {name} Date: {date}
- [ ] QA Lead: {name} Date: {date}

**Comments:**

---

---

---

## Appendix

### Knowledge Base References

- `risk-governance.md` - Risk classification framework
- `probability-impact.md` - Risk scoring methodology
- `test-levels-framework.md` - Test level selection
- `test-priorities-matrix.md` - P0-P3 prioritization

### Related Documents

- PRD: {prd_link}
- Epic: {epic_link}
- Architecture: {arch_link}
- Tech Spec: {tech_spec_link}

---

**Generated by**: BMad TEA Agent - Test Architect Module
**Workflow**: `_bmad/bmm/testarch/test-design`
**Version**: 4.0 (BMad v6)
]]></output-template>
</compiled-workflow>