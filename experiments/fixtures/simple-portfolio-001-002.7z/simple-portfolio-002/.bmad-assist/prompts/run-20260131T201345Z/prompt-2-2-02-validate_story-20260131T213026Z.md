<?xml version="1.0" encoding="UTF-8"?>
<!-- BMAD Prompt Run Metadata -->
<!-- Epic: 2 -->
<!-- Story: 2 -->
<!-- Phase: validate-story -->
<!-- Timestamp: 20260131T213026Z -->
<compiled-workflow>
<mission><![CDATA[Adversarial Story Validation

Target: Story 2.2 - mobile-first-responsive-layout

Your mission is to FIND ISSUES in the story file:
- Identify missing requirements or acceptance criteria
- Find ambiguous or unclear specifications
- Detect gaps in technical context
- Suggest improvements for developer clarity

CRITICAL: You are a VALIDATOR, not a developer.
- Read-only: You cannot modify any files
- Adversarial: Assume the story has problems
- Thorough: Check all sections systematically

Focus on STORY QUALITY, not code implementation.]]></mission>
<context>
<file id="11c89e12" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/docs/project_context.md"><![CDATA[# Project Context: Alex Chen Photography Portfolio

## Overview

Static portfolio website for freelance photographer. Pure HTML/CSS, no JavaScript.

## File Structure

```
index.html    # Single page, semantic HTML5
styles.css    # All styles, BEM naming
```

## Coding Standards

### HTML Rules

- Use semantic elements: `<header>`, `<main>`, `<section>`, `<article>`, `<footer>`
- Proper heading hierarchy: single `<h1>`, then `<h2>`, `<h3>` as needed
- 2-space indentation
- Double quotes for attributes
- Self-closing tags for void elements: `<img />`, `<br />`
- Always include `alt` attribute on images

### CSS Rules

- **BEM naming convention:**
  - Block: `.hero`, `.projects`
  - Element: `.hero__title`, `.projects__card`
  - Modifier: `.hero__cta--primary`, `.projects__card--featured`
- 2-space indentation
- One property per line
- Opening brace on same line as selector
- Blank line between rule sets
- Properties ordered: positioning → display → box model → typography → visual → misc

### CSS Custom Properties

Define all design tokens in `:root`:

```css
:root {
  /* Colors */
  --color-primary: #1a1a2e;
  --color-accent: #e94560;
  --color-background: #ffffff;
  --color-text: #333333;
  --color-text-light: #666666;

  /* Typography */
  --font-heading: 'Georgia', serif;
  --font-body: 'Arial', sans-serif;
  --font-size-base: 16px;
  --font-size-lg: 1.25rem;
  --font-size-xl: 2rem;
  --font-size-xxl: 3rem;

  /* Spacing */
  --spacing-xs: 0.5rem;
  --spacing-sm: 1rem;
  --spacing-md: 2rem;
  --spacing-lg: 4rem;

  /* Layout */
  --max-width: 1200px;
  --border-radius: 8px;
}
```

### Responsive Design

- Mobile-first approach
- Single breakpoint: `768px`
- Use `min-width` media queries only

```css
/* Mobile styles (default) */
.projects__grid {
  display: grid;
  grid-template-columns: 1fr;
}

/* Desktop styles */
@media (min-width: 768px) {
  .projects__grid {
    grid-template-columns: repeat(3, 1fr);
  }
}
```

## Component Structure

### Hero Section

```html
<header class="hero">
  <h1 class="hero__name">Alex Chen</h1>
  <p class="hero__tagline">Capturing moments that last forever</p>
  <a href="#contact" class="hero__cta">Get in Touch</a>
</header>
```

### Projects Section

```html
<main>
  <section class="projects">
    <h2 class="projects__title">Portfolio</h2>
    <div class="projects__grid">
      <article class="projects__card">
        <div class="projects__card-image"></div>
        <h3 class="projects__card-title">Wedding</h3>
        <p class="projects__card-description">...</p>
      </article>
      <!-- Repeat for Portrait, Landscape -->
    </div>
  </section>
</main>
```

## Constraints

- No JavaScript
- No external dependencies
- No CSS preprocessors
- No build tools
- Maximum 2 files (index.html + styles.css)

## Testing Verification

Verify implementation by checking:

1. **Hero section:** `<header class="hero">` exists with `<h1>`, tagline `<p>`, and CTA `<a>`
2. **Projects section:** `<section class="projects">` with exactly 3 `<article class="projects__card">`
3. **CSS variables:** `:root` block defines `--color-*`, `--font-*`, `--spacing-*`
4. **Responsive:** `@media (min-width: 768px)` present in styles.css
5. **BEM naming:** All classes follow `block__element--modifier` pattern
]]></file>
<file id="bda659bb" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/docs/prd.md"><![CDATA[# Product Requirements Document: Alex Chen Photography Portfolio

## Overview

**Product Name:** Alex Chen Photography Portfolio
**Version:** 1.0
**Author:** John (Product Manager)
**Date:** 2025-12-11

## Problem Statement

Alex Chen is a freelance photographer who needs a simple, professional online presence to showcase work to potential clients. Current solution (social media) lacks professionalism and doesn't provide a dedicated space for portfolio presentation.

## Goals

1. Establish professional online presence
2. Showcase photography portfolio effectively
3. Provide clear call-to-action for client inquiries
4. Ensure accessibility across devices

## Target Audience

- Potential clients seeking photography services (weddings, portraits, landscapes)
- Industry peers and collaborators
- Anyone discovering Alex through referrals

## Functional Requirements

### FR-001: Hero Section with Branding

**Description:** The landing page must feature a prominent hero section that establishes brand identity.

**Acceptance Criteria:**
- Display photographer name "Alex Chen" as primary heading
- Include professional tagline communicating photography focus
- Provide clear call-to-action button for contact/inquiry
- Hero section spans full viewport width

### FR-002: Projects Gallery Section

**Description:** A dedicated section showcasing photography projects with visual cards.

**Acceptance Criteria:**
- Display exactly 3 project cards (Wedding, Portrait, Landscape)
- Each card contains: image placeholder, project title, brief description
- Cards arranged in responsive grid layout
- Semantic HTML structure using article elements

### FR-003: Consistent Visual Design System

**Description:** Implement cohesive visual design using CSS custom properties.

**Acceptance Criteria:**
- Define color palette via CSS custom properties in :root
- Establish typography scale (headings, body, captions)
- Consistent spacing using CSS variables
- BEM naming convention for all CSS classes

### FR-004: Mobile-Responsive Layout

**Description:** Ensure optimal viewing experience across device sizes.

**Acceptance Criteria:**
- Mobile-first CSS approach
- Breakpoint at 768px for tablet/desktop layouts
- Hero section adapts to viewport
- Project cards stack vertically on mobile, grid on desktop
- All interactive elements have appropriate touch targets

## Non-Functional Requirements

### NFR-001: Performance
- No JavaScript dependencies
- Single CSS file under 10KB
- Page loads in under 1 second on 3G

### NFR-002: Maintainability
- Semantic HTML5 elements
- Well-commented CSS sections
- BEM methodology for scalable styles

### NFR-003: Accessibility
- Proper heading hierarchy (h1 > h2 > h3)
- Sufficient color contrast ratios
- Focus states for interactive elements

## Out of Scope

- Contact form functionality
- Image gallery lightbox
- CMS integration
- Multi-page navigation
- JavaScript interactions

## Success Metrics

- Clean, valid HTML5 markup
- CSS passes linting with no errors
- Responsive design works on mobile and desktop viewports
- All acceptance criteria met for FR-001 through FR-004
]]></file>
<file id="07a30897" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/docs/ux-spec.md"><![CDATA[# UX Specification: Alex Chen Photography Portfolio

## Overview

**Project:** Alex Chen Photography Portfolio
**UX Designer:** Sally
**Date:** 2025-12-11
**Status:** Approved

## User Persona

### Primary Persona: Potential Client

**Name:** Sarah Mitchell
**Age:** 28-45
**Context:** Planning a wedding, looking for a photographer

**Goals:**
- Quickly assess photographer's style and quality
- See relevant work samples (wedding photography)
- Easy way to make contact

**Behaviors:**
- Browses on mobile during commute (60% mobile traffic expected)
- Makes decisions based on visual first impression
- Scans, doesn't read - needs clear visual hierarchy
- Will leave if page loads slowly or looks unprofessional

**Pain Points:**
- Cluttered portfolios with too many options
- Slow-loading image galleries
- Unclear how to get in touch
- Sites that don't work on mobile

### Secondary Persona: Industry Peer

**Name:** Marcus Rivera
**Context:** Fellow photographer, potential collaborator

**Goals:**
- Evaluate Alex's style for collaboration fit
- Quick overview of specialties

## Visual Direction

### Mood & Tone

**Keywords:** Elegant, Professional, Minimal, Gallery-like

**Concept:** The website should feel like walking into a high-end photography gallery - clean walls, focused lighting, art speaks for itself.

**Visual Metaphor:** White-cube gallery meets premium magazine layout.

### Color Psychology

| Color | Token | Hex | Rationale |
|-------|-------|-----|-----------|
| Deep Navy | `--color-primary` | #1a1a2e | Sophisticated, timeless, makes photos "pop" |
| Coral Accent | `--color-accent` | #e94560 | Warm, inviting, draws eye to CTA |
| Clean White | `--color-background` | #ffffff | Gallery-like, maximizes photo contrast |
| Charcoal | `--color-text` | #333333 | Easy reading, softer than pure black |
| Muted Gray | `--color-text-light` | #666666 | Secondary info, doesn't compete |

**Why Dark Hero + Light Content:**
- Hero section uses `--color-primary` background → dramatic first impression
- Projects section uses `--color-background` → photos are the focus
- This contrast creates natural visual sections without heavy borders

### Typography Rationale

| Element | Font | Token | Rationale |
|---------|------|-------|-----------|
| Headings | Georgia | `--font-heading` | Serif = elegance, timelessness, art-world feel |
| Body | Arial | `--font-body` | Sans-serif = clarity, modern, easy scanning |

**Type Scale:**
- Hero name: `--font-size-xxl` (3rem) - Commanding presence
- Section titles: `--font-size-xl` (2rem) - Clear hierarchy
- Card titles: `--font-size-lg` (1.25rem) - Scannable
- Body: `--font-size-base` (16px) - Comfortable reading

## Layout Design

### Information Architecture

```
┌─────────────────────────────────────┐
│             HERO                    │  ← Emotional hook (3 seconds)
│   Name + Tagline + CTA              │
└─────────────────────────────────────┘
┌─────────────────────────────────────┐
│           PORTFOLIO                 │  ← Proof of work
│   [Wedding] [Portrait] [Landscape]  │
└─────────────────────────────────────┘
```

**Why this order:**
1. Hero creates emotional connection first
2. Portfolio proves capability second
3. No navigation needed - single scroll journey

### Wireframes

**Mobile Layout (< 768px):**

```
┌──────────────────────┐
│                      │
│     ALEX CHEN        │
│                      │
│  Capturing moments   │
│  that last forever   │
│                      │
│   [ Get in Touch ]   │
│                      │
├──────────────────────┤
│      Portfolio       │
├──────────────────────┤
│  ┌────────────────┐  │
│  │   [  image  ]  │  │
│  │    Wedding     │  │
│  │  description   │  │
│  └────────────────┘  │
│  ┌────────────────┐  │
│  │   [  image  ]  │  │
│  │    Portrait    │  │
│  │  description   │  │
│  └────────────────┘  │
│  ┌────────────────┐  │
│  │   [  image  ]  │  │
│  │   Landscape    │  │
│  │  description   │  │
│  └────────────────┘  │
└──────────────────────┘
```

**Desktop Layout (≥ 768px):**

```
┌────────────────────────────────────────────────────┐
│                                                    │
│                    ALEX CHEN                       │
│          Capturing moments that last forever       │
│                                                    │
│                  [ Get in Touch ]                  │
│                                                    │
├────────────────────────────────────────────────────┤
│                     Portfolio                      │
├────────────────────────────────────────────────────┤
│  ┌──────────────┐ ┌──────────────┐ ┌──────────────┐│
│  │   [image]    │ │   [image]    │ │   [image]    ││
│  │   Wedding    │ │   Portrait   │ │  Landscape   ││
│  │ description  │ │ description  │ │ description  ││
│  └──────────────┘ └──────────────┘ └──────────────┘│
└────────────────────────────────────────────────────┘
```

## Interaction Design

### CTA Button States

| State | Visual Treatment |
|-------|------------------|
| Default | `--color-accent` background, white text |
| Hover | Slightly darker accent, subtle scale (1.02) |
| Focus | Visible outline for accessibility |
| Active | Darker accent, scale down (0.98) |

### Project Card States

| State | Visual Treatment |
|-------|------------------|
| Default | Subtle shadow, white background |
| Hover | Elevated shadow, slight lift effect |
| Focus | Visible outline around card |

**Note:** All hover effects use CSS transitions (0.2s ease) for smooth feel.

### Touch Targets

- CTA button: minimum 48x48px tap area
- Cards: entire card is tappable area on mobile
- Adequate spacing between interactive elements (min 8px)

## Accessibility Considerations

### Color Contrast

All text meets WCAG AA standards:
- `--color-text` (#333) on `--color-background` (#fff) = 12.6:1 ✓
- White text on `--color-primary` (#1a1a2e) = 15.1:1 ✓
- White text on `--color-accent` (#e94560) = 4.5:1 ✓

### Focus Indicators

- All interactive elements have visible focus states
- Focus outline uses `--color-accent` for consistency
- Never remove focus outline without replacement

### Motion

- Respect `prefers-reduced-motion` media query
- Hover animations are subtle (no jarring movements)

## Design Token Mapping

How UX decisions map to CSS custom properties:

| UX Goal | Design Token | Value |
|---------|--------------|-------|
| Sophisticated first impression | `--color-primary` | #1a1a2e |
| Draw attention to contact | `--color-accent` | #e94560 |
| Clean gallery feel | `--color-background` | #ffffff |
| Readable content | `--color-text` | #333333 |
| Elegant headings | `--font-heading` | Georgia, serif |
| Clear body text | `--font-body` | Arial, sans-serif |
| Consistent rhythm | `--spacing-*` | 0.5/1/2/4rem scale |
| Professional cards | `--border-radius` | 8px |

## Success Metrics

UX goals verification:

1. **First Impression (3 sec test):** User can identify "photographer portfolio" within 3 seconds
2. **Scannability:** All three project types visible without scrolling on desktop
3. **Mobile Usability:** Full journey completable with thumb-only navigation
4. **CTA Visibility:** Contact button visible in hero without scrolling
5. **Load Performance:** Perceived instant load (no layout shift)
]]></file>
<file id="2e55b2e3" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/docs/architecture.md"><![CDATA[# Architecture Document: Alex Chen Photography Portfolio

## Overview

**Project:** Alex Chen Photography Portfolio
**Architect:** Winston
**Date:** 2025-12-11
**Status:** Approved

## Architecture Philosophy

This is a deliberately simple, static website. We embrace "boring technology" - proven HTML and CSS patterns that require no build tools, no frameworks, and no JavaScript. The architecture prioritizes maintainability and performance over sophistication.

## Technology Decisions

### ADR-001: Pure HTML/CSS Stack

**Decision:** Use vanilla HTML5 and CSS3 only. No JavaScript.

**Context:** Portfolio is purely presentational. No dynamic functionality required.

**Rationale:**
- Zero runtime dependencies
- No build pipeline needed
- Maximum browser compatibility
- Fastest possible load times
- Easy to maintain and modify

**Consequences:**
- No interactive features (acceptable per PRD scope)
- Contact requires mailto: link or external form service

### ADR-002: Single Page Architecture

**Decision:** Entire portfolio on one `index.html` page.

**Context:** Only 2 content sections needed (hero + projects).

**Rationale:**
- Simpler navigation (scroll-based)
- Single HTTP request for HTML
- No routing complexity
- Easier testing and verification

**Consequences:**
- Must use anchor links if navigation added later
- Page weight grows with content (acceptable for 2 sections)

### ADR-003: CSS Custom Properties for Theming

**Decision:** Define all design tokens as CSS custom properties in `:root`.

**Context:** Need consistent colors, typography, and spacing.

**Rationale:**
- Single source of truth for design values
- Easy theme modifications
- Native browser support (no preprocessor)
- Runtime flexibility for future enhancements

**Implementation:**
```css
:root {
  --color-primary: #1a1a2e;
  --color-accent: #e94560;
  --color-background: #ffffff;
  --color-text: #333333;
  --font-heading: 'Georgia', serif;
  --font-body: 'Arial', sans-serif;
  --spacing-unit: 1rem;
}
```

### ADR-004: BEM Naming Convention

**Decision:** Use Block__Element--Modifier pattern for all CSS classes.

**Context:** Need scalable, predictable CSS architecture.

**Rationale:**
- Self-documenting class names
- Avoids specificity conflicts
- Clear component boundaries
- Industry standard, widely understood

**Examples:**
- `.hero` (block)
- `.hero__title` (element)
- `.hero__cta--primary` (modifier)
- `.projects__card` (element)

### ADR-005: Mobile-First Responsive Design

**Decision:** Base styles target mobile, media queries enhance for larger screens.

**Context:** Significant mobile traffic expected for portfolio viewing.

**Rationale:**
- Progressive enhancement philosophy
- Smaller devices get minimal CSS
- Easier to scale up than scale down
- Better performance on constrained devices

**Breakpoints:**
- Base: 0-767px (mobile)
- Desktop: 768px+ (tablet and above)

### ADR-006: Semantic HTML5 Structure

**Decision:** Use semantic elements over generic divs.

**Context:** Need accessible, well-structured markup.

**Rationale:**
- Built-in accessibility benefits
- Better SEO signals
- Self-documenting structure
- Screen reader friendly

**Element Mapping:**
| Content | Element |
|---------|---------|
| Page header with hero | `<header>` |
| Main content area | `<main>` |
| Hero section | `<section class="hero">` |
| Projects section | `<section class="projects">` |
| Individual project | `<article class="projects__card">` |
| Page footer | `<footer>` |

## File Structure

```
portfolio-project/
├── index.html          # Single HTML page
├── styles.css          # All styles
├── docs/
│   ├── prd.md
│   ├── architecture.md
│   ├── project_context.md
│   └── epics.md
└── bmad-assist.yaml
```

## Performance Budget

| Metric | Target |
|--------|--------|
| HTML size | < 5KB |
| CSS size | < 10KB |
| Total page weight | < 20KB (excluding images) |
| First Contentful Paint | < 1s on 3G |

## Security Considerations

- No user input handling (no forms)
- No external scripts
- No cookies or local storage
- Static hosting compatible (no server-side logic)

## Future Considerations

If requirements expand:
- Contact form: Consider external service (Formspree, Netlify Forms)
- Image optimization: Add srcset for responsive images
- Analytics: Add privacy-respecting solution (Plausible, Fathom)
- Multi-page: Consider static site generator

These are explicitly out of scope for v1.0.
]]></file>
<file id="314c28e8" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/implementation-artifacts/test-design-epic-1-story-1.1.md"><![CDATA[# Test Design: Epic 1 - Core Page Structure (Story 1.1)

**Date:** 2026-01-31
**Author:** User
**Status:** Draft

---

## Executive Summary

**Scope:** Epic-level test design for Story 1.1 - Hero Section Implementation

**Risk Summary:**

- Total risks identified: 6
- High-priority risks (≥6): 1
- Critical categories: BUS (business), TECH (technical)

**Coverage Summary:**

- P0 scenarios: 4 (~2 hours)
- P1 scenarios: 2 (~1 hour)
- P2/P3 scenarios: 0 (0 hours)
- **Total effort**: ~3 hours (~0.5 days)

---

## Risk Assessment

### High-Priority Risks (Score ≥6)

| Risk ID | Category | Description | Probability | Impact | Score | Mitigation | Owner | Timeline |
|---------|----------|-------------|-------------|--------|-------|------------|-------|----------|
| R-002 | BUS | Hero section missing required content (name, tagline, CTA) | 2 | 3 | 6 | P0 tests for all 6 acceptance criteria | QA | Sprint 1 |

### Medium-Priority Risks (Score 3-4)

| Risk ID | Category | Description | Probability | Impact | Score | Mitigation | Owner |
|---------|----------|-------------|-------------|--------|-------|------------|-------|
| R-001 | TECH | BEM class naming inconsistency breaks selectors | 2 | 2 | 4 | Selector constants in helpers, validate against project_context.md | Dev |
| R-005 | BUS | CTA link malformed or broken | 2 | 2 | 4 | P0 test for href attribute validation | QA |
| R-004 | OPS | CSS file missing or not linked | 1 | 3 | 3 | P0 test for CSS load verification | QA |

### Low-Priority Risks (Score 1-2)

| Risk ID | Category | Description | Probability | Impact | Score | Action |
|---------|----------|-------------|-------------|--------|-------|--------|
| R-003 | TECH | HTML validation errors (invalid markup) | 1 | 2 | 2 | Monitor |
| R-006 | TECH | h1 heading not unique (accessibility violation) | 1 | 2 | 2 | Monitor |

### Risk Category Legend

- **TECH**: Technical/Architecture (flaws, integration, scalability)
- **SEC**: Security (access controls, auth, data exposure)
- **PERF**: Performance (SLA violations, degradation, resource limits)
- **DATA**: Data Integrity (loss, corruption, inconsistency)
- **BUS**: Business Impact (UX harm, logic errors, revenue)
- **OPS**: Operations (deployment, config, monitoring)

---

## Test Coverage Plan

### P0 (Critical) - Run on every commit

**Criteria**: Blocks core journey + High risk (≥6) + No workaround

| AC ID | Requirement | Test Level | Risk Link | Test | Owner | Notes |
|-------|-------------|------------|-----------|------|-------|-------|
| AC-1.1.1 | Page contains `<header>` element with class `hero` | E2E | R-002 | `homepage.spec.ts` | QA | Existing coverage via `assertHeroSection()` |
| AC-1.1.2 | Hero contains `<h1>` with text "Alex Chen" | E2E | R-002 | `homepage.spec.ts` | QA | Existing coverage with `toContainText` |
| AC-1.1.3 | Hero contains `<p>` with class `hero__tagline` | E2E | R-002 | `homepage.spec.ts` | QA | Existing coverage via selectors |
| AC-1.1.4 | Hero contains `<a>` with class `hero__cta` linking to contact | E2E | R-002, R-005 | `homepage.spec.ts` | QA | Existing coverage, href validation |

**Total P0**: 4 scenarios, ~2 hours

### P1 (High) - Run on PR to main

**Criteria**: Important features + Medium risk (3-4) + Common workflows

| AC ID | Requirement | Test Level | Risk Link | Test | Owner | Notes |
|-------|-------------|------------|-----------|------|-------|-------|
| AC-1.1.5 | HTML is valid and uses semantic elements | E2E | R-003 | `homepage.spec.ts` | QA | Existing `assertSemanticStructure()` |
| AC-1.1.6 | Basic CSS exists to make hero section visible | E2E | R-004 | NEW | QA | Verify computed styles non-empty |

**Total P1**: 2 scenarios, ~1 hour

### P2/P3 - N/A for this story

No P2/P3 scenarios identified. Story is small and focused.

---

## Execution Order

### Smoke Tests (<30s)

**Purpose**: Fast feedback, catch build-breaking issues

- [x] Page loads without HTTP errors (`networkErrorMonitor`)
- [x] Hero section visible (`.hero` exists)

**Total**: 2 scenarios

### P0 Tests (<2 min)

**Purpose**: Critical path validation - all acceptance criteria

- [x] AC-1.1.1: Hero header exists (E2E)
- [x] AC-1.1.2: h1 contains "Alex Chen" (E2E)
- [x] AC-1.1.3: Tagline visible (E2E)
- [x] AC-1.1.4: CTA link valid (E2E)

**Total**: 4 scenarios

### P1 Tests (<3 min)

**Purpose**: Extended validation

- [x] AC-1.1.5: Semantic structure (E2E)
- [ ] AC-1.1.6: CSS styling applied (E2E) - **NEW TEST NEEDED**

**Total**: 2 scenarios

---

## Existing Test Coverage Analysis

### Already Covered by `homepage.spec.ts`

| Test | ACs Covered | Status |
|------|-------------|--------|
| `should display hero section with photographer name and tagline` | AC-1.1.1, AC-1.1.2, AC-1.1.3 | ✅ |
| `should have CTA button linking to contact section` | AC-1.1.4 | ✅ |
| `should have proper semantic HTML structure` | AC-1.1.5 (partial) | ✅ |

### Already Covered by `accessibility.spec.ts`

| Test | ACs Covered | Status |
|------|-------------|--------|
| `should have proper heading hierarchy` | AC-1.1.2 (h1 uniqueness) | ✅ |

### Gap: AC-1.1.6 (CSS Styling)

**New test needed** to verify basic CSS is applied:

```typescript
test('should have CSS styling applied to hero section', async ({ page, log }) => {
  // Given: User navigates to homepage
  await page.goto('/');
  await log.step('Verifying hero section styling');

  // When: Page loads
  const hero = page.locator('.hero');

  // Then: Hero should have visible styling (non-zero dimensions, background or text color)
  const box = await hero.boundingBox();
  expect(box).not.toBeNull();
  expect(box!.height).toBeGreaterThan(0);

  // Verify CSS custom properties are loaded
  await assertCSSCustomProperties(page);
});
```

---

## Resource Estimates

### Test Development Effort

| Priority | Count | Hours/Test | Total Hours | Notes |
|----------|-------|------------|-------------|-------|
| P0 | 4 | 0.5 | 2 | Already exists |
| P1 | 2 | 0.5 | 1 | 1 new test needed |
| **Total** | **6** | - | **~3 hours** | **~0.5 days** |

### Prerequisites

**Test Framework:**
- Playwright with `@seontechnologies/playwright-utils`
- Fixtures: `log`, `networkErrorMonitor`, `recurse`

**Selectors:**
- `heroSelectors` (defined in `tests/support/helpers/selectors.ts`)
- `projectsSelectors` (defined, not needed for Story 1.1)

**Assertions:**
- `assertHeroSection()` - validates hero structure
- `assertSemanticStructure()` - validates HTML5 elements
- `assertCSSCustomProperties()` - validates CSS variables

---

## Quality Gate Criteria

### Pass/Fail Thresholds

- **P0 pass rate**: 100% (no exceptions)
- **P1 pass rate**: ≥95% (waivers required for failures)
- **High-risk mitigations**: 100% complete

### Coverage Targets

- **Acceptance criteria coverage**: 100% (6/6 ACs)
- **Risk mitigation coverage**: 100% for R-002

### Non-Negotiable Requirements

- [x] All P0 tests pass
- [x] No high-risk (≥6) items unmitigated
- [x] Hero section displays correctly in chromium
- [ ] AC-1.1.6 test added (CSS styling)

---

## Mitigation Plans

### R-002: Hero content missing (Score: 6)

**Mitigation Strategy:** Comprehensive E2E test coverage for all 6 acceptance criteria
**Owner:** QA
**Timeline:** Sprint 1
**Status:** In Progress
**Verification:** All P0 tests passing, AC traceability matrix complete

---

## Assumptions and Dependencies

### Assumptions

1. Static HTML file will be served via simple HTTP server for tests
2. BEM naming convention will be followed per `project_context.md`
3. No JavaScript means no async loading concerns

### Dependencies

1. `index.html` created with hero section markup - Required before tests run
2. `styles.css` linked in HTML - Required for AC-1.1.6

### Risks to Plan

- **Risk**: Implementation not started yet
  - **Impact**: Tests will fail initially (expected for ATDD)
  - **Contingency**: Tests designed to fail gracefully with clear error messages

---

## Follow-on Workflows (Manual)

- Run `*atdd` to generate failing P0 tests (if not already covered)
- Run `*automate` for broader coverage once implementation exists
- Run `*trace` to generate traceability matrix after implementation

---

## Traceability Matrix

| AC ID | Acceptance Criteria | Test File | Test Name | Status |
|-------|---------------------|-----------|-----------|--------|
| AC-1.1.1 | `<header>` with class `hero` | `homepage.spec.ts` | `assertHeroSection()` | ✅ Covered |
| AC-1.1.2 | `<h1>` with "Alex Chen" | `homepage.spec.ts` | `toContainText('Alex Chen')` | ✅ Covered |
| AC-1.1.3 | `<p class="hero__tagline">` | `homepage.spec.ts` | `heroSelectors.tagline` | ✅ Covered |
| AC-1.1.4 | `<a class="hero__cta">` | `homepage.spec.ts` | `ctaButton.getAttribute('href')` | ✅ Covered |
| AC-1.1.5 | Valid semantic HTML | `homepage.spec.ts` | `assertSemanticStructure()` | ✅ Covered |
| AC-1.1.6 | Basic CSS exists | NEW | `assertCSSCustomProperties()` | ⚠️ Needs Test |

---

## Approval

**Test Design Approved By:**

- [ ] Product Manager: _______ Date: _______
- [ ] Tech Lead: _______ Date: _______
- [ ] QA Lead: _______ Date: _______

**Comments:**

---

## Appendix

### Knowledge Base References

- `risk-governance.md` - Risk classification framework
- `probability-impact.md` - Risk scoring methodology
- `test-levels-framework.md` - Test level selection
- `test-priorities-matrix.md` - P0-P3 prioritization

### Related Documents

- PRD: `docs/prd.md` (FR-001)
- Epic: `docs/epics.md` (Epic 1, Story 1.1)
- Architecture: `docs/architecture.md` (ADR-001 to ADR-006)
- Project Context: `docs/project_context.md`

---

**Generated by**: BMad TEA Agent - Test Architect Module
**Workflow**: `testarch/test-design`
**Version**: 4.0 (BMad v6)
]]></file>
<file id="a68b9042" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/implementation-artifacts/2-1-css-design-tokens-and-typography.md"><![CDATA[# Story 2.1: CSS Design Tokens and Typography

Status: done

<!-- Note: Validation is optional. Run validate-create-story for quality check before dev-story. -->

## Story

As a **developer**,
I want a **centralized design token system using CSS custom properties**,
so that **visual consistency is maintained and future changes are easy**.

## Prerequisites (Pre-existing from Epic 1)

The following criteria were completed in Story 1.1 and 1.2. Verify they remain intact:
- `:root` selector with CSS custom properties exists
- Color tokens: `--color-primary`, `--color-accent`, `--color-background`, `--color-text`, `--color-text-light`
- Typography tokens: `--font-heading`, `--font-body`, `--font-size-base`, `--font-size-lg`, `--font-size-xl`, `--font-size-xxl`
- Spacing tokens: `--spacing-xs`, `--spacing-sm`, `--spacing-md`, `--spacing-lg`

## Acceptance Criteria

1. **AC-2.1.1:** `<h1>` uses `--font-heading` font family AND `--font-size-xxl` (via `.hero__name` selector)
2. **AC-2.1.2:** Body text uses `--font-body` font family with `line-height: 1.5` (global `body` selector)
3. **AC-2.1.3:** Hero CTA button styled with `--color-accent` background, white text, padding, border-radius
4. **AC-2.1.4:** Hero CTA button has hover, focus, and active states (brightness + scale transforms)
5. **AC-2.1.5:** Hero tagline uses `--font-size-lg` for typography scale
6. **AC-2.1.6:** Project cards have box-shadow `0 2px 8px rgba(0, 0, 0, 0.1)` for depth
7. **AC-2.1.7:** Project cards have elevated shadow `0 4px 16px rgba(0, 0, 0, 0.15)` on hover
8. **AC-2.1.8:** Project cards have white background contrasting with page background
9. **AC-2.1.9:** CSS includes `@media (prefers-reduced-motion: reduce)` query disabling transitions
10. **AC-2.1.10:** All new CSS classes follow BEM naming convention
11. **AC-2.1.11:** All CSS uses `var(--token-name)` syntax, no hardcoded colors/fonts/pixels

## Tasks / Subtasks

- [x] Task 0: Verify pre-existing CSS state (Prerequisites)
  - [x] 0.1: Verify `:root` contains all color tokens with correct values
  - [x] 0.2: Verify `:root` contains all typography tokens
  - [x] 0.3: Verify `:root` contains all spacing tokens

- [x] Task 1: Apply typography tokens globally (AC: 1, 2)
  - [x] 1.1: Add `body { font-family: var(--font-body); font-size: var(--font-size-base); line-height: 1.5; color: var(--color-text); margin: 0; background-color: var(--color-background); }`
  - [x] 1.2: Add `.hero__name { font-family: var(--font-heading); font-size: var(--font-size-xxl); }`
  - [x] 1.3: Verify `<h1>` renders in Georgia serif font (--font-heading)

- [x] Task 2: Apply design tokens to hero section (AC: 3, 4, 5)
  - [x] 2.1: Add `.hero__tagline { font-size: var(--font-size-lg); }` for typography scale
  - [x] 2.2: Style `.hero__cta` button with accent color, padding, border-radius
  - [x] 2.3: Add hover state: filter brightness(0.9), scale(1.02)
  - [x] 2.4: Add focus-visible state: outline 3px solid accent, offset 2px
  - [x] 2.5: Add active state: filter brightness(0.8), scale(0.98)

- [x] Task 3: Enhance project card styling (AC: 6, 7, 8)
  - [x] 3.1: Add box-shadow `0 2px 8px rgba(0, 0, 0, 0.1)` to `.projects__card`
  - [x] 3.2: Add hover state: shadow `0 4px 16px rgba(0, 0, 0, 0.15)`, translateY(-2px)
  - [x] 3.3: Verify card background is white (--color-background)

- [x] Task 4: Add CSS reset/normalize baseline and organize CSS file
  - [x] 4.1: Add section comments to organize CSS: `/* CSS Custom Properties */`, `/* Global Typography */`, `/* Hero Section */`, `/* Projects Section */`, `/* Accessibility */`
  - [x] 4.2: Add `* { box-sizing: border-box; }`
  - [x] 4.3: Reset heading margins: `h1, h2, h3, h4, h5, h6 { margin: 0; margin-bottom: var(--spacing-sm); }`

- [x] Task 5: Add accessibility-focused styles (NFR-003) (AC: 9)
  - [x] 5.1: Add `@media (prefers-reduced-motion: reduce)` query to disable transitions

- [x] Task 6: Verify implementation (all AC)
  - [x] 6.1: Visual inspection: Hero has dark background, white text, styled CTA button
  - [x] 6.2: Visual inspection: Cards have shadows, hover effects
  - [x] 6.3: Run Playwright tests to verify no regressions
  - [x] 6.4: Verify all CSS uses `var(--token-name)` syntax, no hardcoded values

## Dev Notes

### Architecture Constraints

**From ADR-001 (Pure HTML/CSS Stack):**
- NO JavaScript - this is a hard requirement
- NO external dependencies, CSS preprocessors, or build tools
- Vanilla CSS3 only - use native CSS custom properties

**From ADR-003 (CSS Custom Properties for Theming):**
- ALL design values MUST use CSS custom properties via `var(--token-name)`
- NEVER use hardcoded hex colors, font names, or pixel values for design tokens
- This is a HIGH PRIORITY antipattern fix from Epic 1

**From ADR-004 (BEM Naming Convention):**
- All classes follow Block__Element--Modifier pattern
- New styles should extend existing BEM structure, not replace

**From ADR-005 (Mobile-First):**
- Base styles are for mobile
- Responsive breakpoints added in Story 2.2 (NOT this story)
- Do NOT add `@media (min-width: 768px)` in this story (layout queries only - accessibility queries are required)

**From NFR-002 (Maintainability):**
- CSS must be organized with clear section comments
- Use comments like `/* CSS Custom Properties */`, `/* Global Typography */`, `/* Hero Section */`, `/* Accessibility */`

**From NFR-003 (Accessibility):**
- All interactive elements must have visible focus states
- Respect `prefers-reduced-motion` for users who prefer no animation
- Color contrast must meet WCAG AA standards (already verified in design tokens)

### 🚨 CRITICAL: Antipatterns to AVOID (from Epic 1 Code Reviews)

| Antipattern | Fix | Source |
|-------------|-----|--------|
| Hardcoded CSS values instead of custom properties | Use `var(--color-primary)` not `#1a1a2e` | Story 1.1 antipatterns |
| Missing `prefers-reduced-motion` | Add media query for animations/transitions | Story 1.2 code review |
| CSS property ordering violations | Follow: positioning → display → box model → typography → visual → misc | Story 1.2 code review |

### Current CSS State (from Story 1.2 completion)

The `:root` CSS custom properties already exist:

```css
:root {
  --color-primary: #1a1a2e;
  --color-accent: #e94560;
  --color-background: #fff;
  --color-text: #333;
  --color-text-light: #666;
  --font-heading: Georgia, serif;
  --font-body: Arial, sans-serif;
  --font-size-base: 16px;
  --font-size-lg: 1.25rem;
  --font-size-xl: 2rem;
  --font-size-xxl: 3rem;
  --spacing-xs: 0.5rem;
  --spacing-sm: 1rem;
  --spacing-md: 2rem;
  --spacing-lg: 4rem;
  --max-width: 1200px;
  --border-radius: 8px;
}
```

**Existing hero styles:**
- `.hero` has `padding: var(--spacing-md)`, `background: var(--color-primary)`, centered text
- `.hero__cta` has `color: var(--color-background)` (white text)

**Existing projects styles:**
- `.projects` has padding with spacing tokens
- `.projects__title` uses `--font-heading` and `--font-size-xl`
- `.projects__card` has padding, border-radius, background
- `.projects__card-image` has height and background color
- `.projects__card-title` uses `--font-heading`
- `.projects__card-description` uses `--font-body`

### What This Story ADDS

This story is about **completing** the design token application, not starting from scratch:

1. **Typography on `body` element** - Global font stack not yet applied
2. **Typography on `.hero__name`** - The `<h1>` needs explicit `--font-heading` styling
3. **CTA button styling** - Currently only has color, needs full button treatment
4. **Hover/focus states** - UX spec requires interaction states
5. **Card shadows** - UX spec requires depth via shadows
6. **`prefers-reduced-motion`** - Accessibility requirement from NFR-003

### UX Design Token Reference

From `docs/ux-spec.md`:

| UX Goal | Token | Value | Notes |
|---------|-------|-------|-------|
| Sophisticated first impression | `--color-primary` | #1a1a2e | Dark navy hero background |
| Draw attention to contact | `--color-accent` | #e94560 | CTA button background |
| Clean gallery feel | `--color-background` | #ffffff | Card and page background |
| Readable content | `--color-text` | #333333 | Main body text |
| Elegant headings | `--font-heading` | Georgia, serif | h1, h2, h3 |
| Clear body text | `--font-body` | Arial, sans-serif | Paragraphs, descriptions |
| Consistent rhythm | `--spacing-*` | 0.5/1/2/4rem scale | All spacing |
| Professional cards | `--border-radius` | 8px | Card corners |

### CTA Button Styling (from UX spec)

| State | Visual Treatment |
|-------|------------------|
| Default | `--color-accent` background, white text, padding, border-radius |
| Hover | Slightly darker accent (filter: brightness), subtle scale (1.02) |
| Focus | Visible outline for accessibility (use accent color) |
| Active | Darker accent, scale down (0.98) |

**CSS Pattern:**
```css
.hero__cta {
  display: inline-block;
  padding: var(--spacing-sm) var(--spacing-md);
  background: var(--color-accent);
  color: var(--color-background);
  text-decoration: none;
  border-radius: var(--border-radius);
  font-family: var(--font-body);
  font-weight: bold;
  transition: transform 0.2s ease, filter 0.2s ease;
}

.hero__cta:hover {
  filter: brightness(0.9);
  transform: scale(1.02);
}

.hero__cta:focus-visible {
  outline: 3px solid var(--color-accent);
  outline-offset: 2px;
}

.hero__cta:active {
  filter: brightness(0.8);
  transform: scale(0.98);
}
```

### Project Card Styling (from UX spec)

| State | Visual Treatment |
|-------|------------------|
| Default | Subtle shadow, white background |
| Hover | Elevated shadow, slight lift effect |
| Focus | Visible outline around card |

**CSS Pattern:**
```css
.projects__card {
  /* existing box model properties first */
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
  transition: box-shadow 0.2s ease, transform 0.2s ease;
}

.projects__card:hover {
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.15);
  transform: translateY(-2px);
}
```

### Accessibility Requirements (from NFR-003 + UX spec)

1. **Color Contrast:**
   - `--color-text` (#333) on white = 12.6:1 ✓
   - White on `--color-primary` (#1a1a2e) = 15.1:1 ✓
   - White on `--color-accent` (#e94560) = 4.5:1 ✓

2. **Focus States:**
   - All interactive elements MUST have visible focus states
   - Use `--color-accent` for focus outline consistency
   - NEVER use `outline: none` without replacement

3. **Motion:**
   - Respect `prefers-reduced-motion` media query
   - Disable transitions/transforms for users who prefer no motion

**CSS Pattern:**
```css
@media (prefers-reduced-motion: reduce) {
  *,
  *::before,
  *::after {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
  }
}
```

### File Locations

| File | Path | Status |
|------|------|--------|
| styles.css | `/styles.css` (project root) | MODIFY (enhance existing rules) |
| index.html | `/index.html` (project root) | NO CHANGES (HTML complete from Epic 1) |

**Constraint:** Maximum 2 files total for entire project.

### CSS Property Ordering Standard

From `project_context.md`, properties MUST be ordered:

1. **Positioning**: position, top, right, bottom, left, z-index
2. **Display**: display, flex, grid, align, justify
3. **Box model**: width, height, margin, padding, border
4. **Typography**: font-family, font-size, font-weight, line-height, text-align, color
5. **Visual**: background, box-shadow, opacity, filter
6. **Misc**: transition, animation, cursor, outline

**Note on line-height:** Use `line-height: 1.5` (unitless), NOT `1.5em` or `1.5rem`. Unitless values multiply the element's font-size and don't compound through nested elements, which is the correct CSS best practice for consistent vertical rhythm.

### What NOT To Do

- ❌ Do NOT add responsive media queries (Story 2.2 scope)
- ❌ Do NOT add `@media (min-width: 768px)` breakpoint (layout media queries only)
- ❌ Do NOT modify HTML structure (Epic 1 complete)
- ❌ Do NOT use hardcoded hex colors, font names, or px values for design tokens
- ❌ Do NOT use `outline: none` without providing alternative focus indicator
- ❌ Do NOT add new HTML elements or classes
- ❌ Do NOT add footer or contact sections (out of scope)
- ❌ Do NOT mix 6-digit and 3-digit hex formats - use existing format in styles.css

### Media Query Clarification

The "No media queries" constraint in ADR-005 applies to **layout/responsive** breakpoints (e.g., `@media (min-width: 768px)`). **Accessibility** media queries like `@media (prefers-reduced-motion: reduce)` are REQUIRED per NFR-003.

### Testing Verification

Run Playwright tests after implementation to ensure no regressions:

```bash
npx playwright test
```

Expected: All 38 tests pass (test count should remain 38 - no new tests required for this story)

**Visual Verification Checklist:**
1. Hero: Dark navy background, white text, coral CTA button with hover effect
2. Hero: CTA button has visible focus ring when tabbed
3. Cards: Have subtle shadow, shadow elevates on hover
4. Typography: Headings in Georgia serif, body in Arial sans-serif
5. No layout shifts or visual regressions from Epic 1

**Performance Check:**
```bash
# Verify CSS file size is under 10KB
wc -c styles.css
# Output should be < 10240 bytes
```

### Project Structure Notes

**Alignment with unified project structure:**
- Single `styles.css` file in project root
- All styles use CSS custom properties from `:root`
- BEM naming convention maintained

**Detected conflicts or variances:** None - this story extends Epic 1 patterns.

### Performance Budget

From Architecture:
- CSS size: < 10KB (current ~500 bytes, adding ~1KB acceptable)
- Total page weight: < 20KB (excluding images)

### Definition of Done (from epics.md)

1. All acceptance criteria are checked off
2. HTML validates (no changes expected, should still pass)
3. CSS follows BEM naming throughout
4. CSS is organized with section comments per NFR-002
5. All Playwright tests pass (38/38)
6. Manual visual verification passes
7. CSS file size under 10KB

### References

- [Source: docs/project_context.md#CSS Custom Properties]
- [Source: docs/project_context.md#CSS Rules (property ordering)]
- [Source: docs/architecture.md#ADR-003 CSS Custom Properties for Theming]
- [Source: docs/architecture.md#ADR-005 Mobile-First Responsive Design]
- [Source: docs/prd.md#FR-003: Consistent Visual Design System]
- [Source: docs/prd.md#NFR-003: Accessibility]
- [Source: docs/ux-spec.md#Design Token Mapping]
- [Source: docs/ux-spec.md#Interaction Design]
- [Source: docs/ux-spec.md#Accessibility Considerations]
- [Source: docs/epics.md#Story 2.1: CSS Design Tokens and Typography]
- [Source: _bmad-output/implementation-artifacts/antipatterns/epic-1-code-antipatterns.md]
- [Source: _bmad-output/implementation-artifacts/retrospectives/epic-1-retro-20260131.md]

## Dev Agent Record

### Agent Model Used

Claude Opus 4.5 (claude-opus-4-5-20251101)

### Debug Log References

N/A - No debug logs required for this implementation.

### Completion Notes List

1. **Prerequisites verified**: All CSS custom properties from Epic 1 confirmed present in `:root`
2. **Global typography applied**: Body element now uses `--font-body`, `--font-size-base`, `line-height: 1.5`, `--color-text`, and `--color-background`
3. **Hero section enhanced**:
   - `.hero__name` uses `--font-heading` and `--font-size-xxl`
   - `.hero__tagline` uses `--font-size-lg`
   - `.hero__cta` fully styled with accent background, padding, border-radius, and interaction states (hover/focus-visible/active)
4. **Project cards enhanced**: Box-shadow added for depth, hover state with elevated shadow and translateY transform
5. **CSS organization**: Section comments added (`/* CSS Custom Properties */`, `/* Global Typography */`, `/* Hero Section */`, `/* Projects Section */`, `/* Accessibility */`)
6. **CSS reset applied**: `box-sizing: border-box` universal selector, heading margin resets
7. **Accessibility**: `@media (prefers-reduced-motion: reduce)` media query disables transitions
8. **All 11 acceptance criteria satisfied**
9. **All 16 Playwright tests pass** for Story 2.1
10. **CSS file size**: 3,175 bytes (well under 10KB budget)
11. **Test fixes**: Updated AC-2.1.7 test to wait for transition completion, fixed AC-2.1.10 BEM regex to allow hyphens in element names
12. **Code Review Synthesis (2026-01-31)**: Applied fixes from 7 validator reviews:
    - Added new CSS custom properties: `--outline-width`, `--outline-offset`, `--card-image-height`
    - Standardized hex color format to 6-digit (`#ffffff`, `#333333`, `#666666`)
    - Fixed CSS property ordering in `.hero` (color before background) and `.hero__cta` (border-radius before font-family)
    - Removed redundant `box-sizing: border-box` from `.hero`
    - Replaced hardcoded pixel values with CSS custom properties (outline, card-image-height)
    - Added `.projects__card:focus-visible` for accessibility
    - Fixed hover state leak in AC-2.1.4 test by adding explicit mouse click reset before focus test
    - Added active state test coverage to AC-2.1.4 (missing from original implementation)
    - Replaced `page.waitForTimeout(300)` with `expect().toPass()` pattern for robust transition waiting
    - Updated outdated TDD comment in test file header

### Change Log

| Date | Author | Change |
|------|--------|--------|
| 2026-01-31 | BMad | Story created with comprehensive developer context from create-story workflow |
| 2026-01-31 | BMad | Synthesis improvements: separated Prerequisites from ACs, clarified media query constraint, added CSS organization requirements, improved task specificity |
| 2026-01-31 | Claude Opus 4.5 | Implementation complete: All 11 ACs satisfied, all tasks completed, 35/35 tests pass |
| 2026-01-31 | Code Review Synthesis | Applied 7 validator findings: fixed hex format, property ordering, hardcoded values, missing active state test, hover state leak, replaced waitForTimeout with toPass |

### File List

- `styles.css` (MODIFIED) - Complete CSS implementation with design tokens, typography, CTA styling, card shadows, hover states, prefers-reduced-motion, focus-visible states
- `tests/e2e/story-2.1-design-tokens.spec.ts` (MODIFIED) - Enabled all 16 tests (removed `test.skip`), fixed BEM regex and hover timing issues, added active state test coverage

<!-- CODE_REVIEW_SYNTHESIS_START -->
## Synthesis Summary

Synthesized findings from 7 independent code review validators. Identified 9 verified issues requiring fixes, and dismissed 4 false positives. Applied all critical and high-priority fixes to source code. All 16 Story 2.1 tests pass after fixes.

## Validations Quality

| Reviewer | Score | Assessment |
|----------|-------|------------|
| A | 8/10 | Thorough analysis, correctly identified AC-2.1.11 violations and property ordering issues. One false positive on WCAG contrast (actually passes). |
| B | 6/10 | Found legitimate issues but scored too leniently (-0.2 = APPROVED). Missed the hardcoded value violations that other reviewers caught. |
| C | 7/10 | Good catch on missing card focus-visible state and hardcoded values. Some findings duplicated other reviewers. |
| D | 6/10 | Focused narrowly on outline-offset but missed broader AC-2.1.11 violations. Low issue count (3) indicated less thorough review. |
| E | 8/10 | Excellent catch on hover state leak bug in tests and waitForTimeout anti-pattern. Good test quality analysis. |
| F | 7/10 | Correctly identified hex format inconsistency and hardcoded height. Some findings duplicated others. |
| G | 8/10 | Most comprehensive review (10 issues). Good catch on dead CSS code (animation-iteration-count) and missing active state test. |

## Issues Verified (by severity)

### Critical

**No critical issues identified.** All issues were fixable without security vulnerabilities or data corruption risks.

### High

- **Issue**: Hardcoded pixel values violate AC-2.1.11 requirement
  - **Source**: Reviewers A, C, D, F, G (5/7 consensus)
  - **File**: `styles.css:85-88, 127`
  - **Fix**: Added new CSS custom properties (`--outline-width: 3px`, `--outline-offset: 2px`, `--card-image-height: 200px`) and replaced hardcoded values with `var(--outline-width)`, `var(--outline-offset)`, `var(--card-image-height)`

- **Issue**: Missing active state test coverage for AC-2.1.4
  - **Source**: Reviewers B, E, G (3/7 consensus)
  - **File**: `tests/e2e/story-2.1-design-tokens.spec.ts:178-223`
  - **Fix**: Added active state test with `mousedown` event dispatch and assertions for brightness filter and scale transform

- **Issue**: Hex color format inconsistency (3-digit vs 6-digit)
  - **Source**: Reviewers F, G (2/7)
  - **File**: `styles.css:5-7`
  - **Fix**: Standardized all hex colors to 6-digit format: `#fff` → `#ffffff`, `#333` → `#333333`, `#666` → `#666666`

### Medium

- **Issue**: CSS property ordering violations
  - **Source**: Reviewers A, B, C, D, F (5/7 consensus)
  - **File**: `styles.css:52-57, 69-78`
  - **Fix**: Reordered properties in `.hero` (color before background) and `.hero__cta` (border-radius before font-family) to match project standard: positioning → display → box model → typography → visual → misc

- **Issue**: Brittle `waitForTimeout(300)` in AC-2.1.7 test
  - **Source**: Reviewers B, E (2/7)
  - **File**: `tests/e2e/story-2.1-design-tokens.spec.ts:290`
  - **Fix**: Replaced `await page.waitForTimeout(300)` with `await expect(async () => { ... }).toPass({ timeout: 500 })` pattern that waits for actual style changes

- **Issue**: Hover state leak in AC-2.1.4 focus test
  - **Source**: Reviewer E
  - **File**: `tests/e2e/story-2.1-design-tokens.spec.ts:189-207`
  - **Fix**: Added `await page.mouse.click(0, 0)` before focus test and changed to explicit `await ctaButton.focus()` instead of `page.keyboard.press('Tab')`

- **Issue**: Missing focus-visible state for project cards
  - **Source**: Reviewers C, G (2/7)
  - **File**: `styles.css:123-126`
  - **Fix**: Added `.projects__card:focus-visible` rule with outline styling matching CTA focus pattern

### Low

- **Issue**: Redundant `box-sizing: border-box` declaration
  - **Source**: Reviewers A, D, F (3/7 consensus)
  - **File**: `styles.css:51`
  - **Fix**: Removed redundant `box-sizing: border-box;` from `.hero` selector (already covered by universal `*` selector)

- **Issue**: Outdated TDD comment in test file header
  - **Source**: Reviewer G
  - **File**: `tests/e2e/story-2.1-design-tokens.spec.ts:4-5`
  - **Fix**: Removed outdated "TDD RED PHASE: All tests use test.skip()" comment since all tests are now enabled

## Issues Dismissed

- **Claimed Issue**: WCAG AA contrast failure for `--color-text-light: #666` on white background (3.94:1, below 4.5:1 threshold)
  - **Raised by**: Reviewer A
  - **Dismissal Reason**: FALSE POSITIVE - The claimed contrast ratio is incorrect. Using standard WCAG contrast calculation, `#666` on `#fff` actually achieves approximately 5.8:1, which passes WCAG AA. The reviewer appears to have miscalculated or used an incorrect contrast formula.

- **Claimed Issue**: `!important` in `prefers-reduced-motion` query violates "no hardcoded values" rule
  - **Raised by**: Reviewer E
  - **Dismissal Reason**: FALSE POSITIVE - The `!important` flag in accessibility media queries is a documented exception and best practice. User preference overrides (`prefers-reduced-motion`) should always win, and `!important` ensures this. This is not about "hardcoded values" but about correct accessibility implementation.

- **Claimed Issue**: `animation-iteration-count: 1` is dead code since no `@keyframes` animations exist
  - **Raised by**: Reviewer G
  - **Dismissal Reason**: DISMISSED - While technically true that no animations are currently defined, this is defensive programming. The reduced-motion query follows a standard pattern that would apply if animations were added later. Removing it would create a maintenance burden (remembering to add it when adding animations). Keeping it is harmless and follows accessibility best practices.

- **Claimed Issue**: Test file uses Node.js `fs` module directly instead of provided Read tools
  - **Raised by**: Reviewer D
  - **Dismissal Reason**: NOT APPLICABLE - This is a Playwright test file, not BMAD agent code. Playwright tests running in Node.js environment correctly use `fs.readFileSync()` to read CSS files for static analysis assertions. This is standard Playwright practice and not an issue.

## Changes Applied

**File**: `styles.css`
**Change**: Added new CSS custom properties for outline width/offset and card image height
**Before**:
```css
:root {
  --color-primary: #1a1a2e;
  --color-accent: #e94560;
  --color-background: #fff;
  --color-text: #333;
  --color-text-light: #666;
  ...
  --border-radius: 8px;
}
```
**After**:
```css
:root {
  --color-primary: #1a1a2e;
  --color-accent: #e94560;
  --color-background: #ffffff;
  --color-text: #333333;
  --color-text-light: #666666;
  ...
  --border-radius: 8px;
  --outline-width: 3px;
  --outline-offset: 2px;
  --card-image-height: 200px;
}
```

---

**File**: `styles.css`
**Change**: Fixed property ordering in `.hero` selector
**Before**:
```css
.hero {
  width: 100%;
  box-sizing: border-box;
  padding: var(--spacing-md);
  text-align: center;
  background: var(--color-primary);
  color: var(--color-background);
}
```
**After**:
```css
.hero {
  width: 100%;
  padding: var(--spacing-md);
  text-align: center;
  color: var(--color-background);
  background: var(--color-primary);
}
```

---

**File**: `styles.css`
**Change**: Fixed property ordering in `.hero__cta` and replaced hardcoded outline values
**Before**:
```css
.hero__cta {
  display: inline-block;
  padding: var(--spacing-sm) var(--spacing-md);
  font-family: var(--font-body);
  font-weight: bold;
  color: var(--color-background);
  text-decoration: none;
  background: var(--color-accent);
  border-radius: var(--border-radius);
  ...
}

.hero__cta:focus-visible {
  outline: 3px solid var(--color-accent);
  outline-offset: 2px;
}
```
**After**:
```css
.hero__cta {
  display: inline-block;
  padding: var(--spacing-sm) var(--spacing-md);
  border-radius: var(--border-radius);
  font-family: var(--font-body);
  font-weight: bold;
  color: var(--color-background);
  text-decoration: none;
  background: var(--color-accent);
  ...
}

.hero__cta:focus-visible {
  outline: var(--outline-width) solid var(--color-accent);
  outline-offset: var(--outline-offset);
}
```

---

**File**: `styles.css`
**Change**: Added missing `.projects__card:focus-visible` state
**Before**:
```css
.projects__card:hover {
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.15);
  transform: translateY(-2px);
}

.projects__card-image {
  height: 200px;
  ...
}
```
**After**:
```css
.projects__card:hover {
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.15);
  transform: translateY(-2px);
}

.projects__card:focus-visible {
  outline: var(--outline-width) solid var(--color-accent);
  outline-offset: var(--outline-offset);
}

.projects__card-image {
  height: var(--card-image-height);
  ...
}
```

---

**File**: `tests/e2e/story-2.1-design-tokens.spec.ts`
**Change**: Removed outdated TDD comment
**Before**:
```typescript
/**
 * ATDD Tests for Story 2.1: CSS Design Tokens and Typography
 *
 * TDD RED PHASE: All tests use test.skip() and will fail until feature is implemented.
 * After implementation, remove test.skip() to verify tests pass (GREEN phase).
 *
 * Acceptance Criteria:
 * ...
 */
```
**After**:
```typescript
/**
 * ATDD Tests for Story 2.1: CSS Design Tokens and Typography
 *
 * Acceptance Criteria:
 * ...
 */
```

---

**File**: `tests/e2e/story-2.1-design-tokens.spec.ts`
**Change**: Fixed hover state leak and added active state test
**Before**:
```typescript
    const ctaButton = page.locator(heroSelectors.cta);

    // When: User hovers over CTA
    await ctaButton.hover();
    await log.step('Testing hover state');

    // Then: CTA should have transform scale (1.02) on hover
    ...

    // When: User focuses CTA (keyboard navigation)
    await page.keyboard.press('Tab'); // Focus the CTA
    await log.step('Testing focus-visible state');
```
**After**:
```typescript
    const ctaButton = page.locator(heroSelectors.cta);

    // When: User hovers over CTA
    await ctaButton.hover();
    await log.step('Testing hover state');

    // Then: CTA should have transform scale (1.02) on hover
    ...

    // Clear hover state before testing focus
    await page.mouse.click(0, 0);

    // When: User focuses CTA (keyboard navigation)
    await ctaButton.focus();
    await log.step('Testing focus-visible state');

    ...

    // When: User activates CTA (active state)
    await ctaButton.dispatchEvent('mousedown');
    await log.step('Testing active state');

    // Then: CTA should have darker brightness on active
    const activeFilter = await ctaButton.evaluate((el) =>
      getComputedStyle(el).filter
    );
    expect(activeFilter).toContain('brightness');

    // And: CTA should scale down on active
    const activeTransform = await ctaButton.evaluate((el) =>
      getComputedStyle(el).transform
    );
    expect(activeTransform).not.toBe('none');
```

---

**File**: `tests/e2e/story-2.1-design-tokens.spec.ts`
**Change**: Replaced brittle waitForTimeout with robust toPass pattern
**Before**:
```typescript
    // When: User hovers over card
    await card.hover();
    // Wait for transition to complete (0.2s = 200ms + buffer)
    await page.waitForTimeout(300);
    await log.step('Testing card hover state');
```
**After**:
```typescript
    // When: User hovers over card
    await card.hover();
    // Wait for transition to complete - verify shadow changed
    await expect(async () => {
      const shadow = await card.evaluate(el => getComputedStyle(el).boxShadow);
      expect(shadow).toContain('16px'); // Hover shadow has 16px blur
    }).toPass({ timeout: 500 });
    await log.step('Testing card hover state');
```

## Files Modified

- `styles.css`
- `tests/e2e/story-2.1-design-tokens.spec.ts`
- `_bmad-output/implementation-artifacts/2-1-css-design-tokens-and-typography.md` (story file - Dev Agent Record updated)

## Suggested Future Improvements

- **Scope**: Add performance budget test for CSS file size | **Rationale**: Story claims CSS is under 10KB but no automated test verifies this. Future additions could exceed budget without detection. | **Effort**: Low (single test assertion)

- **Scope**: Consider CSS custom property for `font-weight: bold` | **Rationale**: Current implementation uses hardcoded `font-weight: bold` instead of a token. While minor, a `--font-weight-bold` token would be more consistent with the design token philosophy. | **Effort**: Low (add token, update reference)

- **Scope**: Refactor color assertions in tests to be token-agnostic | **Rationale**: Tests currently use hardcoded `rgb()` values which break if token values change. Could read tokens from CSS and compare computed values against token definitions. | **Effort**: Medium (requires parsing CSS or adding token exposure endpoint)

## Test Results

- Tests passed: 16 (all Story 2.1 tests on Chromium)
- Tests failed: 0

```
npx playwright test tests/e2e/story-2.1-design-tokens.spec.ts --project=chromium --reporter=line

Running 16 tests using 1 worker

  ✓  [chromium] › Story 2.1: CSS Design Tokens and Typography › AC-2.1.1: h1 should use --font-heading and --font-size-xxl via .hero__name
  ✓  [chromium] › Story 2.1: CSS Design Tokens and Typography › AC-2.1.2: body should use --font-body with line-height 1.5
  ✓  [chromium] › Story 2.1: CSS Design Tokens and Typography › AC-2.1.3: hero CTA should have accent background, white text, padding, and border-radius
  ✓  [chromium] › Story 2.1: CSS Design Tokens and Typography › AC-2.1.4: hero CTA should have hover, focus, and active states
  ✓  [chromium] › Story 2.1: CSS Design Tokens and Typography › AC-2.1.5: hero tagline should use --font-size-lg
  ✓  [chromium] › Story 2.1: CSS Design Tokens and Typography › AC-2.1.6: project cards should have box-shadow for depth
  ✓  [chromium] › Story 2.1: CSS Design Tokens and Typography › AC-2.1.7: project cards should have elevated shadow on hover
  ✓  [chromium] › Story 2.1: CSS Design Tokens and Typography › AC-2.1.8: project cards should have white background
  ✓  [chromium] › Story 2.1: CSS Design Tokens and Typography › AC-2.1.9: CSS should include prefers-reduced-motion media query
  ✓  [chromium] › Story 2.1: CSS Design Tokens and Typography › AC-2.1.10: all CSS classes should follow BEM naming convention
  ✓  [chromium] › Story 2.1: CSS Design Tokens and Typography › AC-2.1.11: all CSS should use var(--token) syntax for design tokens
  ✓  [chromium] › Story 2.1: CSS Organization › should have organized CSS with section comments
  ✓  [chromium] › Story 2.1: CSS Organization › should have box-sizing border-box reset
  ✓  [chromium] › Story 2.1: CSS Organization › should have heading margin resets with spacing token
  ✓  [chromium] › Story 2.1: CTA Transition › should have transition property on CTA for smooth state changes
  ✓  [chromium] › Story 2.1: Card Transition › should have transition property on cards for smooth hover

  16 passed (4.2s)
```
<!-- CODE_REVIEW_SYNTHESIS_END -->
]]></file>
<file id="da9a0578" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/implementation-artifacts/2-2-mobile-first-responsive-layout.md"><![CDATA[# Story 2.2: Mobile-First Responsive Layout

Status: ready-for-dev

<!-- Note: Validation is optional. Run validate-create-story for quality check before dev-story. -->

## Story

As a **mobile user**,
I want the **portfolio to display correctly on my device**,
so that **I can browse Alex's work comfortably regardless of screen size**.

## Prerequisites (Pre-existing from Story 2.1)

The following must be verified before implementation:
- CSS custom properties defined in `:root` (colors, fonts, spacing, border-radius)
- Typography tokens applied (body, headings, tagline)
- Hero section styling complete (background, padding, CTA button)
- Project card styling complete (shadows, hover states, focus states)
- `prefers-reduced-motion` media query exists

## Acceptance Criteria

1. **AC-2.2.1:** Base styles (no media query) display single-column layout for `.projects__grid`
2. **AC-2.2.2:** `styles.css` contains `@media (min-width: 768px)` query
3. **AC-2.2.3:** On mobile (<768px): project cards stack vertically in single column (`grid-template-columns: 1fr`)
4. **AC-2.2.4:** On desktop (>=768px): project cards display in 3-column grid (`grid-template-columns: repeat(3, 1fr)`)
5. **AC-2.2.5:** Hero section text is readable on mobile (appropriate font sizes preserved from Story 2.1)
6. **AC-2.2.6:** CTA button has minimum touch target of 44x44 pixels on mobile
7. **AC-2.2.7:** No horizontal scrolling occurs on mobile viewport (320px minimum width)
8. **AC-2.2.8:** Grid uses CSS Grid for layout (already implemented, verify preserved)

## Tasks / Subtasks

- [ ] Task 0: Verify prerequisites from Story 2.1 (AC: Prerequisites)
  - [ ] 0.1: Confirm `.projects__grid` has `display: grid` and `gap: var(--spacing-md)`
  - [ ] 0.2: Confirm `:root` contains all required CSS custom properties
  - [ ] 0.3: Confirm hero and card styling from Story 2.1 is intact

- [ ] Task 1: Verify mobile-first base styles (AC: 1, 3)
  - [ ] 1.1: Confirm `.projects__grid` does NOT have `grid-template-columns` in base styles (defaults to single column)
  - [ ] 1.2: If base styles have multi-column layout, remove/modify to single column default

- [ ] Task 2: Add responsive breakpoint media query (AC: 2, 4)
  - [ ] 2.1: Add `/* Responsive Layout */` section comment after `/* Accessibility */` section
  - [ ] 2.2: Add `@media (min-width: 768px)` media query
  - [ ] 2.3: Inside media query, add `.projects__grid { grid-template-columns: repeat(3, 1fr); }`

- [ ] Task 3: Verify CTA touch target (AC: 6)
  - [ ] 3.1: Measure computed CTA button size (padding + content)
  - [ ] 3.2: If < 44px height, increase padding to meet 44x44px minimum
  - [ ] 3.3: CTA currently has `padding: var(--spacing-sm) var(--spacing-md)` (16px 32px) - verify height meets 44px

- [ ] Task 4: Prevent horizontal overflow (AC: 7)
  - [ ] 4.1: Add `max-width: 100%` to content containers if needed
  - [ ] 4.2: Verify `.hero` and `.projects` don't cause horizontal scroll at 320px
  - [ ] 4.3: Consider adding `overflow-x: hidden` to body if edge cases exist

- [ ] Task 5: Create ATDD test file (AC: all)
  - [ ] 5.1: Create `tests/e2e/story-2.2-responsive.spec.ts`
  - [ ] 5.2: Add tests for mobile viewport (320px) - single column layout
  - [ ] 5.3: Add tests for tablet/desktop viewport (768px+) - 3-column layout
  - [ ] 5.4: Add test for CTA touch target (minimum 44x44px)
  - [ ] 5.5: Add test for no horizontal scrollbar at 320px
  - [ ] 5.6: Add test verifying media query exists in CSS file

- [ ] Task 6: Verify implementation (all AC)
  - [ ] 6.1: Visual test at 320px viewport - cards stack vertically
  - [ ] 6.2: Visual test at 768px viewport - cards in 3-column grid
  - [ ] 6.3: Visual test at 1200px viewport - layout stable
  - [ ] 6.4: Run all Playwright tests (existing + new Story 2.2 tests)
  - [ ] 6.5: Verify CSS file size still under 10KB

## Dev Notes

### Architecture Constraints

**From ADR-001 (Pure HTML/CSS Stack):**
- NO JavaScript - responsive layout must use CSS only
- NO external dependencies or build tools
- Vanilla CSS3 media queries only

**From ADR-005 (Mobile-First Responsive Design):**
- Base styles target mobile (smallest viewports)
- Media queries enhance for larger screens using `min-width`
- Single breakpoint at 768px per project specification
- NEVER use `max-width` media queries

**From NFR-001 (Performance):**
- CSS file must remain under 10KB
- Page loads in under 1 second on 3G

**From NFR-003 (Accessibility):**
- Touch targets minimum 44x44px for mobile
- Respect `prefers-reduced-motion` (already implemented in Story 2.1)

### Current CSS State (from Story 2.1 completion)

The `.projects__grid` currently has:
```css
.projects__grid {
  display: grid;
  gap: var(--spacing-md);
}
```

**NOTE:** No `grid-template-columns` is defined, which means CSS Grid defaults to single column. This is already mobile-first compliant! The task is to ADD the desktop breakpoint, not modify base styles.

### Required CSS Addition

Add after the `/* Accessibility */` section:

```css
/* Responsive Layout */
@media (min-width: 768px) {
  .projects__grid {
    grid-template-columns: repeat(3, 1fr);
  }
}
```

### CSS Property Ordering Standard

From `project_context.md`, properties ordered:
1. **Positioning**: position, top, right, bottom, left, z-index
2. **Display**: display, flex, grid, align, justify
3. **Box model**: width, height, margin, padding, border
4. **Typography**: font-family, font-size, font-weight, line-height, text-align, color
5. **Visual**: background, box-shadow, opacity, filter
6. **Misc**: transition, animation, cursor, outline

### CTA Button Touch Target Analysis

Current CTA styling (from `styles.css:69-78`):
```css
.hero__cta {
  display: inline-block;
  padding: var(--spacing-sm) var(--spacing-md);  /* 16px 32px */
  ...
  font-size: var(--font-size-base);  /* inherited - 16px */
}
```

**Calculation:**
- Font size: 16px (inherited from body)
- Line height: 1.5 (from body) = 24px
- Vertical padding: 16px + 16px = 32px
- Total height: 24px + 32px = 56px (exceeds 44px requirement)
- Horizontal: 32px + content + 32px (exceeds 44px requirement)

**Verdict:** CTA already meets 44x44px touch target. No changes needed.

### Viewport Testing Widths

Per UX spec and epics.md:
- **320px**: Minimum mobile width (iPhone SE, older devices)
- **768px**: Breakpoint threshold (tablet)
- **1200px**: Desktop (verify layout stability)

### Horizontal Scroll Prevention

Potential causes of horizontal scroll:
1. Fixed-width elements exceeding viewport
2. Padding/margin causing overflow
3. Images or media without `max-width: 100%`

Current implementation should be safe because:
- `.hero` has `width: 100%` and uses padding tokens
- `.projects` uses padding tokens
- No fixed-width elements exist

If horizontal scroll is detected, add:
```css
html, body {
  overflow-x: hidden;
}
```

**Warning:** Only add this as a fallback. Prefer fixing root cause.

### Antipatterns to AVOID (from Epic 1 Code Reviews)

| Antipattern | Fix | Source |
|-------------|-----|--------|
| Hardcoded CSS values | Use `var(--token-name)` for all design tokens | Story 1.1 antipatterns |
| Missing media query comment | Add `/* Responsive Layout */` section header | CSS organization standard |
| `max-width` media queries | Use `min-width` only (mobile-first) | ADR-005 |
| Multiple breakpoints | Single 768px breakpoint per spec | Project Context |

### Test File Structure

Create `tests/e2e/story-2.2-responsive.spec.ts`:

```typescript
/**
 * ATDD Tests for Story 2.2: Mobile-First Responsive Layout
 *
 * Acceptance Criteria:
 * - AC-2.2.1: Base styles display single-column layout
 * - AC-2.2.2: CSS contains @media (min-width: 768px) query
 * - AC-2.2.3: Mobile (<768px): cards stack vertically
 * - AC-2.2.4: Desktop (>=768px): 3-column grid
 * - AC-2.2.5: Hero text readable on mobile
 * - AC-2.2.6: CTA touch target >= 44x44px
 * - AC-2.2.7: No horizontal scroll at 320px
 * - AC-2.2.8: CSS Grid used for layout
 */
```

Use Playwright viewport configuration:
```typescript
// Mobile viewport
test.use({ viewport: { width: 320, height: 568 } });

// Tablet/Desktop viewport
test.use({ viewport: { width: 768, height: 1024 } });
```

Or within individual tests:
```typescript
await page.setViewportSize({ width: 320, height: 568 });
```

### What NOT To Do

- Do NOT modify HTML structure (Epic 1 complete)
- Do NOT add additional breakpoints beyond 768px
- Do NOT use JavaScript for responsive behavior
- Do NOT use `max-width` media queries
- Do NOT add footer or contact sections (out of scope)
- Do NOT modify existing hover/focus states from Story 2.1
- Do NOT touch the `prefers-reduced-motion` media query

### File Locations

| File | Path | Action |
|------|------|--------|
| styles.css | `/styles.css` (project root) | MODIFY (add media query) |
| index.html | `/index.html` (project root) | NO CHANGES |
| story-2.2-responsive.spec.ts | `/tests/e2e/story-2.2-responsive.spec.ts` | CREATE (ATDD tests) |

### Test Fixture Usage

Import from existing test infrastructure:
```typescript
import { test, expect } from '../support/fixtures';
import { heroSelectors, projectsSelectors } from '../support/helpers/selectors';
```

### Performance Budget

From Architecture:
- CSS size: < 10KB (current ~3.2KB, adding ~100 bytes acceptable)
- Total page weight: < 20KB (excluding images)

### Definition of Done (from epics.md)

1. All acceptance criteria are checked off
2. HTML validates (no changes expected)
3. CSS follows BEM naming throughout
4. Code is committed with descriptive message
5. Manual visual verification passes at 320px, 768px, 1200px
6. All Playwright tests pass (existing + new)

### UX Design Reference

From `docs/ux-spec.md`:

**Mobile Layout (< 768px):**
```
┌──────────────────────┐
│     ALEX CHEN        │
│  Capturing moments   │
│  that last forever   │
│   [ Get in Touch ]   │
├──────────────────────┤
│      Portfolio       │
├──────────────────────┤
│  ┌────────────────┐  │
│  │    Wedding     │  │
│  └────────────────┘  │
│  ┌────────────────┐  │
│  │    Portrait    │  │
│  └────────────────┘  │
│  ┌────────────────┐  │
│  │   Landscape    │  │
│  └────────────────┘  │
└──────────────────────┘
```

**Desktop Layout (>= 768px):**
```
┌────────────────────────────────────────────────────┐
│                    ALEX CHEN                       │
│          Capturing moments that last forever       │
│                  [ Get in Touch ]                  │
├────────────────────────────────────────────────────┤
│                     Portfolio                      │
├────────────────────────────────────────────────────┤
│  ┌──────────────┐ ┌──────────────┐ ┌──────────────┐│
│  │   Wedding    │ │   Portrait   │ │  Landscape   ││
│  └──────────────┘ └──────────────┘ └──────────────┘│
└────────────────────────────────────────────────────┘
```

### Project Structure Notes

**Alignment with unified project structure:**
- Single `styles.css` file in project root (no partials/imports)
- All styles use CSS custom properties from `:root`
- BEM naming convention maintained
- Single 768px breakpoint per project specification

**Detected conflicts or variances:** None - this story completes the responsive design system.

### References

- [Source: docs/project_context.md#Responsive Design]
- [Source: docs/architecture.md#ADR-005 Mobile-First Responsive Design]
- [Source: docs/prd.md#FR-004: Mobile-Responsive Layout]
- [Source: docs/ux-spec.md#Layout Design (wireframes)]
- [Source: docs/ux-spec.md#Touch Targets]
- [Source: docs/epics.md#Story 2.2: Mobile-First Responsive Layout]
- [Source: _bmad-output/implementation-artifacts/2-1-css-design-tokens-and-typography.md]
- [Source: _bmad-output/implementation-artifacts/retrospectives/epic-1-retro-20260131.md]
- [Source: _bmad-output/implementation-artifacts/antipatterns/epic-1-code-antipatterns.md]

## Dev Agent Record

### Agent Model Used

(To be filled by Dev Agent)

### Debug Log References

(To be filled by Dev Agent)

### Completion Notes List

(To be filled by Dev Agent)

### Change Log

| Date | Author | Change |
|------|--------|--------|
| 2026-01-31 | BMad | Story created with comprehensive developer context from create-story workflow |

### File List

(To be filled by Dev Agent upon completion)
]]></file>
</context>
<variables>
<var name="architecture_file" description="Architecture for technical requirements verification" />
<var name="author">BMad</var>
<var name="communication_language">English</var>
<var name="date">2026-01-31</var>
<var name="description">Quality competition validator - systematically review and improve story context created by create-story workflow</var>
<var name="document_output_language">English</var>
<var name="epic_num">2</var>
<var name="epics_file" file_id="314c28e8">/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/implementation-artifacts/test-design-epic-1-story-1.1.md</var>
<var name="implementation_artifacts">/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/implementation-artifacts</var>
<var name="model">validator</var>
<var name="name">validate-story</var>
<var name="output_folder">/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/implementation-artifacts</var>
<var name="planning_artifacts">/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/planning-artifacts</var>
<var name="prd_file" description="PRD for requirements verification" />
<var name="project_context">none</var>
<var name="project_knowledge">/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/docs</var>
<var name="project_name">simple-portfolio</var>
<var name="sprint_status">/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/implementation-artifacts/sprint-status.yaml</var>
<var name="story_dir">/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/implementation-artifacts</var>
<var name="story_file" file_id="da9a0578">/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/implementation-artifacts/2-2-mobile-first-responsive-layout.md</var>
<var name="story_id">2.2</var>
<var name="story_key">2-2-mobile-first-responsive-layout</var>
<var name="story_num">2</var>
<var name="story_title">mobile-first-responsive-layout</var>
<var name="timestamp">20260131_223026</var>
<var name="user_name">User</var>
<var name="user_skill_level">expert</var>
<var name="ux_file" description="UX design for user experience verification" />
<var name="validation_focus">story_quality</var>
</variables>
<file-index>
<entry id="a68b9042" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/implementation-artifacts/2-1-css-design-tokens-and-typography.md" />
<entry id="da9a0578" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/implementation-artifacts/2-2-mobile-first-responsive-layout.md" />
<entry id="314c28e8" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/_bmad-output/implementation-artifacts/test-design-epic-1-story-1.1.md" />
<entry id="2e55b2e3" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/docs/architecture.md" />
<entry id="bda659bb" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/docs/prd.md" />
<entry id="11c89e12" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/docs/project_context.md" />
<entry id="07a30897" path="/home/pawel/projects/bmad-assist-22/experiments/fixtures/simple-portfolio/docs/ux-spec.md" />
</file-index>
<instructions><workflow>
  <critical>SCOPE LIMITATION: You are a READ-ONLY VALIDATOR. Output your validation report to stdout ONLY. Do NOT create files, do NOT modify files, do NOT use Write/Edit/Bash tools. Your stdout output will be captured and saved by the orchestration system.</critical>
  <critical>All configuration and context is available in the VARIABLES section below. Use these resolved values directly.</critical>
  <critical>Communicate all responses in English and generate all documents in English</critical>

  <critical>🔥 CRITICAL MISSION: You are an independent quality validator in a FRESH CONTEXT competing against the original create-story LLM!</critical>
  <critical>Your purpose is to thoroughly review a story file and systematically identify any mistakes, omissions, or disasters that the original LLM missed</critical>
  <critical>🚨 COMMON LLM MISTAKES TO PREVENT: reinventing wheels, wrong libraries, wrong file locations, breaking regressions, ignoring UX, vague implementations, lying about completion, not learning from past work</critical>
  <critical>🔬 UTILIZE SUBPROCESSES AND SUBAGENTS: Use research subagents or parallel processing if available to thoroughly analyze different artifacts simultaneously</critical>

  <step n="1" goal="Story Quality Gate - INVEST validation">
    <critical>🎯 RUTHLESS STORY VALIDATION: Check story quality with surgical precision!</critical>
    <critical>This assessment determines if the story is fundamentally sound before deeper analysis</critical>

    <substep n="1a" title="INVEST Criteria Validation">
      <action>Evaluate each INVEST criterion with severity score (1-10, where 10 is critical violation):</action>

      <action>**I - Independent:** Check if story can be developed independently
        - Does it have hidden dependencies on other stories?
        - Can it be implemented without waiting for other work?
        - Are there circular dependencies?
        Score severity of any violations found
      </action>

      <action>**N - Negotiable:** Check if story allows implementation flexibility
        - Is it overly prescriptive about HOW vs WHAT?
        - Does it leave room for technical decisions?
        - Are requirements stated as outcomes, not solutions?
        Score severity of any violations found
      </action>

      <action>**V - Valuable:** Check if story delivers clear business value
        - Is the benefit clearly stated and meaningful?
        - Does it contribute to epic/product goals?
        - Would stakeholder recognize the value?
        Score severity of any violations found
      </action>

      <action>**E - Estimable:** Check if story can be accurately estimated
        - Are requirements clear enough to estimate?
        - Is scope well-defined without ambiguity?
        - Are there unknown technical risks that prevent estimation?
        Score severity of any violations found
      </action>

      <action>**S - Small:** Check if story is appropriately sized
        - Can it be completed in a single sprint?
        - Is it too large and should be split?
        - Is it too small to be meaningful?
        Score severity of any violations found
      </action>

      <action>**T - Testable:** Check if story has testable acceptance criteria
        - Are acceptance criteria specific and measurable?
        - Can each criterion be verified objectively?
        - Are edge cases and error scenarios covered?
        Score severity of any violations found
      </action>

      <action>Store INVEST results: {{invest_results}} with individual scores</action>
    </substep>

    <substep n="1b" title="Acceptance Criteria Deep Analysis">
      <action>Hunt for acceptance criteria issues:
        - Ambiguous criteria: Vague language like "should work well", "fast", "user-friendly"
        - Untestable criteria: Cannot be objectively verified
        - Missing criteria: Expected behaviors not covered
        - Conflicting criteria: Criteria that contradict each other
        - Incomplete scenarios: Missing edge cases, error handling, boundary conditions
      </action>
      <action>Document each issue with specific quote and recommendation</action>
      <action>Store as {{acceptance_criteria_issues}}</action>
    </substep>

    <substep n="1c" title="Hidden Dependencies Discovery">
      <action>Uncover hidden dependencies and future sprint-killers:
        - Undocumented technical dependencies (libraries, services, APIs)
        - Cross-team dependencies not mentioned
        - Infrastructure dependencies (databases, queues, caches)
        - Data dependencies (migrations, seeds, external data)
        - Sequential dependencies on other stories
        - External blockers (third-party services, approvals)
      </action>
      <action>Document each hidden dependency with impact assessment</action>
      <action>Store as {{hidden_dependencies}}</action>
    </substep>

    <substep n="1d" title="Estimation Reality-Check">
      <action>Reality-check the story estimate against complexity:
        - Compare stated/implied effort vs actual scope
        - Check for underestimated technical complexity
        - Identify scope creep risks
        - Assess if unknown unknowns are accounted for
        - Compare with similar stories from previous work
      </action>
      <action>Provide estimation assessment: realistic / underestimated / overestimated / unestimable</action>
      <action>Store as {{estimation_assessment}}</action>
    </substep>

    <substep n="1e" title="Technical Alignment Verification">
      <action>Verify alignment with embedded context architecture patterns:
        - Does story follow established architectural patterns?
        - Are correct technologies/frameworks specified?
        - Does it respect defined boundaries and layers?
        - Are naming conventions and file structures aligned?
        - Does it integrate correctly with existing components?
      </action>
      <action>Document any misalignments or conflicts</action>
      <action>Store as {{technical_alignment_issues}}</action>
    </substep>

    <o>🎯 **Story Quality Gate Results:**
      - INVEST Violations: {{invest_violation_count}}
      - Acceptance Criteria Issues: {{ac_issues_count}}
      - Hidden Dependencies: {{hidden_deps_count}}
      - Estimation: {{estimation_assessment}}
      - Technical Alignment: {{alignment_status}}

      ℹ️ Continuing with full analysis...
    </o>
  </step>

  <step n="2" goal="Disaster prevention gap analysis">
    <critical>🚨 CRITICAL: Identify every mistake the original LLM missed that could cause DISASTERS!</critical>

    <substep n="2a" title="Reinvention Prevention Gaps">
      <action>Analyze for wheel reinvention risks:
        - Areas where developer might create duplicate functionality
        - Code reuse opportunities not identified
        - Existing solutions not mentioned that developer should extend
        - Patterns from previous stories not referenced
      </action>
      <action>Document each reinvention risk found</action>
    </substep>

    <substep n="2b" title="Technical Specification Disasters">
      <action>Analyze for technical specification gaps:
        - Wrong libraries/frameworks: Missing version requirements
        - API contract violations: Missing endpoint specifications
        - Database schema conflicts: Missing requirements that could corrupt data
        - Security vulnerabilities: Missing security requirements
        - Performance disasters: Missing requirements that could cause failures
      </action>
      <action>Document each technical specification gap</action>
    </substep>

    <substep n="2c" title="File Structure Disasters">
      <action>Analyze for file structure issues:
        - Wrong file locations: Missing organization requirements
        - Coding standard violations: Missing conventions
        - Integration pattern breaks: Missing data flow requirements
        - Deployment failures: Missing environment requirements
      </action>
      <action>Document each file structure issue</action>
    </substep>

    <substep n="2d" title="Regression Disasters">
      <action>Analyze for regression risks:
        - Breaking changes: Missing requirements that could break existing functionality
        - Test failures: Missing test requirements
        - UX violations: Missing user experience requirements
        - Learning failures: Missing previous story context
      </action>
      <action>Document each regression risk</action>
    </substep>

    <substep n="2e" title="Implementation Disasters">
      <action>Analyze for implementation issues:
        - Vague implementations: Missing details that could lead to incorrect work
        - Completion lies: Missing acceptance criteria that could allow fake implementations
        - Scope creep: Missing boundaries that could cause unnecessary work
        - Quality failures: Missing quality requirements
      </action>
      <action>Document each implementation issue</action>
    </substep>
  </step>

  <step n="3" goal="LLM-Dev-Agent optimization analysis">
    <critical>CRITICAL: Optimize story context for LLM developer agent consumption</critical>

    <action>Analyze current story for LLM optimization issues:
      - Verbosity problems: Excessive detail that wastes tokens without adding value
      - Ambiguity issues: Vague instructions that could lead to multiple interpretations
      - Context overload: Too much information not directly relevant to implementation
      - Missing critical signals: Key requirements buried in verbose text
      - Poor structure: Information not organized for efficient LLM processing
    </action>

    <action>Apply LLM Optimization Principles:
      - Clarity over verbosity: Be precise and direct, eliminate fluff
      - Actionable instructions: Every sentence should guide implementation
      - Scannable structure: Clear headings, bullet points, and emphasis
      - Token efficiency: Pack maximum information into minimum text
      - Unambiguous language: Clear requirements with no room for interpretation
    </action>

    <action>Document each LLM optimization opportunity</action>
  </step>

  <step n="4" goal="Categorize and prioritize improvements">
    <action>Categorize all identified issues into:
      - critical_issues: Must fix - essential requirements, security, blocking issues
      - enhancements: Should add - helpful guidance, better specifications
      - optimizations: Nice to have - performance hints, development tips
      - llm_optimizations: Token efficiency and clarity improvements
    </action>

    <action>Count issues in each category:
      - {{critical_count}} critical issues
      - {{enhancement_count}} enhancements
      - {{optimization_count}} optimizations
      - {{llm_opt_count}} LLM optimizations
    </action>

    <action>Assign numbers to each issue for user selection</action>

    <substep n="4b" title="Calculate Evidence Score">
      <critical>🔥 CRITICAL: You MUST calculate and output the Evidence Score for synthesis!</critical>

      <action>Map each finding to Evidence Score severity:
        - **🔴 CRITICAL** (+3 points): Security vulnerabilities, data corruption risks, blocking issues, missing essential requirements
        - **🟠 IMPORTANT** (+1 point): Missing guidance, unclear specifications, integration risks
        - **🟡 MINOR** (+0.3 points): Typos, style issues, minor clarifications
      </action>

      <action>Count CLEAN PASS categories - areas with NO issues found:
        - Each clean category: -0.5 points
        - Categories to check: INVEST criteria (6), Acceptance Criteria, Dependencies, Technical Alignment, Implementation
      </action>

      <action>Calculate Evidence Score:
        {{evidence_score}} = SUM(finding_scores) + (clean_pass_count × -0.5)

        Example: 2 CRITICAL (+6) + 1 IMPORTANT (+1) + 4 CLEAN PASSES (-2) = 5.0
      </action>

      <action>Determine Evidence Verdict:
        - **EXCELLENT** (score ≤ -3): Many clean passes, minimal issues
        - **PASS** (score &lt; 3): Acceptable quality, minor issues only
        - **MAJOR REWORK** (3 ≤ score &lt; 7): Significant issues require attention
        - **REJECT** (score ≥ 7): Critical problems, needs complete rewrite
      </action>

      <action>Store for template output:
        - {{evidence_findings}}: List of findings with severity_icon, severity, description, source, score
        - {{clean_pass_count}}: Number of clean categories
        - {{evidence_score}}: Calculated total score
        - {{evidence_verdict}}: EXCELLENT/PASS/MAJOR REWORK/REJECT
      </action>
    </substep>
  </step>

  <step n="5" goal="Generate validation report">
    <critical>OUTPUT MARKERS REQUIRED: Your validation report MUST start with the marker <!-- VALIDATION_REPORT_START --> on its own line BEFORE the report header, and MUST end with the marker <!-- VALIDATION_REPORT_END --> on its own line AFTER the final line. The orchestrator extracts ONLY content between these markers. Any text outside the markers (thinking, commentary) will be discarded.</critical>

    <action>Use the output template below as a FORMAT GUIDE, replacing all {{placeholders}} with your actual analysis from the previous steps</action>
    <action>Output the complete validation report to stdout with all sections filled in based on your findings</action>
  </step>

</workflow></instructions>
<output-template><![CDATA[<!-- VALIDATION_REPORT_START -->

# 🎯 Story Context Validation Report

<!-- report_header -->

**Story:** {{story_key}} - {{story_title}}
**Story File:** {{story_file}}
**Validated:** {{date}}
**Validator:** Quality Competition Engine

---

<!-- executive_summary -->

## Executive Summary

### Issues Overview

| Category | Found | Applied |
|----------|-------|---------|
| 🚨 Critical Issues | {{critical_count}} | {{critical_applied}} |
| ⚡ Enhancements | {{enhancement_count}} | {{enhancements_applied}} |
| ✨ Optimizations | {{optimization_count}} | {{optimizations_applied}} |
| 🤖 LLM Optimizations | {{llm_opt_count}} | {{llm_opts_applied}} |

**Overall Assessment:** {{overall_assessment}}

---

<!-- evidence_score_summary -->

## Evidence Score Summary

| Severity | Description | Source | Score |
|----------|-------------|--------|-------|
{{#each evidence_findings}}
| {{severity_icon}} {{severity}} | {{description}} | {{source}} | +{{score}} |
{{/each}}
{{#if clean_pass_count}}
| 🟢 CLEAN PASS | {{clean_pass_count}} |
{{/if}}

### Evidence Score: {{evidence_score}}

| Score | Verdict |
|-------|---------|
| **{{evidence_score}}** | **{{evidence_verdict}}** |

---

<!-- story_quality_gate -->

## 🎯 Ruthless Story Validation {{epic_num}}.{{story_num}}

### INVEST Criteria Assessment

| Criterion | Status | Severity | Details |
|-----------|--------|----------|---------|
| **I**ndependent | {{invest_i_status}} | {{invest_i_severity}}/10 | {{invest_i_details}} |
| **N**egotiable | {{invest_n_status}} | {{invest_n_severity}}/10 | {{invest_n_details}} |
| **V**aluable | {{invest_v_status}} | {{invest_v_severity}}/10 | {{invest_v_details}} |
| **E**stimable | {{invest_e_status}} | {{invest_e_severity}}/10 | {{invest_e_details}} |
| **S**mall | {{invest_s_status}} | {{invest_s_severity}}/10 | {{invest_s_details}} |
| **T**estable | {{invest_t_status}} | {{invest_t_severity}}/10 | {{invest_t_details}} |

### INVEST Violations

{{#each invest_violations}}
- **[{{severity}}/10] {{criterion}}:** {{description}}
{{/each}}

{{#if no_invest_violations}}
✅ No significant INVEST violations detected.
{{/if}}

### Acceptance Criteria Issues

{{#each acceptance_criteria_issues}}
- **{{issue_type}}:** {{description}}
  - *Quote:* "{{quote}}"
  - *Recommendation:* {{recommendation}}
{{/each}}

{{#if no_acceptance_criteria_issues}}
✅ Acceptance criteria are well-defined and testable.
{{/if}}

### Hidden Risks & Dependencies

{{#each hidden_dependencies}}
- **{{dependency_type}}:** {{description}}
  - *Impact:* {{impact}}
  - *Mitigation:* {{mitigation}}
{{/each}}

{{#if no_hidden_dependencies}}
✅ No hidden dependencies or blockers identified.
{{/if}}

### Estimation Reality-Check

**Assessment:** {{estimation_assessment}}

{{estimation_details}}

### Technical Alignment

**Status:** {{technical_alignment_status}}

{{#each technical_alignment_issues}}
- **{{issue_type}}:** {{description}}
  - *Architecture Reference:* {{architecture_reference}}
  - *Recommendation:* {{recommendation}}
{{/each}}

{{#if no_technical_alignment_issues}}
✅ Story aligns with architecture.md patterns.
{{/if}}

### Evidence Score: {{evidence_score}} → {{evidence_verdict}}

---

<!-- critical_issues_section -->

## 🚨 Critical Issues (Must Fix)

These are essential requirements, security concerns, or blocking issues that could cause implementation disasters.

{{#each critical_issues}}
### {{number}}. {{title}}

**Impact:** {{impact}}
**Source:** {{source_reference}}

**Problem:**
{{problem_description}}

**Recommended Fix:**
{{recommended_fix}}

{{/each}}

{{#if no_critical_issues}}
✅ No critical issues found - the original story covered essential requirements.
{{/if}}

---

<!-- enhancements_section -->

## ⚡ Enhancement Opportunities (Should Add)

Additional guidance that would significantly help the developer avoid mistakes.

{{#each enhancements}}
### {{number}}. {{title}}

**Benefit:** {{benefit}}
**Source:** {{source_reference}}

**Current Gap:**
{{gap_description}}

**Suggested Addition:**
{{suggested_addition}}

{{/each}}

{{#if no_enhancements}}
✅ No significant enhancement opportunities identified.
{{/if}}

---

<!-- optimizations_section -->

## ✨ Optimizations (Nice to Have)

Performance hints, development tips, and additional context for complex scenarios.

{{#each optimizations}}
### {{number}}. {{title}}

**Value:** {{value}}

**Suggestion:**
{{suggestion}}

{{/each}}

{{#if no_optimizations}}
✅ No additional optimizations identified.
{{/if}}

---

<!-- llm_optimizations_section -->

## 🤖 LLM Optimization Improvements

Token efficiency and clarity improvements for better dev agent processing.

{{#each llm_optimizations}}
### {{number}}. {{title}}

**Issue:** {{issue_type}}
**Token Impact:** {{token_impact}}

**Current:**
```
{{current_text}}
```

**Optimized:**
```
{{optimized_text}}
```

**Rationale:** {{rationale}}

{{/each}}

{{#if no_llm_optimizations}}
✅ Story content is well-optimized for LLM processing.
{{/if}}

---

<!-- competition_results -->

## 🏆 Competition Results

### Quality Metrics

| Metric | Score |
|--------|-------|
| Requirements Coverage | {{requirements_coverage}}% |
| Architecture Alignment | {{architecture_alignment}}% |
| Previous Story Integration | {{previous_story_integration}}% |
| LLM Optimization Score | {{llm_optimization_score}}% |
| **Overall Quality Score** | **{{overall_quality_score}}%** |

### Disaster Prevention Assessment

{{#each disaster_categories}}
- **{{category}}:** {{status}} {{details}}
{{/each}}

### Competition Outcome

{{#if validator_won}}
🏆 **Validator identified {{total_issues}} improvements** that enhance the story context.
{{/if}}

{{#if original_won}}
✅ **Original create-story produced high-quality output** with minimal gaps identified.
{{/if}}

---

**Report Generated:** {{date}}
**Validation Engine:** BMAD Method Quality Competition v1.0

<!-- VALIDATION_REPORT_END -->]]></output-template>
</compiled-workflow>