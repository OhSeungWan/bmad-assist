# Epic Overview: Test Data Generator Library

## Summary

| Epic | Name | Stories | Priority | Status |
|------|------|---------|----------|--------|
| 1 | Core Generator | 5 | P0 | draft |
| 2 | Built-in Providers | 5 | P0 | draft |
| 3 | Schema Features | 4 | P1 | draft |
| 4 | Relational Data | 3 | P1 | draft |
| 5 | Output Formats | 3 | P1 | draft |

**Total Stories**: 20

## Epic Descriptions

### Epic 1: Core Generator

Foundation of the library including schema definition DSL, base generator class, seedable random state, record builder, and batch generation capabilities. This epic establishes the core architecture that all other features build upon.

**Key Deliverables**:
- `Schema` and `Field` classes for Python DSL
- `Generator` class with seedable random state
- Record builder producing dict records
- Batch generation API

### Epic 2: Built-in Providers

Implementation of data providers for common field types. Each provider generates realistic values for a specific data type (strings, numbers, dates, choices, addresses).

**Key Deliverables**:
- String providers (name, email, text, uuid)
- Number providers (int, float, decimal)
- Date/time providers
- Choice/enum providers with weights
- Address provider

### Epic 3: Schema Features

Extended schema capabilities including YAML parsing, field constraints, nullable fields, and unique value generation.

**Key Deliverables**:
- YAML schema parser
- Field constraints (min, max, pattern)
- Nullable field support
- Unique value generation

### Epic 4: Relational Data

Support for generating related records with foreign key relationships, including one-to-many relationships and handling of circular references.

**Key Deliverables**:
- Foreign key reference provider
- One-to-many record generation
- Circular reference detection and handling

### Epic 5: Output Formats

Export capabilities for generated data to JSON, CSV, and SQL INSERT statements with dialect support.

**Key Deliverables**:
- JSON output writer
- CSV output writer
- SQL INSERT statement generator with dialect support

## Dependencies

```
Epic 1: Core Generator (no dependencies)
    ↓
Epic 2: Built-in Providers (depends on Epic 1)
    ↓
Epic 3: Schema Features (depends on Epic 1)
    ↓
Epic 4: Relational Data (depends on Epics 1, 2)
    ↓
Epic 5: Output Formats (depends on Epic 1)
```

## Requirements Coverage

### Functional Requirements

| Requirement | Epic | Story |
|-------------|------|-------|
| FR-001: Python DSL schema | Epic 1 | 1.1 |
| FR-002: YAML schema | Epic 3 | 3.1 |
| FR-003: String fields | Epic 2 | 2.1 |
| FR-004: Number fields | Epic 2 | 2.2 |
| FR-005: Date fields | Epic 2 | 2.3 |
| FR-006: Choice fields | Epic 2 | 2.4 |
| FR-007: Related records | Epic 4 | 4.1, 4.2 |
| FR-008: Deterministic seeds | Epic 1 | 1.3 |
| FR-009: JSON output | Epic 5 | 5.1 |
| FR-010: CSV output | Epic 5 | 5.2 |
| FR-011: SQL output | Epic 5 | 5.3 |
| FR-012: Batch generation | Epic 1 | 1.5 |
| FR-013: Custom generators | Epic 1 | 1.2 |

### Non-Functional Requirements

| Requirement | Verified By |
|-------------|-------------|
| NFR-001: 10K records < 1s | Performance tests in Epic 1 |
| NFR-002: Consistent output | Determinism tests in Epic 1 |
| NFR-003: Type hints | Code review, mypy checks |
| NFR-004: 90%+ coverage | pytest-cov in CI |
| NFR-005: Zero core deps | Dependency audit |
| NFR-006: Pydantic optional | Integration tests |
