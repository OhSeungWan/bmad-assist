---
epic_num: 2
title: Built-in Providers
status: draft
---

# Epic 2: Built-in Providers

**Status**: draft
**Priority**: P0
**Stories**: 5

## Overview

This epic implements the data providers for common field types. Each provider generates realistic values for a specific data type, using the seedable random state established in Epic 1. Providers follow a common interface for consistency and extensibility.

## Stories

---

## Story 2.1: Implement String Providers

**Status:** draft
**Epic:** Built-in Providers
**Priority:** P0

## User Story

As a developer, I want to generate realistic string data like names, emails, and text so that my test data looks authentic and covers common use cases.

## Acceptance Criteria

1. **AC-2.1.1:** `name` provider generates realistic first and last name combinations
2. **AC-2.1.2:** `email` provider generates valid email addresses
3. **AC-2.1.3:** `text` provider generates lorem ipsum text with configurable length
4. **AC-2.1.4:** `uuid` provider generates valid UUID v4 strings
5. **AC-2.1.5:** All string providers use the shared random state for determinism

## Tasks

- [ ] Task 1: Create providers/strings.py module (AC: all)
  - [ ] Subtask 1.1: Create StringProvider base class
- [ ] Task 2: Implement NameProvider (AC: 1, 5)
  - [ ] Subtask 2.1: Create lists of first names and last names
  - [ ] Subtask 2.2: Implement generate() returning "FirstName LastName"
  - [ ] Subtask 2.3: Use rng.choice for selection
- [ ] Task 3: Implement EmailProvider (AC: 2, 5)
  - [ ] Subtask 3.1: Generate username from name or random string
  - [ ] Subtask 3.2: Add domain selection from common domains
  - [ ] Subtask 3.3: Support custom domain config option
- [ ] Task 4: Implement TextProvider (AC: 3, 5)
  - [ ] Subtask 4.1: Create lorem ipsum word list
  - [ ] Subtask 4.2: Accept max_length config parameter
  - [ ] Subtask 4.3: Generate sentences up to max_length
- [ ] Task 5: Implement UuidProvider (AC: 4, 5)
  - [ ] Subtask 5.1: Generate UUID v4 format using rng
  - [ ] Subtask 5.2: Ensure proper hyphenation and format
- [ ] Task 6: Register all providers in registry (AC: all)
- [ ] Task 7: Write comprehensive tests for each provider (AC: all)

## Technical Notes

- Name lists should have ~50 common first names and ~50 last names
- Email domains: example.com, test.com, mail.test (avoid real domains)
- UUID must use random state, not uuid.uuid4() which uses system random

## Dependencies

- Requires: Story 1.2 (Base Generator Class)

---

## Story 2.2: Implement Number Providers

**Status:** draft
**Epic:** Built-in Providers
**Priority:** P0

## User Story

As a developer, I want to generate numeric data with configurable ranges so that I can create test data for age, price, quantity, and other numeric fields.

## Acceptance Criteria

1. **AC-2.2.1:** `int` provider generates integers within optional min/max range
2. **AC-2.2.2:** `float` provider generates floats within optional min/max range
3. **AC-2.2.3:** `decimal` provider generates fixed-precision decimals with configurable precision
4. **AC-2.2.4:** Default ranges are sensible (0-100 for int, 0.0-1.0 for float)
5. **AC-2.2.5:** All number providers use shared random state

## Tasks

- [ ] Task 1: Create providers/numbers.py module (AC: all)
  - [ ] Subtask 1.1: Define default min/max constants
- [ ] Task 2: Implement IntProvider (AC: 1, 4, 5)
  - [ ] Subtask 2.1: Accept min/max config parameters
  - [ ] Subtask 2.2: Use rng.randint for generation
  - [ ] Subtask 2.3: Default to 0-100 range
- [ ] Task 3: Implement FloatProvider (AC: 2, 4, 5)
  - [ ] Subtask 3.1: Accept min/max config parameters
  - [ ] Subtask 3.2: Use rng.uniform for generation
  - [ ] Subtask 3.3: Default to 0.0-1.0 range
- [ ] Task 4: Implement DecimalProvider (AC: 3, 5)
  - [ ] Subtask 4.1: Accept min, max, precision config parameters
  - [ ] Subtask 4.2: Generate float and round to precision
  - [ ] Subtask 4.3: Return as Python Decimal type
- [ ] Task 5: Register providers and write tests (AC: all)
  - [ ] Subtask 5.1: Test range boundaries
  - [ ] Subtask 5.2: Test precision handling

## Technical Notes

- Decimal should use Python's decimal.Decimal for precision
- Float range validation: min < max
- Consider negative ranges support

## Dependencies

- Requires: Story 1.2 (Base Generator Class)

---

## Story 2.3: Implement Date/Time Providers

**Status:** draft
**Epic:** Built-in Providers
**Priority:** P0

## User Story

As a developer, I want to generate date and datetime values within configurable ranges so that I can create realistic temporal test data.

## Acceptance Criteria

1. **AC-2.3.1:** `date` provider generates date objects within start/end range
2. **AC-2.3.2:** `datetime` provider generates datetime objects within start/end range
3. **AC-2.3.3:** `time` provider generates random time-of-day values
4. **AC-2.3.4:** Start/end can be specified as strings (ISO format) or date objects
5. **AC-2.3.5:** Default range is year 2020 to current date

## Tasks

- [ ] Task 1: Create providers/dates.py module (AC: all)
  - [ ] Subtask 1.1: Import datetime module
  - [ ] Subtask 1.2: Create date parsing utility for string inputs
- [ ] Task 2: Implement DateProvider (AC: 1, 4, 5)
  - [ ] Subtask 2.1: Accept start/end config parameters
  - [ ] Subtask 2.2: Parse string dates to date objects
  - [ ] Subtask 2.3: Generate random date in range using ordinal
  - [ ] Subtask 2.4: Return datetime.date object
- [ ] Task 3: Implement DatetimeProvider (AC: 2, 4, 5)
  - [ ] Subtask 3.1: Accept start/end config parameters
  - [ ] Subtask 3.2: Parse string datetimes
  - [ ] Subtask 3.3: Generate random timestamp in range
  - [ ] Subtask 3.4: Return datetime.datetime object
- [ ] Task 4: Implement TimeProvider (AC: 3)
  - [ ] Subtask 4.1: Generate random hour, minute, second
  - [ ] Subtask 4.2: Return datetime.time object
- [ ] Task 5: Register providers and write tests (AC: all)
  - [ ] Subtask 5.1: Test date range boundaries
  - [ ] Subtask 5.2: Test string parsing

## Technical Notes

- Use ISO 8601 format for string parsing: "YYYY-MM-DD" or "YYYY-MM-DD HH:MM:SS"
- Generate random ordinal/timestamp and convert to date/datetime
- Timezone handling: naive datetimes (no timezone) for simplicity

## Dependencies

- Requires: Story 1.2 (Base Generator Class)

---

## Story 2.4: Implement Choice Provider

**Status:** draft
**Epic:** Built-in Providers
**Priority:** P0

## User Story

As a developer, I want to generate values from a predefined list of choices so that I can create test data for enum fields, status codes, and categories.

## Acceptance Criteria

1. **AC-2.4.1:** `choice` provider selects randomly from provided choices list
2. **AC-2.4.2:** Supports weighted random selection with weights parameter
3. **AC-2.4.3:** Equal weights are used when weights not specified
4. **AC-2.4.4:** Raises error if choices list is empty
5. **AC-2.4.5:** Works with any hashable choice values (strings, ints, enums)

## Tasks

- [ ] Task 1: Create providers/choices.py module (AC: all)
- [ ] Task 2: Implement ChoiceProvider (AC: 1, 3, 5)
  - [ ] Subtask 2.1: Accept choices config parameter
  - [ ] Subtask 2.2: Use rng.choice for unweighted selection
  - [ ] Subtask 2.3: Validate choices is non-empty
- [ ] Task 3: Add weighted selection support (AC: 2)
  - [ ] Subtask 3.1: Accept weights config parameter
  - [ ] Subtask 3.2: Use rng.choices with weights for weighted selection
  - [ ] Subtask 3.3: Validate weights length matches choices length
- [ ] Task 4: Add error handling (AC: 4)
  - [ ] Subtask 4.1: Raise ProviderError for empty choices
  - [ ] Subtask 4.2: Raise ProviderError for mismatched weights
- [ ] Task 5: Register provider and write tests (AC: all)
  - [ ] Subtask 5.1: Test uniform distribution without weights
  - [ ] Subtask 5.2: Test weighted distribution
  - [ ] Subtask 5.3: Test error cases

## Technical Notes

- Use random.choices() for weighted selection (Python 3.6+)
- Weight values are relative (e.g., [1, 2, 1] means middle is 2x likely)
- Distribution tests should use large sample sizes for statistical validity

## Dependencies

- Requires: Story 1.2 (Base Generator Class)

---

## Story 2.5: Implement Address Provider

**Status:** draft
**Epic:** Built-in Providers
**Priority:** P0

## User Story

As a developer, I want to generate realistic address data so that I can create test data for user profiles, shipping, and location-based features.

## Acceptance Criteria

1. **AC-2.5.1:** `address` provider generates complete street addresses
2. **AC-2.5.2:** Address includes street number, street name, and street type
3. **AC-2.5.3:** Optionally generates city, state, and zip code
4. **AC-2.5.4:** Uses US-style addresses (no i18n requirement)
5. **AC-2.5.5:** Components are configurable (full address or parts only)

## Tasks

- [ ] Task 1: Create address data lists (AC: 2, 4)
  - [ ] Subtask 1.1: Create street name list (50+ names)
  - [ ] Subtask 1.2: Create street type list (St, Ave, Blvd, etc.)
  - [ ] Subtask 1.3: Create city name list (50+ cities)
  - [ ] Subtask 1.4: Create state abbreviation list
- [ ] Task 2: Implement AddressProvider (AC: 1, 2, 5)
  - [ ] Subtask 2.1: Generate street number (random int 1-9999)
  - [ ] Subtask 2.2: Generate street name and type
  - [ ] Subtask 2.3: Combine into full street address
- [ ] Task 3: Add optional components (AC: 3, 5)
  - [ ] Subtask 3.1: Accept include_city, include_state, include_zip config
  - [ ] Subtask 3.2: Generate city name from list
  - [ ] Subtask 3.3: Generate state from list
  - [ ] Subtask 3.4: Generate zip code (5 digit random)
- [ ] Task 4: Register provider and write tests (AC: all)
  - [ ] Subtask 4.1: Test full address format
  - [ ] Subtask 4.2: Test component options

## Technical Notes

- Full address format: "123 Oak Street, Springfield, IL 12345"
- Street types: Street, Avenue, Boulevard, Lane, Drive, Court, Place
- Zip codes: 5 digits, 00000-99999 range (not validated against real zips)

## Dependencies

- Requires: Story 1.2 (Base Generator Class)
