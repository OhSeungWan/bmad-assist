---
epic_num: 1
title: Core Generator
status: draft
---

# Epic 1: Core Generator

**Status**: draft
**Priority**: P0
**Stories**: 5

## Overview

This epic establishes the foundation of the Test Data Generator library. It includes the schema definition DSL, base generator class with seedable random state, record builder, and batch generation capabilities. All subsequent epics depend on this core infrastructure.

## Stories

---

## Story 1.1: Create Schema Definition DSL

**Status:** draft
**Epic:** Core Generator
**Priority:** P0

## User Story

As a developer, I want to define data schemas using Python classes so that I can specify the structure of test data with full IDE support and type safety.

## Acceptance Criteria

1. **AC-1.1.1:** `Schema` class accepts a name and variable number of `Field` objects
2. **AC-1.1.2:** `Field` class accepts name, type, and optional keyword configuration
3. **AC-1.1.3:** Schema and Field are importable from `testdatagen` package root
4. **AC-1.1.4:** Schema provides `fields` property returning list of Field objects
5. **AC-1.1.5:** Both classes are fully type-hinted with mypy passing strict mode

## Tasks

- [ ] Task 1: Create `schema.py` module with Schema class (AC: 1, 3, 4)
  - [ ] Subtask 1.1: Implement Schema.__init__ accepting name and *fields
  - [ ] Subtask 1.2: Add fields property returning list
  - [ ] Subtask 1.3: Add __repr__ for debugging
- [ ] Task 2: Implement Field class in schema.py (AC: 2, 5)
  - [ ] Subtask 2.1: Implement Field.__init__ with name, type, **config
  - [ ] Subtask 2.2: Add config property for accessing field configuration
  - [ ] Subtask 2.3: Add type hints for all attributes
- [ ] Task 3: Export classes from package __init__.py (AC: 3)
- [ ] Task 4: Write unit tests for Schema and Field (AC: all)
  - [ ] Subtask 4.1: Test schema creation with multiple fields
  - [ ] Subtask 4.2: Test field configuration access
  - [ ] Subtask 4.3: Verify type hints with mypy

## Technical Notes

- Schema name is used for output table/collection naming
- Field type is a string matching provider names (validated at generation time)
- Config uses **kwargs for flexibility with different provider options

## Dependencies

- Requires: None

---

## Story 1.2: Implement Base Generator Class

**Status:** draft
**Epic:** Core Generator
**Priority:** P0

## User Story

As a developer, I want a generator class that coordinates data generation so that I can produce records from schemas with extensible provider support.

## Acceptance Criteria

1. **AC-1.2.1:** `Generator` class accepts schema and optional seed
2. **AC-1.2.2:** Generator uses a provider registry to resolve field types to providers
3. **AC-1.2.3:** `register_provider` function allows adding custom providers
4. **AC-1.2.4:** Generator raises `ProviderError` for unknown field types
5. **AC-1.2.5:** Built-in providers are auto-registered on module import

## Tasks

- [ ] Task 1: Create `generator.py` module with Generator class (AC: 1)
  - [ ] Subtask 1.1: Implement Generator.__init__ with schema and seed
  - [ ] Subtask 1.2: Create internal random.Random instance with seed
- [ ] Task 2: Implement provider registry in providers/__init__.py (AC: 2, 3, 5)
  - [ ] Subtask 2.1: Create _registry dict for provider classes
  - [ ] Subtask 2.2: Implement register_provider function
  - [ ] Subtask 2.3: Implement get_provider function with error handling
  - [ ] Subtask 2.4: Auto-register built-in providers on import
- [ ] Task 3: Add error handling for unknown providers (AC: 4)
  - [ ] Subtask 3.1: Create ProviderError exception class
  - [ ] Subtask 3.2: Raise ProviderError in get_provider for unknown types
- [ ] Task 4: Write tests for generator and registry (AC: all)

## Technical Notes

- Provider registry is module-level dict mapping type names to provider classes
- Generator instantiates providers lazily on first record generation
- random.Random instance is passed to providers for determinism

## Dependencies

- Requires: Story 1.1

---

## Story 1.3: Add Seedable Random State

**Status:** draft
**Epic:** Core Generator
**Priority:** P0

## User Story

As a test engineer, I want to specify a random seed so that I can reproduce the exact same test data across multiple runs.

## Acceptance Criteria

1. **AC-1.3.1:** Generator accepts optional `seed` parameter
2. **AC-1.3.2:** Same seed produces identical output across runs
3. **AC-1.3.3:** Different seeds produce different output
4. **AC-1.3.4:** No seed (None) produces random output each run
5. **AC-1.3.5:** Seed is propagated to all providers consistently

## Tasks

- [ ] Task 1: Implement seed handling in Generator (AC: 1, 4, 5)
  - [ ] Subtask 1.1: Create random.Random instance with seed
  - [ ] Subtask 1.2: Pass random instance to provider constructors
  - [ ] Subtask 1.3: Handle None seed for random behavior
- [ ] Task 2: Update BaseProvider to accept random instance (AC: 5)
  - [ ] Subtask 2.1: Add rng parameter to BaseProvider.__init__
  - [ ] Subtask 2.2: Store rng as instance attribute
- [ ] Task 3: Write determinism tests (AC: 2, 3)
  - [ ] Subtask 3.1: Test same seed produces same output
  - [ ] Subtask 3.2: Test different seeds produce different output
  - [ ] Subtask 3.3: Test None seed produces varying output

## Technical Notes

- Use random.Random class, not module-level random functions
- Each Generator gets its own Random instance to avoid global state
- Determinism tests should compare full record lists, not just first record

## Dependencies

- Requires: Story 1.2

---

## Story 1.4: Create Record Builder

**Status:** draft
**Epic:** Core Generator
**Priority:** P0

## User Story

As a developer, I want the generator to produce dictionary records so that I can easily work with generated data in Python.

## Acceptance Criteria

1. **AC-1.4.1:** Generator produces dict records with field names as keys
2. **AC-1.4.2:** Each field value is generated by its configured provider
3. **AC-1.4.3:** Single record generation via `generate_one()` method
4. **AC-1.4.4:** Records are generated lazily using iterator pattern
5. **AC-1.4.5:** Field order in dict matches field definition order

## Tasks

- [ ] Task 1: Implement record building in Generator (AC: 1, 2, 5)
  - [ ] Subtask 1.1: Create _build_record method
  - [ ] Subtask 1.2: Iterate fields and call provider.generate()
  - [ ] Subtask 1.3: Return dict with field names as keys
- [ ] Task 2: Add generate_one() method (AC: 3)
  - [ ] Subtask 2.1: Implement method returning single dict
- [ ] Task 3: Implement lazy iteration (AC: 4)
  - [ ] Subtask 3.1: Add __iter__ method to Generator
  - [ ] Subtask 3.2: Yield records on demand
- [ ] Task 4: Write tests for record generation (AC: all)
  - [ ] Subtask 4.1: Test single record structure
  - [ ] Subtask 4.2: Test field order preservation
  - [ ] Subtask 4.3: Test lazy iteration behavior

## Technical Notes

- Providers are instantiated once and reused for all records
- Field order uses Python dict insertion order (Python 3.7+)
- Lazy iteration enables memory-efficient large dataset generation

## Dependencies

- Requires: Story 1.3

---

## Story 1.5: Add Batch Generation

**Status:** draft
**Epic:** Core Generator
**Priority:** P0

## User Story

As a developer, I want to generate a specific number of records in one call so that I can quickly create test datasets of known sizes.

## Acceptance Criteria

1. **AC-1.5.1:** `generate()` function accepts schema, count, and optional seed
2. **AC-1.5.2:** Returns `RecordSet` object containing generated records
3. **AC-1.5.3:** RecordSet is iterable and provides `to_list()` method
4. **AC-1.5.4:** Generation of 10,000 records completes in under 1 second
5. **AC-1.5.5:** Count of 0 returns empty RecordSet

## Tasks

- [ ] Task 1: Create generate() function in generator.py (AC: 1)
  - [ ] Subtask 1.1: Accept schema, count, seed parameters
  - [ ] Subtask 1.2: Create Generator instance internally
  - [ ] Subtask 1.3: Return RecordSet wrapping generator
- [ ] Task 2: Implement RecordSet class (AC: 2, 3, 5)
  - [ ] Subtask 2.1: Store schema and record iterator
  - [ ] Subtask 2.2: Implement __iter__ for iteration
  - [ ] Subtask 2.3: Implement to_list() with caching
  - [ ] Subtask 2.4: Implement __len__ using cached list
- [ ] Task 3: Add performance tests (AC: 4)
  - [ ] Subtask 3.1: Benchmark 10K record generation
  - [ ] Subtask 3.2: Assert completion under 1 second
- [ ] Task 4: Export generate and RecordSet from package (AC: all)

## Technical Notes

- RecordSet caches list on first to_list() call to avoid re-generation
- Performance test should use simple schema (int field only) for baseline
- Consider using time.perf_counter for accurate timing

## Dependencies

- Requires: Story 1.4
