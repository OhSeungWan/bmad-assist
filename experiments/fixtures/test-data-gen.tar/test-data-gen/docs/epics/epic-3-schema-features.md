---
epic_num: 3
title: Schema Features
status: draft
---

# Epic 3: Schema Features

**Status**: draft
**Priority**: P1
**Stories**: 4

## Overview

This epic extends schema capabilities with YAML parsing support, field constraints, nullable fields, and unique value generation. These features enable more complex and realistic data generation scenarios.

## Stories

---

## Story 3.1: Add YAML Schema Parser

**Status:** draft
**Epic:** Schema Features
**Priority:** P1

## User Story

As a developer, I want to define schemas in YAML files so that I can share schema definitions without Python code and configure them externally.

## Acceptance Criteria

1. **AC-3.1.1:** `load_schema()` function parses YAML file into Schema object
2. **AC-3.1.2:** YAML structure supports schema name and fields list
3. **AC-3.1.3:** Field definitions in YAML map to Field objects with all config options
4. **AC-3.1.4:** Parser raises `SchemaError` for invalid YAML structure
5. **AC-3.1.5:** YAML schema produces identical results to equivalent Python DSL

## Tasks

- [ ] Task 1: Create parsers/yaml.py module (AC: 1)
  - [ ] Subtask 1.1: Import yaml (pyyaml dependency)
  - [ ] Subtask 1.2: Create load_schema function accepting file path
- [ ] Task 2: Implement YAML parsing logic (AC: 2, 3)
  - [ ] Subtask 2.1: Load and parse YAML file
  - [ ] Subtask 2.2: Extract schema name from 'name' key
  - [ ] Subtask 2.3: Iterate 'fields' list creating Field objects
  - [ ] Subtask 2.4: Map YAML field keys to Field config kwargs
- [ ] Task 3: Add validation and error handling (AC: 4)
  - [ ] Subtask 3.1: Validate required 'name' key exists
  - [ ] Subtask 3.2: Validate 'fields' is a list
  - [ ] Subtask 3.3: Validate each field has 'name' and 'type' keys
  - [ ] Subtask 3.4: Raise SchemaError with descriptive messages
- [ ] Task 4: Export load_schema from package root (AC: 1)
- [ ] Task 5: Write tests comparing YAML and Python DSL (AC: 5)
  - [ ] Subtask 5.1: Create equivalent YAML and Python schemas
  - [ ] Subtask 5.2: Generate data from both, compare output
  - [ ] Subtask 5.3: Test error cases

## Technical Notes

- YAML structure matches spec example in architecture.md
- PyYAML is an optional dependency; import error should be descriptive
- Schema name comes from 'schema.name' in YAML

## Dependencies

- Requires: Story 1.1 (Schema Definition DSL)

---

## Story 3.2: Implement Field Constraints

**Status:** draft
**Epic:** Schema Features
**Priority:** P1

## User Story

As a developer, I want to specify constraints on fields like min/max values and patterns so that generated data meets my validation requirements.

## Acceptance Criteria

1. **AC-3.2.1:** Field accepts min/max constraints for numeric types
2. **AC-3.2.2:** Field accepts max_length constraint for string types
3. **AC-3.2.3:** Field accepts pattern constraint for regex matching
4. **AC-3.2.4:** Constraints are passed to providers and enforced during generation
5. **AC-3.2.5:** Invalid constraint combinations raise SchemaError at schema creation

## Tasks

- [ ] Task 1: Extend Field class with constraint attributes (AC: 1, 2, 3)
  - [ ] Subtask 1.1: Add min, max optional parameters
  - [ ] Subtask 1.2: Add max_length optional parameter
  - [ ] Subtask 1.3: Add pattern optional parameter
- [ ] Task 2: Pass constraints to providers (AC: 4)
  - [ ] Subtask 2.1: Include constraints in provider config dict
  - [ ] Subtask 2.2: Update providers to use constraints
- [ ] Task 3: Add constraint validation (AC: 5)
  - [ ] Subtask 3.1: Validate min <= max when both specified
  - [ ] Subtask 3.2: Validate max_length > 0
  - [ ] Subtask 3.3: Validate pattern is valid regex
  - [ ] Subtask 3.4: Raise SchemaError for invalid constraints
- [ ] Task 4: Write constraint tests (AC: all)
  - [ ] Subtask 4.1: Test numeric min/max enforcement
  - [ ] Subtask 4.2: Test string max_length enforcement
  - [ ] Subtask 4.3: Test pattern matching
  - [ ] Subtask 4.4: Test validation errors

## Technical Notes

- Pattern constraint uses regex for validation, not generation
- Pattern-based generation is complex; consider validation-only approach
- For pattern requirement, generate then validate, retry if needed

## Dependencies

- Requires: Story 1.1, Epic 2 (Built-in Providers)

---

## Story 3.3: Add Nullable Field Support

**Status:** draft
**Epic:** Schema Features
**Priority:** P1

## User Story

As a developer, I want to specify that fields can be null so that I can generate realistic data that includes missing values.

## Acceptance Criteria

1. **AC-3.3.1:** Field accepts `nullable=True` parameter
2. **AC-3.3.2:** Nullable fields randomly generate None based on null_probability
3. **AC-3.3.3:** Default null_probability is 0.1 (10% null values)
4. **AC-3.3.4:** null_probability is configurable per field (0.0 to 1.0)
5. **AC-3.3.5:** Non-nullable fields never generate None

## Tasks

- [ ] Task 1: Extend Field class with nullable support (AC: 1, 4)
  - [ ] Subtask 1.1: Add nullable boolean parameter (default False)
  - [ ] Subtask 1.2: Add null_probability float parameter (default 0.1)
  - [ ] Subtask 1.3: Validate null_probability is 0.0 to 1.0
- [ ] Task 2: Implement null generation in Generator (AC: 2, 3, 5)
  - [ ] Subtask 2.1: Check nullable flag before generating
  - [ ] Subtask 2.2: Use rng.random() < null_probability to decide
  - [ ] Subtask 2.3: Return None if null, otherwise call provider
- [ ] Task 3: Update YAML parser for nullable fields (AC: 1)
  - [ ] Subtask 3.1: Parse 'nullable' key from YAML
  - [ ] Subtask 3.2: Parse 'null_probability' key from YAML
- [ ] Task 4: Write nullable field tests (AC: all)
  - [ ] Subtask 4.1: Test null probability distribution
  - [ ] Subtask 4.2: Test non-nullable fields never null
  - [ ] Subtask 4.3: Test custom null_probability

## Technical Notes

- Distribution test: generate 1000 records, check null ratio is ~expected
- Use tolerance for probability tests (e.g., 10% ± 3%)
- Null check happens in Generator, not in individual providers

## Dependencies

- Requires: Story 1.4 (Record Builder)

---

## Story 3.4: Implement Unique Value Generation

**Status:** draft
**Epic:** Schema Features
**Priority:** P1

## User Story

As a developer, I want to specify that field values must be unique so that I can generate data for primary keys and other unique constraints.

## Acceptance Criteria

1. **AC-3.4.1:** Field accepts `unique=True` parameter
2. **AC-3.4.2:** Unique fields never repeat values within a generation run
3. **AC-3.4.3:** Generator tracks seen values per unique field
4. **AC-3.4.4:** Raises error if unique values exhausted (e.g., 1000 ints in 0-100 range)
5. **AC-3.4.5:** UUID and sequential int types are inherently unique-friendly

## Tasks

- [ ] Task 1: Extend Field class with unique support (AC: 1)
  - [ ] Subtask 1.1: Add unique boolean parameter (default False)
- [ ] Task 2: Track unique values in Generator (AC: 2, 3)
  - [ ] Subtask 2.1: Create _seen dict mapping field name to set of values
  - [ ] Subtask 2.2: After generating value, check if in seen set
  - [ ] Subtask 2.3: If seen, regenerate (with retry limit)
  - [ ] Subtask 2.4: Add value to seen set after successful generation
- [ ] Task 3: Handle exhaustion case (AC: 4)
  - [ ] Subtask 3.1: Track retry count per generation attempt
  - [ ] Subtask 3.2: After N retries (e.g., 100), raise UniqueExhaustedError
  - [ ] Subtask 3.3: Include field name and constraints in error message
- [ ] Task 4: Optimize for unique-friendly types (AC: 5)
  - [ ] Subtask 4.1: UUID provider generates guaranteed unique values
  - [ ] Subtask 4.2: Consider sequential int provider for unique needs
- [ ] Task 5: Write unique constraint tests (AC: all)
  - [ ] Subtask 5.1: Test uniqueness over 100 records
  - [ ] Subtask 5.2: Test exhaustion error
  - [ ] Subtask 5.3: Test UUID inherent uniqueness

## Technical Notes

- Use set for O(1) lookup of seen values
- Retry limit prevents infinite loop on constrained ranges
- Consider warning when nearing exhaustion threshold

## Dependencies

- Requires: Story 1.4 (Record Builder), Story 3.2 (Field Constraints)
