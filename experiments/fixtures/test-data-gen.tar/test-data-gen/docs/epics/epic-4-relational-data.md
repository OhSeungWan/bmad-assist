---
epic_num: 4
title: Relational Data
status: draft
---

# Epic 4: Relational Data

**Status**: draft
**Priority**: P1
**Stories**: 3

## Overview

This epic enables generation of related records with foreign key relationships. It supports referencing values from other schemas, generating one-to-many relationships, and handling circular references gracefully.

## Stories

---

## Story 4.1: Add Foreign Key Reference Support

**Status:** draft
**Epic:** Relational Data
**Priority:** P1

## User Story

As a developer, I want to generate fields that reference values from another schema so that I can create realistic relational test data.

## Acceptance Criteria

1. **AC-4.1.1:** `ref` provider type references a field from another schema
2. **AC-4.1.2:** Reference syntax is `schema_name.field_name` in config
3. **AC-4.1.3:** Referenced schema must be generated before referencing schema
4. **AC-4.1.4:** Provider randomly selects from existing referenced values
5. **AC-4.1.5:** Raises error if referenced schema has no records

## Tasks

- [ ] Task 1: Create providers/refs.py module (AC: 1)
  - [ ] Subtask 1.1: Create RefProvider class extending BaseProvider
  - [ ] Subtask 1.2: Accept ref config parameter
- [ ] Task 2: Implement reference resolution (AC: 2, 4)
  - [ ] Subtask 2.1: Parse schema_name.field_name from ref string
  - [ ] Subtask 2.2: Access generated records from context
  - [ ] Subtask 2.3: Extract referenced field values
  - [ ] Subtask 2.4: Use rng.choice to select random value
- [ ] Task 3: Add generation context (AC: 3)
  - [ ] Subtask 3.1: Create GenerationContext class
  - [ ] Subtask 3.2: Store generated records by schema name
  - [ ] Subtask 3.3: Pass context to Generator and providers
- [ ] Task 4: Handle error cases (AC: 5)
  - [ ] Subtask 4.1: Raise error if referenced schema not in context
  - [ ] Subtask 4.2: Raise error if referenced field not in schema
  - [ ] Subtask 4.3: Raise error if referenced records list is empty
- [ ] Task 5: Write reference tests (AC: all)
  - [ ] Subtask 5.1: Test basic reference generation
  - [ ] Subtask 5.2: Test all generated refs exist in source
  - [ ] Subtask 5.3: Test error cases

## Technical Notes

- GenerationContext is a dict-like object mapping schema names to RecordSets
- Context is passed through Generator to RefProvider
- Consider lazy evaluation if referenced schema not yet generated

## Dependencies

- Requires: Story 1.5 (Batch Generation), Epic 2 (Built-in Providers)

---

## Story 4.2: Implement One-to-Many Generation

**Status:** draft
**Epic:** Relational Data
**Priority:** P1

## User Story

As a developer, I want to generate child records for each parent record so that I can create realistic one-to-many relationships like orders with order items.

## Acceptance Criteria

1. **AC-4.2.1:** `generate_related()` function generates child records for parent schema
2. **AC-4.2.2:** Accepts parent schema, child schema, and relationship config
3. **AC-4.2.3:** Configurable number of children per parent (fixed or range)
4. **AC-4.2.4:** Child records automatically get parent's ID in foreign key field
5. **AC-4.2.5:** Returns combined RecordSet with all child records

## Tasks

- [ ] Task 1: Create generate_related function (AC: 1, 2)
  - [ ] Subtask 1.1: Accept parent_records, child_schema, fk_field parameters
  - [ ] Subtask 1.2: Accept children_per_parent config (int or tuple range)
- [ ] Task 2: Implement relationship generation (AC: 3, 4)
  - [ ] Subtask 2.1: Iterate parent records
  - [ ] Subtask 2.2: Determine child count (fixed or rng.randint range)
  - [ ] Subtask 2.3: Generate child records for each parent
  - [ ] Subtask 2.4: Inject parent ID into fk_field of each child
- [ ] Task 3: Build combined output (AC: 5)
  - [ ] Subtask 3.1: Collect all child records
  - [ ] Subtask 3.2: Return as RecordSet
  - [ ] Subtask 3.3: Maintain determinism with seed
- [ ] Task 4: Write one-to-many tests (AC: all)
  - [ ] Subtask 4.1: Test fixed children per parent
  - [ ] Subtask 4.2: Test range of children per parent
  - [ ] Subtask 4.3: Verify FK values match parent IDs

## Technical Notes

- children_per_parent can be int (fixed) or (min, max) tuple
- FK field should be string name matching child schema field
- Parent ID field defaults to 'id' but should be configurable

## Dependencies

- Requires: Story 4.1 (Foreign Key Reference Support)

---

## Story 4.3: Add Circular Reference Handling

**Status:** draft
**Epic:** Relational Data
**Priority:** P2

## User Story

As a developer, I want the generator to detect and handle circular references so that I can safely define schemas that reference each other.

## Acceptance Criteria

1. **AC-4.3.1:** Generator detects circular references between schemas
2. **AC-4.3.2:** Circular references raise `CircularReferenceError` by default
3. **AC-4.3.3:** Optional `allow_circular=True` enables deferred reference resolution
4. **AC-4.3.4:** Deferred resolution uses None initially, fills in after all records generated
5. **AC-4.3.5:** Error message clearly identifies the circular reference chain

## Tasks

- [ ] Task 1: Implement circular reference detection (AC: 1, 5)
  - [ ] Subtask 1.1: Build dependency graph from schema references
  - [ ] Subtask 1.2: Detect cycles using topological sort or DFS
  - [ ] Subtask 1.3: Generate descriptive error with cycle path
- [ ] Task 2: Add CircularReferenceError (AC: 2)
  - [ ] Subtask 2.1: Create exception class in exceptions.py
  - [ ] Subtask 2.2: Include cycle path in exception message
- [ ] Task 3: Implement deferred resolution (AC: 3, 4)
  - [ ] Subtask 3.1: Add allow_circular parameter to generate
  - [ ] Subtask 3.2: Mark circular ref fields with placeholder
  - [ ] Subtask 3.3: After all schemas generated, resolve placeholders
  - [ ] Subtask 3.4: Fill placeholders with random valid references
- [ ] Task 4: Write circular reference tests (AC: all)
  - [ ] Subtask 4.1: Test error raised for simple A->B->A cycle
  - [ ] Subtask 4.2: Test allow_circular resolves correctly
  - [ ] Subtask 4.3: Test error message includes full path

## Technical Notes

- Simple cycle: users.manager_id -> users.id (self-reference)
- Complex cycle: orders.user_id -> users.id, users.last_order_id -> orders.id
- Deferred resolution requires two-pass generation

## Dependencies

- Requires: Story 4.1 (Foreign Key Reference Support)
