---
epic_num: 5
title: Output Formats
status: draft
---

# Epic 5: Output Formats

**Status**: draft
**Priority**: P1
**Stories**: 3

## Overview

This epic implements export capabilities for generated data. It provides writers for JSON, CSV, and SQL INSERT statement formats, enabling users to easily use generated data in various testing and development scenarios.

## Stories

---

## Story 5.1: Implement JSON Output

**Status:** draft
**Epic:** Output Formats
**Priority:** P1

## User Story

As a developer, I want to export generated data to JSON format so that I can use it with APIs, JavaScript applications, and data processing pipelines.

## Acceptance Criteria

1. **AC-5.1.1:** `RecordSet.to_json()` writes records to JSON file
2. **AC-5.1.2:** Output is a JSON array of objects
3. **AC-5.1.3:** Supports optional indent parameter for pretty printing
4. **AC-5.1.4:** Handles datetime objects by converting to ISO format strings
5. **AC-5.1.5:** Supports writing to file path or returning string

## Tasks

- [ ] Task 1: Create output/json.py module (AC: 1)
  - [ ] Subtask 1.1: Create JsonWriter class
  - [ ] Subtask 1.2: Accept records iterator in constructor
- [ ] Task 2: Implement JSON serialization (AC: 2, 3, 4)
  - [ ] Subtask 2.1: Convert records to list if needed
  - [ ] Subtask 2.2: Create custom JSONEncoder for datetime
  - [ ] Subtask 2.3: Handle Decimal conversion to float/string
  - [ ] Subtask 2.4: Support indent parameter
- [ ] Task 3: Add file and string output (AC: 5)
  - [ ] Subtask 3.1: Implement write(path) method for file output
  - [ ] Subtask 3.2: Implement to_string() method for string output
  - [ ] Subtask 3.3: Use utf-8 encoding for file output
- [ ] Task 4: Add to_json to RecordSet (AC: 1)
  - [ ] Subtask 4.1: Create to_json method on RecordSet
  - [ ] Subtask 4.2: Accept file_path and indent parameters
  - [ ] Subtask 4.3: Return string if no path provided
- [ ] Task 5: Write JSON output tests (AC: all)
  - [ ] Subtask 5.1: Test file output
  - [ ] Subtask 5.2: Test string output
  - [ ] Subtask 5.3: Test datetime serialization
  - [ ] Subtask 5.4: Test pretty print with indent

## Technical Notes

- Use json.dump for file, json.dumps for string
- Custom encoder handles datetime, date, time, Decimal, UUID
- ISO format for dates: YYYY-MM-DDTHH:MM:SS

## Dependencies

- Requires: Story 1.5 (Batch Generation)

---

## Story 5.2: Implement CSV Output

**Status:** draft
**Epic:** Output Formats
**Priority:** P1

## User Story

As a data analyst, I want to export generated data to CSV format so that I can import it into spreadsheets, databases, and data analysis tools.

## Acceptance Criteria

1. **AC-5.2.1:** `RecordSet.to_csv()` writes records to CSV file
2. **AC-5.2.2:** First row contains column headers from field names
3. **AC-5.2.3:** Supports configurable delimiter (default comma)
4. **AC-5.2.4:** Properly escapes values containing delimiter or quotes
5. **AC-5.2.5:** Handles None values as empty strings

## Tasks

- [ ] Task 1: Create output/csv.py module (AC: 1)
  - [ ] Subtask 1.1: Create CsvWriter class
  - [ ] Subtask 1.2: Accept records iterator and schema in constructor
- [ ] Task 2: Implement CSV writing (AC: 2, 3, 4)
  - [ ] Subtask 2.1: Extract field names from schema for headers
  - [ ] Subtask 2.2: Use csv.writer with configurable delimiter
  - [ ] Subtask 2.3: Configure quoting for proper escaping
- [ ] Task 3: Handle special values (AC: 5)
  - [ ] Subtask 3.1: Convert None to empty string
  - [ ] Subtask 3.2: Convert datetime to string representation
  - [ ] Subtask 3.3: Convert Decimal to string
- [ ] Task 4: Add to_csv to RecordSet (AC: 1)
  - [ ] Subtask 4.1: Create to_csv method on RecordSet
  - [ ] Subtask 4.2: Accept file_path and delimiter parameters
  - [ ] Subtask 4.3: Return string if no path provided
- [ ] Task 5: Write CSV output tests (AC: all)
  - [ ] Subtask 5.1: Test file output with headers
  - [ ] Subtask 5.2: Test delimiter configuration
  - [ ] Subtask 5.3: Test escaping special characters
  - [ ] Subtask 5.4: Test None handling

## Technical Notes

- Use Python csv module for proper RFC 4180 compliance
- Default quoting: csv.QUOTE_MINIMAL
- Consider BOM for Excel compatibility (optional)

## Dependencies

- Requires: Story 1.5 (Batch Generation)

---

## Story 5.3: Implement SQL INSERT Output

**Status:** draft
**Epic:** Output Formats
**Priority:** P1

## User Story

As a backend developer, I want to export generated data as SQL INSERT statements so that I can seed databases directly with test data.

## Acceptance Criteria

1. **AC-5.3.1:** `RecordSet.to_sql()` generates INSERT statements
2. **AC-5.3.2:** Supports dialect parameter for SQLite, MySQL, PostgreSQL
3. **AC-5.3.3:** Properly escapes string values to prevent SQL injection
4. **AC-5.3.4:** Handles NULL for None values
5. **AC-5.3.5:** Configurable table name (defaults to schema name)

## Tasks

- [ ] Task 1: Create output/sql.py module (AC: 1)
  - [ ] Subtask 1.1: Create SqlWriter class
  - [ ] Subtask 1.2: Accept records, schema, dialect parameters
- [ ] Task 2: Implement SQL generation (AC: 1, 5)
  - [ ] Subtask 2.1: Build INSERT INTO table (columns) VALUES
  - [ ] Subtask 2.2: Get column names from schema fields
  - [ ] Subtask 2.3: Support custom table_name parameter
- [ ] Task 3: Add dialect support (AC: 2, 3, 4)
  - [ ] Subtask 3.1: Create Dialect base class with escape methods
  - [ ] Subtask 3.2: Implement SqliteDialect
  - [ ] Subtask 3.3: Implement MysqlDialect
  - [ ] Subtask 3.4: Implement PostgresDialect
  - [ ] Subtask 3.5: Handle string escaping per dialect
  - [ ] Subtask 3.6: Handle NULL representation
- [ ] Task 4: Handle data types (AC: 3, 4)
  - [ ] Subtask 4.1: Quote strings with proper escaping
  - [ ] Subtask 4.2: Format dates/datetimes appropriately
  - [ ] Subtask 4.3: Output NULL for None values
  - [ ] Subtask 4.4: Handle numeric types without quotes
- [ ] Task 5: Add to_sql to RecordSet (AC: 1, 2, 5)
  - [ ] Subtask 5.1: Create to_sql method on RecordSet
  - [ ] Subtask 5.2: Accept file_path, dialect, table_name parameters
  - [ ] Subtask 5.3: Return string if no path provided
- [ ] Task 6: Write SQL output tests (AC: all)
  - [ ] Subtask 6.1: Test each dialect output
  - [ ] Subtask 6.2: Test string escaping (quotes, special chars)
  - [ ] Subtask 6.3: Test NULL handling
  - [ ] Subtask 6.4: Test custom table name

## Technical Notes

- SQLite: single quotes for strings, NULL keyword
- MySQL: backticks for identifiers, single quotes for strings
- PostgreSQL: double quotes for identifiers, single quotes for strings
- Escape single quotes by doubling: ' -> ''

## Dependencies

- Requires: Story 1.5 (Batch Generation)
