# Product Requirements Document: Test Data Generator Library

## Vision

Test Data Generator is a Python library for generating realistic, deterministic test data with schema validation. It provides a type-safe DSL for defining data schemas and produces consistent, reproducible datasets for testing purposes. The library focuses on simplicity, zero external dependencies for core functionality, and seamless integration into Python testing workflows.

## Goals

1. **Deterministic Generation**: Provide seedable random generation ensuring reproducible test data across runs
2. **Flexible Schema Definition**: Support both Python DSL and YAML-based schema definitions
3. **Relational Data Support**: Enable generation of related records with foreign key relationships
4. **Multiple Output Formats**: Export generated data to JSON, CSV, and SQL INSERT statements
5. **Zero Core Dependencies**: Core functionality works with Python stdlib only; Pydantic optional for validation
6. **High Performance**: Generate 10,000+ records per second for efficient test data creation

## User Personas

### Test Engineer
- Needs consistent test datasets for integration and E2E testing
- Values reproducibility across test runs
- Wants easy schema definition without complex configuration

### Backend Developer
- Generates seed data for local development databases
- Requires relational data with proper foreign key relationships
- Needs output in SQL format for database seeding

### Data Analyst
- Creates sample datasets for testing data pipelines
- Exports to CSV for analysis tool compatibility
- Values realistic data distributions

## Functional Requirements

### Core Generation

- **FR-001**: Define data schema in Python DSL using `Schema` and `Field` classes
- **FR-002**: Define data schema in YAML format with equivalent capabilities to Python DSL
- **FR-003**: Generate string fields including names, emails, addresses, and lorem ipsum text
- **FR-004**: Generate number fields including integers, floats, and decimals with configurable ranges
- **FR-005**: Generate date and datetime fields with configurable ranges and formats
- **FR-006**: Generate choice fields supporting enum values and weighted random selection
- **FR-007**: Generate related records using foreign key references between schemas
- **FR-008**: Provide deterministic generation using configurable seed values
- **FR-009**: Output generated data to JSON format
- **FR-010**: Output generated data to CSV format
- **FR-011**: Output generated data to SQL INSERT statements with dialect support
- **FR-012**: Support batch generation of N records in a single operation
- **FR-013**: Allow custom field generators through a plugin interface

## Non-Functional Requirements

- **NFR-001**: Generate 10,000 records in less than 1 second
- **NFR-002**: Produce consistent output given the same seed value
- **NFR-003**: Provide type hints on all public API functions and classes
- **NFR-004**: Maintain test coverage above 90%
- **NFR-005**: Core functionality requires zero external dependencies (stdlib only)
- **NFR-006**: Pydantic integration is optional and not required for basic usage

## MVP Scope

### In Scope

- Python DSL for schema definition (`Schema`, `Field` classes)
- YAML schema parser
- Built-in providers: strings (name, email, text), numbers (int, float, decimal), dates, choices
- Foreign key reference support for relational data
- Deterministic seeding for reproducible generation
- JSON, CSV, and SQL output formats
- Batch generation API
- Custom provider plugin interface
- Type hints on all public APIs
- Comprehensive test suite with 90%+ coverage

### Out of Scope

- Locale/internationalization support
- Direct database insertion (users export to SQL and execute)
- Web API or REST interface
- Graphical user interface
- Image or binary data generation
- Fetching real external data sources
- Complex statistical distributions beyond weighted random
- Streaming to external systems

## Success Metrics

- 90%+ test coverage
- Generation performance: 10K records < 1 second
- Zero core dependencies verified
- All public APIs have complete type hints
- YAML and Python DSL feature parity
