# Project Context: Test Data Generator Library

## File Structure

```
src/
├── testdatagen/
│   ├── __init__.py
│   ├── schema.py           # Schema, Field classes
│   ├── generator.py        # Core generator
│   ├── providers/
│   │   ├── __init__.py
│   │   ├── base.py         # Provider interface
│   │   ├── strings.py      # Name, email, text
│   │   ├── numbers.py      # Int, float, decimal
│   │   ├── dates.py        # Date, datetime
│   │   ├── choices.py      # Enum, weighted
│   │   └── refs.py         # Foreign key refs
│   ├── output/
│   │   ├── __init__.py
│   │   ├── json.py
│   │   ├── csv.py
│   │   └── sql.py
│   ├── parsers/
│   │   └── yaml.py
│   └── cli.py              # Optional CLI
└── tests/
    ├── test_schema.py
    ├── test_providers.py
    ├── test_output.py
    └── test_determinism.py
```

## Naming Conventions

### Files and Modules

- All Python files use `snake_case`
- Module names are singular nouns (e.g., `schema.py`, not `schemas.py`)
- Test files mirror source structure with `test_` prefix
- Provider files named by category (e.g., `strings.py`, `numbers.py`)

### Classes

- Use `PascalCase` for all class names
- Abstract base classes end with `Base` or use `ABC` mixin
- Provider classes end with `Provider` (e.g., `StringProvider`)
- Exception classes end with `Error` (e.g., `SchemaError`)

### Functions and Methods

- Use `snake_case` for all functions and methods
- Public methods have descriptive verb names (e.g., `generate`, `validate`)
- Private methods prefixed with single underscore (e.g., `_build_record`)
- Dunder methods for special Python protocols only

### Variables and Constants

- Variables use `snake_case`
- Constants use `UPPER_SNAKE_CASE`
- Private attributes prefixed with single underscore
- Type aliases use `PascalCase`

### Examples

```python
# Classes
class Schema:
class Field:
class BaseProvider(ABC):
class StringProvider(BaseProvider):

# Functions
def generate(schema: Schema, count: int) -> RecordSet:
def load_schema(path: str) -> Schema:
def _build_record(fields: list[Field]) -> dict:

# Constants
DEFAULT_SEED = 42
MAX_BATCH_SIZE = 100_000

# Variables
field_config = {}
record_count = 100
```

## Python Library Patterns

### Public API Design

The public API is defined in `__init__.py`:

```python
# testdatagen/__init__.py
from testdatagen.schema import Schema, Field
from testdatagen.generator import generate
from testdatagen.parsers.yaml import load_schema
from testdatagen.providers import register_provider

__all__ = [
    "Schema",
    "Field",
    "generate",
    "load_schema",
    "register_provider",
]
```

### Type Hints

All public APIs require complete type hints:

```python
from typing import Any, Iterator

def generate(
    schema: Schema,
    count: int,
    seed: int | None = None,
) -> RecordSet:
    """Generate records according to schema.

    Args:
        schema: Data schema definition
        count: Number of records to generate
        seed: Random seed for deterministic output

    Returns:
        RecordSet containing generated records
    """
```

### Provider Registration

Custom providers use a registry pattern:

```python
_provider_registry: dict[str, type[BaseProvider]] = {}

def register_provider(name: str, provider_class: type[BaseProvider]) -> None:
    """Register a custom provider type."""
    _provider_registry[name] = provider_class

def get_provider(name: str) -> type[BaseProvider]:
    """Get provider class by name."""
    if name not in _provider_registry:
        raise ProviderNotFoundError(f"Unknown provider: {name}")
    return _provider_registry[name]
```

### Lazy Generation

Use iterators for memory-efficient generation:

```python
class RecordSet:
    def __init__(self, schema: Schema, records: Iterator[dict]):
        self._schema = schema
        self._records = records
        self._cached: list[dict] | None = None

    def __iter__(self) -> Iterator[dict]:
        if self._cached is not None:
            yield from self._cached
        else:
            for record in self._records:
                yield record

    def to_list(self) -> list[dict]:
        if self._cached is None:
            self._cached = list(self._records)
        return self._cached
```

### Configuration with Defaults

Use dataclasses or Pydantic for configuration:

```python
from dataclasses import dataclass, field

@dataclass
class FieldConfig:
    type: str
    min: int | None = None
    max: int | None = None
    choices: list[str] = field(default_factory=list)
    nullable: bool = False
    unique: bool = False
```

## Testing Standards

### Coverage Requirement

- Minimum 90% test coverage required
- All public APIs must have test coverage
- Edge cases and error conditions tested

### Test Organization

```
tests/
├── conftest.py           # Shared fixtures
├── test_schema.py        # Schema and Field tests
├── test_generator.py     # Generator tests
├── test_providers.py     # Provider tests
├── test_output.py        # Output format tests
├── test_determinism.py   # Seed reproducibility tests
└── test_integration.py   # End-to-end tests
```

### Testing Patterns

```python
import pytest
from testdatagen import Schema, Field, generate

class TestGenerator:
    """Generator test suite."""

    def test_generate_single_record(self):
        """Should generate one record."""
        schema = Schema("users", Field("id", "int"))
        result = generate(schema, count=1, seed=42)
        records = list(result)
        assert len(records) == 1

    def test_deterministic_with_seed(self):
        """Same seed should produce same output."""
        schema = Schema("users", Field("name", "name"))
        result1 = list(generate(schema, count=5, seed=42))
        result2 = list(generate(schema, count=5, seed=42))
        assert result1 == result2

    @pytest.mark.parametrize("count", [0, 1, 100, 10000])
    def test_generate_various_counts(self, count: int):
        """Should handle various record counts."""
        schema = Schema("items", Field("id", "int"))
        result = list(generate(schema, count=count, seed=1))
        assert len(result) == count
```

### Property-Based Testing

Use hypothesis for property-based tests:

```python
from hypothesis import given, strategies as st

@given(count=st.integers(min_value=0, max_value=1000))
def test_generate_count_matches_requested(count: int):
    """Generated count should match requested count."""
    schema = Schema("items", Field("id", "int"))
    result = list(generate(schema, count=count, seed=1))
    assert len(result) == count

@given(seed=st.integers())
def test_same_seed_same_output(seed: int):
    """Same seed should always produce same output."""
    schema = Schema("items", Field("id", "int"))
    result1 = list(generate(schema, count=10, seed=seed))
    result2 = list(generate(schema, count=10, seed=seed))
    assert result1 == result2
```

### Running Tests

```bash
# Run all tests
pytest

# Run with coverage
pytest --cov=testdatagen --cov-report=term-missing

# Run specific test file
pytest tests/test_schema.py

# Run tests matching pattern
pytest -k "determinism"

# Run with verbose output
pytest -v
```

## Error Handling

### Custom Exceptions

```python
class TestDataGenError(Exception):
    """Base exception for testdatagen."""
    pass

class SchemaError(TestDataGenError):
    """Invalid schema definition."""
    pass

class ProviderError(TestDataGenError):
    """Provider configuration or execution error."""
    pass

class OutputError(TestDataGenError):
    """Output format or writing error."""
    pass
```

### Validation Pattern

```python
def validate_schema(schema: Schema) -> None:
    """Validate schema configuration.

    Raises:
        SchemaError: If schema is invalid
    """
    if not schema.name:
        raise SchemaError("Schema name is required")

    for field in schema.fields:
        if not field.name:
            raise SchemaError("Field name is required")
        if field.type not in _provider_registry:
            raise SchemaError(f"Unknown field type: {field.type}")
```

## Dependencies

### Core (Zero Dependencies)

The core library uses only Python stdlib:
- `random` for seedable randomness
- `json` for JSON output
- `csv` for CSV output
- `datetime` for date handling
- `typing` for type hints
- `dataclasses` for data structures

### Optional Dependencies

- `pydantic>=2.0` - For schema validation (optional)
- `typer>=0.9` - For CLI wrapper (optional)
- `pyyaml>=6.0` - For YAML schema parsing

### Development Dependencies

- `pytest>=7.0`
- `pytest-cov>=4.0`
- `hypothesis>=6.0`
- `ruff>=0.1`
- `mypy>=1.0`
