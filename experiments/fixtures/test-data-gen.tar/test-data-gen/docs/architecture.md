# Technical Architecture: Test Data Generator Library

## Overview

Test Data Generator is a Python library designed for generating realistic, deterministic test data. The architecture prioritizes simplicity, zero core dependencies, and extensibility through a provider plugin system. The library uses lazy generation for memory efficiency and supports both Python DSL and YAML schema definitions.

## Tech Stack

- **Language**: Python 3.11+
- **Validation**: Pydantic v2 (optional)
- **Randomness**: Built-in `random` module (seedable)
- **Output Formats**: JSON, CSV, SQL INSERT statements
- **CLI**: Typer (optional CLI wrapper)
- **Testing**: pytest, hypothesis
- **Linting**: ruff

## Core Components

### Schema Definition Layer

The schema layer defines the structure of generated data:

```
testdatagen/
├── schema.py        # Schema and Field class definitions
└── parsers/
    └── yaml.py      # YAML schema parser
```

- `Schema`: Container for field definitions with metadata (name, constraints)
- `Field`: Individual field definition with type, constraints, and provider config
- YAML parser converts YAML definitions to Schema objects

### Generator Engine

The core generation engine orchestrates data creation:

```
testdatagen/
├── generator.py     # Core Generator class
└── state.py         # Random state management (internal)
```

- `Generator`: Main entry point, manages provider dispatch and record building
- Seedable random state ensures deterministic output
- Lazy generation pattern for memory efficiency

### Provider System

Providers generate specific data types:

```
testdatagen/providers/
├── __init__.py
├── base.py          # BaseProvider interface
├── strings.py       # Name, email, text, address
├── numbers.py       # Int, float, decimal
├── dates.py         # Date, datetime, time
├── choices.py       # Enum, weighted random
└── refs.py          # Foreign key references
```

Each provider:
- Implements `BaseProvider` interface
- Accepts configuration (min, max, choices, etc.)
- Uses shared random state for determinism
- Returns generated value for single field

### Output Formatters

Output layer converts generated records to target formats:

```
testdatagen/output/
├── __init__.py
├── base.py          # BaseWriter interface
├── json.py          # JSON output
├── csv.py           # CSV output
└── sql.py           # SQL INSERT statements
```

- Writers receive record iterators (lazy)
- Support streaming to file or string
- SQL writer supports dialect configuration (sqlite, mysql, postgresql)

## Provider System

### Provider Interface

```python
from abc import ABC, abstractmethod
from typing import Any
import random

class BaseProvider(ABC):
    """Base class for all data providers."""

    def __init__(self, rng: random.Random, **config):
        self.rng = rng
        self.config = config

    @abstractmethod
    def generate(self) -> Any:
        """Generate and return a single value."""
        pass
```

### Built-in Providers

| Provider | Types | Configuration |
|----------|-------|---------------|
| `StringProvider` | name, email, text, address, uuid | max_length, domain |
| `NumberProvider` | int, float, decimal | min, max, precision |
| `DateProvider` | date, datetime, time | start, end, format |
| `ChoiceProvider` | choice, enum | choices, weights |
| `RefProvider` | ref | schema, field |

### Custom Providers

Users can register custom providers:

```python
from testdatagen import register_provider
from testdatagen.providers.base import BaseProvider

class PhoneProvider(BaseProvider):
    def generate(self) -> str:
        return f"+1-{self.rng.randint(200,999)}-{self.rng.randint(100,999)}-{self.rng.randint(1000,9999)}"

register_provider("phone", PhoneProvider)
```

## Output Formats

### JSON Output

```python
users.to_json("users.json")
users.to_json("users.json", indent=2)  # Pretty print
```

Outputs array of objects with field names as keys.

### CSV Output

```python
users.to_csv("users.csv")
users.to_csv("users.csv", delimiter=";")
```

First row contains headers, subsequent rows contain values.

### SQL Output

```python
users.to_sql("users.sql", dialect="sqlite")
users.to_sql("users.sql", dialect="postgresql", table_name="app_users")
```

Generates INSERT statements with proper escaping per dialect.

## Example Usage

### Python DSL

```python
from testdatagen import Schema, Field, generate

# Define schema
schema = Schema(
    "users",
    Field("id", "uuid"),
    Field("name", "name"),
    Field("email", "email"),
    Field("age", "int", min=18, max=80),
    Field("role", "choice", choices=["admin", "user", "guest"]),
    Field("created_at", "datetime", start="2020-01-01"),
)

# Generate with seed
users = generate(schema, count=100, seed=42)

# Output
users.to_json("users.json")
users.to_csv("users.csv")
users.to_sql("users.sql", dialect="sqlite")
```

### YAML Schema

```yaml
schema:
  name: orders
  fields:
    - name: id
      type: uuid
    - name: user_id
      type: ref
      ref: users.id
    - name: total
      type: decimal
      min: 10.00
      max: 1000.00
      precision: 2
    - name: status
      type: choice
      choices: [pending, shipped, delivered]
```

```python
from testdatagen import load_schema, generate

schema = load_schema("orders.yaml")
orders = generate(schema, count=50, seed=42)
```

## Architecture Decision Records

### ADR-001: No Faker Dependency

**Status**: Accepted

**Context**: Faker is a popular library for generating fake data but adds a significant dependency and is designed for general-purpose fake data rather than deterministic test data.

**Decision**: Build custom providers without Faker dependency.

**Rationale**:
- Custom providers allow precise control over determinism
- Smaller library footprint
- No external locale data requirements
- Focused on test data generation, not general fake data

**Trade-off**: Fewer built-in locales and data types, but not needed for test data focus.

### ADR-002: Stdlib Random Over Secrets

**Status**: Accepted

**Context**: Python offers `random` (seedable, not cryptographic) and `secrets` (cryptographic, not seedable) modules.

**Decision**: Use `random` module for all randomness.

**Rationale**:
- Seedable random is essential for deterministic test data
- Cryptographic security is not a requirement for test data
- Reproducibility across runs is a core feature

**Trade-off**: Not cryptographically secure, but that is explicitly not a goal.

### ADR-003: Lazy Generation Over Pre-generation

**Status**: Accepted

**Context**: Generation can either pre-generate all records into memory or generate lazily as needed.

**Decision**: Use lazy generation with iterators.

**Rationale**:
- Memory efficient for large datasets
- Enables streaming output to files
- Performance improves for partial consumption

**Trade-off**: Cannot reference "all records" during generation (e.g., pick random existing record). This limitation is acceptable as foreign key references handle relational needs.

### ADR-004: Python DSL Primary, YAML Secondary

**Status**: Accepted

**Context**: Schema definitions can be in code (Python DSL) or configuration (YAML).

**Decision**: Python DSL is the primary interface; YAML support is secondary.

**Rationale**:
- Python DSL provides full type hints and IDE support
- More flexible for complex schemas
- YAML serves users who prefer configuration over code
- Both compile to same internal Schema representation

**Trade-off**: YAML is simpler for non-Python users but lacks IDE support for the schema.
