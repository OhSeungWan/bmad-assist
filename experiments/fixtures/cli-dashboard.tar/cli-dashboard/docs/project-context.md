# Project Context: CLI Dashboard Generator

## File Structure

```
src/
├── cli_dashboard/
│   ├── __init__.py
│   ├── cli.py              # Typer CLI
│   ├── config/
│   │   ├── __init__.py
│   │   ├── schema.py       # Pydantic models
│   │   ├── parser.py       # YAML loading
│   │   └── validator.py    # Validation logic
│   ├── widgets/
│   │   ├── __init__.py
│   │   ├── base.py         # Widget interface
│   │   ├── text.py
│   │   ├── table.py
│   │   ├── chart.py
│   │   ├── progress.py
│   │   └── sparkline.py
│   ├── layout/
│   │   ├── __init__.py
│   │   ├── grid.py
│   │   └── renderer.py
│   ├── sources/
│   │   ├── __init__.py
│   │   ├── base.py
│   │   ├── file.py
│   │   ├── command.py
│   │   └── json.py
│   └── export/
│       └── html.py
└── tests/
    ├── conftest.py
    ├── test_config.py
    ├── test_widgets.py
    └── test_sources.py
```

## Naming Conventions

### Files
- All Python files use `snake_case`
- Module `__init__.py` files export public API
- Test files prefixed with `test_`

### Classes
- `PascalCase` for all classes
- Widget classes: `{Type}Widget` (e.g., `TextWidget`, `TableWidget`)
- Config classes: `{Type}Config` (e.g., `DashboardConfig`, `WidgetConfig`)
- Source classes: `{Type}Source` (e.g., `FileSource`, `CommandSource`)

### Functions and Variables
- `snake_case` for all functions and variables
- Private functions prefixed with `_`
- Constants in `UPPER_SNAKE_CASE`

### CLI Commands
- `kebab-case` for CLI commands
- Example: `cli-dashboard run`, `cli-dashboard validate`

### Config Keys
- `snake_case` for all YAML configuration keys
- Example: `refresh_interval`, `source_type`

## Python Patterns

### Type Hints
All functions require type hints:

```python
def parse_config(path: Path) -> DashboardConfig:
    """Load and validate dashboard configuration from YAML file."""
    ...
```

### Abstract Base Classes
Widgets and sources use ABCs for interface definition:

```python
from abc import ABC, abstractmethod

class BaseWidget(ABC):
    @abstractmethod
    def render(self) -> RenderableType:
        pass
```

### Pydantic Models
Configuration uses Pydantic v2 models:

```python
from pydantic import BaseModel, Field

class WidgetConfig(BaseModel):
    type: WidgetType
    title: str = Field(..., min_length=1)
    span: int = Field(default=1, ge=1, le=12)
```

### Error Handling
Custom exceptions inherit from base error class:

```python
class DashboardError(Exception):
    """Base exception for all dashboard errors."""
    pass

class ConfigError(DashboardError):
    """Configuration parsing or validation error."""
    def __init__(self, message: str, path: str | None = None, line: int | None = None):
        self.path = path
        self.line = line
        super().__init__(message)
```

### Logging
Each module uses its own logger:

```python
import logging

logger = logging.getLogger(__name__)
```

### Factory Pattern
Widget and source creation uses factory functions:

```python
def create_widget(config: WidgetConfig, source: DataSource) -> BaseWidget:
    """Create widget instance based on config type."""
    widget_map = {
        WidgetType.TEXT: TextWidget,
        WidgetType.TABLE: TableWidget,
        # ...
    }
    return widget_map[config.type](config, source)
```

### Context Managers
Resources use context managers:

```python
class Dashboard:
    def __enter__(self) -> "Dashboard":
        self._start_sources()
        return self

    def __exit__(self, *args) -> None:
        self._stop_sources()
```

## Testing Standards

### Test Organization
- Unit tests in `tests/` mirroring source structure
- Integration tests in `tests/integration/`
- Fixtures in `tests/conftest.py`

### Test Naming
```python
def test_parse_config_valid_yaml():
    """Test parsing valid YAML configuration."""
    ...

def test_parse_config_invalid_yaml_raises_error():
    """Test that invalid YAML raises ConfigError."""
    ...
```

### Fixtures
Use pytest fixtures for common setup:

```python
@pytest.fixture
def sample_config() -> dict:
    return {
        "dashboard": {"title": "Test", "refresh": "1s"},
        "layout": {"columns": 12, "rows": []}
    }

@pytest.fixture
def temp_config_file(sample_config: dict, tmp_path: Path) -> Path:
    config_path = tmp_path / "dashboard.yaml"
    config_path.write_text(yaml.dump(sample_config))
    return config_path
```

### Assertions
Use plain assert statements with descriptive messages:

```python
def test_widget_render():
    widget = TextWidget(config, source)
    result = widget.render()
    assert isinstance(result, Panel), "TextWidget should return a Panel"
    assert "expected text" in str(result), "Panel should contain source text"
```

### Mocking
Mock external dependencies (commands, files):

```python
def test_command_source(mocker):
    mock_run = mocker.patch("subprocess.run")
    mock_run.return_value.stdout = "test output"

    source = CommandSource("echo test")
    result = source.fetch()

    assert result == "test output"
```

## Dependencies

### Runtime
- `rich>=13.0.0` - Terminal rendering
- `pyyaml>=6.0` - YAML parsing
- `pydantic>=2.0.0` - Schema validation
- `typer>=0.9.0` - CLI framework

### Development
- `pytest>=7.0.0` - Testing framework
- `pytest-mock>=3.10.0` - Mocking utilities
- `ruff>=0.1.0` - Linting and formatting

## Configuration

### pyproject.toml
```toml
[project]
name = "cli-dashboard"
version = "0.1.0"
requires-python = ">=3.11"

[tool.ruff]
target-version = "py311"
line-length = 100

[tool.ruff.lint]
select = ["E", "F", "I", "UP", "B"]

[tool.pytest.ini_options]
testpaths = ["tests"]
```

## Code Quality Rules

1. **No hardcoded values** - Use configuration or constants
2. **Single responsibility** - Each class/function does one thing
3. **Explicit over implicit** - Use type hints everywhere
4. **Fail fast** - Validate configuration at startup
5. **Graceful degradation** - Handle data source failures without crashing
6. **Minimal dependencies** - Only add packages that provide significant value
