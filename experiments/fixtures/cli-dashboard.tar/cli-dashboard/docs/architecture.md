# Technical Architecture: CLI Dashboard Generator

## Overview

CLI Dashboard Generator is a Python CLI application that reads YAML configuration files and renders interactive terminal dashboards using the Rich library. The architecture follows a modular design with clear separation between configuration parsing, widget rendering, layout management, and data sourcing.

## Tech Stack

| Component | Technology | Purpose |
|-----------|------------|---------|
| Language | Python 3.11+ | Core implementation |
| TUI Framework | Rich + Textual | Terminal rendering |
| Config Parsing | PyYAML | YAML file loading |
| Validation | Pydantic v2 | Schema validation |
| CLI Framework | Typer | Command-line interface |
| Testing | pytest | Unit and integration tests |
| Linting | ruff | Code quality |

## System Components

### 1. Configuration Layer

```
cli_dashboard/config/
├── schema.py       # Pydantic models for all config types
├── parser.py       # YAML loading and initial parsing
└── validator.py    # Business logic validation
```

The configuration layer handles:
- Loading YAML files with PyYAML
- Validating structure with Pydantic models
- Providing helpful error messages with line numbers
- Supporting variable interpolation (environment variables)

### 2. Widget Layer

```
cli_dashboard/widgets/
├── base.py         # Abstract base widget interface
├── text.py         # Text widget implementation
├── table.py        # Table widget implementation
├── chart.py        # Bar chart widget implementation
├── progress.py     # Progress bar widget implementation
└── sparkline.py    # Sparkline widget implementation
```

Each widget:
- Inherits from `BaseWidget` abstract class
- Implements `render()` returning Rich renderables
- Accepts configuration via Pydantic model
- Handles its own data source binding

### 3. Layout Layer

```
cli_dashboard/layout/
├── grid.py         # Grid container and cell management
└── renderer.py     # Dashboard-level rendering orchestration
```

The layout system:
- Divides terminal into configurable grid
- Manages widget placement and spanning
- Handles terminal resize events
- Coordinates refresh cycles

### 4. Data Source Layer

```
cli_dashboard/sources/
├── base.py         # Abstract data source interface
├── file.py         # File watching data source
├── command.py      # Command execution data source
└── json.py         # JSON parsing utilities
```

Data sources:
- Implement `DataSource` protocol
- Return structured data on `fetch()`
- Support configurable refresh intervals
- Handle errors gracefully (return error state, not exceptions)

### 5. Export Layer

```
cli_dashboard/export/
└── html.py         # HTML export functionality
```

Export system:
- Captures current dashboard state
- Generates self-contained HTML
- Inlines CSS styles
- Preserves color and formatting

## Config Schema

### Dashboard Configuration

```yaml
dashboard:
  title: "System Monitor"
  refresh: 1s
  theme: dark

layout:
  columns: 12
  rows:
    - height: auto
      widgets:
        - type: text
          title: "Uptime"
          span: 4
          source:
            type: command
            command: "uptime -p"
        - type: progress
          title: "CPU"
          span: 4
          source:
            type: command
            command: "grep 'cpu ' /proc/stat | awk '{print ($2+$4)*100/($2+$4+$5)}'"
        - type: progress
          title: "Memory"
          span: 4
          source:
            type: command
            command: "free | grep Mem | awk '{print $3/$2 * 100}'"
    - height: 10
      widgets:
        - type: table
          title: "Top Processes"
          span: 12
          source:
            type: command
            command: "ps aux --sort=-%mem | head -6"
            format: table
```

### Pydantic Schema Hierarchy

```
DashboardConfig
├── DashboardMeta (title, refresh, theme)
├── LayoutConfig
│   ├── columns: int
│   └── rows: list[RowConfig]
│       ├── height: str | int
│       └── widgets: list[WidgetConfig]
│           ├── type: WidgetType
│           ├── title: str
│           ├── span: int
│           └── source: SourceConfig
│               ├── type: SourceType
│               └── [source-specific fields]
└── ThemeConfig (optional)
```

## Widget System

### Base Widget Interface

```python
from abc import ABC, abstractmethod
from rich.console import RenderableType

class BaseWidget(ABC):
    def __init__(self, config: WidgetConfig, source: DataSource):
        self.config = config
        self.source = source
        self._last_data = None
        self._last_error = None

    @abstractmethod
    def render(self) -> RenderableType:
        """Return Rich renderable for this widget."""
        pass

    def update(self) -> None:
        """Fetch new data from source."""
        try:
            self._last_data = self.source.fetch()
            self._last_error = None
        except Exception as e:
            self._last_error = str(e)
```

### Widget Types

| Widget | Rich Component | Data Format |
|--------|---------------|-------------|
| Text | `Panel(Text(...))` | string |
| Table | `Table` | list of dicts or table format |
| Bar Chart | `Panel(Text with blocks)` | dict of label: value |
| Progress | `Progress` | float (0-100) |
| Sparkline | Custom Text with braille | list of floats |

## Data Flow

```
┌─────────────────┐
│   YAML Config   │
└────────┬────────┘
         ▼
┌─────────────────┐
│  Config Parser  │ ──→ Validation Errors (if any)
└────────┬────────┘
         ▼
┌─────────────────┐
│  Widget Factory │ ──→ Creates widgets with data sources
└────────┬────────┘
         ▼
┌─────────────────┐
│  Layout Engine  │ ──→ Arranges widgets in grid
└────────┬────────┘
         ▼
┌─────────────────┐     ┌─────────────────┐
│    Renderer     │ ←─→ │  Data Sources   │
└────────┬────────┘     └─────────────────┘
         ▼
┌─────────────────┐
│ Rich Live/Panel │
└─────────────────┘
```

## Refresh Cycle

1. Renderer maintains list of (widget, next_refresh_time) tuples
2. On each cycle:
   - Check which widgets need refresh
   - Call `widget.update()` for those due
   - Re-render affected widgets
   - Calculate next cycle delay (minimum of all pending refreshes)
3. Rich Live display updates atomically

## Architectural Decision Records (ADRs)

### ADR-001: Rich over Textual for Rendering

**Status:** Accepted

**Context:** Need to choose a Python terminal UI framework for rendering dashboards.

**Decision:** Use Rich for primary rendering, with Textual as optional dependency for advanced features.

**Rationale:**
- Rich is simpler for static/periodic refresh dashboards
- Rich has excellent table, panel, and progress bar components
- Textual adds complexity for minimal benefit in this use case
- Rich Live provides sufficient dynamic update capability

**Trade-offs:**
- Less interactive than full Textual app
- No built-in keyboard handling (acceptable for monitoring use case)
- Cannot support complex widget interactions

### ADR-002: Pydantic for Config Validation

**Status:** Accepted

**Context:** Need robust configuration validation with good error messages.

**Decision:** Use Pydantic v2 for all configuration models.

**Rationale:**
- Type-safe configuration with automatic validation
- Excellent error messages with field paths
- JSON Schema generation for editor support
- Serialization/deserialization built-in
- Wide community adoption

**Trade-offs:**
- Additional dependency (~3MB)
- Slightly more complex than simple dataclasses
- Learning curve for Pydantic v2 syntax

### ADR-003: Pull-Based Refresh over Push

**Status:** Accepted

**Context:** Need to decide how widgets receive data updates.

**Decision:** Use pull-based refresh with configurable intervals per widget.

**Rationale:**
- Simpler implementation than event-driven push
- Predictable resource usage
- Easy to configure per-widget intervals
- Natural fit for command and file sources
- No need for complex event handling

**Trade-offs:**
- Not true real-time (minimum 100ms latency)
- Wastes resources polling unchanged sources
- Cannot react instantly to external events

### ADR-004: YAML over TOML for Configuration

**Status:** Accepted

**Context:** Need to choose configuration file format.

**Decision:** Use YAML as the primary configuration format.

**Rationale:**
- Better support for nested/hierarchical structures
- More familiar to DevOps/infrastructure users
- YAML is standard for dashboard configs (Grafana, k8s)
- PyYAML is well-maintained and fast

**Trade-offs:**
- Whitespace-sensitive syntax can cause errors
- Multiple YAML parsers with subtle differences
- No built-in schema validation (mitigated by Pydantic)

## Error Handling Strategy

### Configuration Errors
- Fail fast with clear error messages
- Include file path, line number, and field name
- Suggest corrections for common mistakes

### Data Source Errors
- Never crash the dashboard
- Display error state in widget
- Log error details for debugging
- Retry on next refresh cycle

### Rendering Errors
- Fallback to simplified rendering
- Show error panel in widget space
- Preserve other widget functionality
