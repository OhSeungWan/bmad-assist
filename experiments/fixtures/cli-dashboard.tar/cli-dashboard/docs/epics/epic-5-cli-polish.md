---
epic_num: 5
title: CLI & Polish
status: draft
---

# Epic 5: CLI & Polish

**Status:** Backlog
**Priority:** P2
**Stories:** 2

## Overview

Command-line interface and final polish including HTML export functionality. Provides the user-facing entry point to run, validate, and export dashboards.

## Stories

---

## Story 5.1: Create CLI with Typer (run, validate, export)

**Status:** draft
**Epic:** CLI & Polish
**Priority:** P0

## User Story
As a user, I want a command-line interface so that I can run dashboards, validate configurations, and export to HTML from the terminal.

## Acceptance Criteria
1. **AC-5.1.1:** CLI provides `run` command to start dashboard from config file
2. **AC-5.1.2:** CLI provides `validate` command to check config without running
3. **AC-5.1.3:** CLI provides `export` command to generate HTML output
4. **AC-5.1.4:** CLI displays helpful error messages for invalid arguments
5. **AC-5.1.5:** CLI supports --version and --help flags
6. **AC-5.1.6:** CLI supports --config flag to specify config file path
7. **AC-5.1.7:** CLI supports --theme flag to override theme
8. **AC-5.1.8:** CLI supports --no-watch flag to disable live reload

## Tasks
- [ ] Task 1: Set up Typer CLI application (AC: 5)
  - [ ] Subtask 1.1: Create main app with typer.Typer()
  - [ ] Subtask 1.2: Add version callback
  - [ ] Subtask 1.3: Configure help text and documentation
- [ ] Task 2: Implement run command (AC: 1, 6, 7, 8)
  - [ ] Subtask 2.1: Add run command with config path argument
  - [ ] Subtask 2.2: Add --theme option
  - [ ] Subtask 2.3: Add --no-watch option
  - [ ] Subtask 2.4: Load config and start dashboard
  - [ ] Subtask 2.5: Handle Ctrl+C gracefully
- [ ] Task 3: Implement validate command (AC: 2)
  - [ ] Subtask 3.1: Add validate command with config path
  - [ ] Subtask 3.2: Parse and validate config
  - [ ] Subtask 3.3: Print success or error messages
  - [ ] Subtask 3.4: Exit with appropriate code (0 or 1)
- [ ] Task 4: Implement export command (AC: 3)
  - [ ] Subtask 4.1: Add export command with config and output paths
  - [ ] Subtask 4.2: Render dashboard once
  - [ ] Subtask 4.3: Call HTML export module
  - [ ] Subtask 4.4: Print success message
- [ ] Task 5: Handle CLI errors (AC: 4)
  - [ ] Subtask 5.1: Catch ConfigError and format nicely
  - [ ] Subtask 5.2: Use typer.echo for output
  - [ ] Subtask 5.3: Set appropriate exit codes
- [ ] Task 6: Write CLI integration tests

## Technical Notes
- Use typer[all] for rich formatting support
- Entry point defined in pyproject.toml: `cli-dashboard = cli_dashboard.cli:app`
- Consider adding --quiet flag for CI usage

## Dependencies
- Requires: Story 1.3, Story 3.4, Story 4.5

---

## Story 5.2: Add HTML Export Functionality

**Status:** draft
**Epic:** CLI & Polish
**Priority:** P1

## User Story
As a user, I want to export my dashboard to HTML so that I can share it with others who don't have the CLI installed.

## Acceptance Criteria
1. **AC-5.2.1:** Export generates self-contained HTML file
2. **AC-5.2.2:** Export preserves visual appearance (colors, layout, borders)
3. **AC-5.2.3:** Export includes current data snapshot (not live updating)
4. **AC-5.2.4:** Export CSS is inlined for portability
5. **AC-5.2.5:** Export includes dashboard title and timestamp
6. **AC-5.2.6:** Exported file opens correctly in modern browsers

## Tasks
- [ ] Task 1: Create HTML exporter module (AC: 1)
  - [ ] Subtask 1.1: Create export/html.py module
  - [ ] Subtask 1.2: Define export_html(dashboard, path) function
  - [ ] Subtask 1.3: Generate complete HTML document
- [ ] Task 2: Preserve visual appearance (AC: 2)
  - [ ] Subtask 2.1: Use Rich Console export to HTML
  - [ ] Subtask 2.2: Map Rich styles to CSS
  - [ ] Subtask 2.3: Preserve table borders and structure
- [ ] Task 3: Capture data snapshot (AC: 3)
  - [ ] Subtask 3.1: Fetch all widget data once
  - [ ] Subtask 3.2: Render dashboard with fetched data
  - [ ] Subtask 3.3: Include note that data is static
- [ ] Task 4: Inline CSS (AC: 4)
  - [ ] Subtask 4.1: Generate CSS from Rich styles
  - [ ] Subtask 4.2: Include in <style> tag
  - [ ] Subtask 4.3: Use monospace font for terminal feel
- [ ] Task 5: Add metadata (AC: 5)
  - [ ] Subtask 5.1: Include dashboard title in <title>
  - [ ] Subtask 5.2: Add generation timestamp in footer
  - [ ] Subtask 5.3: Include config file path for reference
- [ ] Task 6: Test browser compatibility (AC: 6)
  - [ ] Subtask 6.1: Test in Chrome, Firefox, Safari
  - [ ] Subtask 6.2: Verify colors and layout
  - [ ] Subtask 6.3: Check responsive behavior
- [ ] Task 7: Write unit tests for HTML export

## Technical Notes
- Rich Console has export_html() method
- Consider using <pre> for terminal-like appearance
- Add CSS for dark theme if dashboard uses dark theme
- Consider adding print stylesheet

## Dependencies
- Requires: Story 3.4, Story 4.5
