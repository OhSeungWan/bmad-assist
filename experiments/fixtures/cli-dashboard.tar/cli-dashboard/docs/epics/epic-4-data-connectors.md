---
epic_num: 4
title: Data Connectors
status: draft
---

# Epic 4: Data Connectors

**Status:** Backlog
**Priority:** P1
**Stories:** 5

## Overview

Data source implementations for fetching dynamic content from files, commands, and JSON. Provides the data layer that widgets consume for dynamic updates.

## Stories

---

## Story 4.1: Create Data Source Interface

**Status:** draft
**Epic:** Data Connectors
**Priority:** P0

## User Story
As a developer, I want a data source interface so that all data sources have consistent behavior and can be used interchangeably by widgets.

## Acceptance Criteria
1. **AC-4.1.1:** DataSource abstract class defines fetch() method returning string or structured data
2. **AC-4.1.2:** DataSource defines refresh_interval property
3. **AC-4.1.3:** DataSource stores last fetch time for scheduling
4. **AC-4.1.4:** DataSource provides is_stale() method to check if refresh needed
5. **AC-4.1.5:** DataSource handles fetch errors and returns error state

## Tasks
- [ ] Task 1: Create DataSource abstract class (AC: 1)
  - [ ] Subtask 1.1: Define abstract fetch() method
  - [ ] Subtask 1.2: Return type: str | dict | list
  - [ ] Subtask 1.3: Add type hints and docstring
- [ ] Task 2: Implement refresh interval (AC: 2)
  - [ ] Subtask 2.1: Add refresh_interval property
  - [ ] Subtask 2.2: Accept timedelta in constructor
  - [ ] Subtask 2.3: Parse from config string (e.g., "1s", "500ms")
- [ ] Task 3: Track fetch timing (AC: 3)
  - [ ] Subtask 3.1: Store _last_fetch_time as datetime
  - [ ] Subtask 3.2: Update after each fetch() call
- [ ] Task 4: Implement staleness check (AC: 4)
  - [ ] Subtask 4.1: Create is_stale() method
  - [ ] Subtask 4.2: Compare current time with last fetch + interval
- [ ] Task 5: Handle fetch errors (AC: 5)
  - [ ] Subtask 5.1: Wrap fetch in try/except
  - [ ] Subtask 5.2: Store error state
  - [ ] Subtask 5.3: Return None or raise DataSourceError
- [ ] Task 6: Write unit tests for DataSource interface

## Technical Notes
- Use ABC from abc module
- Consider Protocol for structural typing
- Interval parsing: support "1s", "500ms", "2m" formats

## Dependencies
- Requires: Story 1.2

---

## Story 4.2: Implement File Data Source

**Status:** draft
**Epic:** Data Connectors
**Priority:** P0

## User Story
As a user, I want a file data source so that I can display content from local files and have it update when files change.

## Acceptance Criteria
1. **AC-4.2.1:** FileSource reads content from specified file path
2. **AC-4.2.2:** FileSource detects file modifications for refresh
3. **AC-4.2.3:** FileSource handles file not found with error state
4. **AC-4.2.4:** FileSource supports reading last N lines for large files
5. **AC-4.2.5:** FileSource handles encoding issues gracefully (UTF-8 default)

## Tasks
- [ ] Task 1: Create FileSource class extending DataSource (AC: 1)
  - [ ] Subtask 1.1: Accept file path in constructor
  - [ ] Subtask 1.2: Implement fetch() reading file content
  - [ ] Subtask 1.3: Return file content as string
- [ ] Task 2: Detect file modifications (AC: 2)
  - [ ] Subtask 2.1: Check file mtime on each fetch
  - [ ] Subtask 2.2: Cache mtime and compare
  - [ ] Subtask 2.3: Return cached content if unchanged
- [ ] Task 3: Handle missing files (AC: 3)
  - [ ] Subtask 3.1: Catch FileNotFoundError
  - [ ] Subtask 3.2: Return error state with helpful message
- [ ] Task 4: Support tail mode (AC: 4)
  - [ ] Subtask 4.1: Add lines config option
  - [ ] Subtask 4.2: Read only last N lines efficiently
  - [ ] Subtask 4.3: Seek from end for large files
- [ ] Task 5: Handle encoding (AC: 5)
  - [ ] Subtask 5.1: Default to UTF-8 encoding
  - [ ] Subtask 5.2: Accept encoding config option
  - [ ] Subtask 5.3: Handle decode errors gracefully
- [ ] Task 6: Write unit tests for FileSource

## Technical Notes
- Use pathlib.Path for file operations
- os.stat() for mtime checking
- Consider memory-mapped files for very large files

## Dependencies
- Requires: Story 4.1

---

## Story 4.3: Implement Command Data Source

**Status:** draft
**Epic:** Data Connectors
**Priority:** P0

## User Story
As a user, I want a command data source so that I can display output from shell commands like system status or logs.

## Acceptance Criteria
1. **AC-4.3.1:** CommandSource executes shell command and returns stdout
2. **AC-4.3.2:** CommandSource handles command failures with error state
3. **AC-4.3.3:** CommandSource supports timeout configuration
4. **AC-4.3.4:** CommandSource captures stderr on failure for debugging
5. **AC-4.3.5:** CommandSource sanitizes command output (trim, encoding)

## Tasks
- [ ] Task 1: Create CommandSource class extending DataSource (AC: 1)
  - [ ] Subtask 1.1: Accept command string in constructor
  - [ ] Subtask 1.2: Implement fetch() using subprocess
  - [ ] Subtask 1.3: Return stdout as string
- [ ] Task 2: Handle command failures (AC: 2)
  - [ ] Subtask 2.1: Check return code after execution
  - [ ] Subtask 2.2: Return error state for non-zero exit
  - [ ] Subtask 2.3: Include exit code in error message
- [ ] Task 3: Implement timeout (AC: 3)
  - [ ] Subtask 3.1: Add timeout config option
  - [ ] Subtask 3.2: Pass timeout to subprocess.run()
  - [ ] Subtask 3.3: Handle TimeoutExpired exception
- [ ] Task 4: Capture stderr (AC: 4)
  - [ ] Subtask 4.1: Set stderr=PIPE in subprocess
  - [ ] Subtask 4.2: Include stderr in error state
  - [ ] Subtask 4.3: Optionally merge stderr with stdout
- [ ] Task 5: Sanitize output (AC: 5)
  - [ ] Subtask 5.1: Strip trailing whitespace
  - [ ] Subtask 5.2: Decode as UTF-8 with error handling
  - [ ] Subtask 5.3: Remove ANSI escape codes if present
- [ ] Task 6: Write unit tests for CommandSource

## Technical Notes
- Use subprocess.run with capture_output=True
- shell=True for command string, be aware of security
- Consider shell=False with shlex.split() for safety

## Dependencies
- Requires: Story 4.1

---

## Story 4.4: Implement JSON Parser for Sources

**Status:** draft
**Epic:** Data Connectors
**Priority:** P1

## User Story
As a user, I want to parse JSON from data sources so that I can extract specific values from structured data using JSON path expressions.

## Acceptance Criteria
1. **AC-4.4.1:** JSONSource parses JSON from file or command source
2. **AC-4.4.2:** JSONSource supports JSON path expressions for value extraction
3. **AC-4.4.3:** JSONSource handles invalid JSON with error state
4. **AC-4.4.4:** JSONSource supports extracting nested values
5. **AC-4.4.5:** JSONSource returns appropriate type (string, number, array, object)

## Tasks
- [ ] Task 1: Create JSONSource wrapper class (AC: 1)
  - [ ] Subtask 1.1: Accept underlying source (file or command)
  - [ ] Subtask 1.2: Parse JSON from source output
  - [ ] Subtask 1.3: Return parsed dict/list
- [ ] Task 2: Implement JSON path (AC: 2)
  - [ ] Subtask 2.1: Add path config option
  - [ ] Subtask 2.2: Support basic paths (e.g., "data.value")
  - [ ] Subtask 2.3: Support array indexing (e.g., "items[0].name")
- [ ] Task 3: Handle JSON errors (AC: 3)
  - [ ] Subtask 3.1: Catch json.JSONDecodeError
  - [ ] Subtask 3.2: Return error state with position info
- [ ] Task 4: Extract nested values (AC: 4)
  - [ ] Subtask 4.1: Traverse nested dicts/lists
  - [ ] Subtask 4.2: Handle missing keys gracefully
  - [ ] Subtask 4.3: Return None for missing paths
- [ ] Task 5: Return correct types (AC: 5)
  - [ ] Subtask 5.1: Preserve original JSON types
  - [ ] Subtask 5.2: Format numbers appropriately for display
- [ ] Task 6: Write unit tests for JSONSource

## Technical Notes
- Use built-in json module
- Consider jsonpath-ng for advanced path support
- May need to coerce types for widget consumption

## Dependencies
- Requires: Story 4.2, Story 4.3

---

## Story 4.5: Add Refresh Interval Scheduling

**Status:** draft
**Epic:** Data Connectors
**Priority:** P0

## User Story
As a user, I want widgets to refresh automatically at configurable intervals so that I see updated data without manual intervention.

## Acceptance Criteria
1. **AC-4.5.1:** Scheduler tracks refresh times for all data sources
2. **AC-4.5.2:** Scheduler triggers fetch only when source is stale
3. **AC-4.5.3:** Scheduler enforces minimum refresh interval (100ms)
4. **AC-4.5.4:** Scheduler handles overlapping refresh requests efficiently
5. **AC-4.5.5:** Scheduler supports dashboard-wide default interval with per-widget override

## Tasks
- [ ] Task 1: Create Scheduler class (AC: 1)
  - [ ] Subtask 1.1: Track list of (source, next_refresh) tuples
  - [ ] Subtask 1.2: Calculate next refresh based on interval
- [ ] Task 2: Implement staleness-based refresh (AC: 2)
  - [ ] Subtask 2.1: Call source.is_stale() before fetch
  - [ ] Subtask 2.2: Only fetch if stale
  - [ ] Subtask 2.3: Update next_refresh after fetch
- [ ] Task 3: Enforce minimum interval (AC: 3)
  - [ ] Subtask 3.1: Define MIN_REFRESH_INTERVAL constant
  - [ ] Subtask 3.2: Clamp intervals below minimum
  - [ ] Subtask 3.3: Log warning when clamping
- [ ] Task 4: Handle concurrent refreshes (AC: 4)
  - [ ] Subtask 4.1: Batch refreshes that are due together
  - [ ] Subtask 4.2: Use asyncio or threading for parallel fetch
  - [ ] Subtask 4.3: Prevent duplicate refreshes for same source
- [ ] Task 5: Implement interval hierarchy (AC: 5)
  - [ ] Subtask 5.1: Read default from dashboard config
  - [ ] Subtask 5.2: Override with widget-specific interval
  - [ ] Subtask 5.3: Parse interval strings ("1s", "500ms")
- [ ] Task 6: Write integration tests for scheduling

## Technical Notes
- Use heapq for efficient next-due-source lookup
- Consider asyncio for non-blocking I/O
- Rich Live handles display refresh separately

## Dependencies
- Requires: Story 4.1
