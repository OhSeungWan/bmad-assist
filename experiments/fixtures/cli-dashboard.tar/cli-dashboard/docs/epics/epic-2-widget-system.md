---
epic_num: 2
title: Widget System
status: draft
---

# Epic 2: Widget System

**Status:** Backlog
**Priority:** P0
**Stories:** 6

## Overview

Core widget implementations using Rich library. Each widget type handles its own rendering and data source binding. Widgets follow a common interface for consistency and maintainability.

## Stories

---

## Story 2.1: Create Base Widget Interface

**Status:** draft
**Epic:** Widget System
**Priority:** P0

## User Story
As a developer, I want a base widget interface so that all widgets have consistent behavior and can be used interchangeably by the layout engine.

## Acceptance Criteria
1. **AC-2.1.1:** BaseWidget abstract class defines render() method returning Rich RenderableType
2. **AC-2.1.2:** BaseWidget defines update() method for fetching new data from source
3. **AC-2.1.3:** BaseWidget stores last data and last error state
4. **AC-2.1.4:** BaseWidget accepts WidgetConfig and DataSource in constructor
5. **AC-2.1.5:** BaseWidget provides render_error() method for displaying error states

## Tasks
- [ ] Task 1: Create BaseWidget abstract class (AC: 1, 2)
  - [ ] Subtask 1.1: Define abstract render() method
  - [ ] Subtask 1.2: Define update() method with data source fetch
  - [ ] Subtask 1.3: Add type hints for Rich RenderableType
- [ ] Task 2: Implement state management (AC: 3)
  - [ ] Subtask 2.1: Add _last_data property
  - [ ] Subtask 2.2: Add _last_error property
  - [ ] Subtask 2.3: Update state in update() method
- [ ] Task 3: Define constructor signature (AC: 4)
  - [ ] Subtask 3.1: Accept WidgetConfig parameter
  - [ ] Subtask 3.2: Accept DataSource parameter
  - [ ] Subtask 3.3: Store as instance attributes
- [ ] Task 4: Implement error rendering (AC: 5)
  - [ ] Subtask 4.1: Create render_error() method
  - [ ] Subtask 4.2: Return Rich Panel with error styling
- [ ] Task 5: Write unit tests for BaseWidget behavior

## Technical Notes
- Use ABC from abc module for abstract class
- RenderableType comes from rich.console
- Consider adding optional refresh_interval override per widget

## Dependencies
- Requires: Story 1.2

---

## Story 2.2: Implement Text Widget

**Status:** draft
**Epic:** Widget System
**Priority:** P0

## User Story
As a user, I want a text widget to display static or dynamic text content so that I can show simple information like uptime or status messages.

## Acceptance Criteria
1. **AC-2.2.1:** TextWidget renders data as text inside a Rich Panel
2. **AC-2.2.2:** TextWidget displays configured title in panel header
3. **AC-2.2.3:** TextWidget handles multiline text with proper wrapping
4. **AC-2.2.4:** TextWidget shows placeholder when no data available
5. **AC-2.2.5:** TextWidget applies theme colors from configuration

## Tasks
- [ ] Task 1: Create TextWidget class extending BaseWidget (AC: 1)
  - [ ] Subtask 1.1: Implement render() returning Panel(Text(...))
  - [ ] Subtask 1.2: Use _last_data as text content
- [ ] Task 2: Add title support (AC: 2)
  - [ ] Subtask 2.1: Extract title from config
  - [ ] Subtask 2.2: Pass title to Panel constructor
- [ ] Task 3: Handle multiline text (AC: 3)
  - [ ] Subtask 3.1: Configure Rich Text with overflow="fold"
  - [ ] Subtask 3.2: Test with various line lengths
- [ ] Task 4: Implement placeholder (AC: 4)
  - [ ] Subtask 4.1: Show "No data" when _last_data is None
  - [ ] Subtask 4.2: Style placeholder with muted color
- [ ] Task 5: Apply theming (AC: 5)
  - [ ] Subtask 5.1: Get colors from theme configuration
  - [ ] Subtask 5.2: Apply to panel border and text
- [ ] Task 6: Write unit tests for TextWidget

## Technical Notes
- Rich Panel supports title parameter
- Use style parameter for theming
- Consider supporting Rich markup in text content

## Dependencies
- Requires: Story 2.1

---

## Story 2.3: Implement Table Widget

**Status:** draft
**Epic:** Widget System
**Priority:** P0

## User Story
As a user, I want a table widget to display tabular data so that I can show lists of processes, logs, or other structured data.

## Acceptance Criteria
1. **AC-2.3.1:** TableWidget renders data as Rich Table
2. **AC-2.3.2:** TableWidget automatically detects headers from first row or data keys
3. **AC-2.3.3:** TableWidget supports column alignment configuration (left, center, right)
4. **AC-2.3.4:** TableWidget handles missing data in rows gracefully
5. **AC-2.3.5:** TableWidget respects column width limits with truncation

## Tasks
- [ ] Task 1: Create TableWidget class extending BaseWidget (AC: 1)
  - [ ] Subtask 1.1: Implement render() returning Rich Table
  - [ ] Subtask 1.2: Parse _last_data as rows
- [ ] Task 2: Implement header detection (AC: 2)
  - [ ] Subtask 2.1: If data is list of dicts, use keys as headers
  - [ ] Subtask 2.2: If data is list of lists, use first row as headers
  - [ ] Subtask 2.3: Support explicit header config override
- [ ] Task 3: Add column alignment (AC: 3)
  - [ ] Subtask 3.1: Accept alignment config per column
  - [ ] Subtask 3.2: Apply justify parameter to table.add_column()
- [ ] Task 4: Handle missing data (AC: 4)
  - [ ] Subtask 4.1: Fill missing values with empty string
  - [ ] Subtask 4.2: Handle rows with different lengths
- [ ] Task 5: Implement column truncation (AC: 5)
  - [ ] Subtask 5.1: Accept max_width config
  - [ ] Subtask 5.2: Truncate with ellipsis
- [ ] Task 6: Write unit tests for TableWidget

## Technical Notes
- Rich Table has add_column() and add_row() methods
- Table supports no_wrap parameter for truncation
- Consider supporting row highlighting for alternating colors

## Dependencies
- Requires: Story 2.1

---

## Story 2.4: Implement Bar Chart Widget

**Status:** draft
**Epic:** Widget System
**Priority:** P1

## User Story
As a user, I want a bar chart widget to visualize numerical data so that I can see relative values at a glance.

## Acceptance Criteria
1. **AC-2.4.1:** BarChartWidget renders horizontal bars using block characters
2. **AC-2.4.2:** BarChartWidget displays labels next to each bar
3. **AC-2.4.3:** BarChartWidget scales bars relative to maximum value
4. **AC-2.4.4:** BarChartWidget supports configurable bar colors
5. **AC-2.4.5:** BarChartWidget displays values at end of bars

## Tasks
- [ ] Task 1: Create BarChartWidget class extending BaseWidget (AC: 1)
  - [ ] Subtask 1.1: Implement render() returning Panel with bar content
  - [ ] Subtask 1.2: Use Unicode block characters (█ ▓ ▒ ░)
- [ ] Task 2: Add labels (AC: 2)
  - [ ] Subtask 2.1: Parse label:value pairs from data
  - [ ] Subtask 2.2: Left-align labels with consistent width
- [ ] Task 3: Implement bar scaling (AC: 3)
  - [ ] Subtask 3.1: Find maximum value in dataset
  - [ ] Subtask 3.2: Calculate bar width as percentage of max
  - [ ] Subtask 3.3: Scale to available terminal width
- [ ] Task 4: Add color support (AC: 4)
  - [ ] Subtask 4.1: Accept bar_color config
  - [ ] Subtask 4.2: Apply Rich style to bar characters
- [ ] Task 5: Display values (AC: 5)
  - [ ] Subtask 5.1: Show value after bar
  - [ ] Subtask 5.2: Format numbers appropriately (int vs float)
- [ ] Task 6: Write unit tests for BarChartWidget

## Technical Notes
- Use Rich Text with styled block characters
- Consider supporting fractional blocks for precision
- Handle zero and negative values gracefully

## Dependencies
- Requires: Story 2.1

---

## Story 2.5: Implement Progress Bar Widget

**Status:** draft
**Epic:** Widget System
**Priority:** P0

## User Story
As a user, I want a progress bar widget to show completion percentage so that I can monitor tasks, resource usage, or other progress metrics.

## Acceptance Criteria
1. **AC-2.5.1:** ProgressWidget renders Rich Progress bar
2. **AC-2.5.2:** ProgressWidget displays percentage value
3. **AC-2.5.3:** ProgressWidget supports custom colors based on value ranges
4. **AC-2.5.4:** ProgressWidget handles values outside 0-100 range gracefully
5. **AC-2.5.5:** ProgressWidget displays optional ETA or time elapsed

## Tasks
- [ ] Task 1: Create ProgressWidget class extending BaseWidget (AC: 1)
  - [ ] Subtask 1.1: Implement render() returning Progress bar
  - [ ] Subtask 1.2: Parse _last_data as numeric percentage
- [ ] Task 2: Display percentage (AC: 2)
  - [ ] Subtask 2.1: Format value with % suffix
  - [ ] Subtask 2.2: Position after progress bar
- [ ] Task 3: Implement color ranges (AC: 3)
  - [ ] Subtask 3.1: Accept thresholds config (e.g., 80% warning, 95% danger)
  - [ ] Subtask 3.2: Apply different colors based on value
- [ ] Task 4: Handle edge cases (AC: 4)
  - [ ] Subtask 4.1: Clamp values to 0-100
  - [ ] Subtask 4.2: Handle non-numeric data with error state
- [ ] Task 5: Add ETA support (AC: 5)
  - [ ] Subtask 5.1: Accept show_eta config
  - [ ] Subtask 5.2: Calculate ETA from progress rate
- [ ] Task 6: Write unit tests for ProgressWidget

## Technical Notes
- Rich Progress has BarColumn, TextColumn, etc.
- For single progress bars, may use simpler Panel approach
- Consider using ProgressBar from rich.progress_bar

## Dependencies
- Requires: Story 2.1

---

## Story 2.6: Implement Sparkline Widget

**Status:** draft
**Epic:** Widget System
**Priority:** P1

## User Story
As a user, I want a sparkline widget to show trends over time so that I can visualize historical data in a compact format.

## Acceptance Criteria
1. **AC-2.6.1:** SparklineWidget renders mini line chart using braille characters
2. **AC-2.6.2:** SparklineWidget accepts list of numeric values as data
3. **AC-2.6.3:** SparklineWidget auto-scales Y-axis to data range
4. **AC-2.6.4:** SparklineWidget supports configurable width (number of points)
5. **AC-2.6.5:** SparklineWidget shows current value alongside chart

## Tasks
- [ ] Task 1: Create SparklineWidget class extending BaseWidget (AC: 1)
  - [ ] Subtask 1.1: Implement render() returning sparkline text
  - [ ] Subtask 1.2: Use braille characters for mini chart (⣀ ⣤ ⣶ ⣿)
- [ ] Task 2: Parse data as numeric list (AC: 2)
  - [ ] Subtask 2.1: Accept JSON array from data source
  - [ ] Subtask 2.2: Handle comma-separated string format
- [ ] Task 3: Implement Y-axis scaling (AC: 3)
  - [ ] Subtask 3.1: Find min and max in dataset
  - [ ] Subtask 3.2: Scale values to available height (braille has 4 levels)
- [ ] Task 4: Configure width (AC: 4)
  - [ ] Subtask 4.1: Accept max_points config
  - [ ] Subtask 4.2: Take last N points if data exceeds limit
- [ ] Task 5: Show current value (AC: 5)
  - [ ] Subtask 5.1: Display last value next to sparkline
  - [ ] Subtask 5.2: Format appropriately (int/float/percentage)
- [ ] Task 6: Write unit tests for SparklineWidget

## Technical Notes
- Braille characters offer 8 vertical positions per character
- Consider using plotext library for more sophisticated charts
- Handle empty data gracefully

## Dependencies
- Requires: Story 2.1
