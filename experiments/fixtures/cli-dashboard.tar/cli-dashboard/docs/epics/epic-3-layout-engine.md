---
epic_num: 3
title: Layout Engine
status: draft
---

# Epic 3: Layout Engine

**Status:** Backlog
**Priority:** P1
**Stories:** 4

## Overview

Grid-based layout system for arranging widgets. Handles terminal sizing, widget placement, and responsive behavior. Coordinates with the widget system to render the complete dashboard.

## Stories

---

## Story 3.1: Implement Grid Layout Container

**Status:** draft
**Epic:** Layout Engine
**Priority:** P0

## User Story
As a user, I want a grid layout system so that I can arrange widgets in rows and columns for an organized dashboard display.

## Acceptance Criteria
1. **AC-3.1.1:** Grid container divides terminal width into configurable number of columns
2. **AC-3.1.2:** Grid container arranges widgets in rows as specified in configuration
3. **AC-3.1.3:** Grid container calculates widget widths based on column count and spans
4. **AC-3.1.4:** Grid container renders all widgets using Rich Layout/Table
5. **AC-3.1.5:** Grid container handles empty rows gracefully

## Tasks
- [ ] Task 1: Create Grid class in layout/grid.py (AC: 1)
  - [ ] Subtask 1.1: Accept column count in constructor
  - [ ] Subtask 1.2: Calculate column width based on terminal width
- [ ] Task 2: Implement row management (AC: 2)
  - [ ] Subtask 2.1: Store rows as list of widget lists
  - [ ] Subtask 2.2: Add widgets to rows based on configuration
- [ ] Task 3: Calculate widget widths (AC: 3)
  - [ ] Subtask 3.1: Determine width from span and column count
  - [ ] Subtask 3.2: Handle widgets that don't fill row completely
- [ ] Task 4: Render grid using Rich (AC: 4)
  - [ ] Subtask 4.1: Use Rich Table for grid structure
  - [ ] Subtask 4.2: Add each widget as table cell
  - [ ] Subtask 4.3: Configure table borders and padding
- [ ] Task 5: Handle empty rows (AC: 5)
  - [ ] Subtask 5.1: Skip rendering of empty rows
  - [ ] Subtask 5.2: Or render spacer if explicit height set
- [ ] Task 6: Write unit tests for Grid layout

## Technical Notes
- Rich Table can be used as a grid with expand=True
- Consider using Rich Layout for more complex arrangements
- Terminal width available via console.width

## Dependencies
- Requires: Story 2.1

---

## Story 3.2: Add Row and Column Span Support

**Status:** draft
**Epic:** Layout Engine
**Priority:** P0

## User Story
As a user, I want widgets to span multiple columns so that I can create varied layouts with different widget sizes.

## Acceptance Criteria
1. **AC-3.2.1:** Widgets can span multiple columns using span configuration
2. **AC-3.2.2:** Widgets respect span limits (cannot exceed remaining columns in row)
3. **AC-3.2.3:** Row automatically wraps to next line when span would exceed
4. **AC-3.2.4:** Default span is 1 if not specified
5. **AC-3.2.5:** Validation error if span exceeds total column count

## Tasks
- [ ] Task 1: Implement column spanning (AC: 1)
  - [ ] Subtask 1.1: Read span from widget configuration
  - [ ] Subtask 1.2: Calculate width as span * column_width
  - [ ] Subtask 1.3: Apply colspan to Rich Table cell
- [ ] Task 2: Validate span limits (AC: 2, 5)
  - [ ] Subtask 2.1: Check span <= remaining columns in row
  - [ ] Subtask 2.2: Check span <= total columns during config validation
- [ ] Task 3: Implement row wrapping (AC: 3)
  - [ ] Subtask 3.1: Track current column position
  - [ ] Subtask 3.2: Start new row when widget doesn't fit
- [ ] Task 4: Set default span (AC: 4)
  - [ ] Subtask 4.1: Default span to 1 in Pydantic model
  - [ ] Subtask 4.2: Test widgets without explicit span
- [ ] Task 5: Write unit tests for spanning behavior

## Technical Notes
- Rich Table supports colspan parameter
- Consider logging when row wrap occurs for debugging
- May need ratio-based width for fractional columns

## Dependencies
- Requires: Story 3.1

---

## Story 3.3: Implement Widget Padding and Borders

**Status:** draft
**Epic:** Layout Engine
**Priority:** P1

## User Story
As a user, I want to configure padding and borders for widgets so that I can create visually distinct and well-spaced layouts.

## Acceptance Criteria
1. **AC-3.3.1:** Widgets support configurable padding (top, right, bottom, left)
2. **AC-3.3.2:** Widgets support border style configuration (none, single, double, rounded)
3. **AC-3.3.3:** Grid supports gutter spacing between widgets
4. **AC-3.3.4:** Border colors can be customized per widget or globally
5. **AC-3.3.5:** Padding and border styles apply consistently across all widget types

## Tasks
- [ ] Task 1: Implement padding configuration (AC: 1)
  - [ ] Subtask 1.1: Add padding config to WidgetConfig
  - [ ] Subtask 1.2: Apply padding using Rich Padding wrapper
  - [ ] Subtask 1.3: Support shorthand (single value = all sides)
- [ ] Task 2: Implement border styles (AC: 2)
  - [ ] Subtask 2.1: Add border_style config to WidgetConfig
  - [ ] Subtask 2.2: Map to Rich box styles (SQUARE, ROUNDED, DOUBLE)
  - [ ] Subtask 2.3: Support "none" for borderless
- [ ] Task 3: Add grid gutter (AC: 3)
  - [ ] Subtask 3.1: Add gutter config to LayoutConfig
  - [ ] Subtask 3.2: Apply spacing between table cells
- [ ] Task 4: Customize border colors (AC: 4)
  - [ ] Subtask 4.1: Add border_color to WidgetConfig
  - [ ] Subtask 4.2: Inherit from theme if not specified
- [ ] Task 5: Ensure consistency (AC: 5)
  - [ ] Subtask 5.1: Apply in BaseWidget.render()
  - [ ] Subtask 5.2: Test with all widget types
- [ ] Task 6: Write unit tests for styling

## Technical Notes
- Rich Panel accepts box parameter for border style
- Padding wrapper: `Padding(content, (top, right, bottom, left))`
- Consider default padding for readability

## Dependencies
- Requires: Story 3.2

---

## Story 3.4: Add Responsive Terminal Size Handling

**Status:** draft
**Epic:** Layout Engine
**Priority:** P1

## User Story
As a user, I want the dashboard to adapt when I resize my terminal so that widgets remain readable and properly arranged.

## Acceptance Criteria
1. **AC-3.4.1:** Dashboard detects terminal size changes
2. **AC-3.4.2:** Grid recalculates column widths on resize
3. **AC-3.4.3:** Widgets re-render with new dimensions
4. **AC-3.4.4:** Minimum terminal width is enforced with warning message
5. **AC-3.4.5:** Dashboard handles very narrow terminals gracefully (stack widgets)

## Tasks
- [ ] Task 1: Detect terminal resize (AC: 1)
  - [ ] Subtask 1.1: Use signal handler for SIGWINCH (Unix)
  - [ ] Subtask 1.2: Poll console.size for cross-platform support
  - [ ] Subtask 1.3: Integrate with Rich Live display
- [ ] Task 2: Recalculate layout on resize (AC: 2)
  - [ ] Subtask 2.1: Store current terminal dimensions
  - [ ] Subtask 2.2: Compare with new dimensions on resize
  - [ ] Subtask 2.3: Trigger layout recalculation
- [ ] Task 3: Re-render widgets (AC: 3)
  - [ ] Subtask 3.1: Clear and rebuild grid
  - [ ] Subtask 3.2: Preserve widget data state
  - [ ] Subtask 3.3: Update Rich Live display
- [ ] Task 4: Enforce minimum width (AC: 4)
  - [ ] Subtask 4.1: Define minimum width (e.g., 60 columns)
  - [ ] Subtask 4.2: Show warning if below minimum
  - [ ] Subtask 4.3: Continue rendering best-effort
- [ ] Task 5: Handle narrow terminals (AC: 5)
  - [ ] Subtask 5.1: Stack widgets vertically below threshold
  - [ ] Subtask 5.2: Or truncate/hide less important widgets
- [ ] Task 6: Write integration tests for resize handling

## Technical Notes
- Rich Live auto-handles terminal refresh
- Rich console.size gives (width, height) tuple
- SIGWINCH only available on Unix systems

## Dependencies
- Requires: Story 3.2
