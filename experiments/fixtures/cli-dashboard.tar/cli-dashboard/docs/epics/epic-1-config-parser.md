---
epic_num: 1
title: Config Parser
status: draft
---

# Epic 1: Config Parser

**Status:** Backlog
**Priority:** P0
**Stories:** 5

## Overview

Foundation layer for parsing and validating YAML dashboard configurations. Establishes the Pydantic schema models and validation logic that all other components depend on.

## Stories

---

## Story 1.1: Define YAML Schema for Dashboard Config

**Status:** draft
**Epic:** Config Parser
**Priority:** P0

## User Story
As a developer, I want a well-defined YAML schema for dashboard configuration so that I can validate and document the expected configuration format.

## Acceptance Criteria
1. **AC-1.1.1:** Schema supports `dashboard` section with title, refresh interval, and theme
2. **AC-1.1.2:** Schema supports `layout` section with columns and rows configuration
3. **AC-1.1.3:** Schema supports widget definitions within rows including type, title, span, and source
4. **AC-1.1.4:** Schema supports source configuration with type-specific fields (command, file, json)
5. **AC-1.1.5:** Schema documentation exists as comments in example config file

## Tasks
- [ ] Task 1: Define dashboard metadata schema (title, refresh, theme) (AC: 1)
  - [ ] Subtask 1.1: Create DashboardMeta fields with types
  - [ ] Subtask 1.2: Define valid theme values (light, dark)
  - [ ] Subtask 1.3: Define refresh interval format (e.g., "1s", "500ms")
- [ ] Task 2: Define layout schema (columns, rows) (AC: 2)
  - [ ] Subtask 2.1: Create LayoutConfig with columns field
  - [ ] Subtask 2.2: Define RowConfig with height and widgets list
- [ ] Task 3: Define widget schema with all widget types (AC: 3)
  - [ ] Subtask 3.1: Create WidgetType enum (text, table, chart, progress, sparkline)
  - [ ] Subtask 3.2: Define WidgetConfig with common fields
- [ ] Task 4: Define source configuration schema (AC: 4)
  - [ ] Subtask 4.1: Create SourceType enum (command, file, json)
  - [ ] Subtask 4.2: Define source-specific fields (command string, file path, etc.)
- [ ] Task 5: Create example configuration file with schema documentation (AC: 5)

## Technical Notes
- Use Pydantic discriminated unions for source types
- Refresh interval should accept human-readable format (1s, 500ms, 2m)
- Default column count should be 12 (standard grid)

## Dependencies
- Requires: None

---

## Story 1.2: Implement Config Parser with Pydantic Models

**Status:** draft
**Epic:** Config Parser
**Priority:** P0

## User Story
As a developer, I want to parse YAML configuration files into type-safe Pydantic models so that I can access configuration with IDE support and runtime validation.

## Acceptance Criteria
1. **AC-1.2.1:** Parser loads YAML file and returns DashboardConfig Pydantic model
2. **AC-1.2.2:** Parser raises ConfigError for invalid YAML syntax
3. **AC-1.2.3:** Parser raises ConfigError for missing required fields
4. **AC-1.2.4:** Parser sets default values for optional fields
5. **AC-1.2.5:** Pydantic models have proper type hints and field descriptions

## Tasks
- [ ] Task 1: Create Pydantic models in config/schema.py (AC: 5)
  - [ ] Subtask 1.1: Create DashboardConfig root model
  - [ ] Subtask 1.2: Create nested models (LayoutConfig, RowConfig, WidgetConfig)
  - [ ] Subtask 1.3: Add Field descriptions for documentation
- [ ] Task 2: Implement YAML parser in config/parser.py (AC: 1)
  - [ ] Subtask 2.1: Create parse_config(path: Path) function
  - [ ] Subtask 2.2: Load YAML with PyYAML
  - [ ] Subtask 2.3: Instantiate and return DashboardConfig
- [ ] Task 3: Handle YAML syntax errors (AC: 2)
  - [ ] Subtask 3.1: Catch yaml.YAMLError
  - [ ] Subtask 3.2: Create ConfigError with line number
- [ ] Task 4: Handle missing required fields (AC: 3)
  - [ ] Subtask 4.1: Catch Pydantic ValidationError
  - [ ] Subtask 4.2: Format error message with field path
- [ ] Task 5: Define and test default values (AC: 4)
  - [ ] Subtask 5.1: Set default theme to "dark"
  - [ ] Subtask 5.2: Set default refresh to "1s"
  - [ ] Subtask 5.3: Set default span to 1

## Technical Notes
- Use `yaml.safe_load()` for security
- Preserve YAML line numbers in errors using ruamel.yaml if needed
- Models should be serializable back to YAML

## Dependencies
- Requires: Story 1.1

---

## Story 1.3: Add Config Validation with Error Messages

**Status:** draft
**Epic:** Config Parser
**Priority:** P0

## User Story
As a user, I want helpful error messages when my configuration is invalid so that I can quickly fix issues without guessing.

## Acceptance Criteria
1. **AC-1.3.1:** Validation errors include the field path (e.g., "layout.rows[0].widgets[1].span")
2. **AC-1.3.2:** Validation errors explain what value was expected vs received
3. **AC-1.3.3:** Validator checks that widget spans don't exceed column count
4. **AC-1.3.4:** Validator checks that source configuration is complete for each type
5. **AC-1.3.5:** Validator provides suggestions for common mistakes (e.g., typos in widget type)

## Tasks
- [ ] Task 1: Create custom Pydantic validators (AC: 3, 4)
  - [ ] Subtask 1.1: Add span validation against layout columns
  - [ ] Subtask 1.2: Add source completeness validation per type
- [ ] Task 2: Format Pydantic errors with field paths (AC: 1)
  - [ ] Subtask 2.1: Create error formatter function
  - [ ] Subtask 2.2: Convert Pydantic error locations to dot notation
- [ ] Task 3: Add expected vs received to error messages (AC: 2)
  - [ ] Subtask 3.1: Extract expected type from Pydantic error
  - [ ] Subtask 3.2: Include actual value in message
- [ ] Task 4: Implement typo suggestions (AC: 5)
  - [ ] Subtask 4.1: Create string similarity function
  - [ ] Subtask 4.2: Suggest similar valid values for enum errors
- [ ] Task 5: Write unit tests for all validation scenarios

## Technical Notes
- Use Pydantic `model_validator` for cross-field validation
- Consider using `difflib.get_close_matches()` for suggestions
- Error messages should be concise but actionable

## Dependencies
- Requires: Story 1.2

---

## Story 1.4: Support Variable Interpolation in Config

**Status:** draft
**Epic:** Config Parser
**Priority:** P1

## User Story
As a user, I want to use environment variables and references in my configuration so that I can reuse values and keep secrets out of config files.

## Acceptance Criteria
1. **AC-1.4.1:** Parser resolves `${ENV_VAR}` to environment variable values
2. **AC-1.4.2:** Parser resolves `${ENV_VAR:-default}` with default fallback
3. **AC-1.4.3:** Parser raises error for unset variables without defaults
4. **AC-1.4.4:** Interpolation works in string fields throughout the config
5. **AC-1.4.5:** Special characters in variable values are properly escaped

## Tasks
- [ ] Task 1: Create variable resolver module (AC: 1, 2)
  - [ ] Subtask 1.1: Implement regex to find `${...}` patterns
  - [ ] Subtask 1.2: Parse variable name and optional default
  - [ ] Subtask 1.3: Lookup value from os.environ
- [ ] Task 2: Handle missing variables (AC: 3)
  - [ ] Subtask 2.1: Raise ConfigError with variable name
  - [ ] Subtask 2.2: Include context (which field references it)
- [ ] Task 3: Integrate resolver into parser (AC: 4)
  - [ ] Subtask 3.1: Pre-process YAML string before parsing
  - [ ] Subtask 3.2: Apply interpolation recursively to all strings
- [ ] Task 4: Handle special characters (AC: 5)
  - [ ] Subtask 4.1: Test with quotes, newlines, YAML special chars
  - [ ] Subtask 4.2: Properly escape values to preserve YAML validity
- [ ] Task 5: Write unit tests for interpolation scenarios

## Technical Notes
- Process interpolation before YAML parsing to avoid type issues
- Consider supporting `${ref:widget.id}` for internal references (future)
- Document all supported interpolation patterns

## Dependencies
- Requires: Story 1.2

---

## Story 1.5: Add Config File Watching for Live Reload

**Status:** draft
**Epic:** Config Parser
**Priority:** P2

## User Story
As a user, I want the dashboard to automatically reload when I edit the config file so that I can iterate quickly without restarting.

## Acceptance Criteria
1. **AC-1.5.1:** Dashboard watches config file for modifications
2. **AC-1.5.2:** Dashboard reloads and re-renders when config changes
3. **AC-1.5.3:** Invalid config changes show error but don't crash dashboard
4. **AC-1.5.4:** File watcher handles file deletion gracefully
5. **AC-1.5.5:** Live reload can be disabled via CLI flag or config option

## Tasks
- [ ] Task 1: Implement file watcher (AC: 1)
  - [ ] Subtask 1.1: Use watchdog library or poll-based watching
  - [ ] Subtask 1.2: Create ConfigWatcher class
  - [ ] Subtask 1.3: Emit callback on file modification
- [ ] Task 2: Integrate watcher with dashboard lifecycle (AC: 2)
  - [ ] Subtask 2.1: Register reload callback
  - [ ] Subtask 2.2: Re-parse config on change
  - [ ] Subtask 2.3: Rebuild widgets and layout
- [ ] Task 3: Handle validation errors gracefully (AC: 3)
  - [ ] Subtask 3.1: Catch ConfigError during reload
  - [ ] Subtask 3.2: Log error and keep current config
  - [ ] Subtask 3.3: Optionally show error notification in dashboard
- [ ] Task 4: Handle file deletion (AC: 4)
  - [ ] Subtask 4.1: Detect deletion event
  - [ ] Subtask 4.2: Log warning and keep current config
- [ ] Task 5: Add disable option (AC: 5)
  - [ ] Subtask 5.1: Add --no-watch CLI flag
  - [ ] Subtask 5.2: Add watch: false config option
- [ ] Task 6: Write integration tests for file watching

## Technical Notes
- Consider debouncing rapid file changes (editor save behavior)
- Use threading or asyncio for non-blocking file watching
- On Windows, file watching may require different approach

## Dependencies
- Requires: Story 1.3
