# Technical Architecture: Webhook Relay Service

## Overview

The Webhook Relay Service is a high-performance Go application that receives webhooks, transforms payloads, and delivers them to configured destinations with retry logic. The architecture prioritizes throughput, reliability, and operational simplicity.

## Tech Stack

| Component | Technology | Version |
|-----------|------------|---------|
| Language | Go | 1.21+ |
| Web Framework | chi router | v5 |
| Database | SQLite (modernc.org/sqlite) | Pure Go |
| Metrics | Prometheus client | v1.17+ |
| Config | YAML + envconfig | - |
| Testing | go test + testify | v1.8+ |
| Linting | golangci-lint | v1.55+ |

## System Components

```
┌─────────────────────────────────────────────────────────────────────┐
│                        Webhook Relay Service                         │
├─────────────────────────────────────────────────────────────────────┤
│                                                                      │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐          │
│  │   Receiver   │───▶│  Transformer │───▶│   Delivery   │          │
│  │   Handler    │    │   Pipeline   │    │    Engine    │          │
│  └──────────────┘    └──────────────┘    └──────────────┘          │
│         │                   │                   │                   │
│         ▼                   ▼                   ▼                   │
│  ┌──────────────┐    ┌──────────────┐    ┌──────────────┐          │
│  │   Signature  │    │   JSONPath   │    │    Retry     │          │
│  │  Validator   │    │   Template   │    │    Queue     │          │
│  └──────────────┘    └──────────────┘    └──────────────┘          │
│                                                │                    │
│                                                ▼                    │
│  ┌──────────────┐                       ┌──────────────┐           │
│  │  Admin API   │                       │     DLQ      │           │
│  │   Handler    │                       │   Storage    │           │
│  └──────────────┘                       └──────────────┘           │
│         │                                      │                    │
│         └──────────────────┬───────────────────┘                   │
│                            ▼                                        │
│                     ┌──────────────┐                               │
│                     │    SQLite    │                               │
│                     │   Storage    │                               │
│                     └──────────────┘                               │
│                                                                      │
├─────────────────────────────────────────────────────────────────────┤
│  Observability: Prometheus Metrics │ Health Check │ Structured Logs │
└─────────────────────────────────────────────────────────────────────┘
```

## Data Flow

### Webhook Reception Flow

```
┌──────────┐    ┌──────────┐    ┌──────────┐    ┌──────────┐
│ Incoming │    │ Signature│    │  Route   │    │  Queue   │
│ Webhook  │───▶│  Verify  │───▶│  Lookup  │───▶│ Delivery │
└──────────┘    └──────────┘    └──────────┘    └──────────┘
                     │                               │
                     ▼                               ▼
              ┌──────────┐                   ┌──────────┐
              │  Reject  │                   │Transform │
              │  (401)   │                   │ Payload  │
              └──────────┘                   └──────────┘
                                                   │
                    ┌──────────────────────────────┤
                    ▼                              ▼
             ┌──────────┐                  ┌──────────┐
             │   Dest   │                  │   Dest   │
             │    A     │                  │    B     │
             └──────────┘                  └──────────┘
```

### Delivery Retry Flow

```
┌──────────┐    ┌──────────┐    ┌──────────┐    ┌──────────┐
│ Delivery │    │  HTTP    │    │ Success? │───▶│  Record  │
│  Attempt │───▶│  Send    │───▶│   Yes    │    │ Success  │
└──────────┘    └──────────┘    └──────────┘    └──────────┘
                                     │
                                     ▼ No
                              ┌──────────┐
                              │ Retries  │
                              │  Left?   │
                              └──────────┘
                                │      │
                           Yes ▼      ▼ No
                        ┌──────────┐ ┌──────────┐
                        │  Queue   │ │  Move    │
                        │  Retry   │ │  to DLQ  │
                        └──────────┘ └──────────┘
```

## API Design

### Webhook Receiver Endpoints

| Method | Path | Description |
|--------|------|-------------|
| POST | `/webhook/{route_id}` | Receive webhook for route |
| POST | `/webhook/{route_id}/{secret}` | Receive webhook with URL secret |

### Admin API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | `/admin/routes` | List all routes |
| POST | `/admin/routes` | Create route |
| GET | `/admin/routes/{id}` | Get route details |
| PUT | `/admin/routes/{id}` | Update route |
| DELETE | `/admin/routes/{id}` | Delete route |
| GET | `/admin/routes/{id}/destinations` | List destinations |
| POST | `/admin/routes/{id}/destinations` | Add destination |
| DELETE | `/admin/destinations/{id}` | Remove destination |
| GET | `/admin/deliveries` | Query delivery history |
| GET | `/admin/dead-letter-queue` | List DLQ entries |
| POST | `/admin/dead-letter-queue/{id}/replay` | Replay DLQ entry |
| DELETE | `/admin/dead-letter-queue/{id}` | Delete DLQ entry |

### Observability Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | `/metrics` | Prometheus metrics |
| GET | `/health` | Health check |
| GET | `/health/ready` | Readiness probe |
| GET | `/health/live` | Liveness probe |

## Architecture Decision Records

### ADR-001: Go over Rust

**Status:** Accepted

**Context:** Need to choose a language for a high-concurrency network service.

**Decision:** Use Go 1.21+ for the implementation.

**Rationale:**
- Excellent goroutine-based concurrency model
- Fast compilation and development cycle
- Strong standard library for HTTP and networking
- Simpler learning curve and maintenance

**Trade-offs:**
- Less memory efficient than Rust
- No compile-time memory safety guarantees
- Garbage collection pauses (mitigated by Go's low-latency GC)

### ADR-002: SQLite over Redis for Queue

**Status:** Accepted

**Context:** Need persistent storage for delivery queue and dead letter queue.

**Decision:** Use SQLite (modernc.org/sqlite pure Go driver) for all persistence.

**Rationale:**
- Single binary deployment (no external dependencies)
- ACID transactions for delivery guarantees
- Sufficient throughput for 1K req/s target
- Simple backup (single file)

**Trade-offs:**
- Lower throughput than Redis
- Single-node only (no clustering)
- Write lock contention under very high load

### ADR-003: In-Memory Routing Table

**Status:** Accepted

**Context:** Need fast route lookup for incoming webhooks.

**Decision:** Cache routing configuration in memory, use SQLite for persistence only.

**Rationale:**
- O(1) route lookup latency
- Routes change infrequently
- Memory footprint is small (hundreds of routes at most)

**Trade-offs:**
- Startup time includes loading all routes
- Memory usage proportional to route count
- Requires cache invalidation on updates

### ADR-004: Synchronous Delivery with Goroutines

**Status:** Accepted

**Context:** Need to deliver webhooks to destinations with retry capability.

**Decision:** Use synchronous per-request delivery with goroutines, not async workers.

**Rationale:**
- Simpler implementation and debugging
- Natural backpressure through goroutine count
- Each request handles its own retries
- Easier to trace delivery lifecycle

**Trade-offs:**
- Goroutine count grows with concurrent webhooks
- Slow destinations block their goroutine
- Mitigated by request timeouts and destination health tracking

### ADR-005: chi Router over gin

**Status:** Accepted

**Context:** Need an HTTP router for the service.

**Decision:** Use chi router (go-chi/chi) instead of gin or other frameworks.

**Rationale:**
- Stdlib net/http compatible
- Lightweight with minimal dependencies
- Clean middleware composition
- No reflection-based magic

**Trade-offs:**
- Smaller middleware ecosystem than gin
- Less "batteries included"
- Acceptable given our focused requirements
