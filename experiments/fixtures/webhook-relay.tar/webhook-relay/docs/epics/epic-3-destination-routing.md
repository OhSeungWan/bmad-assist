---
epic_num: 3
title: Destination Routing
status: draft
---

# Epic 3: Destination Routing

**Status:** draft
**Priority:** P0
**Stories:** 5

## Overview

Implements destination configuration and HTTP delivery. Each route can have multiple destinations (fan-out pattern), with support for custom headers, configurable timeouts, and health tracking to avoid sending to unhealthy destinations.

## Requirements Coverage

- FR-007: Multiple Destinations
- FR-008: HTTP Destinations
- FR-009: Custom Headers
- NFR-001: Handle 1000 req/s
- NFR-002: Delivery latency < 100ms

---

## Story 3.1: Create Destination Configuration Model

**Status:** draft
**Epic:** Destination Routing
**Priority:** P0

## User Story

As a platform engineer, I want to configure HTTP destinations for each route so that webhooks are forwarded to the correct endpoints.

## Acceptance Criteria

1. **AC-3.1.1:** Destination has unique ID, name, URL, HTTP method, and timeout
2. **AC-3.1.2:** Each route can have multiple destinations (1 to N relationship)
3. **AC-3.1.3:** Destination URL is validated for proper HTTP/HTTPS format
4. **AC-3.1.4:** Default timeout is 10 seconds, configurable per destination
5. **AC-3.1.5:** Destinations are stored in SQLite with foreign key to routes
6. **AC-3.1.6:** Destination order is preserved for deterministic delivery

## Tasks

- [ ] Task 1: Define Destination model (AC: 1)
  - [ ] Subtask 1.1: Create Destination struct in `internal/routing/destination.go`
  - [ ] Subtask 1.2: Add JSON tags for API serialization
  - [ ] Subtask 1.3: Add timeout with default value
- [ ] Task 2: Create database schema (AC: 5, 6)
  - [ ] Subtask 2.1: Create destinations table migration
  - [ ] Subtask 2.2: Add foreign key constraint to routes
  - [ ] Subtask 2.3: Add order_index column for ordering
- [ ] Task 3: Implement URL validation (AC: 3)
  - [ ] Subtask 3.1: Validate URL format with url.Parse
  - [ ] Subtask 3.2: Require http or https scheme
  - [ ] Subtask 3.3: Validate host is not empty
- [ ] Task 4: Update Route model (AC: 2)
  - [ ] Subtask 4.1: Add Destinations slice to Route
  - [ ] Subtask 4.2: Load destinations when loading routes
- [ ] Task 5: Add CRUD operations (AC: 5)
  - [ ] Subtask 5.1: Implement destination create/read/update/delete
  - [ ] Subtask 5.2: Update route cache when destinations change

## Technical Notes

- URL validation should not make network requests
- Destination ID should be UUID for global uniqueness
- Consider adding enabled/disabled flag for soft disable

## Dependencies

- Requires: Story 2.3 (transformation pipeline complete)

---

## Story 3.2: Implement HTTP Destination Sender

**Status:** draft
**Epic:** Destination Routing
**Priority:** P0

## User Story

As a platform engineer, I want webhooks to be delivered via HTTP POST so that downstream services receive the data.

## Acceptance Criteria

1. **AC-3.2.1:** HTTP POST request is sent to destination URL with transformed payload as body
2. **AC-3.2.2:** Content-Type header is set to `application/json`
3. **AC-3.2.3:** Request timeout is honored with context cancellation
4. **AC-3.2.4:** Response status 2xx is considered successful delivery
5. **AC-3.2.5:** Response status 4xx/5xx is considered failed delivery
6. **AC-3.2.6:** Network errors (timeout, connection refused) are considered failed delivery

## Tasks

- [ ] Task 1: Create HTTP client (AC: 3)
  - [ ] Subtask 1.1: Create `internal/delivery/sender.go`
  - [ ] Subtask 1.2: Configure http.Client with transport settings
  - [ ] Subtask 1.3: Use context with timeout for requests
- [ ] Task 2: Implement Send method (AC: 1, 2)
  - [ ] Subtask 2.1: Build http.Request with POST method
  - [ ] Subtask 2.2: Set Content-Type header
  - [ ] Subtask 2.3: Set body from transformed payload
- [ ] Task 3: Handle responses (AC: 4, 5)
  - [ ] Subtask 3.1: Check response status code
  - [ ] Subtask 3.2: Return success for 2xx
  - [ ] Subtask 3.3: Return error with status for 4xx/5xx
- [ ] Task 4: Handle errors (AC: 6)
  - [ ] Subtask 4.1: Detect timeout errors
  - [ ] Subtask 4.2: Detect connection errors
  - [ ] Subtask 4.3: Return typed errors for retry logic
- [ ] Task 5: Add unit tests with mock server
  - [ ] Subtask 5.1: Test successful delivery
  - [ ] Subtask 5.2: Test various failure modes

## Technical Notes

- Reuse http.Client across requests for connection pooling
- Read and discard response body to enable connection reuse
- Log response body excerpt on failure for debugging

## Dependencies

- Requires: Story 3.1 (destination model)

---

## Story 3.3: Add Custom Header Injection

**Status:** draft
**Epic:** Destination Routing
**Priority:** P1

## User Story

As a platform engineer, I want to inject custom headers on outbound requests so that downstream services can identify the relay or authenticate.

## Acceptance Criteria

1. **AC-3.3.1:** Destination configuration includes custom headers map
2. **AC-3.3.2:** Custom headers are added to outbound HTTP request
3. **AC-3.3.3:** Custom headers can override default headers (except Content-Type)
4. **AC-3.3.4:** Header values support variable substitution: `${route_id}`, `${destination_id}`, `${timestamp}`
5. **AC-3.3.5:** Maximum 20 custom headers per destination
6. **AC-3.3.6:** Header names are validated for HTTP compliance

## Tasks

- [ ] Task 1: Extend destination model (AC: 1, 5)
  - [ ] Subtask 1.1: Add Headers map[string]string to Destination
  - [ ] Subtask 1.2: Add validation for max headers count
- [ ] Task 2: Implement header injection (AC: 2, 3)
  - [ ] Subtask 2.1: Add headers to request before sending
  - [ ] Subtask 2.2: Preserve Content-Type header
- [ ] Task 3: Implement variable substitution (AC: 4)
  - [ ] Subtask 3.1: Parse variable placeholders in header values
  - [ ] Subtask 3.2: Replace with actual values from context
  - [ ] Subtask 3.3: Support route_id, destination_id, timestamp
- [ ] Task 4: Add validation (AC: 6)
  - [ ] Subtask 4.1: Validate header names against RFC 7230
  - [ ] Subtask 4.2: Reject invalid header names at config time
- [ ] Task 5: Add unit tests
  - [ ] Subtask 5.1: Test header injection
  - [ ] Subtask 5.2: Test variable substitution

## Technical Notes

- Common use cases: Authorization header, X-Webhook-Source, correlation IDs
- Variable substitution happens at request time, not config time
- Consider adding secret reference support for sensitive headers

## Dependencies

- Requires: Story 3.2 (HTTP sender)

---

## Story 3.4: Implement Fan-out to Multiple Destinations

**Status:** draft
**Epic:** Destination Routing
**Priority:** P0

## User Story

As a platform engineer, I want webhooks to be delivered to multiple destinations so that different services can receive the same event.

## Acceptance Criteria

1. **AC-3.4.1:** Webhook is delivered to all configured destinations for the route
2. **AC-3.4.2:** Deliveries to multiple destinations happen concurrently
3. **AC-3.4.3:** Failure to one destination does not block delivery to others
4. **AC-3.4.4:** Overall webhook processing succeeds if at least one destination succeeds
5. **AC-3.4.5:** Each destination delivery is tracked independently for retry
6. **AC-3.4.6:** Maximum concurrent destinations per route is configurable (default 10)

## Tasks

- [ ] Task 1: Implement concurrent delivery (AC: 1, 2)
  - [ ] Subtask 1.1: Create goroutine per destination
  - [ ] Subtask 1.2: Use sync.WaitGroup for coordination
  - [ ] Subtask 1.3: Collect results from all deliveries
- [ ] Task 2: Handle partial failures (AC: 3, 4)
  - [ ] Subtask 2.1: Track success/failure per destination
  - [ ] Subtask 2.2: Determine overall status based on results
  - [ ] Subtask 2.3: Return detailed result with per-destination status
- [ ] Task 3: Implement delivery tracking (AC: 5)
  - [ ] Subtask 3.1: Create DeliveryAttempt record per destination
  - [ ] Subtask 3.2: Store in database for retry handling
- [ ] Task 4: Add concurrency limit (AC: 6)
  - [ ] Subtask 4.1: Add max_concurrent_destinations to config
  - [ ] Subtask 4.2: Use semaphore to limit concurrent deliveries
- [ ] Task 5: Add unit tests
  - [ ] Subtask 5.1: Test successful fan-out
  - [ ] Subtask 5.2: Test partial failure handling

## Technical Notes

- Use errgroup for structured concurrency with error handling
- Consider circuit breaker pattern for repeated failures
- Destination order doesn't affect delivery (all concurrent)

## Dependencies

- Requires: Story 3.2 (HTTP sender)

---

## Story 3.5: Add Destination Health Tracking

**Status:** draft
**Epic:** Destination Routing
**Priority:** P2

## User Story

As a platform engineer, I want destination health to be tracked so that I can identify problematic endpoints.

## Acceptance Criteria

1. **AC-3.5.1:** Track success/failure count per destination over sliding window
2. **AC-3.5.2:** Calculate success rate percentage for each destination
3. **AC-3.5.3:** Expose health status via Admin API
4. **AC-3.5.4:** Log warning when success rate drops below threshold (default 90%)
5. **AC-3.5.5:** Health tracking does not affect delivery decisions (informational only)
6. **AC-3.5.6:** Health metrics are exposed via Prometheus

## Tasks

- [ ] Task 1: Implement health tracker (AC: 1, 2)
  - [ ] Subtask 1.1: Create HealthTracker in `internal/delivery/health.go`
  - [ ] Subtask 1.2: Use circular buffer for sliding window
  - [ ] Subtask 1.3: Calculate success rate from window
- [ ] Task 2: Integrate with sender (AC: 1)
  - [ ] Subtask 2.1: Record success/failure after each delivery
  - [ ] Subtask 2.2: Update health tracker atomically
- [ ] Task 3: Add threshold alerting (AC: 4)
  - [ ] Subtask 3.1: Configure warning threshold
  - [ ] Subtask 3.2: Log warning on threshold breach
- [ ] Task 4: Expose via API (AC: 3)
  - [ ] Subtask 4.1: Add health endpoint to Admin API
  - [ ] Subtask 4.2: Return per-destination health status
- [ ] Task 5: Add Prometheus metrics (AC: 6)
  - [ ] Subtask 5.1: Gauge for current success rate
  - [ ] Subtask 5.2: Counter for total successes/failures

## Technical Notes

- Sliding window should be time-based (e.g., last 5 minutes)
- Consider using ring buffer for memory efficiency
- Health tracking is best-effort, not critical path

## Dependencies

- Requires: Story 3.2 (HTTP sender)
