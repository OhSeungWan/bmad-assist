---
epic_num: 4
title: Retry & Dead Letter Queue
status: draft
---

# Epic 4: Retry & Dead Letter Queue

**Status:** draft
**Priority:** P0
**Stories:** 4

## Overview

Implements delivery reliability features including a persistent delivery queue, exponential backoff retry logic, and a dead letter queue for failed deliveries that have exhausted all retry attempts. Ensures at-least-once delivery guarantee for all accepted webhooks.

## Requirements Coverage

- FR-010: Retry Logic
- FR-011: Dead Letter Queue
- FR-012: DLQ Replay
- NFR-004: At-least-once delivery
- NFR-005: Retry policy (3 attempts, 1s/5s/30s backoff)
- NFR-006: DLQ retention (7 days)

---

## Story 4.1: Create Delivery Queue with SQLite

**Status:** draft
**Epic:** Retry & Dead Letter Queue
**Priority:** P0

## User Story

As a platform engineer, I want webhook deliveries to be queued persistently so that no data is lost if the service restarts.

## Acceptance Criteria

1. **AC-4.1.1:** Each delivery attempt is stored in SQLite with status, payload, and metadata
2. **AC-4.1.2:** Queue entries include: route_id, destination_id, payload, status, created_at, next_attempt_at
3. **AC-4.1.3:** Delivery status transitions: pending -> in_progress -> completed | failed | dlq
4. **AC-4.1.4:** In-memory queue is populated from database on startup for pending/in_progress entries
5. **AC-4.1.5:** Queue operations are transactional to prevent data loss
6. **AC-4.1.6:** Queue depth metrics are exposed for monitoring

## Tasks

- [ ] Task 1: Create delivery_queue table (AC: 2)
  - [ ] Subtask 1.1: Define schema with all required columns
  - [ ] Subtask 1.2: Add indexes for efficient queries (status, next_attempt_at)
  - [ ] Subtask 1.3: Create migration file
- [ ] Task 2: Create DeliveryEntry model (AC: 1, 3)
  - [ ] Subtask 2.1: Define struct in `internal/delivery/queue.go`
  - [ ] Subtask 2.2: Add status enum type
  - [ ] Subtask 2.3: Implement status transitions
- [ ] Task 3: Implement queue operations (AC: 5)
  - [ ] Subtask 3.1: Implement Enqueue with transaction
  - [ ] Subtask 3.2: Implement Dequeue for processing
  - [ ] Subtask 3.3: Implement UpdateStatus
  - [ ] Subtask 3.4: Implement GetPending for startup recovery
- [ ] Task 4: Implement startup recovery (AC: 4)
  - [ ] Subtask 4.1: Load pending entries on startup
  - [ ] Subtask 4.2: Reset in_progress entries to pending
- [ ] Task 5: Add metrics (AC: 6)
  - [ ] Subtask 5.1: Gauge for queue depth by status
  - [ ] Subtask 5.2: Counter for entries processed

## Technical Notes

- Use `modernc.org/sqlite` for pure Go implementation
- Consider WAL mode for better concurrent read/write
- Payload is stored as BLOB to preserve exact bytes

## Dependencies

- Requires: Story 3.4 (fan-out delivery)

---

## Story 4.2: Implement Retry with Exponential Backoff

**Status:** draft
**Epic:** Retry & Dead Letter Queue
**Priority:** P0

## User Story

As a platform engineer, I want failed deliveries to be retried with exponential backoff so that transient failures are handled automatically.

## Acceptance Criteria

1. **AC-4.2.1:** Failed deliveries are retried up to configured max attempts (default 3)
2. **AC-4.2.2:** Retry intervals follow exponential backoff: 1s, 5s, 30s (configurable)
3. **AC-4.2.3:** Retry attempts are tracked per delivery entry
4. **AC-4.2.4:** After max attempts, entry is moved to dead letter queue
5. **AC-4.2.5:** Retries are processed by background worker goroutine
6. **AC-4.2.6:** Retry worker respects graceful shutdown

## Tasks

- [ ] Task 1: Add retry configuration (AC: 1, 2)
  - [ ] Subtask 1.1: Add max_retries to config
  - [ ] Subtask 1.2: Add backoff intervals array to config
  - [ ] Subtask 1.3: Validate configuration values
- [ ] Task 2: Implement retry logic (AC: 1, 3)
  - [ ] Subtask 2.1: Create `internal/delivery/retry.go`
  - [ ] Subtask 2.2: Track attempt count on DeliveryEntry
  - [ ] Subtask 2.3: Calculate next_attempt_at based on backoff
- [ ] Task 3: Implement retry worker (AC: 5)
  - [ ] Subtask 3.1: Create background goroutine polling for due entries
  - [ ] Subtask 3.2: Process due entries and update status
  - [ ] Subtask 3.3: Use ticker for polling interval
- [ ] Task 4: Handle max attempts (AC: 4)
  - [ ] Subtask 4.1: Check attempt count before retry
  - [ ] Subtask 4.2: Move to DLQ when exhausted
  - [ ] Subtask 4.3: Log exhausted retries
- [ ] Task 5: Implement graceful shutdown (AC: 6)
  - [ ] Subtask 5.1: Stop ticker on shutdown signal
  - [ ] Subtask 5.2: Wait for in-flight retries to complete
- [ ] Task 6: Add unit tests
  - [ ] Subtask 6.1: Test backoff calculation
  - [ ] Subtask 6.2: Test max attempts handling

## Technical Notes

- Backoff intervals are configured as durations: [1s, 5s, 30s]
- Consider jitter to prevent thundering herd
- Worker poll interval should be less than smallest backoff

## Dependencies

- Requires: Story 4.1 (delivery queue)

---

## Story 4.3: Add Dead Letter Queue Storage

**Status:** draft
**Epic:** Retry & Dead Letter Queue
**Priority:** P0

## User Story

As a platform engineer, I want failed deliveries to be stored in a dead letter queue so that I can investigate and manually retry them.

## Acceptance Criteria

1. **AC-4.3.1:** DLQ entries store complete delivery context (route, destination, payload, error, timestamps)
2. **AC-4.3.2:** DLQ entries include failure reason from last attempt
3. **AC-4.3.3:** DLQ entries are stored in dedicated SQLite table
4. **AC-4.3.4:** DLQ entries older than retention period are automatically purged (default 7 days)
5. **AC-4.3.5:** DLQ count metrics are exposed per route
6. **AC-4.3.6:** DLQ entries can be queried by route, destination, or time range

## Tasks

- [ ] Task 1: Create DLQ table (AC: 1, 3)
  - [ ] Subtask 1.1: Define schema with full context
  - [ ] Subtask 1.2: Add indexes for efficient queries
  - [ ] Subtask 1.3: Create migration file
- [ ] Task 2: Create DLQEntry model (AC: 1, 2)
  - [ ] Subtask 2.1: Define struct in `internal/delivery/dlq.go`
  - [ ] Subtask 2.2: Include last_error field
  - [ ] Subtask 2.3: Add timestamps for tracking
- [ ] Task 3: Implement DLQ operations (AC: 3, 6)
  - [ ] Subtask 3.1: Implement Add from failed delivery
  - [ ] Subtask 3.2: Implement List with filters
  - [ ] Subtask 3.3: Implement Get by ID
  - [ ] Subtask 3.4: Implement Delete
- [ ] Task 4: Implement retention purge (AC: 4)
  - [ ] Subtask 4.1: Add retention_days to config
  - [ ] Subtask 4.2: Create purge job (daily or hourly)
  - [ ] Subtask 4.3: Delete entries older than retention
- [ ] Task 5: Add metrics (AC: 5)
  - [ ] Subtask 5.1: Gauge for DLQ depth by route
  - [ ] Subtask 5.2: Counter for entries added/purged

## Technical Notes

- Store complete payload even if large (max 1MB from ingress)
- Error messages should be sanitized for logging
- Consider compression for payload storage

## Dependencies

- Requires: Story 4.2 (retry exhaustion triggers DLQ)

---

## Story 4.4: Create DLQ Inspection and Replay

**Status:** draft
**Epic:** Retry & Dead Letter Queue
**Priority:** P1

## User Story

As a platform engineer, I want to inspect and replay dead letter queue entries so that I can recover from delivery failures after fixing issues.

## Acceptance Criteria

1. **AC-4.4.1:** DLQ entries can be viewed with full context via Admin API
2. **AC-4.4.2:** Single DLQ entry can be replayed (re-queued for delivery)
3. **AC-4.4.3:** Bulk replay supports filtering by route or destination
4. **AC-4.4.4:** Replayed entries are removed from DLQ and added to delivery queue
5. **AC-4.4.5:** Replay resets attempt count to zero
6. **AC-4.4.6:** Replay action is logged with operator context

## Tasks

- [ ] Task 1: Implement DLQ view endpoint (AC: 1)
  - [ ] Subtask 1.1: GET /admin/dead-letter-queue returns list
  - [ ] Subtask 1.2: Support pagination
  - [ ] Subtask 1.3: GET /admin/dead-letter-queue/{id} returns single entry
- [ ] Task 2: Implement single replay (AC: 2, 4, 5)
  - [ ] Subtask 2.1: POST /admin/dead-letter-queue/{id}/replay endpoint
  - [ ] Subtask 2.2: Create new delivery entry with reset attempts
  - [ ] Subtask 2.3: Delete DLQ entry after successful queue
- [ ] Task 3: Implement bulk replay (AC: 3, 4)
  - [ ] Subtask 3.1: POST /admin/dead-letter-queue/replay-all endpoint
  - [ ] Subtask 3.2: Accept filter parameters (route_id, destination_id)
  - [ ] Subtask 3.3: Process in batches with transaction
- [ ] Task 4: Add audit logging (AC: 6)
  - [ ] Subtask 4.1: Log replay action with entry ID
  - [ ] Subtask 4.2: Include operator/source in log
- [ ] Task 5: Add unit tests
  - [ ] Subtask 5.1: Test single replay flow
  - [ ] Subtask 5.2: Test bulk replay with filters

## Technical Notes

- Bulk replay should be transactional per batch
- Consider rate limiting replay to prevent overload
- Return count of replayed entries in response

## Dependencies

- Requires: Story 4.3 (DLQ storage)
