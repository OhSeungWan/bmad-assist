---
epic_num: 5
title: Admin API
status: draft
---

# Epic 5: Admin API

**Status:** draft
**Priority:** P1
**Stories:** 4

## Overview

REST API for managing routes, destinations, and inspecting delivery history. Enables runtime configuration without service restart. Protected by API token authentication.

## Requirements Coverage

- FR-013: Route Management
- FR-014: Destination Management
- FR-015: Delivery History
- FR-016: DLQ Operations

---

## Story 5.1: Create Route Management Endpoints

**Status:** draft
**Epic:** Admin API
**Priority:** P0

## User Story

As a platform engineer, I want to manage webhook routes via REST API so that I can configure integrations without restarting the service.

## Acceptance Criteria

1. **AC-5.1.1:** GET /admin/routes returns paginated list of all routes
2. **AC-5.1.2:** POST /admin/routes creates new route with validation
3. **AC-5.1.3:** GET /admin/routes/{id} returns single route with destinations
4. **AC-5.1.4:** PUT /admin/routes/{id} updates existing route
5. **AC-5.1.5:** DELETE /admin/routes/{id} removes route and associated destinations
6. **AC-5.1.6:** All endpoints require Authorization header with valid admin token
7. **AC-5.1.7:** Invalid token returns 401 Unauthorized

## Tasks

- [ ] Task 1: Create admin handler (AC: 6, 7)
  - [ ] Subtask 1.1: Create `internal/server/handlers/admin.go`
  - [ ] Subtask 1.2: Implement token validation middleware
  - [ ] Subtask 1.3: Configure token from environment/config
- [ ] Task 2: Implement list routes (AC: 1)
  - [ ] Subtask 2.1: GET /admin/routes handler
  - [ ] Subtask 2.2: Add pagination with limit/offset
  - [ ] Subtask 2.3: Return route count in response
- [ ] Task 3: Implement create route (AC: 2)
  - [ ] Subtask 3.1: POST /admin/routes handler
  - [ ] Subtask 3.2: Validate input with Pydantic-style validation
  - [ ] Subtask 3.3: Return created route with 201 status
- [ ] Task 4: Implement get single route (AC: 3)
  - [ ] Subtask 4.1: GET /admin/routes/{id} handler
  - [ ] Subtask 4.2: Include destinations in response
  - [ ] Subtask 4.3: Return 404 if not found
- [ ] Task 5: Implement update route (AC: 4)
  - [ ] Subtask 5.1: PUT /admin/routes/{id} handler
  - [ ] Subtask 5.2: Validate input
  - [ ] Subtask 5.3: Update cache after database update
- [ ] Task 6: Implement delete route (AC: 5)
  - [ ] Subtask 6.1: DELETE /admin/routes/{id} handler
  - [ ] Subtask 6.2: Cascade delete destinations
  - [ ] Subtask 6.3: Remove from cache
- [ ] Task 7: Add integration tests
  - [ ] Subtask 7.1: Test CRUD operations
  - [ ] Subtask 7.2: Test authentication

## Technical Notes

- Use chi router groups for /admin prefix
- Token should be compared with constant-time comparison
- Consider adding ETag for optimistic locking

## Dependencies

- Requires: Epic 4 complete (full delivery pipeline)

---

## Story 5.2: Add Destination Management Endpoints

**Status:** draft
**Epic:** Admin API
**Priority:** P0

## User Story

As a platform engineer, I want to manage destinations for each route via REST API so that I can configure where webhooks are forwarded.

## Acceptance Criteria

1. **AC-5.2.1:** GET /admin/routes/{route_id}/destinations returns destinations for route
2. **AC-5.2.2:** POST /admin/routes/{route_id}/destinations adds new destination to route
3. **AC-5.2.3:** GET /admin/destinations/{id} returns single destination
4. **AC-5.2.4:** PUT /admin/destinations/{id} updates destination
5. **AC-5.2.5:** DELETE /admin/destinations/{id} removes destination
6. **AC-5.2.6:** Destination order can be updated via PUT /admin/routes/{route_id}/destinations/order

## Tasks

- [ ] Task 1: Implement list destinations (AC: 1)
  - [ ] Subtask 1.1: GET /admin/routes/{route_id}/destinations handler
  - [ ] Subtask 1.2: Return destinations ordered by order_index
  - [ ] Subtask 1.3: Return 404 if route not found
- [ ] Task 2: Implement add destination (AC: 2)
  - [ ] Subtask 2.1: POST handler
  - [ ] Subtask 2.2: Validate URL and other fields
  - [ ] Subtask 2.3: Auto-assign order_index
  - [ ] Subtask 2.4: Update route cache
- [ ] Task 3: Implement get/update destination (AC: 3, 4)
  - [ ] Subtask 3.1: GET /admin/destinations/{id} handler
  - [ ] Subtask 3.2: PUT /admin/destinations/{id} handler
  - [ ] Subtask 3.3: Update cache on change
- [ ] Task 4: Implement delete destination (AC: 5)
  - [ ] Subtask 4.1: DELETE handler
  - [ ] Subtask 4.2: Update cache
  - [ ] Subtask 4.3: Re-order remaining destinations
- [ ] Task 5: Implement reorder (AC: 6)
  - [ ] Subtask 5.1: PUT /admin/routes/{route_id}/destinations/order handler
  - [ ] Subtask 5.2: Accept array of destination IDs in desired order
  - [ ] Subtask 5.3: Update order_index in database

## Technical Notes

- Destination updates should invalidate route cache
- Order update should be transactional
- Validate destination URL connectivity is optional

## Dependencies

- Requires: Story 5.1 (route management)

---

## Story 5.3: Implement Delivery History Query

**Status:** draft
**Epic:** Admin API
**Priority:** P1

## User Story

As a platform engineer, I want to query delivery history so that I can monitor webhook processing and debug issues.

## Acceptance Criteria

1. **AC-5.3.1:** GET /admin/deliveries returns paginated delivery history
2. **AC-5.3.2:** Deliveries can be filtered by route_id, destination_id, status
3. **AC-5.3.3:** Deliveries can be filtered by time range (start_time, end_time)
4. **AC-5.3.4:** Each delivery includes: id, route, destination, status, attempts, timestamps, duration
5. **AC-5.3.5:** GET /admin/deliveries/{id} returns single delivery with full context
6. **AC-5.3.6:** History retention is configurable (default 24 hours)

## Tasks

- [ ] Task 1: Create delivery history table (AC: 4)
  - [ ] Subtask 1.1: Define schema with all required fields
  - [ ] Subtask 1.2: Add indexes for efficient queries
  - [ ] Subtask 1.3: Record delivery attempts with timing
- [ ] Task 2: Implement delivery recording
  - [ ] Subtask 2.1: Record on successful delivery
  - [ ] Subtask 2.2: Record on failed delivery (before DLQ)
  - [ ] Subtask 2.3: Track duration per attempt
- [ ] Task 3: Implement list endpoint (AC: 1, 2, 3)
  - [ ] Subtask 3.1: GET /admin/deliveries handler
  - [ ] Subtask 3.2: Parse filter query parameters
  - [ ] Subtask 3.3: Build SQL query with filters
  - [ ] Subtask 3.4: Add pagination
- [ ] Task 4: Implement detail endpoint (AC: 5)
  - [ ] Subtask 4.1: GET /admin/deliveries/{id} handler
  - [ ] Subtask 4.2: Include attempt history
- [ ] Task 5: Implement retention purge (AC: 6)
  - [ ] Subtask 5.1: Add retention_hours to config
  - [ ] Subtask 5.2: Create purge job
  - [ ] Subtask 5.3: Delete old entries periodically

## Technical Notes

- Consider partitioning by date for large volumes
- Do not store full payload in history (reference to DLQ if failed)
- Time range queries need indexed timestamp column

## Dependencies

- Requires: Story 5.1 (admin API foundation)

---

## Story 5.4: Add DLQ Management Endpoints

**Status:** draft
**Epic:** Admin API
**Priority:** P1

## User Story

As a platform engineer, I want to manage the dead letter queue via REST API so that I can investigate and recover failed deliveries.

## Acceptance Criteria

1. **AC-5.4.1:** GET /admin/dead-letter-queue returns paginated DLQ entries
2. **AC-5.4.2:** Entries can be filtered by route_id, destination_id, error_type
3. **AC-5.4.3:** GET /admin/dead-letter-queue/{id} returns single entry with full payload
4. **AC-5.4.4:** POST /admin/dead-letter-queue/{id}/replay re-queues entry for delivery
5. **AC-5.4.5:** DELETE /admin/dead-letter-queue/{id} permanently removes entry
6. **AC-5.4.6:** POST /admin/dead-letter-queue/purge removes entries older than specified age

## Tasks

- [ ] Task 1: Implement list endpoint (AC: 1, 2)
  - [ ] Subtask 1.1: GET /admin/dead-letter-queue handler
  - [ ] Subtask 1.2: Parse filter parameters
  - [ ] Subtask 1.3: Add pagination with total count
- [ ] Task 2: Implement detail endpoint (AC: 3)
  - [ ] Subtask 2.1: GET /admin/dead-letter-queue/{id} handler
  - [ ] Subtask 2.2: Include full payload in response
  - [ ] Subtask 2.3: Include error details and attempt history
- [ ] Task 3: Implement replay endpoint (AC: 4)
  - [ ] Subtask 3.1: POST /admin/dead-letter-queue/{id}/replay handler
  - [ ] Subtask 3.2: Create new delivery queue entry
  - [ ] Subtask 3.3: Remove from DLQ
  - [ ] Subtask 3.4: Return new delivery ID
- [ ] Task 4: Implement delete endpoint (AC: 5)
  - [ ] Subtask 4.1: DELETE /admin/dead-letter-queue/{id} handler
  - [ ] Subtask 4.2: Return 404 if not found
- [ ] Task 5: Implement purge endpoint (AC: 6)
  - [ ] Subtask 5.1: POST /admin/dead-letter-queue/purge handler
  - [ ] Subtask 5.2: Accept age parameter (e.g., older_than=7d)
  - [ ] Subtask 5.3: Return count of purged entries
- [ ] Task 6: Add integration tests
  - [ ] Subtask 6.1: Test DLQ operations
  - [ ] Subtask 6.2: Test replay flow end-to-end

## Technical Notes

- Payload display should handle binary/non-UTF8 gracefully
- Bulk operations should be rate-limited
- Consider adding bulk delete by filter

## Dependencies

- Requires: Story 4.4 (DLQ storage and replay logic)
