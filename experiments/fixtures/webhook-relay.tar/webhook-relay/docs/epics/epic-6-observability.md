---
epic_num: 6
title: Observability
status: draft
---

# Epic 6: Observability

**Status:** draft
**Priority:** P1
**Stories:** 2

## Overview

Implements Prometheus metrics endpoint and health check endpoints for monitoring and load balancer integration. Provides visibility into system performance, delivery success rates, and operational health.

## Requirements Coverage

- FR-017: Prometheus Metrics
- FR-018: Health Check
- NFR-001: Handle 1000 req/s monitoring
- NFR-002: Latency tracking

---

## Story 6.1: Add Prometheus Metrics

**Status:** draft
**Epic:** Observability
**Priority:** P0

## User Story

As an operations engineer, I want Prometheus metrics exposed so that I can monitor system performance and set up alerting.

## Acceptance Criteria

1. **AC-6.1.1:** GET /metrics returns Prometheus-compatible metrics
2. **AC-6.1.2:** Request metrics include: total requests, latency histogram, status codes by endpoint
3. **AC-6.1.3:** Delivery metrics include: attempts, successes, failures by route and destination
4. **AC-6.1.4:** Queue metrics include: depth, processing time, retry counts
5. **AC-6.1.5:** DLQ metrics include: entries count, entries added rate
6. **AC-6.1.6:** All metrics include appropriate labels for filtering

## Tasks

- [ ] Task 1: Set up Prometheus client (AC: 1)
  - [ ] Subtask 1.1: Add prometheus/client_golang dependency
  - [ ] Subtask 1.2: Create metrics registry
  - [ ] Subtask 1.3: Register /metrics endpoint
- [ ] Task 2: Implement request metrics (AC: 2)
  - [ ] Subtask 2.1: Create counter for total requests
  - [ ] Subtask 2.2: Create histogram for latency
  - [ ] Subtask 2.3: Create counter for status codes
  - [ ] Subtask 2.4: Add middleware to record metrics
- [ ] Task 3: Implement delivery metrics (AC: 3)
  - [ ] Subtask 3.1: Counter for delivery attempts by route, destination
  - [ ] Subtask 3.2: Counter for successful deliveries
  - [ ] Subtask 3.3: Counter for failed deliveries
  - [ ] Subtask 3.4: Histogram for delivery duration
- [ ] Task 4: Implement queue metrics (AC: 4)
  - [ ] Subtask 4.1: Gauge for queue depth by status
  - [ ] Subtask 4.2: Counter for retries
  - [ ] Subtask 4.3: Histogram for time in queue
- [ ] Task 5: Implement DLQ metrics (AC: 5)
  - [ ] Subtask 5.1: Gauge for DLQ size by route
  - [ ] Subtask 5.2: Counter for DLQ entries added
  - [ ] Subtask 5.3: Counter for DLQ entries purged
- [ ] Task 6: Add metric labels (AC: 6)
  - [ ] Subtask 6.1: Define consistent label naming
  - [ ] Subtask 6.2: Add route_id, destination_id, status labels

## Technical Notes

- Use prometheus.NewHistogramVec for latency with appropriate buckets
- Limit cardinality by using bounded label values
- Consider metric collection performance impact

### Metric Definitions

```
# Request metrics
webhook_relay_requests_total{method, path, status}
webhook_relay_request_duration_seconds{method, path}

# Delivery metrics
webhook_relay_delivery_attempts_total{route_id, destination_id}
webhook_relay_delivery_success_total{route_id, destination_id}
webhook_relay_delivery_failure_total{route_id, destination_id}
webhook_relay_delivery_duration_seconds{route_id, destination_id}

# Queue metrics
webhook_relay_queue_depth{status}
webhook_relay_queue_retries_total{route_id}
webhook_relay_queue_wait_seconds

# DLQ metrics
webhook_relay_dlq_size{route_id}
webhook_relay_dlq_entries_added_total{route_id}
webhook_relay_dlq_entries_purged_total
```

## Dependencies

- Requires: Epic 4 complete (delivery pipeline for meaningful metrics)

---

## Story 6.2: Implement Health Check Endpoint

**Status:** draft
**Epic:** Observability
**Priority:** P0

## User Story

As an operations engineer, I want health check endpoints so that load balancers and orchestrators can monitor service availability.

## Acceptance Criteria

1. **AC-6.2.1:** GET /health returns overall health status with component details
2. **AC-6.2.2:** GET /health/live returns 200 if process is running (liveness probe)
3. **AC-6.2.3:** GET /health/ready returns 200 if ready to accept traffic (readiness probe)
4. **AC-6.2.4:** Health check includes database connectivity status
5. **AC-6.2.5:** Health check includes queue worker status
6. **AC-6.2.6:** Unhealthy components return 503 Service Unavailable

## Tasks

- [ ] Task 1: Create health handler (AC: 1)
  - [ ] Subtask 1.1: Create `internal/server/handlers/health.go`
  - [ ] Subtask 1.2: Define HealthStatus struct with components
  - [ ] Subtask 1.3: Implement aggregation logic
- [ ] Task 2: Implement liveness probe (AC: 2)
  - [ ] Subtask 2.1: GET /health/live handler
  - [ ] Subtask 2.2: Return 200 unconditionally if handler runs
- [ ] Task 3: Implement readiness probe (AC: 3, 6)
  - [ ] Subtask 3.1: GET /health/ready handler
  - [ ] Subtask 3.2: Check all critical components
  - [ ] Subtask 3.3: Return 503 if any component unhealthy
- [ ] Task 4: Add database health check (AC: 4)
  - [ ] Subtask 4.1: Execute simple query (SELECT 1)
  - [ ] Subtask 4.2: Timeout after 1 second
  - [ ] Subtask 4.3: Report status in response
- [ ] Task 5: Add queue worker health (AC: 5)
  - [ ] Subtask 5.1: Track worker goroutine status
  - [ ] Subtask 5.2: Check last successful poll time
  - [ ] Subtask 5.3: Report unhealthy if stale
- [ ] Task 6: Implement detailed health (AC: 1)
  - [ ] Subtask 6.1: GET /health returns JSON with all components
  - [ ] Subtask 6.2: Include version and uptime

## Technical Notes

- Liveness should be fast and simple
- Readiness can include dependency checks
- Health checks should not expose sensitive information

### Response Format

```json
{
  "status": "healthy",
  "version": "1.0.0",
  "uptime": "24h15m30s",
  "components": {
    "database": {
      "status": "healthy",
      "latency_ms": 2
    },
    "queue_worker": {
      "status": "healthy",
      "last_poll": "2025-01-15T10:30:00Z"
    }
  }
}
```

## Dependencies

- Requires: Story 5.1 (admin API foundation)
