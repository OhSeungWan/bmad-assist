# UI/UX Design: Markdown Note Taking App

## Layout

The application uses a three-panel layout optimized for note-taking workflows:

```
+------------------+------------------------+-------------------+
|    Sidebar       |       Editor           |     Preview       |
|                  |                        |                   |
| [Folders]        | # Note Title           | Note Title        |
| - All Notes      |                        | ═══════════════   |
| - Favorites      | Start writing...       | Rendered markdown |
| - Folder A       |                        |                   |
|   - Subfolder    |                        |                   |
| [Tags]           |                        |                   |
| #work #personal  |                        | **Backlinks:**    |
|                  |                        | - Other Note      |
| [Search]         |                        |                   |
+------------------+------------------------+-------------------+
```

### Panel Widths
- **Sidebar**: 250px fixed, collapsible
- **Editor**: Flexible, minimum 400px
- **Preview**: 40% of remaining space, collapsible

### Responsive Behavior
- Below 1024px: Preview hidden by default, toggle available
- Below 768px: Sidebar hidden by default, hamburger menu
- Mobile: Single panel view with navigation drawer

## Color Scheme

### Light Theme (Default)

| Element | Color | Hex |
|---------|-------|-----|
| Background | White | #ffffff |
| Sidebar | Slate 50 | #f8fafc |
| Editor | White | #ffffff |
| Preview | Gray 50 | #fafafa |
| Primary | Blue 500 | #3b82f6 |
| Primary Hover | Blue 600 | #2563eb |
| Text | Slate 800 | #1e293b |
| Text Muted | Slate 500 | #64748b |
| Border | Slate 200 | #e2e8f0 |
| Selection | Blue 100 | #dbeafe |

### Dark Theme (Future)

| Element | Color | Hex |
|---------|-------|-----|
| Background | Slate 900 | #0f172a |
| Sidebar | Slate 800 | #1e293b |
| Editor | Slate 900 | #0f172a |
| Preview | Slate 950 | #020617 |
| Primary | Blue 400 | #60a5fa |
| Text | Slate 100 | #f1f5f9 |
| Text Muted | Slate 400 | #94a3b8 |
| Border | Slate 700 | #334155 |

## Keyboard Shortcuts

| Shortcut | Action | Context |
|----------|--------|---------|
| Cmd/Ctrl + N | Create new note | Global |
| Cmd/Ctrl + S | Save current note | Editor |
| Cmd/Ctrl + F | Focus search input | Global |
| Cmd/Ctrl + B | Toggle sidebar | Global |
| Cmd/Ctrl + P | Toggle preview panel | Global |
| Cmd/Ctrl + K | Open quick switcher | Global |
| Cmd/Ctrl + Delete | Delete current note | Editor |
| Escape | Clear search / Close modal | Global |

### Editor Shortcuts

| Shortcut | Action |
|----------|--------|
| Cmd/Ctrl + B | Bold selection |
| Cmd/Ctrl + I | Italic selection |
| Cmd/Ctrl + [ | Outdent list |
| Cmd/Ctrl + ] | Indent list |
| Tab | Indent in code block |

## Component Hierarchy

```
App
├── Layout (+layout.svelte)
│   ├── Sidebar
│   │   ├── SidebarHeader
│   │   │   └── NewNoteButton
│   │   ├── FolderTree
│   │   │   ├── FolderItem (recursive)
│   │   │   └── NoteItem
│   │   ├── TagBrowser
│   │   │   └── TagItem
│   │   └── SearchInput
│   │       └── SearchResults
│   ├── MainContent
│   │   ├── EditorToolbar
│   │   │   ├── TitleInput
│   │   │   ├── TagInput
│   │   │   └── ActionButtons
│   │   └── Editor
│   │       └── CodeMirror (or textarea)
│   └── PreviewPanel
│       ├── RenderedMarkdown
│       └── BacklinksSection
│           └── BacklinkItem
├── Modals
│   ├── QuickSwitcher
│   ├── DeleteConfirmation
│   └── ImportDialog
└── Toasts
    └── ToastItem
```

## Component Specifications

### Sidebar

**FolderTree**
- Expandable/collapsible folders with chevron icons
- Indent level: 16px per depth
- Active folder/note highlighted with primary color background
- Drag handle appears on hover for reordering
- Right-click context menu: Rename, Delete, New Subfolder

**TagBrowser**
- Tags displayed as pills with # prefix
- Tag count shown in muted text
- Click to filter notes by tag
- Active tag highlighted with primary color

**SearchInput**
- Magnifying glass icon
- Placeholder: "Search notes..."
- Results appear in dropdown as user types
- Keyboard navigation: Arrow keys + Enter
- Escape to clear and close

### Editor

**EditorToolbar**
- Note title as editable h1-styled input
- Folder breadcrumb (clickable)
- Tag pills with X to remove, + to add
- Timestamps: Created / Last modified (muted, right-aligned)

**Editor Area**
- Monospace font for markdown
- Syntax highlighting for:
  - Headers (larger, bold)
  - Bold/Italic
  - Code blocks (background tint)
  - Links (primary color)
  - Wiki-links [[title]] (distinct style)
- Line numbers optional (off by default)
- Auto-save indicator (Saved / Saving...)

### Preview Panel

**RenderedMarkdown**
- Clean typography with proper spacing
- Code blocks with syntax highlighting
- Clickable links (external open in new tab)
- Wiki-links navigate within app
- Images with max-width: 100%

**BacklinksSection**
- Collapsed by default, expandable
- Shows count: "3 notes link here"
- Each backlink shows:
  - Note title (link)
  - Context snippet with match highlighted

## Interaction Patterns

### Note Creation
1. User presses Cmd+N or clicks "New Note"
2. New untitled note created in current folder
3. Editor focused with cursor in title field
4. Placeholder title: "Untitled Note"

### Note Deletion
1. User clicks delete or presses Cmd+Delete
2. Confirmation modal appears with note title
3. Option to "Don't ask again" for session
4. Note moves to recently deleted (or hard delete)

### Tag Assignment
1. Click + button in tag area
2. Autocomplete dropdown with existing tags
3. Type to filter or create new tag
4. Press Enter to add, Escape to cancel

### Search
1. Focus search with Cmd+F
2. Type query, results appear after 2 characters
3. Arrow keys to navigate results
4. Enter to open selected note
5. Escape to clear and return to editor

### Wiki-Link Creation
1. Type [[ to trigger autocomplete
2. Continue typing to filter note titles
3. Select with arrow keys + Enter
4. Or type full title and close with ]]
5. Non-existent links shown in different color (create on click)

## Accessibility

- All interactive elements keyboard accessible
- Focus visible with 2px ring
- ARIA labels on icon-only buttons
- Skip to main content link
- Reduced motion support for animations
- Minimum touch target: 44x44px on mobile
- Color contrast ratio: 4.5:1 minimum
