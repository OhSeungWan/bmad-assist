# Project Context: Markdown Note Taking App

## File Structure

```
src/
├── lib/
│   ├── db/
│   │   ├── schema.sql
│   │   ├── connection.ts
│   │   └── queries.ts
│   ├── markdown/
│   │   ├── parser.ts
│   │   └── plugins/
│   │       └── wikilink.ts
│   ├── components/
│   │   ├── Editor.svelte
│   │   ├── Preview.svelte
│   │   ├── Sidebar.svelte
│   │   ├── FolderTree.svelte
│   │   ├── TagBrowser.svelte
│   │   └── SearchResults.svelte
│   └── stores/
│       ├── notes.ts
│       └── ui.ts
├── routes/
│   ├── +layout.svelte
│   ├── +page.svelte
│   ├── note/[id]/
│   │   └── +page.svelte
│   └── api/
│       ├── notes/
│       ├── tags/
│       └── search/
└── tests/
    ├── unit/
    └── e2e/
```

## Naming Conventions

### Files and Directories

| Type | Convention | Example |
|------|------------|---------|
| Routes | kebab-case | `note/[id]/+page.svelte` |
| Components | PascalCase | `FolderTree.svelte` |
| Stores | camelCase | `notes.ts` |
| Utilities | camelCase | `parser.ts` |
| Tests | *.test.ts | `notes.test.ts` |
| E2E Tests | *.spec.ts | `editor.spec.ts` |

### Code

| Type | Convention | Example |
|------|------------|---------|
| Variables | camelCase | `noteContent` |
| Constants | UPPER_SNAKE_CASE | `MAX_TITLE_LENGTH` |
| Functions | camelCase | `parseMarkdown()` |
| Classes | PascalCase | `MarkdownParser` |
| Interfaces | PascalCase | `NoteData` |
| Types | PascalCase | `TagId` |
| Enums | PascalCase | `SortOrder` |

### Database

| Type | Convention | Example |
|------|------------|---------|
| Tables | snake_case plural | `notes`, `note_tags` |
| Columns | snake_case | `created_at`, `folder_id` |
| Indexes | idx_table_column | `idx_notes_folder` |
| Foreign Keys | singular_id | `folder_id`, `tag_id` |

### API Routes

| Style | Example |
|-------|---------|
| REST resources | `/api/notes`, `/api/notes/:id` |
| Actions | `/api/notes/:id/tags` |
| Search | `/api/search?q=term` |

## SvelteKit Patterns

### Route Structure

```typescript
// +page.svelte - Page component
<script lang="ts">
  export let data; // From +page.server.ts
</script>

// +page.server.ts - Server-side data loading
export const load: PageServerLoad = async ({ params }) => {
  const note = await getNote(params.id);
  return { note };
};

// +server.ts - API endpoint
export const GET: RequestHandler = async ({ params }) => {
  const data = await fetchData(params.id);
  return json(data);
};
```

### Store Pattern

```typescript
// src/lib/stores/notes.ts
import { writable, derived } from 'svelte/store';

export const notes = writable<Note[]>([]);
export const currentNoteId = writable<number | null>(null);

export const currentNote = derived(
  [notes, currentNoteId],
  ([$notes, $id]) => $notes.find(n => n.id === $id)
);
```

### Component Props

```svelte
<script lang="ts">
  // Props with TypeScript
  export let note: Note;
  export let onSave: (content: string) => void;
  export let isEditing = false; // With default
</script>
```

### API Error Handling

```typescript
// Consistent error response format
export const GET: RequestHandler = async ({ params }) => {
  try {
    const data = await fetchData(params.id);
    return json(data);
  } catch (error) {
    if (error instanceof NotFoundError) {
      return json({ error: 'Note not found' }, { status: 404 });
    }
    return json({ error: 'Internal server error' }, { status: 500 });
  }
};
```

## Database Patterns

### Connection Management

```typescript
// src/lib/db/connection.ts
import Database from 'better-sqlite3';

let db: Database.Database | null = null;

export function getDb(): Database.Database {
  if (!db) {
    db = new Database(getDatabasePath());
    db.pragma('journal_mode = WAL');
    db.pragma('foreign_keys = ON');
  }
  return db;
}
```

### Prepared Statements

```typescript
// src/lib/db/queries.ts
const getNoteStmt = db.prepare(`
  SELECT id, title, content, folder_id, is_pinned, created_at, updated_at
  FROM notes
  WHERE id = ?
`);

export function getNote(id: number): Note | undefined {
  return getNoteStmt.get(id) as Note | undefined;
}
```

### Transactions

```typescript
export function moveNoteToFolder(noteId: number, folderId: number): void {
  const transaction = db.transaction(() => {
    updateNoteFolderStmt.run(folderId, noteId);
    updateNoteTimestampStmt.run(noteId);
  });
  transaction();
}
```

## Testing Standards

### Unit Tests (Vitest)

```typescript
// src/lib/markdown/parser.test.ts
import { describe, it, expect } from 'vitest';
import { parseWikiLinks } from './parser';

describe('parseWikiLinks', () => {
  it('extracts wiki links from content', () => {
    const content = 'See [[My Note]] for details';
    const links = parseWikiLinks(content);
    expect(links).toEqual(['My Note']);
  });

  it('returns empty array when no links', () => {
    const content = 'No links here';
    const links = parseWikiLinks(content);
    expect(links).toEqual([]);
  });
});
```

### E2E Tests (Playwright)

```typescript
// tests/e2e/editor.spec.ts
import { test, expect } from '@playwright/test';

test.describe('Note Editor', () => {
  test('creates a new note', async ({ page }) => {
    await page.goto('/');
    await page.keyboard.press('Meta+n');

    await expect(page.locator('[data-testid="note-title"]')).toBeFocused();
    await page.fill('[data-testid="note-title"]', 'My New Note');
    await page.fill('[data-testid="note-content"]', '# Hello World');

    await page.keyboard.press('Meta+s');
    await expect(page.locator('.save-indicator')).toHaveText('Saved');
  });
});
```

### Test Data

```typescript
// tests/fixtures/notes.ts
export const testNote: Note = {
  id: 1,
  title: 'Test Note',
  content: '# Test\n\nThis is a test note.',
  folder_id: null,
  is_pinned: false,
  created_at: '2024-01-01T00:00:00Z',
  updated_at: '2024-01-01T00:00:00Z',
};
```

## Code Quality

### TypeScript Configuration

```json
{
  "compilerOptions": {
    "strict": true,
    "noUncheckedIndexedAccess": true,
    "noImplicitReturns": true,
    "noFallthroughCasesInSwitch": true
  }
}
```

### Import Organization

```typescript
// 1. External packages
import { writable } from 'svelte/store';
import Database from 'better-sqlite3';

// 2. Internal modules (absolute paths)
import { getDb } from '$lib/db/connection';
import type { Note } from '$lib/types';

// 3. Relative imports
import { parseWikiLinks } from './parser';
```

### Error Types

```typescript
// src/lib/errors.ts
export class NoteNotFoundError extends Error {
  constructor(id: number) {
    super(`Note with id ${id} not found`);
    this.name = 'NoteNotFoundError';
  }
}

export class FolderNotEmptyError extends Error {
  constructor(id: number) {
    super(`Folder ${id} is not empty`);
    this.name = 'FolderNotEmptyError';
  }
}
```

## Performance Guidelines

1. **Database queries**: Use prepared statements, avoid N+1
2. **Markdown parsing**: Parse on content change only, debounce 100ms
3. **Store updates**: Batch updates when possible
4. **Component rendering**: Use {#key} blocks for forced re-renders
5. **Large lists**: Virtualize folder tree and search results if > 100 items
