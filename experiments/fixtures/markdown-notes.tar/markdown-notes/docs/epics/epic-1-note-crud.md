---
epic_num: 1
title: Note CRUD
status: draft
---

# Epic 1: Note CRUD

**Status:** backlog
**Priority:** P0
**Stories:** 5

## Overview

Foundation epic that establishes the core note management functionality. This includes setting up the SQLite database schema, creating REST API endpoints for note operations, building the editor component, implementing real-time markdown preview, and adding note deletion with confirmation dialog.

## Dependencies

None - this is the foundation epic.

---

## Story 1.1: Set up SQLite database schema

**Status:** draft
**Epic:** Note CRUD
**Priority:** P0

## User Story

As a developer, I want to set up the SQLite database schema so that notes can be persisted locally with proper structure and relationships.

## Acceptance Criteria

1. **AC-1.1.1:** SQLite database is created at `~/.markdown-notes/notes.db` on first application startup
2. **AC-1.1.2:** Notes table exists with columns: id, title, content, folder_id, is_pinned, created_at, updated_at
3. **AC-1.1.3:** Folders table exists with columns: id, name, parent_id, created_at
4. **AC-1.1.4:** Database connection uses WAL mode for concurrent reads
5. **AC-1.1.5:** Foreign key constraints are enabled and enforced

## Tasks

- [ ] Task 1: Create database directory and file initialization (AC: 1)
  - [ ] Subtask 1.1: Create `src/lib/db/connection.ts` with singleton pattern
  - [ ] Subtask 1.2: Add directory creation if `~/.markdown-notes` doesn't exist
  - [ ] Subtask 1.3: Configure WAL mode and foreign keys pragmas
- [ ] Task 2: Define database schema (AC: 2, 3)
  - [ ] Subtask 2.1: Create `src/lib/db/schema.sql` with notes table DDL
  - [ ] Subtask 2.2: Add folders table DDL with self-referential parent_id
  - [ ] Subtask 2.3: Add indexes for folder_id, is_pinned, updated_at
- [ ] Task 3: Implement schema initialization (AC: 4, 5)
  - [ ] Subtask 3.1: Add schema execution on first connection
  - [ ] Subtask 3.2: Add migration version tracking table

## Technical Notes

- Use better-sqlite3 for synchronous database operations
- Store database path in environment variable for testing override
- Consider using `db.pragma('journal_mode = WAL')` for performance

## Dependencies

- Requires: None

---

## Story 1.2: Create note API endpoints (CRUD)

**Status:** draft
**Epic:** Note CRUD
**Priority:** P0

## User Story

As a user, I want API endpoints to create, read, update, and delete notes so that the frontend can manage note data.

## Acceptance Criteria

1. **AC-1.2.1:** GET /api/notes returns a list of all notes with id, title, updated_at, is_pinned
2. **AC-1.2.2:** POST /api/notes creates a new note and returns the created note with id
3. **AC-1.2.3:** GET /api/notes/:id returns a single note with full content
4. **AC-1.2.4:** PUT /api/notes/:id updates note title and/or content, updates updated_at timestamp
5. **AC-1.2.5:** DELETE /api/notes/:id removes the note from database
6. **AC-1.2.6:** All endpoints return appropriate HTTP status codes (200, 201, 404, 500)

## Tasks

- [ ] Task 1: Create notes query functions (AC: 1, 3)
  - [ ] Subtask 1.1: Create `src/lib/db/queries.ts` with prepared statements
  - [ ] Subtask 1.2: Implement `getAllNotes()` function
  - [ ] Subtask 1.3: Implement `getNoteById(id)` function
- [ ] Task 2: Implement list and get endpoints (AC: 1, 3, 6)
  - [ ] Subtask 2.1: Create `src/routes/api/notes/+server.ts` with GET handler
  - [ ] Subtask 2.2: Create `src/routes/api/notes/[id]/+server.ts` with GET handler
- [ ] Task 3: Implement create endpoint (AC: 2, 6)
  - [ ] Subtask 3.1: Add `createNote(title, content)` query function
  - [ ] Subtask 3.2: Add POST handler to `/api/notes/+server.ts`
  - [ ] Subtask 3.3: Validate request body has required fields
- [ ] Task 4: Implement update endpoint (AC: 4, 6)
  - [ ] Subtask 4.1: Add `updateNote(id, data)` query function
  - [ ] Subtask 4.2: Add PUT handler to `/api/notes/[id]/+server.ts`
  - [ ] Subtask 4.3: Auto-update updated_at timestamp
- [ ] Task 5: Implement delete endpoint (AC: 5, 6)
  - [ ] Subtask 5.1: Add `deleteNote(id)` query function
  - [ ] Subtask 5.2: Add DELETE handler to `/api/notes/[id]/+server.ts`

## Technical Notes

- Use json() helper from @sveltejs/kit for responses
- Return 404 when note not found
- Consider adding pagination to list endpoint for large datasets

## Dependencies

- Requires: Story 1.1

---

## Story 1.3: Build note editor component

**Status:** draft
**Epic:** Note CRUD
**Priority:** P0

## User Story

As a user, I want a markdown editor so that I can write and edit my notes with a clean editing experience.

## Acceptance Criteria

1. **AC-1.3.1:** Editor component displays note title in an editable input field
2. **AC-1.3.2:** Editor component displays note content in a textarea or code editor
3. **AC-1.3.3:** Changes to title or content trigger auto-save after 1 second of inactivity
4. **AC-1.3.4:** Save indicator shows "Saving..." during save and "Saved" after completion
5. **AC-1.3.5:** Editor uses monospace font for markdown editing
6. **AC-1.3.6:** Editor fills available vertical space in the layout

## Tasks

- [ ] Task 1: Create Editor component structure (AC: 1, 2, 5)
  - [ ] Subtask 1.1: Create `src/lib/components/Editor.svelte`
  - [ ] Subtask 1.2: Add title input with styling
  - [ ] Subtask 1.3: Add content textarea with monospace font
- [ ] Task 2: Implement auto-save functionality (AC: 3, 4)
  - [ ] Subtask 2.1: Add debounced save function (1000ms)
  - [ ] Subtask 2.2: Create save status store in `src/lib/stores/ui.ts`
  - [ ] Subtask 2.3: Display save indicator in editor toolbar
- [ ] Task 3: Integrate with API (AC: 3)
  - [ ] Subtask 3.1: Add `saveNote()` function that calls PUT endpoint
  - [ ] Subtask 3.2: Handle save errors with user notification
- [ ] Task 4: Style editor layout (AC: 6)
  - [ ] Subtask 4.1: Use Tailwind classes for flexible layout
  - [ ] Subtask 4.2: Ensure editor scrolls independently

## Technical Notes

- Use svelte reactive statements for debouncing
- Consider CodeMirror for enhanced editing in future iteration
- Handle unsaved changes warning on navigation

## Dependencies

- Requires: Story 1.2

---

## Story 1.4: Implement markdown preview

**Status:** draft
**Epic:** Note CRUD
**Priority:** P0

## User Story

As a user, I want to see a live preview of my markdown so that I can see how my note will look when rendered.

## Acceptance Criteria

1. **AC-1.4.1:** Preview panel shows rendered HTML from markdown content
2. **AC-1.4.2:** Preview updates within 100ms of content change (debounced)
3. **AC-1.4.3:** Preview renders headers, bold, italic, lists, code blocks, and links
4. **AC-1.4.4:** Code blocks display with syntax highlighting
5. **AC-1.4.5:** Preview panel is scrollable and synchronized with editor (optional)
6. **AC-1.4.6:** Preview can be toggled on/off with Cmd+P keyboard shortcut

## Tasks

- [ ] Task 1: Set up markdown-it parser (AC: 1, 3)
  - [ ] Subtask 1.1: Create `src/lib/markdown/parser.ts`
  - [ ] Subtask 1.2: Configure markdown-it with common extensions
  - [ ] Subtask 1.3: Export `parseMarkdown(content)` function
- [ ] Task 2: Create Preview component (AC: 1, 2)
  - [ ] Subtask 2.1: Create `src/lib/components/Preview.svelte`
  - [ ] Subtask 2.2: Add debounced reactive parsing (100ms)
  - [ ] Subtask 2.3: Render HTML safely with {@html} directive
- [ ] Task 3: Add syntax highlighting (AC: 4)
  - [ ] Subtask 3.1: Install and configure highlight.js or Prism
  - [ ] Subtask 3.2: Apply highlighting to code blocks in rendered output
- [ ] Task 4: Implement toggle functionality (AC: 6)
  - [ ] Subtask 4.1: Add preview visibility state to ui store
  - [ ] Subtask 4.2: Add keyboard shortcut handler for Cmd+P
  - [ ] Subtask 4.3: Animate panel show/hide transition

## Technical Notes

- Use `{@html}` carefully - markdown-it output is safe by default
- Consider using highlight.js for syntax highlighting (smaller bundle)
- Preview styling should match final rendered note appearance

## Dependencies

- Requires: Story 1.3

---

## Story 1.5: Add note deletion with confirmation

**Status:** draft
**Epic:** Note CRUD
**Priority:** P0

## User Story

As a user, I want to delete notes with a confirmation dialog so that I don't accidentally lose important content.

## Acceptance Criteria

1. **AC-1.5.1:** Delete button is visible in the editor toolbar
2. **AC-1.5.2:** Clicking delete shows a confirmation modal with note title
3. **AC-1.5.3:** Modal has "Cancel" and "Delete" buttons with clear visual distinction
4. **AC-1.5.4:** Confirming deletion removes note from database and navigates to home
5. **AC-1.5.5:** Cancel closes modal without action
6. **AC-1.5.6:** Keyboard shortcut Cmd+Delete triggers delete flow
7. **AC-1.5.7:** Escape key closes the confirmation modal

## Tasks

- [ ] Task 1: Create confirmation modal component (AC: 2, 3, 5, 7)
  - [ ] Subtask 1.1: Create `src/lib/components/DeleteConfirmation.svelte`
  - [ ] Subtask 1.2: Add modal overlay with focus trap
  - [ ] Subtask 1.3: Style Cancel (secondary) and Delete (danger) buttons
  - [ ] Subtask 1.4: Handle Escape key to close
- [ ] Task 2: Add delete button to editor (AC: 1, 6)
  - [ ] Subtask 2.1: Add trash icon button to editor toolbar
  - [ ] Subtask 2.2: Wire up Cmd+Delete keyboard shortcut
- [ ] Task 3: Implement deletion flow (AC: 4)
  - [ ] Subtask 3.1: Call DELETE /api/notes/:id on confirmation
  - [ ] Subtask 3.2: Update notes store to remove deleted note
  - [ ] Subtask 3.3: Navigate to home page after deletion
  - [ ] Subtask 3.4: Show toast notification for successful deletion

## Technical Notes

- Use Svelte's `createEventDispatcher` for modal events
- Consider "Don't ask again this session" checkbox for power users
- Focus should return to trigger element when modal closes

## Dependencies

- Requires: Story 1.2, Story 1.3
