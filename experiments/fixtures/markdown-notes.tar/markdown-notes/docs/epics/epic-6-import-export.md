---
epic_num: 6
title: Import/Export
status: draft
---

# Epic 6: Import/Export

**Status:** backlog
**Priority:** P2
**Stories:** 4

## Overview

Enable data portability by supporting markdown file import and export. Users can import existing markdown files (with optional frontmatter metadata), export individual notes, or bulk export folders or all notes. This ensures notes are never locked into the application.

## Dependencies

- Epic 1: Note CRUD (all stories)
- Epic 3: Organization (Story 3.1 - folders)
- Epic 4: Tagging System (Story 4.1 - tags)

---

## Story 6.1: Create markdown file import

**Status:** draft
**Epic:** Import/Export
**Priority:** P2

## User Story

As a user, I want to import markdown files so that I can bring my existing notes into the application.

## Acceptance Criteria

1. **AC-6.1.1:** Import button opens file picker for .md files
2. **AC-6.1.2:** Selected file content is parsed and creates a new note
3. **AC-6.1.3:** File name (without extension) becomes note title
4. **AC-6.1.4:** Import supports single file selection
5. **AC-6.1.5:** Success message shows after import with link to new note
6. **AC-6.1.6:** Error handling for invalid files with user-friendly message

## Tasks

- [ ] Task 1: Create import UI (AC: 1)
  - [ ] Subtask 1.1: Add "Import" button to sidebar header or menu
  - [ ] Subtask 1.2: Create hidden file input with accept=".md"
  - [ ] Subtask 1.3: Trigger file picker on button click
- [ ] Task 2: Implement file reading (AC: 2, 3, 6)
  - [ ] Subtask 2.1: Read file content using FileReader API
  - [ ] Subtask 2.2: Extract title from filename
  - [ ] Subtask 2.3: Handle encoding issues gracefully
  - [ ] Subtask 2.4: Validate file is valid markdown
- [ ] Task 3: Create note from import (AC: 4, 5)
  - [ ] Subtask 3.1: Call POST /api/notes with parsed content
  - [ ] Subtask 3.2: Navigate to new note after creation
  - [ ] Subtask 3.3: Show toast with success message

## Technical Notes

- Use FileReader API for client-side file reading
- Consider max file size limit (e.g., 10MB)
- Handle common encodings (UTF-8, UTF-16)

## Dependencies

- Requires: Story 1.2

---

## Story 6.2: Implement single note export

**Status:** draft
**Epic:** Import/Export
**Priority:** P2

## User Story

As a user, I want to export a note as a markdown file so that I can use it in other applications or backup.

## Acceptance Criteria

1. **AC-6.2.1:** Export button appears in editor toolbar
2. **AC-6.2.2:** Clicking export downloads a .md file
3. **AC-6.2.3:** File name is based on note title (sanitized for filesystem)
4. **AC-6.2.4:** Exported content matches note content exactly
5. **AC-6.2.5:** Keyboard shortcut Cmd+Shift+E triggers export

## Tasks

- [ ] Task 1: Add export button (AC: 1, 5)
  - [ ] Subtask 1.1: Add download icon button to editor toolbar
  - [ ] Subtask 1.2: Wire up Cmd+Shift+E keyboard shortcut
- [ ] Task 2: Implement download functionality (AC: 2, 3, 4)
  - [ ] Subtask 2.1: Create GET /api/export/:id endpoint
  - [ ] Subtask 2.2: Sanitize title for filename (remove special chars)
  - [ ] Subtask 2.3: Set Content-Disposition header for download
  - [ ] Subtask 2.4: Return plain text markdown content
- [ ] Task 3: Client-side download (AC: 2)
  - [ ] Subtask 3.1: Alternative: use Blob API for client-side download
  - [ ] Subtask 3.2: Create download link and trigger click

## Technical Notes

- Filename sanitization: replace `/\:*?"<>|` with `-` or `_`
- Use `Content-Type: text/markdown` header
- Consider adding timestamp to filename to avoid conflicts

## Dependencies

- Requires: Story 1.2

---

## Story 6.3: Add bulk export (folder/all)

**Status:** draft
**Epic:** Import/Export
**Priority:** P2

## User Story

As a user, I want to export multiple notes at once so that I can backup my entire knowledge base or share a folder.

## Acceptance Criteria

1. **AC-6.3.1:** Export option in folder context menu exports all notes in folder
2. **AC-6.3.2:** Global "Export All" option in settings/menu
3. **AC-6.3.3:** Bulk export creates a ZIP file containing all notes
4. **AC-6.3.4:** Notes preserve folder structure in ZIP (folder/note.md)
5. **AC-6.3.5:** Progress indicator shows during bulk export
6. **AC-6.3.6:** Subfolder notes included when exporting parent folder

## Tasks

- [ ] Task 1: Add bulk export triggers (AC: 1, 2)
  - [ ] Subtask 1.1: Add "Export folder" to folder context menu
  - [ ] Subtask 1.2: Add "Export all notes" to app menu/settings
- [ ] Task 2: Implement ZIP generation (AC: 3, 4, 6)
  - [ ] Subtask 2.1: Create POST /api/export/bulk endpoint
  - [ ] Subtask 2.2: Accept folder_id param (null for all)
  - [ ] Subtask 2.3: Use JSZip or similar for ZIP creation
  - [ ] Subtask 2.4: Build folder structure paths for notes
- [ ] Task 3: Handle large exports (AC: 5)
  - [ ] Subtask 3.1: Show progress modal during export
  - [ ] Subtask 3.2: Stream ZIP generation for large datasets
  - [ ] Subtask 3.3: Cancel option for long-running exports

## Technical Notes

- Use JSZip library for client-side ZIP generation
- Consider server-side ZIP for very large exports
- ZIP filename: `notes-export-YYYY-MM-DD.zip`

## Dependencies

- Requires: Story 6.2, Story 3.1

---

## Story 6.4: Handle frontmatter metadata

**Status:** draft
**Epic:** Import/Export
**Priority:** P2

## User Story

As a user, I want frontmatter metadata preserved during import/export so that tags and other metadata are not lost.

## Acceptance Criteria

1. **AC-6.4.1:** Import parses YAML frontmatter from markdown files
2. **AC-6.4.2:** Frontmatter "tags" field creates note tags on import
3. **AC-6.4.3:** Frontmatter "created" field sets note created_at
4. **AC-6.4.4:** Export includes frontmatter with tags and dates
5. **AC-6.4.5:** Frontmatter is stripped from note content (not duplicated)
6. **AC-6.4.6:** Invalid frontmatter is ignored (import continues with content only)

## Tasks

- [ ] Task 1: Implement frontmatter parsing (AC: 1, 5, 6)
  - [ ] Subtask 1.1: Create parseFrontmatter() utility function
  - [ ] Subtask 1.2: Detect frontmatter delimiters (---)
  - [ ] Subtask 1.3: Parse YAML between delimiters
  - [ ] Subtask 1.4: Return content without frontmatter
  - [ ] Subtask 1.5: Handle invalid YAML gracefully
- [ ] Task 2: Apply metadata on import (AC: 2, 3)
  - [ ] Subtask 2.1: Extract tags array from frontmatter
  - [ ] Subtask 2.2: Create tags and associations after note creation
  - [ ] Subtask 2.3: Parse and set created_at if valid date
- [ ] Task 3: Generate frontmatter on export (AC: 4)
  - [ ] Subtask 3.1: Create generateFrontmatter() utility
  - [ ] Subtask 3.2: Include tags as array
  - [ ] Subtask 3.3: Include created and updated dates
  - [ ] Subtask 3.4: Prepend to exported content

## Technical Notes

- Use js-yaml for YAML parsing
- Standard frontmatter format:
  ```yaml
  ---
  tags: [work, project-x]
  created: 2024-01-15T10:30:00Z
  updated: 2024-01-20T14:15:00Z
  ---
  ```
- Consider supporting additional metadata: folder path, pinned status

## Dependencies

- Requires: Story 6.1, Story 6.2, Story 4.1
