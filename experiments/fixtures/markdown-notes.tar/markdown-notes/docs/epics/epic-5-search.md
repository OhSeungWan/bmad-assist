---
epic_num: 5
title: Search
status: draft
---

# Epic 5: Search

**Status:** backlog
**Priority:** P1
**Stories:** 4

## Overview

Implement full-text search using SQLite FTS5 for fast, relevant search across all note content. Includes search input with live results dropdown, highlighted matches in results, and keyboard shortcuts for efficient navigation.

## Dependencies

- Epic 1: Note CRUD (all stories)

---

## Story 5.1: Set up SQLite FTS5 for full-text search

**Status:** draft
**Epic:** Search
**Priority:** P1

## User Story

As a developer, I want to set up full-text search indexing so that users can quickly find notes by content.

## Acceptance Criteria

1. **AC-5.1.1:** FTS5 virtual table notes_fts exists with title and content columns
2. **AC-5.1.2:** Triggers keep FTS index in sync with notes table (INSERT, UPDATE, DELETE)
3. **AC-5.1.3:** GET /api/search?q=term returns matching notes with relevance ranking
4. **AC-5.1.4:** Search results include note id, title, and snippet with match context
5. **AC-5.1.5:** Search returns results within 100ms for 10,000 notes

## Tasks

- [ ] Task 1: Create FTS5 virtual table (AC: 1)
  - [ ] Subtask 1.1: Add FTS5 table definition to schema.sql
  - [ ] Subtask 1.2: Configure content sync with notes table
- [ ] Task 2: Create sync triggers (AC: 2)
  - [ ] Subtask 2.1: Add AFTER INSERT trigger to populate FTS
  - [ ] Subtask 2.2: Add AFTER DELETE trigger to remove from FTS
  - [ ] Subtask 2.3: Add AFTER UPDATE trigger to update FTS
- [ ] Task 3: Implement search endpoint (AC: 3, 4)
  - [ ] Subtask 3.1: Create `src/routes/api/search/+server.ts`
  - [ ] Subtask 3.2: Use FTS5 MATCH with bm25() for ranking
  - [ ] Subtask 3.3: Use snippet() function for context extraction
- [ ] Task 4: Optimize performance (AC: 5)
  - [ ] Subtask 4.1: Add LIMIT to search query
  - [ ] Subtask 4.2: Consider prefix search for incremental results

## Technical Notes

- FTS5 query syntax: `MATCH '"term1 term2"'` for phrase, `term1 OR term2` for either
- snippet() function: `snippet(notes_fts, 1, '<mark>', '</mark>', '...', 64)`
- bm25() provides relevance ranking

## Dependencies

- Requires: Story 1.1

---

## Story 5.2: Create search input with results

**Status:** draft
**Epic:** Search
**Priority:** P1

## User Story

As a user, I want a search box that shows results as I type so that I can quickly find notes.

## Acceptance Criteria

1. **AC-5.2.1:** Search input appears in the sidebar with magnifying glass icon
2. **AC-5.2.2:** Results dropdown appears after typing 2+ characters
3. **AC-5.2.3:** Results show note title and context snippet
4. **AC-5.2.4:** Clicking a result navigates to that note
5. **AC-5.2.5:** "No results" message displays when search returns empty
6. **AC-5.2.6:** Loading indicator shows during search request

## Tasks

- [ ] Task 1: Create SearchInput component (AC: 1)
  - [ ] Subtask 1.1: Create `src/lib/components/SearchInput.svelte`
  - [ ] Subtask 1.2: Add input with magnifying glass icon
  - [ ] Subtask 1.3: Style consistent with sidebar design
- [ ] Task 2: Implement search triggering (AC: 2, 6)
  - [ ] Subtask 2.1: Add debounced search call (200ms)
  - [ ] Subtask 2.2: Only search when query >= 2 characters
  - [ ] Subtask 2.3: Show loading spinner during fetch
- [ ] Task 3: Build results dropdown (AC: 3, 4, 5)
  - [ ] Subtask 3.1: Create SearchResults component
  - [ ] Subtask 3.2: Display title and snippet for each result
  - [ ] Subtask 3.3: Handle click to navigate to note
  - [ ] Subtask 3.4: Display empty state message

## Technical Notes

- Use Svelte portal for dropdown if it needs to overflow sidebar
- Consider virtual scrolling for many results
- Close dropdown on click outside or Escape

## Dependencies

- Requires: Story 5.1

---

## Story 5.3: Add search highlighting in results

**Status:** draft
**Epic:** Search
**Priority:** P2

## User Story

As a user, I want search matches highlighted so that I can quickly see why each result matched.

## Acceptance Criteria

1. **AC-5.3.1:** Matched terms in title are highlighted with background color
2. **AC-5.3.2:** Matched terms in snippet are highlighted with background color
3. **AC-5.3.3:** Highlight color matches primary color at low opacity
4. **AC-5.3.4:** Multiple matches in same result are all highlighted
5. **AC-5.3.5:** Highlighting works for partial word matches

## Tasks

- [ ] Task 1: Extract match positions from API (AC: 1, 2, 4)
  - [ ] Subtask 1.1: Update search query to use highlight() or snippet() markers
  - [ ] Subtask 1.2: Return marked text from API
- [ ] Task 2: Render highlighted text (AC: 1, 2, 3)
  - [ ] Subtask 2.1: Create HighlightedText component
  - [ ] Subtask 2.2: Parse marked text and render with styled spans
  - [ ] Subtask 2.3: Use consistent highlight styling
- [ ] Task 3: Handle partial matches (AC: 5)
  - [ ] Subtask 3.1: Ensure FTS5 configuration captures partial words
  - [ ] Subtask 3.2: Verify highlighting for partial matches

## Technical Notes

- FTS5 snippet() wraps matches in specified tags
- Use `<mark>` or custom span for semantic highlighting
- Consider accessibility: highlight color must have sufficient contrast

## Dependencies

- Requires: Story 5.2

---

## Story 5.4: Implement search keyboard shortcuts

**Status:** draft
**Epic:** Search
**Priority:** P2

## User Story

As a power user, I want keyboard shortcuts for search so that I can find notes without using the mouse.

## Acceptance Criteria

1. **AC-5.4.1:** Cmd+F focuses the search input from anywhere in the app
2. **AC-5.4.2:** Arrow up/down navigates through search results
3. **AC-5.4.3:** Enter opens the currently highlighted result
4. **AC-5.4.4:** Escape clears search and closes results dropdown
5. **AC-5.4.5:** Focus returns to previous element after closing search
6. **AC-5.4.6:** Cmd+K opens quick switcher (search with note titles only)

## Tasks

- [ ] Task 1: Implement global search shortcut (AC: 1, 5)
  - [ ] Subtask 1.1: Add global keydown handler for Cmd+F
  - [ ] Subtask 1.2: Store previous activeElement before focusing
  - [ ] Subtask 1.3: Restore focus on search close
- [ ] Task 2: Add result navigation (AC: 2, 3)
  - [ ] Subtask 2.1: Track highlighted result index
  - [ ] Subtask 2.2: Handle ArrowUp/ArrowDown to change selection
  - [ ] Subtask 2.3: Handle Enter to open selected result
  - [ ] Subtask 2.4: Scroll highlighted item into view
- [ ] Task 3: Implement close behavior (AC: 4)
  - [ ] Subtask 3.1: Handle Escape key to clear input
  - [ ] Subtask 3.2: Close dropdown on Escape
  - [ ] Subtask 3.3: Close dropdown on blur (with delay for click)
- [ ] Task 4: Create quick switcher (AC: 6)
  - [ ] Subtask 4.1: Create QuickSwitcher modal component
  - [ ] Subtask 4.2: Search note titles only (faster)
  - [ ] Subtask 4.3: Open with Cmd+K shortcut

## Technical Notes

- Use event.preventDefault() to prevent browser find dialog on Cmd+F
- Quick switcher is a common pattern in Notion, Obsidian
- Consider recent notes in quick switcher when query is empty

## Dependencies

- Requires: Story 5.2
