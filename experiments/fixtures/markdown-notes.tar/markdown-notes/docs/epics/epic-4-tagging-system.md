---
epic_num: 4
title: Tagging System
status: draft
---

# Epic 4: Tagging System

**Status:** backlog
**Priority:** P1
**Stories:** 4

## Overview

Implement a flexible tagging system allowing multiple tags per note with a tag input component, tag browser in the sidebar, and tag-based filtering of notes. Tags provide cross-cutting organization complementary to the folder hierarchy.

## Dependencies

- Epic 1: Note CRUD (all stories)

---

## Story 4.1: Add tags table and relations

**Status:** draft
**Epic:** Tagging System
**Priority:** P1

## User Story

As a developer, I want a database schema for tags so that notes can have multiple tags associated with them.

## Acceptance Criteria

1. **AC-4.1.1:** Tags table exists with id and unique name columns
2. **AC-4.1.2:** Note_tags junction table exists with note_id and tag_id foreign keys
3. **AC-4.1.3:** GET /api/tags returns all tags with usage count
4. **AC-4.1.4:** POST /api/notes/:id/tags adds tag to note (creates tag if new)
5. **AC-4.1.5:** DELETE /api/notes/:id/tags/:tagId removes tag from note
6. **AC-4.1.6:** Deleting a note removes all its tag associations (CASCADE)

## Tasks

- [ ] Task 1: Update database schema (AC: 1, 2, 6)
  - [ ] Subtask 1.1: Add tags table to schema.sql
  - [ ] Subtask 1.2: Add note_tags junction table with composite primary key
  - [ ] Subtask 1.3: Add ON DELETE CASCADE for note_id foreign key
- [ ] Task 2: Create tag query functions (AC: 3)
  - [ ] Subtask 2.1: Add getAllTags() with note count per tag
  - [ ] Subtask 2.2: Add getTagsForNote(noteId) function
- [ ] Task 3: Implement tag management endpoints (AC: 4, 5)
  - [ ] Subtask 3.1: Create `src/routes/api/tags/+server.ts` with GET
  - [ ] Subtask 3.2: Create `src/routes/api/notes/[id]/tags/+server.ts` with POST
  - [ ] Subtask 3.3: Create `src/routes/api/notes/[id]/tags/[tagId]/+server.ts` with DELETE
  - [ ] Subtask 3.4: Handle tag creation when adding new tag name

## Technical Notes

- Tag names should be case-insensitive (normalize to lowercase)
- Consider tag name validation (alphanumeric, hyphens, max length)
- Orphaned tags (no notes) can be cleaned up periodically or left as suggestions

## Dependencies

- Requires: Story 1.1

---

## Story 4.2: Create tag input component

**Status:** draft
**Epic:** Tagging System
**Priority:** P1

## User Story

As a user, I want to add and remove tags from notes so that I can organize notes by topic or category.

## Acceptance Criteria

1. **AC-4.2.1:** Tag input area displays in the editor toolbar below title
2. **AC-4.2.2:** Existing tags for the note display as removable pills
3. **AC-4.2.3:** Plus button opens tag input with autocomplete dropdown
4. **AC-4.2.4:** Typing in input filters existing tags and shows matches
5. **AC-4.2.5:** Pressing Enter adds the tag (existing or new)
6. **AC-4.2.6:** Clicking X on a tag pill removes it from the note
7. **AC-4.2.7:** Tags are saved immediately (no need for note save)

## Tasks

- [ ] Task 1: Create TagInput component (AC: 1, 2, 6)
  - [ ] Subtask 1.1: Create `src/lib/components/TagInput.svelte`
  - [ ] Subtask 1.2: Display current note tags as styled pills
  - [ ] Subtask 1.3: Add X button on each pill with remove handler
- [ ] Task 2: Implement tag addition flow (AC: 3, 4, 5)
  - [ ] Subtask 2.1: Add plus button that reveals input field
  - [ ] Subtask 2.2: Create tags store with all available tags
  - [ ] Subtask 2.3: Filter tags based on input text
  - [ ] Subtask 2.4: Show dropdown with matching tags
  - [ ] Subtask 2.5: Handle Enter key to add selected/typed tag
- [ ] Task 3: Connect to API (AC: 7)
  - [ ] Subtask 3.1: Call POST endpoint on tag add
  - [ ] Subtask 3.2: Call DELETE endpoint on tag remove
  - [ ] Subtask 3.3: Update local note tags state

## Technical Notes

- Use Svelte action for click-outside to close dropdown
- Debounce filter input for performance
- Style tags with # prefix for visual consistency

## Dependencies

- Requires: Story 4.1

---

## Story 4.3: Build tag browser sidebar

**Status:** draft
**Epic:** Tagging System
**Priority:** P1

## User Story

As a user, I want to see all my tags in the sidebar so that I can browse notes by tag.

## Acceptance Criteria

1. **AC-4.3.1:** Tags section appears in sidebar below folders
2. **AC-4.3.2:** Tags display as clickable pills with # prefix
3. **AC-4.3.3:** Each tag shows note count in muted text
4. **AC-4.3.4:** Tags are sorted alphabetically
5. **AC-4.3.5:** Clicking a tag filters notes to show only tagged notes
6. **AC-4.3.6:** Section is collapsible if tag list is long (>10)

## Tasks

- [ ] Task 1: Create TagBrowser component (AC: 1, 2, 4)
  - [ ] Subtask 1.1: Create `src/lib/components/TagBrowser.svelte`
  - [ ] Subtask 1.2: Fetch and display all tags sorted alphabetically
  - [ ] Subtask 1.3: Style as pills with # prefix
- [ ] Task 2: Display usage counts (AC: 3)
  - [ ] Subtask 2.1: Include count in tag list API response
  - [ ] Subtask 2.2: Display count in smaller muted text
- [ ] Task 3: Implement tag selection (AC: 5)
  - [ ] Subtask 3.1: Add selectedTagId to ui store
  - [ ] Subtask 3.2: Add click handler to set selected tag
  - [ ] Subtask 3.3: Filter notes list by selected tag
  - [ ] Subtask 3.4: Highlight selected tag in browser
- [ ] Task 4: Add collapse functionality (AC: 6)
  - [ ] Subtask 4.1: Add "Show more" / "Show less" toggle
  - [ ] Subtask 4.2: Limit initial display to 10 tags
  - [ ] Subtask 4.3: Store collapsed state in localStorage

## Technical Notes

- Consider showing tag cloud with varying sizes based on count
- Empty state: "No tags yet" message
- Tags with 0 notes can be hidden or shown with visual distinction

## Dependencies

- Requires: Story 4.1

---

## Story 4.4: Implement tag filtering

**Status:** draft
**Epic:** Tagging System
**Priority:** P1

## User Story

As a user, I want to filter notes by tag so that I can focus on notes about a specific topic.

## Acceptance Criteria

1. **AC-4.4.1:** Selecting a tag in sidebar filters note list to matching notes
2. **AC-4.4.2:** Active tag filter shows in notes list header
3. **AC-4.4.3:** Clear button removes tag filter and shows all notes
4. **AC-4.4.4:** Tag filter works in combination with folder filter
5. **AC-4.4.5:** Tag filter works with search (intersection of results)
6. **AC-4.4.6:** URL reflects active tag filter for shareability

## Tasks

- [ ] Task 1: Implement filter state (AC: 1, 3)
  - [ ] Subtask 1.1: Add activeTagFilter to ui store
  - [ ] Subtask 1.2: Create derived filteredNotes store
  - [ ] Subtask 1.3: Add clear filter button when tag active
- [ ] Task 2: Show filter indicator (AC: 2)
  - [ ] Subtask 2.1: Display active tag as chip in notes list header
  - [ ] Subtask 2.2: Add X button on chip to clear filter
- [ ] Task 3: Combine filters (AC: 4, 5)
  - [ ] Subtask 3.1: Update filteredNotes to respect folder AND tag
  - [ ] Subtask 3.2: Integrate with search results when active
- [ ] Task 4: Sync with URL (AC: 6)
  - [ ] Subtask 4.1: Add ?tag=tagName query parameter
  - [ ] Subtask 4.2: Read tag from URL on page load
  - [ ] Subtask 4.3: Update URL when tag changes (history.replaceState)

## Technical Notes

- Multiple simultaneous tag filters could be future enhancement
- Consider keyboard shortcut to clear all filters
- Empty state when filter returns no results

## Dependencies

- Requires: Story 4.3
