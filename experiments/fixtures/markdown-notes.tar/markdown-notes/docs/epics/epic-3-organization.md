---
epic_num: 3
title: Organization
status: draft
---

# Epic 3: Organization

**Status:** backlog
**Priority:** P1
**Stories:** 5

## Overview

Implement hierarchical folder organization for notes including a tree navigation component in the sidebar, drag-and-drop note moving between folders, note pinning for favorites, and multiple sorting options for note lists.

## Dependencies

- Epic 1: Note CRUD (all stories)

---

## Story 3.1: Implement folder hierarchy

**Status:** draft
**Epic:** Organization
**Priority:** P1

## User Story

As a user, I want to organize my notes into folders so that I can group related notes together.

## Acceptance Criteria

1. **AC-3.1.1:** Folders table exists with name, parent_id for nesting
2. **AC-3.1.2:** GET /api/folders returns flat list with parent_id for tree building
3. **AC-3.1.3:** POST /api/folders creates a new folder with optional parent_id
4. **AC-3.1.4:** PUT /api/folders/:id renames or moves folder to new parent
5. **AC-3.1.5:** DELETE /api/folders/:id removes empty folder (error if contains notes or subfolders)
6. **AC-3.1.6:** Notes can be assigned to a folder via folder_id

## Tasks

- [ ] Task 1: Create folder database operations (AC: 1, 2)
  - [ ] Subtask 1.1: Verify folders table exists in schema
  - [ ] Subtask 1.2: Add folder query functions to queries.ts
  - [ ] Subtask 1.3: Create getAllFolders() returning flat list
- [ ] Task 2: Implement folder CRUD endpoints (AC: 3, 4, 5)
  - [ ] Subtask 2.1: Create `src/routes/api/folders/+server.ts` with GET, POST
  - [ ] Subtask 2.2: Create `src/routes/api/folders/[id]/+server.ts` with PUT, DELETE
  - [ ] Subtask 2.3: Add validation for non-empty folder deletion
- [ ] Task 3: Add folder assignment to notes (AC: 6)
  - [ ] Subtask 3.1: Update note PUT endpoint to accept folder_id
  - [ ] Subtask 3.2: Add folder filter to note GET endpoint query params

## Technical Notes

- Use recursive CTE for tree queries if needed
- Limit nesting depth to prevent performance issues (3-4 levels)
- Consider soft delete for folders to prevent data loss

## Dependencies

- Requires: Story 1.1, Story 1.2

---

## Story 3.2: Create folder tree navigation

**Status:** draft
**Epic:** Organization
**Priority:** P1

## User Story

As a user, I want to see my folders as a tree in the sidebar so that I can navigate to notes within folders.

## Acceptance Criteria

1. **AC-3.2.1:** Sidebar displays folder hierarchy as expandable tree
2. **AC-3.2.2:** Clicking a folder shows notes within that folder
3. **AC-3.2.3:** Folders can be expanded/collapsed with chevron icon
4. **AC-3.2.4:** Current folder is visually highlighted
5. **AC-3.2.5:** "All Notes" option shows all notes regardless of folder
6. **AC-3.2.6:** Right-click context menu offers: New Subfolder, Rename, Delete

## Tasks

- [ ] Task 1: Create FolderTree component (AC: 1, 3)
  - [ ] Subtask 1.1: Create `src/lib/components/FolderTree.svelte`
  - [ ] Subtask 1.2: Build tree structure from flat folder list
  - [ ] Subtask 1.3: Add expand/collapse state per folder
  - [ ] Subtask 1.4: Add chevron rotation animation
- [ ] Task 2: Implement folder navigation (AC: 2, 4, 5)
  - [ ] Subtask 2.1: Create folders store in `src/lib/stores/folders.ts`
  - [ ] Subtask 2.2: Add currentFolderId state to ui store
  - [ ] Subtask 2.3: Filter notes display based on selected folder
  - [ ] Subtask 2.4: Add "All Notes" as first item in tree
- [ ] Task 3: Add context menu (AC: 6)
  - [ ] Subtask 3.1: Create ContextMenu component
  - [ ] Subtask 3.2: Wire up right-click handler on folder items
  - [ ] Subtask 3.3: Implement New Subfolder, Rename, Delete actions

## Technical Notes

- Use recursive component for nested rendering
- Store expand/collapse state in localStorage for persistence
- Indent children with consistent spacing (16px per level)

## Dependencies

- Requires: Story 3.1

---

## Story 3.3: Add drag-and-drop note moving

**Status:** draft
**Epic:** Organization
**Priority:** P2

## User Story

As a user, I want to drag notes between folders so that I can reorganize my notes quickly.

## Acceptance Criteria

1. **AC-3.3.1:** Notes in the list can be dragged
2. **AC-3.3.2:** Folders in the tree are valid drop targets
3. **AC-3.3.3:** Visual indicator shows valid drop target on hover
4. **AC-3.3.4:** Dropping updates the note's folder_id
5. **AC-3.3.5:** Drag operation can be cancelled with Escape key
6. **AC-3.3.6:** Accessibility: keyboard alternative for moving (context menu or shortcut)

## Tasks

- [ ] Task 1: Implement drag functionality on notes (AC: 1, 5)
  - [ ] Subtask 1.1: Add draggable attribute to note list items
  - [ ] Subtask 1.2: Set drag data with note ID
  - [ ] Subtask 1.3: Add Escape key handler to cancel drag
- [ ] Task 2: Implement drop targets on folders (AC: 2, 3)
  - [ ] Subtask 2.1: Add drop zone handlers to FolderTree items
  - [ ] Subtask 2.2: Add visual highlight style on dragover
  - [ ] Subtask 2.3: Validate drop target (prevent invalid drops)
- [ ] Task 3: Execute move operation (AC: 4)
  - [ ] Subtask 3.1: Call PUT /api/notes/:id with new folder_id on drop
  - [ ] Subtask 3.2: Update notes store to reflect new folder
  - [ ] Subtask 3.3: Show toast confirmation of move
- [ ] Task 4: Add keyboard alternative (AC: 6)
  - [ ] Subtask 4.1: Add "Move to folder" option in note context menu
  - [ ] Subtask 4.2: Show folder picker dialog when selected

## Technical Notes

- Use native HTML5 drag and drop API
- Consider using svelte-dnd-action for enhanced UX
- Test on touch devices (may need fallback)

## Dependencies

- Requires: Story 3.2

---

## Story 3.4: Implement note pinning

**Status:** draft
**Epic:** Organization
**Priority:** P1

## User Story

As a user, I want to pin important notes so that they appear at the top of my notes list for quick access.

## Acceptance Criteria

1. **AC-3.4.1:** Pin button appears in editor toolbar and note list item hover
2. **AC-3.4.2:** Clicking pin toggles the note's is_pinned state
3. **AC-3.4.3:** Pinned notes display a pin icon indicator
4. **AC-3.4.4:** Pinned notes appear at the top of note lists, before unpinned
5. **AC-3.4.5:** "Favorites" folder in sidebar shows all pinned notes
6. **AC-3.4.6:** Pinned state persists across sessions

## Tasks

- [ ] Task 1: Add pin toggle to UI (AC: 1, 2, 3)
  - [ ] Subtask 1.1: Add pin icon button to editor toolbar
  - [ ] Subtask 1.2: Add pin icon button to note list item (hover reveal)
  - [ ] Subtask 1.3: Show filled/outline icon based on pinned state
- [ ] Task 2: Implement pin persistence (AC: 2, 6)
  - [ ] Subtask 2.1: Create PUT /api/notes/:id/pin endpoint (toggle)
  - [ ] Subtask 2.2: Update notes store on pin toggle
- [ ] Task 3: Sort pinned notes to top (AC: 4)
  - [ ] Subtask 3.1: Update note list sorting to prioritize is_pinned
  - [ ] Subtask 3.2: Add visual separator between pinned and unpinned sections
- [ ] Task 4: Add Favorites virtual folder (AC: 5)
  - [ ] Subtask 4.1: Add "Favorites" as second item in sidebar (after All Notes)
  - [ ] Subtask 4.2: Filter to show only pinned notes when selected

## Technical Notes

- Pin toggle is a single boolean flip, not a separate endpoint
- Sort order: pinned first, then by selected sort (date, title, etc.)
- Star icon is common alternative to pin icon

## Dependencies

- Requires: Story 1.2

---

## Story 3.5: Add sorting options (date, title, modified)

**Status:** draft
**Epic:** Organization
**Priority:** P2

## User Story

As a user, I want to sort my notes by different criteria so that I can find notes based on my current needs.

## Acceptance Criteria

1. **AC-3.5.1:** Sort dropdown appears in the notes list header
2. **AC-3.5.2:** Available sort options: Last Modified, Date Created, Title (A-Z), Title (Z-A)
3. **AC-3.5.3:** Selected sort order persists in localStorage
4. **AC-3.5.4:** Notes list updates immediately when sort order changes
5. **AC-3.5.5:** Pinned notes remain at top regardless of sort order

## Tasks

- [ ] Task 1: Create sort selector UI (AC: 1, 2)
  - [ ] Subtask 1.1: Add dropdown component to notes list header
  - [ ] Subtask 1.2: Define sort options with labels and values
  - [ ] Subtask 1.3: Show current selection in dropdown trigger
- [ ] Task 2: Implement sort logic (AC: 4, 5)
  - [ ] Subtask 2.1: Add sortOrder state to ui store
  - [ ] Subtask 2.2: Create derived store that sorts notes
  - [ ] Subtask 2.3: Ensure pinned notes sort separately at top
- [ ] Task 3: Persist sort preference (AC: 3)
  - [ ] Subtask 3.1: Save sortOrder to localStorage on change
  - [ ] Subtask 3.2: Load sortOrder from localStorage on app init

## Technical Notes

- Default sort: Last Modified (descending)
- Client-side sorting is sufficient for reasonable note counts
- Consider server-side sort for large datasets (1000+ notes)

## Dependencies

- Requires: Story 3.4
