# Epics Overview: Markdown Note Taking App

## Summary

| Epic | Name | Stories | Priority | Status |
|------|------|---------|----------|--------|
| 1 | Note CRUD | 5 | P0 | backlog |
| 2 | Markdown Features | 4 | P0 | backlog |
| 3 | Organization | 5 | P1 | backlog |
| 4 | Tagging System | 4 | P1 | backlog |
| 5 | Search | 4 | P1 | backlog |
| 6 | Import/Export | 4 | P2 | backlog |

**Total Stories: 26**

## Epic 1: Note CRUD

Foundation epic establishing core note management functionality including database setup, API endpoints, editor component, markdown preview, and note deletion.

**Stories:**
- 1.1: Set up SQLite database schema
- 1.2: Create note API endpoints (CRUD)
- 1.3: Build note editor component
- 1.4: Implement markdown preview
- 1.5: Add note deletion with confirmation

**Dependencies:** None (foundation epic)

## Epic 2: Markdown Features

Enhance markdown editing with wiki-style linking and backlinks display, enabling connected knowledge base functionality.

**Stories:**
- 2.1: Configure markdown-it with extensions
- 2.2: Add syntax highlighting in preview
- 2.3: Implement wiki-link parsing [[title]]
- 2.4: Build backlinks display component

**Dependencies:** Epic 1 (Note CRUD)

## Epic 3: Organization

Implement folder hierarchy for note organization with tree navigation, drag-and-drop, pinning, and sorting options.

**Stories:**
- 3.1: Implement folder hierarchy
- 3.2: Create folder tree navigation
- 3.3: Add drag-and-drop note moving
- 3.4: Implement note pinning
- 3.5: Add sorting options (date, title, modified)

**Dependencies:** Epic 1 (Note CRUD)

## Epic 4: Tagging System

Add tagging functionality with multi-tag assignment per note, tag browsing sidebar, and tag-based filtering.

**Stories:**
- 4.1: Add tags table and relations
- 4.2: Create tag input component
- 4.3: Build tag browser sidebar
- 4.4: Implement tag filtering

**Dependencies:** Epic 1 (Note CRUD)

## Epic 5: Search

Implement full-text search using SQLite FTS5 with search input, results display, highlighting, and keyboard shortcuts.

**Stories:**
- 5.1: Set up SQLite FTS5 for full-text search
- 5.2: Create search input with results
- 5.3: Add search highlighting in results
- 5.4: Implement search keyboard shortcuts

**Dependencies:** Epic 1 (Note CRUD)

## Epic 6: Import/Export

Enable data portability with markdown file import and export capabilities including frontmatter metadata handling.

**Stories:**
- 6.1: Create markdown file import
- 6.2: Implement single note export
- 6.3: Add bulk export (folder/all)
- 6.4: Handle frontmatter metadata

**Dependencies:** Epic 1 (Note CRUD), Epic 3 (Organization), Epic 4 (Tagging System)

## Dependency Graph

```
Epic 1: Note CRUD
    │
    ├──► Epic 2: Markdown Features
    │
    ├──► Epic 3: Organization ──┐
    │                           │
    ├──► Epic 4: Tagging System ├──► Epic 6: Import/Export
    │                           │
    └──► Epic 5: Search ────────┘
```

## Recommended Implementation Order

1. **Epic 1: Note CRUD** - Foundation, must be first
2. **Epic 2: Markdown Features** - Core editing experience
3. **Epic 3: Organization** - Folder structure
4. **Epic 4: Tagging System** - Cross-cutting organization
5. **Epic 5: Search** - Discoverability
6. **Epic 6: Import/Export** - Data portability (depends on 3, 4)
