---
epic_num: 2
title: Markdown Features
status: draft
---

# Epic 2: Markdown Features

**Status:** backlog
**Priority:** P0
**Stories:** 4

## Overview

Enhance the markdown editing and preview experience with advanced features including configurable markdown-it extensions, syntax highlighting for code blocks, wiki-style linking between notes using [[title]] syntax, and a backlinks panel showing notes that reference the current note.

## Dependencies

- Epic 1: Note CRUD (Stories 1.3, 1.4)

---

## Story 2.1: Configure markdown-it with extensions

**Status:** draft
**Epic:** Markdown Features
**Priority:** P0

## User Story

As a user, I want extended markdown syntax support so that I can use tables, task lists, and other common markdown features.

## Acceptance Criteria

1. **AC-2.1.1:** Tables render correctly with header row and alignment support
2. **AC-2.1.2:** Task lists render with checkboxes (- [ ] and - [x] syntax)
3. **AC-2.1.3:** Footnotes are supported with [^1] reference syntax
4. **AC-2.1.4:** Strikethrough renders with ~~text~~ syntax
5. **AC-2.1.5:** Typographic replacements work (-- to em dash, ... to ellipsis)
6. **AC-2.1.6:** External links open in new tab with rel="noopener"

## Tasks

- [ ] Task 1: Configure markdown-it base settings (AC: 5, 6)
  - [ ] Subtask 1.1: Update `src/lib/markdown/parser.ts` with base configuration
  - [ ] Subtask 1.2: Enable typographer option
  - [ ] Subtask 1.3: Configure link renderer to add target="_blank" for external links
- [ ] Task 2: Add table support (AC: 1)
  - [ ] Subtask 2.1: Enable markdown-it-table or built-in table support
  - [ ] Subtask 2.2: Add CSS styling for rendered tables
- [ ] Task 3: Add task list support (AC: 2)
  - [ ] Subtask 3.1: Install and configure markdown-it-task-lists plugin
  - [ ] Subtask 3.2: Style checkboxes to match design system
- [ ] Task 4: Add footnotes and strikethrough (AC: 3, 4)
  - [ ] Subtask 4.1: Install markdown-it-footnote plugin
  - [ ] Subtask 4.2: Enable strikethrough in markdown-it options
  - [ ] Subtask 4.3: Style footnotes section at bottom of preview

## Technical Notes

- Use markdown-it plugins from npm ecosystem
- Consider bundle size impact of each plugin
- Test rendering edge cases thoroughly

## Dependencies

- Requires: Story 1.4

---

## Story 2.2: Add syntax highlighting in preview

**Status:** draft
**Epic:** Markdown Features
**Priority:** P0

## User Story

As a developer, I want code blocks in my notes to have syntax highlighting so that code is easier to read and understand.

## Acceptance Criteria

1. **AC-2.2.1:** Code blocks with language identifier show syntax highlighting
2. **AC-2.2.2:** At minimum, support JavaScript, TypeScript, Python, HTML, CSS, JSON, SQL, and Bash
3. **AC-2.2.3:** Code blocks without language show as plain monospace text
4. **AC-2.2.4:** Inline code (`backticks`) is styled distinctly but not syntax highlighted
5. **AC-2.2.5:** Color scheme matches light theme and is readable

## Tasks

- [ ] Task 1: Integrate highlight.js (AC: 1, 2)
  - [ ] Subtask 1.1: Install highlight.js package
  - [ ] Subtask 1.2: Configure markdown-it to use highlight.js for code blocks
  - [ ] Subtask 1.3: Register required language grammars
- [ ] Task 2: Configure highlighting options (AC: 3, 4)
  - [ ] Subtask 2.1: Handle blocks without language gracefully
  - [ ] Subtask 2.2: Add distinct styling for inline code
- [ ] Task 3: Add styling (AC: 5)
  - [ ] Subtask 3.1: Import highlight.js theme CSS (e.g., github or atom-one-light)
  - [ ] Subtask 3.2: Customize colors to match app color scheme if needed
  - [ ] Subtask 3.3: Ensure code blocks have proper padding and background

## Technical Notes

- Use highlight.js over Prism for smaller bundle with markdown-it integration
- Load only necessary language grammars to reduce bundle size
- Consider lazy loading language grammars for less common languages

## Dependencies

- Requires: Story 1.4

---

## Story 2.3: Implement wiki-link parsing [[title]]

**Status:** draft
**Epic:** Markdown Features
**Priority:** P0

## User Story

As a user, I want to create links between notes using [[note title]] syntax so that I can build a connected knowledge base.

## Acceptance Criteria

1. **AC-2.3.1:** Text matching [[Note Title]] pattern is recognized as a wiki-link
2. **AC-2.3.2:** Wiki-links render as clickable links in preview
3. **AC-2.3.3:** Clicking a wiki-link navigates to the linked note
4. **AC-2.3.4:** Links to non-existent notes render with a different style (e.g., red or dashed)
5. **AC-2.3.5:** Clicking a non-existent link creates a new note with that title
6. **AC-2.3.6:** Wiki-links are stored in database for backlink calculation

## Tasks

- [ ] Task 1: Create wiki-link markdown-it plugin (AC: 1, 2)
  - [ ] Subtask 1.1: Create `src/lib/markdown/plugins/wikilink.ts`
  - [ ] Subtask 1.2: Implement inline rule to match [[...]] pattern
  - [ ] Subtask 1.3: Render as anchor tag with special class
- [ ] Task 2: Implement link resolution (AC: 3, 4)
  - [ ] Subtask 2.1: Create function to resolve note title to note ID
  - [ ] Subtask 2.2: Add data attribute with resolved note ID or "not-found"
  - [ ] Subtask 2.3: Style non-existent links distinctly
- [ ] Task 3: Handle link clicks (AC: 3, 5)
  - [ ] Subtask 3.1: Add click handler for wiki-links in Preview component
  - [ ] Subtask 3.2: Navigate to existing note using SvelteKit navigation
  - [ ] Subtask 3.3: Create new note on non-existent link click and navigate
- [ ] Task 4: Track outgoing links (AC: 6)
  - [ ] Subtask 4.1: Parse wiki-links when saving note
  - [ ] Subtask 4.2: Store link relationships in database (or derive on query)

## Technical Notes

- Wiki-link pattern: `\[\[([^\]]+)\]\]`
- Consider case-insensitive matching for titles
- May need a separate links table or compute on-the-fly for backlinks

## Dependencies

- Requires: Story 1.4, Story 2.1

---

## Story 2.4: Build backlinks display component

**Status:** draft
**Epic:** Markdown Features
**Priority:** P1

## User Story

As a user, I want to see which notes link to the current note so that I can discover connections in my knowledge base.

## Acceptance Criteria

1. **AC-2.4.1:** Backlinks section appears in the preview panel below the rendered content
2. **AC-2.4.2:** Section shows count of linking notes (e.g., "3 notes link here")
3. **AC-2.4.3:** Each backlink displays the note title as a clickable link
4. **AC-2.4.4:** Each backlink shows a context snippet with the link highlighted
5. **AC-2.4.5:** Backlinks section is collapsible (expanded by default if links exist)
6. **AC-2.4.6:** Backlinks update when navigating between notes

## Tasks

- [ ] Task 1: Create backlinks API endpoint (AC: 2, 3, 4)
  - [ ] Subtask 1.1: Add GET /api/notes/:id/backlinks endpoint
  - [ ] Subtask 1.2: Query notes containing [[current note title]] in content
  - [ ] Subtask 1.3: Extract context snippet around the wiki-link
- [ ] Task 2: Build BacklinksSection component (AC: 1, 2, 5)
  - [ ] Subtask 2.1: Create `src/lib/components/BacklinksSection.svelte`
  - [ ] Subtask 2.2: Display count header with collapse toggle
  - [ ] Subtask 2.3: Add expand/collapse animation
- [ ] Task 3: Display individual backlinks (AC: 3, 4, 6)
  - [ ] Subtask 3.1: Create BacklinkItem component with title link
  - [ ] Subtask 3.2: Render context snippet with highlighted match
  - [ ] Subtask 3.3: Fetch backlinks when currentNoteId changes

## Technical Notes

- Use SQL LIKE or FTS to find notes containing wiki-link
- Context snippet: ~50 characters before and after the link
- Highlight can use `<mark>` tag for match

## Dependencies

- Requires: Story 2.3
