# Product Requirements Document: Markdown Note Taking App

## Vision

A local-first markdown note-taking application that provides a seamless experience for capturing, organizing, and connecting thoughts. The app prioritizes speed, simplicity, and offline capability while offering powerful features like wiki-style linking, full-text search, and hierarchical organization.

## Goals

1. **Instant Performance**: All local operations complete in under 50ms
2. **Local-First**: Full functionality without internet connection
3. **Connected Knowledge**: Wiki-style linking enables building a personal knowledge base
4. **Flexible Organization**: Combine folders, tags, and links for multi-dimensional organization
5. **Standard Format**: Data stored in accessible SQLite with markdown export/import

## User Personas

### Primary: Knowledge Worker (Alex)
- Takes daily notes for work projects
- Needs to quickly capture ideas and find them later
- Values keyboard shortcuts and minimal friction
- Wants to link related concepts across notes

### Secondary: Student (Jordan)
- Takes lecture notes and study materials
- Organizes by course/semester using folders
- Uses tags for cross-cutting topics
- Exports notes for sharing or backup

### Tertiary: Personal Journaler (Sam)
- Daily journaling and personal notes
- Values simplicity over features
- Wants notes accessible and not locked in proprietary format
- Occasional search for past entries

## Functional Requirements

### Note Management
- **FR-001**: Create, read, update, and delete notes with automatic saving
- **FR-002**: Markdown editor with syntax highlighting for code blocks, headers, lists
- **FR-003**: Real-time markdown preview that updates as user types (debounced 100ms)
- **FR-012**: Pin notes as favorites for quick access
- **FR-013**: Sort notes by last modified date, creation date, or title

### Markdown Features
- **FR-008**: Wiki-style linking using [[note-title]] syntax to create internal links
- **FR-009**: Display backlinks showing all notes that link to the current note

### Organization
- **FR-004**: Organize notes in nested folder hierarchy
- **FR-005**: Assign multiple tags to each note
- **FR-006**: Browse and filter notes by tag
- **FR-007**: Full-text search across all note content with highlighting

### Import/Export
- **FR-010**: Import standard markdown files with frontmatter metadata
- **FR-011**: Export notes to markdown files (single note, folder, or all)

### User Interface
- **FR-014**: Keyboard shortcuts for common actions (new note, save, search, toggle panels)

## Non-Functional Requirements

### Performance
- **NFR-001**: All local operations (save, navigate, toggle) complete in under 50ms
- **NFR-002**: Search results return in under 100ms for databases up to 10,000 notes
- **NFR-003**: Preview updates on keystroke with 100ms debounce for smooth typing

### Data & Privacy
- **NFR-004**: Full offline functionality - no internet required for any feature
- **NFR-005**: All data stored in user-accessible SQLite file in known location

### Quality
- **NFR-006**: Automated test coverage exceeds 80% across unit and integration tests

## MVP Scope

### Included in MVP
- Note CRUD with markdown editor and preview
- Folder hierarchy (single level nesting)
- Tag assignment and filtering
- Full-text search
- Wiki-style links and backlinks
- Keyboard shortcuts
- Single note export to markdown

### Post-MVP
- Bulk import/export
- Drag-and-drop folder organization
- Advanced sorting options
- Note templates
- Dark mode theme
- Mobile responsive layout
