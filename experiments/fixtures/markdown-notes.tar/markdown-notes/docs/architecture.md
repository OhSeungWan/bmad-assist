# Technical Architecture: Markdown Note Taking App

## Overview

The Markdown Note Taking App is a local-first SvelteKit application using SQLite for persistent storage. The architecture prioritizes instant performance through synchronous database operations and minimal client-server round trips. All data remains on the user's machine with no cloud dependencies.

## Tech Stack

| Layer | Technology | Version |
|-------|------------|---------|
| Language | TypeScript | 5.0+ |
| Framework | SvelteKit | 2.0+ |
| Database | SQLite | via better-sqlite3 |
| Markdown | markdown-it | + plugins |
| Search | SQLite FTS5 | built-in |
| Styling | Tailwind CSS | 3.0+ |
| Testing | Vitest + Playwright | latest |
| Build | Vite | latest |

## System Components

### Frontend Layer

```
┌─────────────────────────────────────────────────────────────┐
│                      SvelteKit App                          │
├─────────────────┬─────────────────┬─────────────────────────┤
│    Sidebar      │     Editor      │        Preview          │
│  - FolderTree   │  - CodeMirror   │  - markdown-it render   │
│  - TagBrowser   │  - Auto-save    │  - Backlinks panel      │
│  - SearchInput  │                 │                         │
└─────────────────┴─────────────────┴─────────────────────────┘
                            │
                    Svelte Stores
                  (notes, ui state)
                            │
┌─────────────────────────────────────────────────────────────┐
│                     API Routes                               │
│  /api/notes  /api/tags  /api/search  /api/folders           │
└─────────────────────────────────────────────────────────────┘
```

### Backend Layer

```
┌─────────────────────────────────────────────────────────────┐
│                    SvelteKit Server                          │
├─────────────────────────────────────────────────────────────┤
│  src/lib/db/                                                 │
│  ├── connection.ts   # SQLite connection singleton          │
│  ├── queries.ts      # Prepared statements                  │
│  └── schema.sql      # DDL for tables and FTS               │
├─────────────────────────────────────────────────────────────┤
│  src/lib/markdown/                                           │
│  ├── parser.ts       # markdown-it configuration            │
│  └── plugins/        # Custom plugins (wikilink)            │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│                    SQLite Database                           │
│  - notes, folders, tags, note_tags tables                   │
│  - notes_fts (FTS5 virtual table)                           │
│  - Stored in: ~/.markdown-notes/notes.db                    │
└─────────────────────────────────────────────────────────────┘
```

## Database Schema

### Tables

```sql
-- Folders for hierarchical organization
CREATE TABLE folders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    parent_id INTEGER REFERENCES folders(id) ON DELETE CASCADE,
    created_at TEXT DEFAULT (datetime('now')),
    UNIQUE(name, parent_id)
);

-- Notes with markdown content
CREATE TABLE notes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    content TEXT NOT NULL DEFAULT '',
    folder_id INTEGER REFERENCES folders(id) ON DELETE SET NULL,
    is_pinned INTEGER DEFAULT 0,
    created_at TEXT DEFAULT (datetime('now')),
    updated_at TEXT DEFAULT (datetime('now'))
);

-- Tags for cross-cutting organization
CREATE TABLE tags (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL
);

-- Many-to-many relationship between notes and tags
CREATE TABLE note_tags (
    note_id INTEGER REFERENCES notes(id) ON DELETE CASCADE,
    tag_id INTEGER REFERENCES tags(id) ON DELETE CASCADE,
    PRIMARY KEY (note_id, tag_id)
);

-- Full-text search virtual table
CREATE VIRTUAL TABLE notes_fts USING fts5(
    title,
    content,
    content='notes',
    content_rowid='id'
);

-- Triggers to keep FTS in sync
CREATE TRIGGER notes_ai AFTER INSERT ON notes BEGIN
    INSERT INTO notes_fts(rowid, title, content) VALUES (new.id, new.title, new.content);
END;

CREATE TRIGGER notes_ad AFTER DELETE ON notes BEGIN
    INSERT INTO notes_fts(notes_fts, rowid, title, content) VALUES('delete', old.id, old.title, old.content);
END;

CREATE TRIGGER notes_au AFTER UPDATE ON notes BEGIN
    INSERT INTO notes_fts(notes_fts, rowid, title, content) VALUES('delete', old.id, old.title, old.content);
    INSERT INTO notes_fts(rowid, title, content) VALUES (new.id, new.title, new.content);
END;
```

### Indexes

```sql
CREATE INDEX idx_notes_folder ON notes(folder_id);
CREATE INDEX idx_notes_pinned ON notes(is_pinned);
CREATE INDEX idx_notes_updated ON notes(updated_at DESC);
CREATE INDEX idx_folders_parent ON folders(parent_id);
```

## API Routes

| Method | Route | Description |
|--------|-------|-------------|
| GET | /api/notes | List notes (with filters) |
| POST | /api/notes | Create new note |
| GET | /api/notes/:id | Get single note |
| PUT | /api/notes/:id | Update note |
| DELETE | /api/notes/:id | Delete note |
| GET | /api/notes/:id/backlinks | Get notes linking to this note |
| GET | /api/folders | List folder tree |
| POST | /api/folders | Create folder |
| PUT | /api/folders/:id | Rename/move folder |
| DELETE | /api/folders/:id | Delete folder |
| GET | /api/tags | List all tags |
| POST | /api/notes/:id/tags | Add tag to note |
| DELETE | /api/notes/:id/tags/:tagId | Remove tag from note |
| GET | /api/search?q=term | Full-text search |
| POST | /api/import | Import markdown file |
| GET | /api/export/:id | Export note as markdown |

## Architecture Decision Records

### ADR-001: SvelteKit over Next.js

**Status**: Accepted

**Context**: Need a modern full-stack framework for building the note-taking app with server-side capabilities.

**Decision**: Use SvelteKit instead of Next.js.

**Rationale**:
- Simpler mental model with less boilerplate
- Smaller bundle sizes due to compile-time approach
- Excellent developer experience with hot reload
- Built-in adapters for different deployment targets

**Trade-offs**:
- Smaller ecosystem than React/Next.js
- Fewer third-party component libraries
- Less community resources and tutorials

### ADR-002: better-sqlite3 over Prisma

**Status**: Accepted

**Context**: Need a database solution for local SQLite storage.

**Decision**: Use better-sqlite3 directly instead of an ORM like Prisma.

**Rationale**:
- Synchronous API matches our performance requirements
- Direct SQL gives full control over queries
- No migration tooling overhead for simple schema
- Smaller dependency footprint

**Trade-offs**:
- Manual SQL query writing
- No automatic migrations
- Must handle type safety manually

### ADR-003: SQLite FTS5 over External Search

**Status**: Accepted

**Context**: Need full-text search across all notes.

**Decision**: Use SQLite's built-in FTS5 extension rather than external search engines.

**Rationale**:
- Zero additional dependencies
- Integrated with existing database
- Fast enough for local use (10K+ notes)
- Supports ranking and highlighting

**Trade-offs**:
- Less sophisticated ranking than Elasticsearch
- No fuzzy matching by default
- Limited language analysis

### ADR-004: markdown-it over remark

**Status**: Accepted

**Context**: Need a markdown parser for rendering preview.

**Decision**: Use markdown-it instead of remark/unified ecosystem.

**Rationale**:
- Faster parsing performance
- Smaller bundle size
- Mature plugin ecosystem
- Simple extension API for wiki-links

**Trade-offs**:
- Less AST manipulation capability
- Fewer transformation plugins
- Not as composable as unified

### ADR-005: Tailwind CSS over CSS Modules

**Status**: Accepted

**Context**: Need a styling solution for the UI components.

**Decision**: Use Tailwind CSS utility classes.

**Rationale**:
- Rapid prototyping with utility classes
- Consistent design system via config
- No context switching between files
- Tree-shaking removes unused styles

**Trade-offs**:
- Verbose class names in HTML
- Learning curve for utility-first approach
- Some resistance from CSS purists
