# Project Context: Auth Microservice

## File Structure

```
src/
├── auth_service/
│   ├── __init__.py
│   ├── main.py              # FastAPI app
│   ├── config.py            # Settings
│   ├── database.py          # SQLAlchemy setup
│   ├── models/
│   │   ├── __init__.py
│   │   ├── user.py
│   │   ├── session.py
│   │   └── audit.py
│   ├── schemas/
│   │   ├── __init__.py
│   │   ├── user.py
│   │   ├── auth.py
│   │   └── token.py
│   ├── services/
│   │   ├── __init__.py
│   │   ├── auth.py
│   │   ├── user.py
│   │   ├── token.py
│   │   └── password.py
│   ├── api/
│   │   ├── __init__.py
│   │   ├── deps.py          # Dependencies
│   │   ├── auth.py
│   │   ├── users.py
│   │   └── admin.py
│   └── middleware/
│       ├── __init__.py
│       ├── rate_limit.py
│       └── audit.py
└── tests/
    ├── conftest.py
    ├── test_auth.py
    ├── test_users.py
    └── test_rbac.py
```

## Naming Conventions

| Element | Convention | Example |
|---------|------------|---------|
| Files | snake_case | `user_service.py` |
| Classes | PascalCase | `UserService` |
| Functions | snake_case | `get_user_by_id` |
| Variables | snake_case | `current_user` |
| Constants | UPPER_SNAKE_CASE | `JWT_SECRET_KEY` |
| API routes | kebab-case | `/api/v1/password-reset` |
| Database tables | snake_case plural | `users`, `sessions` |
| Pydantic schemas | PascalCase + suffix | `UserCreate`, `UserResponse` |

## Patterns to Use

### Dependency Injection
Use FastAPI's `Depends()` for all service and database dependencies.

```python
async def get_current_user(
    token: str = Depends(oauth2_scheme),
    db: AsyncSession = Depends(get_db),
) -> User:
    ...
```

### Service Layer Pattern
Business logic resides in service classes, not in route handlers.

```python
class AuthService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def authenticate(self, email: str, password: str) -> User:
        ...
```

### Repository Pattern
Database operations abstracted in model-specific query methods.

### Pydantic for Validation
All request/response bodies use Pydantic models with strict validation.

### Async/Await
All database operations use async SQLAlchemy with aiosqlite.

### Type Hints
All functions have complete type annotations.

```python
async def create_user(self, user_data: UserCreate) -> User:
    ...
```

### Error Handling
Use FastAPI's `HTTPException` with appropriate status codes.

```python
raise HTTPException(
    status_code=status.HTTP_401_UNAUTHORIZED,
    detail="Invalid credentials",
)
```

## Patterns to Avoid

### Direct Database Access in Routes
Never access database directly in route handlers. Always go through services.

### Hardcoded Configuration
Use `config.py` with pydantic-settings for all configuration values.

### Synchronous Blocking Calls
Never use synchronous I/O in async context. Use `run_in_executor` for CPU-bound work like bcrypt.

### Mutable Default Arguments
Never use mutable defaults in function signatures.

### Broad Exception Handling
Avoid bare `except:` clauses. Catch specific exceptions.

### Business Logic in Models
SQLAlchemy models should only define schema. Logic belongs in services.

### Direct Password Storage
Never store plain passwords. Always hash with bcrypt.

## Testing Standards

### Test File Naming
- Unit tests: `test_<module>.py`
- Integration tests: `test_<feature>_integration.py`

### Test Function Naming
```python
def test_<function_name>_<scenario>_<expected_result>():
    # Example: test_login_invalid_password_returns_401
```

### Fixtures
Use `conftest.py` for shared fixtures:
- `db_session` - Test database session
- `client` - AsyncClient for API tests
- `test_user` - Pre-created user for auth tests

### Coverage Requirements
- Minimum 85% coverage overall
- 100% coverage for auth and security modules

### Test Categories
- Unit tests for services (mocked dependencies)
- Integration tests for API endpoints (real database)
- Security tests for auth edge cases

### Async Testing
Use `pytest-asyncio` with `@pytest.mark.asyncio` decorator.

```python
@pytest.mark.asyncio
async def test_create_user(db_session: AsyncSession):
    ...
```
