---
epic_num: 3
title: Password Management
status: draft
---

# Epic 3: Password Management

Secure password handling with bcrypt hashing, password change, and reset flow.

---

## Story 3.1: Implement Password Hashing Service

**Status:** draft
**Epic:** Password Management
**Priority:** P0

## User Story

As a system, I want to securely hash passwords so that user credentials are protected even if the database is compromised.

## Acceptance Criteria

1. **AC-3.1.1:** Passwords are hashed using bcrypt algorithm
2. **AC-3.1.2:** Bcrypt cost factor is set to 12
3. **AC-3.1.3:** Password verification compares against stored hash
4. **AC-3.1.4:** Hash generation is performed asynchronously (non-blocking)
5. **AC-3.1.5:** Plain text passwords are never logged or stored

## Tasks

- [ ] Task 1: Create PasswordService class (AC: 1, 2)
  - [ ] Subtask 1.1: Define services/password.py
  - [ ] Subtask 1.2: Configure passlib CryptContext with bcrypt
  - [ ] Subtask 1.3: Set rounds=12 for cost factor
- [ ] Task 2: Implement hash_password method (AC: 1, 4)
  - [ ] Subtask 2.1: Use passlib's hash method
  - [ ] Subtask 2.2: Run in executor for async compatibility
- [ ] Task 3: Implement verify_password method (AC: 3)
  - [ ] Subtask 3.1: Use passlib's verify method
  - [ ] Subtask 3.2: Return boolean result
- [ ] Task 4: Ensure no password logging (AC: 5)
  - [ ] Subtask 4.1: Review all log statements in auth flow
  - [ ] Subtask 4.2: Add Pydantic SecretStr if needed

## Technical Notes

- Use passlib[bcrypt] for cross-platform compatibility
- Bcrypt is CPU-intensive; use run_in_executor in async context
- Cost factor 12 provides good security/performance balance

## Dependencies

- Requires: None

---

## Story 3.2: Create Password Change Endpoint

**Status:** draft
**Epic:** Password Management
**Priority:** P1

## User Story

As an authenticated user, I want to change my password so that I can update my credentials for security.

## Acceptance Criteria

1. **AC-3.2.1:** POST /api/v1/password/change requires authentication
2. **AC-3.2.2:** Request includes current_password and new_password
3. **AC-3.2.3:** Current password is verified before change
4. **AC-3.2.4:** Invalid current password returns 401 Unauthorized
5. **AC-3.2.5:** New password must meet strength requirements
6. **AC-3.2.6:** Successful change returns 200 with success message
7. **AC-3.2.7:** Password change is recorded in audit log

## Tasks

- [ ] Task 1: Create PasswordChangeRequest schema (AC: 2, 5)
  - [ ] Subtask 1.1: Define schema with current_password and new_password
  - [ ] Subtask 1.2: Apply password validation rules to new_password
- [ ] Task 2: Implement AuthService.change_password method (AC: 3, 4)
  - [ ] Subtask 2.1: Verify current password
  - [ ] Subtask 2.2: Hash and save new password
  - [ ] Subtask 2.3: Update updated_at timestamp
- [ ] Task 3: Create password change endpoint (AC: 1, 6)
  - [ ] Subtask 3.1: Define POST /api/v1/password/change route
  - [ ] Subtask 3.2: Require get_current_user dependency
- [ ] Task 4: Add audit log entry (AC: 7)
  - [ ] Subtask 4.1: Log password_changed event with user_id

## Technical Notes

- New password should differ from current password
- Consider invalidating all refresh tokens after password change
- Audit log entry should not contain password values

## Dependencies

- Requires: Story 3.1, Story 1.3

---

## Story 3.3: Implement Password Reset Token Generation

**Status:** draft
**Epic:** Password Management
**Priority:** P1

## User Story

As a user who forgot my password, I want to request a reset token so that I can regain access to my account.

## Acceptance Criteria

1. **AC-3.3.1:** POST /api/v1/password/reset-request accepts email
2. **AC-3.3.2:** Valid email generates a reset token (stored in database)
3. **AC-3.3.3:** Reset token expires in 1 hour
4. **AC-3.3.4:** Response always returns 200 (no email enumeration)
5. **AC-3.3.5:** Email is logged to console (mock email service)
6. **AC-3.3.6:** Previous reset tokens for user are invalidated

## Tasks

- [ ] Task 1: Create PasswordResetToken model (AC: 2, 3, 6)
  - [ ] Subtask 1.1: Define model with token_hash, user_id, expires_at, used_at
  - [ ] Subtask 1.2: Add index on token_hash for lookup
- [ ] Task 2: Implement PasswordService.create_reset_token method (AC: 2, 3, 6)
  - [ ] Subtask 2.1: Generate secure random token
  - [ ] Subtask 2.2: Hash token before storage
  - [ ] Subtask 2.3: Invalidate existing tokens for user
  - [ ] Subtask 2.4: Set expiry to 1 hour
- [ ] Task 3: Create reset request endpoint (AC: 1, 4)
  - [ ] Subtask 3.1: Define POST /api/v1/password/reset-request route
  - [ ] Subtask 3.2: Return 200 regardless of email existence
- [ ] Task 4: Mock email sending (AC: 5)
  - [ ] Subtask 4.1: Log reset token and link to console
  - [ ] Subtask 4.2: Use logging.info for visibility

## Technical Notes

- Use secrets.token_urlsafe(32) for token generation
- Store hashed token, return plain token to user (via email)
- Constant-time response prevents timing attacks

## Dependencies

- Requires: Story 3.1

---

## Story 3.4: Create Password Reset Confirmation Endpoint

**Status:** draft
**Epic:** Password Management
**Priority:** P1

## User Story

As a user with a reset token, I want to set a new password so that I can regain access to my account.

## Acceptance Criteria

1. **AC-3.4.1:** POST /api/v1/password/reset-confirm accepts token and new_password
2. **AC-3.4.2:** Valid token allows password reset
3. **AC-3.4.3:** Expired token returns 400 Bad Request
4. **AC-3.4.4:** Already used token returns 400 Bad Request
5. **AC-3.4.5:** Invalid token returns 400 Bad Request
6. **AC-3.4.6:** New password must meet strength requirements
7. **AC-3.4.7:** Token is marked as used after successful reset
8. **AC-3.4.8:** All user sessions are revoked after reset

## Tasks

- [ ] Task 1: Create PasswordResetConfirm schema (AC: 1, 6)
  - [ ] Subtask 1.1: Define schema with token and new_password
  - [ ] Subtask 1.2: Apply password validation rules
- [ ] Task 2: Implement PasswordService.reset_password method (AC: 2, 3, 4, 5, 7)
  - [ ] Subtask 2.1: Hash incoming token and lookup
  - [ ] Subtask 2.2: Validate token not expired or used
  - [ ] Subtask 2.3: Update user password
  - [ ] Subtask 2.4: Mark token as used (set used_at)
- [ ] Task 3: Create reset confirm endpoint (AC: 1)
  - [ ] Subtask 3.1: Define POST /api/v1/password/reset-confirm route
  - [ ] Subtask 3.2: Return 200 on success
- [ ] Task 4: Revoke all user sessions (AC: 8)
  - [ ] Subtask 4.1: Set revoked_at on all user sessions
  - [ ] Subtask 4.2: Force re-authentication on all devices

## Technical Notes

- Use constant-time comparison for token validation
- Generic error message prevents information leakage
- Session revocation is a security best practice after password reset

## Dependencies

- Requires: Story 3.3, Story 5.4 (logout all)
