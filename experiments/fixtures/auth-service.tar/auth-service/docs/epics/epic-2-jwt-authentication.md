---
epic_num: 2
title: JWT Authentication
status: draft
---

# Epic 2: JWT Authentication

Core authentication flow with JWT token generation, validation, refresh rotation, and logout.

---

## Story 2.1: Implement Login Endpoint with JWT Generation

**Status:** draft
**Epic:** JWT Authentication
**Priority:** P0

## User Story

As a registered user, I want to login with my credentials so that I receive tokens for authenticated API access.

## Acceptance Criteria

1. **AC-2.1.1:** POST /api/v1/auth/login accepts email and password
2. **AC-2.1.2:** Successful login returns access_token and refresh_token
3. **AC-2.1.3:** Access token expires in 15 minutes (configurable)
4. **AC-2.1.4:** Refresh token expires in 7 days (configurable)
5. **AC-2.1.5:** Invalid credentials return 401 Unauthorized
6. **AC-2.1.6:** Disabled user account returns 403 Forbidden
7. **AC-2.1.7:** Response includes token_type: "bearer"

## Tasks

- [ ] Task 1: Create TokenService for JWT generation (AC: 2, 3, 4, 7)
  - [ ] Subtask 1.1: Implement create_access_token method with PyJWT
  - [ ] Subtask 1.2: Implement create_refresh_token method
  - [ ] Subtask 1.3: Add expiry configuration from settings
- [ ] Task 2: Create AuthService.authenticate method (AC: 1, 5, 6)
  - [ ] Subtask 2.1: Implement password verification with passlib
  - [ ] Subtask 2.2: Check is_active status
- [ ] Task 3: Create login endpoint (AC: 1, 2, 7)
  - [ ] Subtask 3.1: Define POST /api/v1/auth/login route
  - [ ] Subtask 3.2: Return TokenResponse schema
- [ ] Task 4: Create TokenResponse Pydantic schema (AC: 2, 7)

## Technical Notes

- Use HS256 algorithm for JWT signing
- Store JWT secret in config, never hardcode
- Include user_id in token payload (sub claim)

## Dependencies

- Requires: Story 1.1, Story 3.1 (password hashing)

---

## Story 2.2: Create JWT Validation Middleware

**Status:** draft
**Epic:** JWT Authentication
**Priority:** P0

## User Story

As an API, I want to validate JWT tokens on protected endpoints so that only authenticated users can access them.

## Acceptance Criteria

1. **AC-2.2.1:** Protected endpoints require Authorization: Bearer <token> header
2. **AC-2.2.2:** Valid token allows request to proceed
3. **AC-2.2.3:** Expired token returns 401 with "Token expired" message
4. **AC-2.2.4:** Invalid signature returns 401 with "Invalid token" message
5. **AC-2.2.5:** Malformed token returns 401 with "Invalid token" message
6. **AC-2.2.6:** Current user is available to route handlers via dependency

## Tasks

- [ ] Task 1: Implement TokenService.verify_access_token method (AC: 2, 3, 4, 5)
  - [ ] Subtask 1.1: Decode and validate JWT with PyJWT
  - [ ] Subtask 1.2: Handle ExpiredSignatureError
  - [ ] Subtask 1.3: Handle InvalidTokenError
- [ ] Task 2: Create get_current_user dependency (AC: 1, 6)
  - [ ] Subtask 2.1: Extract token from Authorization header
  - [ ] Subtask 2.2: Verify token and load user from database
  - [ ] Subtask 2.3: Raise HTTPException on validation failure
- [ ] Task 3: Apply OAuth2PasswordBearer to protected routes (AC: 1)

## Technical Notes

- Use FastAPI's OAuth2PasswordBearer for OpenAPI integration
- Consider caching user lookups if performance is a concern
- Token payload should include: sub (user_id), exp, iat

## Dependencies

- Requires: Story 2.1

---

## Story 2.3: Implement Refresh Token Endpoint

**Status:** draft
**Epic:** JWT Authentication
**Priority:** P0

## User Story

As an authenticated user, I want to refresh my access token so that I can maintain my session without re-entering credentials.

## Acceptance Criteria

1. **AC-2.3.1:** POST /api/v1/auth/refresh accepts refresh_token in body
2. **AC-2.3.2:** Valid refresh token returns new access_token
3. **AC-2.3.3:** Expired refresh token returns 401 Unauthorized
4. **AC-2.3.4:** Revoked refresh token returns 401 Unauthorized
5. **AC-2.3.5:** Response includes new token_type: "bearer"

## Tasks

- [ ] Task 1: Create Session model to track refresh tokens (AC: 4)
  - [ ] Subtask 1.1: Define Session model with refresh_token_hash, expires_at, revoked_at
  - [ ] Subtask 1.2: Add foreign key to User
- [ ] Task 2: Implement TokenService.verify_refresh_token method (AC: 2, 3, 4)
  - [ ] Subtask 2.1: Decode token and check expiry
  - [ ] Subtask 2.2: Verify token exists in sessions table
  - [ ] Subtask 2.3: Check revoked_at is null
- [ ] Task 3: Create refresh endpoint (AC: 1, 2, 5)
  - [ ] Subtask 3.1: Define POST /api/v1/auth/refresh route
  - [ ] Subtask 3.2: Generate new access token for valid refresh

## Technical Notes

- Store hashed refresh token, not plain text
- Refresh token in database enables revocation
- Consider storing device/IP info with session

## Dependencies

- Requires: Story 2.1

---

## Story 2.4: Add Refresh Token Rotation Logic

**Status:** draft
**Epic:** JWT Authentication
**Priority:** P1

## User Story

As a security measure, I want refresh tokens to rotate on use so that stolen tokens have limited lifetime.

## Acceptance Criteria

1. **AC-2.4.1:** Refresh endpoint returns new refresh_token along with access_token
2. **AC-2.4.2:** Old refresh token is invalidated after use
3. **AC-2.4.3:** Attempting to use old refresh token returns 401
4. **AC-2.4.4:** New refresh token has fresh 7-day expiry
5. **AC-2.4.5:** Session record is updated, not duplicated

## Tasks

- [ ] Task 1: Update refresh endpoint to return new refresh token (AC: 1, 4)
  - [ ] Subtask 1.1: Generate new refresh token on successful refresh
  - [ ] Subtask 1.2: Update response schema to include refresh_token
- [ ] Task 2: Implement token rotation in TokenService (AC: 2, 3, 5)
  - [ ] Subtask 2.1: Mark old token as revoked
  - [ ] Subtask 2.2: Update session with new token hash
  - [ ] Subtask 2.3: Set new expires_at
- [ ] Task 3: Add tests for rotation behavior (AC: 3)
  - [ ] Subtask 3.1: Test old token rejected after rotation
  - [ ] Subtask 3.2: Test new token works after rotation

## Technical Notes

- Rotation prevents replay attacks with stolen refresh tokens
- Update existing session record rather than creating new one
- Consider grace period for concurrent requests (optional)

## Dependencies

- Requires: Story 2.3

---

## Story 2.5: Create Logout Endpoint

**Status:** draft
**Epic:** JWT Authentication
**Priority:** P1

## User Story

As an authenticated user, I want to logout so that my current session is invalidated.

## Acceptance Criteria

1. **AC-2.5.1:** POST /api/v1/auth/logout requires valid access token
2. **AC-2.5.2:** Logout revokes the current session's refresh token
3. **AC-2.5.3:** Successful logout returns 204 No Content
4. **AC-2.5.4:** Subsequent refresh attempts with that token fail
5. **AC-2.5.5:** Access token remains valid until expiry (by design)

## Tasks

- [ ] Task 1: Implement AuthService.logout method (AC: 2, 4)
  - [ ] Subtask 1.1: Set revoked_at on current session
  - [ ] Subtask 1.2: Accept session_id or refresh_token to identify session
- [ ] Task 2: Create logout endpoint (AC: 1, 3)
  - [ ] Subtask 2.1: Define POST /api/v1/auth/logout route
  - [ ] Subtask 2.2: Require authentication via get_current_user
  - [ ] Subtask 2.3: Return 204 on success
- [ ] Task 3: Determine session from access token (AC: 2)
  - [ ] Subtask 3.1: Include session_id in access token payload
  - [ ] Subtask 3.2: Or accept refresh_token in logout request body

## Technical Notes

- Access tokens cannot be revoked (stateless design per ADR-002)
- Only refresh token is revoked; access token expires naturally
- Consider which session to revoke: current device or specific token

## Dependencies

- Requires: Story 2.3
