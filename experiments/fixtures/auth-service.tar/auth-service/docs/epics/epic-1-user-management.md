---
epic_num: 1
title: User Management
status: draft
---

# Epic 1: User Management

Foundation for user accounts including registration, profile management, and input validation.

---

## Story 1.1: Create User Registration Endpoint

**Status:** draft
**Epic:** User Management
**Priority:** P0

## User Story

As a new user, I want to register with my email and password so that I can create an account in the system.

## Acceptance Criteria

1. **AC-1.1.1:** POST /api/v1/auth/register accepts email and password in request body
2. **AC-1.1.2:** Successful registration returns 201 with user ID and email (no password)
3. **AC-1.1.3:** Password is hashed before storage (never stored in plain text)
4. **AC-1.1.4:** Response includes created_at timestamp
5. **AC-1.1.5:** Invalid request body returns 422 with validation errors

## Tasks

- [ ] Task 1: Create User SQLAlchemy model with id, email, password_hash, is_active, created_at, updated_at (AC: 1, 3, 4)
  - [ ] Subtask 1.1: Define model in models/user.py
  - [ ] Subtask 1.2: Add async session factory in database.py
- [ ] Task 2: Create Pydantic schemas UserCreate and UserResponse (AC: 1, 2)
  - [ ] Subtask 2.1: Define schemas in schemas/user.py
  - [ ] Subtask 2.2: Ensure password excluded from response schema
- [ ] Task 3: Implement UserService.create_user method (AC: 3)
  - [ ] Subtask 3.1: Create services/user.py with UserService class
  - [ ] Subtask 3.2: Add password hashing using passlib bcrypt
- [ ] Task 4: Create POST /api/v1/auth/register route handler (AC: 1, 2, 4, 5)
  - [ ] Subtask 4.1: Define route in api/auth.py
  - [ ] Subtask 4.2: Wire up dependency injection for UserService

## Technical Notes

- Use SQLAlchemy 2.0 async API with aiosqlite
- Password hashing is CPU-bound; use run_in_executor to avoid blocking
- Return 201 Created on success, not 200 OK

## Dependencies

- Requires: None

---

## Story 1.2: Implement Email Uniqueness Validation

**Status:** draft
**Epic:** User Management
**Priority:** P0

## User Story

As a system, I want to enforce unique email addresses so that each account has a distinct identifier.

## Acceptance Criteria

1. **AC-1.2.1:** Registration with existing email returns 409 Conflict
2. **AC-1.2.2:** Error response includes message "Email already registered"
3. **AC-1.2.3:** Email uniqueness enforced at database level (unique constraint)
4. **AC-1.2.4:** Email comparison is case-insensitive

## Tasks

- [ ] Task 1: Add unique constraint on email column in User model (AC: 3)
  - [ ] Subtask 1.1: Update User model with unique=True
  - [ ] Subtask 1.2: Add index on email column for performance
- [ ] Task 2: Normalize email to lowercase before storage (AC: 4)
  - [ ] Subtask 2.1: Add email normalization in UserService.create_user
- [ ] Task 3: Handle IntegrityError and return 409 response (AC: 1, 2)
  - [ ] Subtask 3.1: Catch SQLAlchemy IntegrityError in registration endpoint
  - [ ] Subtask 3.2: Return appropriate HTTPException with detail message

## Technical Notes

- Use SQLAlchemy's UniqueConstraint or Column(unique=True)
- Normalize email in Pydantic validator or service layer

## Dependencies

- Requires: Story 1.1

---

## Story 1.3: Create User Profile GET Endpoint

**Status:** draft
**Epic:** User Management
**Priority:** P1

## User Story

As an authenticated user, I want to view my profile information so that I can see my account details.

## Acceptance Criteria

1. **AC-1.3.1:** GET /api/v1/users/me returns current user's profile
2. **AC-1.3.2:** Response includes id, email, created_at, updated_at
3. **AC-1.3.3:** Password hash is never included in response
4. **AC-1.3.4:** Unauthenticated request returns 401 Unauthorized
5. **AC-1.3.5:** Invalid token returns 401 with "Invalid token" message

## Tasks

- [ ] Task 1: Create get_current_user dependency (AC: 4, 5)
  - [ ] Subtask 1.1: Define OAuth2PasswordBearer scheme in api/deps.py
  - [ ] Subtask 1.2: Implement token validation and user lookup
- [ ] Task 2: Create GET /api/v1/users/me endpoint (AC: 1, 2, 3)
  - [ ] Subtask 2.1: Define route in api/users.py
  - [ ] Subtask 2.2: Use Depends(get_current_user) for authentication
- [ ] Task 3: Create UserProfile response schema (AC: 2, 3)
  - [ ] Subtask 3.1: Define schema excluding sensitive fields

## Technical Notes

- Depends on JWT validation from Epic 2, but can stub the dependency initially
- Use response_model to ensure password_hash exclusion

## Dependencies

- Requires: Story 1.1
- Soft dependency: Story 2.2 (JWT middleware)

---

## Story 1.4: Create User Profile UPDATE Endpoint

**Status:** draft
**Epic:** User Management
**Priority:** P1

## User Story

As an authenticated user, I want to update my profile information so that I can keep my account details current.

## Acceptance Criteria

1. **AC-1.4.1:** PATCH /api/v1/users/me updates user profile
2. **AC-1.4.2:** Only provided fields are updated (partial update)
3. **AC-1.4.3:** Email update triggers uniqueness validation
4. **AC-1.4.4:** updated_at timestamp is refreshed on successful update
5. **AC-1.4.5:** Cannot update password via this endpoint (use password change)
6. **AC-1.4.6:** Returns updated profile in response

## Tasks

- [ ] Task 1: Create UserUpdate Pydantic schema (AC: 2, 5)
  - [ ] Subtask 1.1: Define schema with optional fields
  - [ ] Subtask 1.2: Exclude password from updatable fields
- [ ] Task 2: Implement UserService.update_user method (AC: 2, 3, 4)
  - [ ] Subtask 2.1: Handle partial updates with exclude_unset
  - [ ] Subtask 2.2: Update updated_at on save
- [ ] Task 3: Create PATCH /api/v1/users/me endpoint (AC: 1, 6)
  - [ ] Subtask 3.1: Define route in api/users.py
  - [ ] Subtask 3.2: Handle email uniqueness conflict (409)

## Technical Notes

- Use Pydantic's model.dict(exclude_unset=True) for partial updates
- Consider using SQLAlchemy's onupdate for updated_at

## Dependencies

- Requires: Story 1.3

---

## Story 1.5: Add Input Validation and Error Responses

**Status:** draft
**Epic:** User Management
**Priority:** P1

## User Story

As an API consumer, I want clear validation errors so that I can fix invalid requests.

## Acceptance Criteria

1. **AC-1.5.1:** Email field validates proper email format
2. **AC-1.5.2:** Password requires minimum 8 characters
3. **AC-1.5.3:** Password requires at least one number
4. **AC-1.5.4:** Password requires at least one uppercase letter
5. **AC-1.5.5:** Validation errors return 422 with field-level details
6. **AC-1.5.6:** Error response follows RFC 7807 problem details format

## Tasks

- [ ] Task 1: Add email validation to UserCreate schema (AC: 1)
  - [ ] Subtask 1.1: Use Pydantic EmailStr or custom validator
- [ ] Task 2: Add password strength validators (AC: 2, 3, 4)
  - [ ] Subtask 2.1: Create password validator function
  - [ ] Subtask 2.2: Apply @field_validator decorator to password field
- [ ] Task 3: Configure custom exception handler for validation errors (AC: 5, 6)
  - [ ] Subtask 3.1: Create exception handler in main.py
  - [ ] Subtask 3.2: Format errors with field names and messages

## Technical Notes

- Use Pydantic v2 field validators
- Consider using regex pattern for password validation
- FastAPI's default RequestValidationError handler can be customized

## Dependencies

- Requires: Story 1.1
