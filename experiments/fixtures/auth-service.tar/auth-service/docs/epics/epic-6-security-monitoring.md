---
epic_num: 6
title: Security & Monitoring
status: draft
---

# Epic 6: Security & Monitoring

Security hardening with rate limiting and comprehensive audit logging.

---

## Story 6.1: Implement Rate Limiting Middleware

**Status:** draft
**Epic:** Security & Monitoring
**Priority:** P1

## User Story

As a system, I want to rate limit authentication endpoints so that brute force attacks are prevented.

## Acceptance Criteria

1. **AC-6.1.1:** Rate limit applies to /auth/login, /auth/register, /password/reset-request
2. **AC-6.1.2:** Limit: 5 requests per 15 minutes per IP for login failures
3. **AC-6.1.3:** Limit: 10 requests per hour per IP for registration
4. **AC-6.1.4:** Exceeding limit returns 429 Too Many Requests
5. **AC-6.1.5:** Response includes Retry-After header with seconds
6. **AC-6.1.6:** Successful login does not count against limit
7. **AC-6.1.7:** Rate limit state stored in memory (not database)

## Tasks

- [ ] Task 1: Create RateLimiter class (AC: 2, 3, 7)
  - [ ] Subtask 1.1: Implement sliding window counter
  - [ ] Subtask 1.2: Store counts in dict keyed by IP + endpoint
  - [ ] Subtask 1.3: Support configurable limits and windows
- [ ] Task 2: Create rate limit middleware (AC: 1, 4, 5)
  - [ ] Subtask 2.1: Define middleware in middleware/rate_limit.py
  - [ ] Subtask 2.2: Check limit before processing request
  - [ ] Subtask 2.3: Add Retry-After header on 429
- [ ] Task 3: Apply middleware to auth endpoints (AC: 1, 6)
  - [ ] Subtask 3.1: Create rate_limit_login dependency
  - [ ] Subtask 3.2: Only increment on failed login attempts
  - [ ] Subtask 3.3: Apply to registration and reset endpoints
- [ ] Task 4: Add IP extraction utility (AC: 2)
  - [ ] Subtask 4.1: Handle X-Forwarded-For for proxied requests
  - [ ] Subtask 4.2: Fall back to client.host

## Technical Notes

- Use in-memory dict for simplicity (not shared across processes)
- Consider slowapi library for production-grade rate limiting
- Sliding window provides smoother limiting than fixed window

## Dependencies

- Requires: Story 2.1

---

## Story 6.2: Create Audit Log for Auth Events

**Status:** draft
**Epic:** Security & Monitoring
**Priority:** P2

## User Story

As an administrator, I want to view authentication audit logs so that I can investigate security incidents.

## Acceptance Criteria

1. **AC-6.2.1:** Login success/failure events are logged
2. **AC-6.2.2:** Logout events are logged
3. **AC-6.2.3:** Password change and reset events are logged
4. **AC-6.2.4:** Each log includes: user_id, event_type, ip_address, user_agent, timestamp
5. **AC-6.2.5:** Failed attempts include email (not password)
6. **AC-6.2.6:** GET /api/v1/admin/audit-logs returns paginated logs (admin only)
7. **AC-6.2.7:** Logs can be filtered by user_id, event_type, date range

## Tasks

- [ ] Task 1: Create AuditLog model (AC: 4, 5)
  - [ ] Subtask 1.1: Define model in models/audit.py
  - [ ] Subtask 1.2: Add event_type enum column
  - [ ] Subtask 1.3: Add details JSON column for extra info
- [ ] Task 2: Create AuditService for logging (AC: 1, 2, 3)
  - [ ] Subtask 2.1: Implement log_event method
  - [ ] Subtask 2.2: Accept event type and optional details
  - [ ] Subtask 2.3: Capture request context (IP, user agent)
- [ ] Task 3: Add audit logging to auth endpoints (AC: 1, 2, 3)
  - [ ] Subtask 3.1: Log login_success, login_failure
  - [ ] Subtask 3.2: Log logout, logout_all
  - [ ] Subtask 3.3: Log password_changed, password_reset
- [ ] Task 4: Create audit log query endpoint (AC: 6, 7)
  - [ ] Subtask 4.1: Define GET /api/v1/admin/audit-logs
  - [ ] Subtask 4.2: Add query params for filters
  - [ ] Subtask 4.3: Implement pagination
- [ ] Task 5: Define AuditEvent enum (AC: 4)
  - [ ] Subtask 5.1: LOGIN_SUCCESS, LOGIN_FAILURE
  - [ ] Subtask 5.2: LOGOUT, LOGOUT_ALL
  - [ ] Subtask 5.3: PASSWORD_CHANGED, PASSWORD_RESET
  - [ ] Subtask 5.4: ROLE_ASSIGNED, ROLE_REMOVED

## Technical Notes

- Audit logs are append-only; never delete or modify
- Consider async logging to avoid blocking request processing
- Log rotation/archival is out of scope (production concern)

## Dependencies

- Requires: Story 4.5 (admin access)
