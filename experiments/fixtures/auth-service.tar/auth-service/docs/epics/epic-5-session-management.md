---
epic_num: 5
title: Session Management
status: draft
---

# Epic 5: Session Management

Device session tracking with listing, individual revocation, and bulk logout.

---

## Story 5.1: Track Active Sessions in Database

**Status:** draft
**Epic:** Session Management
**Priority:** P1

## User Story

As a system, I want to track all active sessions so that users can manage their logged-in devices.

## Acceptance Criteria

1. **AC-5.1.1:** Each login creates a session record
2. **AC-5.1.2:** Session stores user_agent, ip_address, created_at
3. **AC-5.1.3:** Session links to refresh token (one-to-one)
4. **AC-5.1.4:** Session has unique identifier for reference
5. **AC-5.1.5:** Expired sessions are not automatically deleted (retained for audit)

## Tasks

- [ ] Task 1: Extend Session model with device info (AC: 2, 4)
  - [ ] Subtask 1.1: Add user_agent column
  - [ ] Subtask 1.2: Add ip_address column
  - [ ] Subtask 1.3: Ensure id is UUID for unique reference
- [ ] Task 2: Update login flow to capture device info (AC: 1, 2)
  - [ ] Subtask 2.1: Extract User-Agent header in login endpoint
  - [ ] Subtask 2.2: Extract client IP (handle X-Forwarded-For)
  - [ ] Subtask 2.3: Store in session record
- [ ] Task 3: Update token refresh to preserve session (AC: 3)
  - [ ] Subtask 3.1: Update existing session on token rotation
  - [ ] Subtask 3.2: Do not create new session on refresh

## Technical Notes

- Use Request object to access headers and client info
- Consider privacy implications of storing IP addresses
- Session ID should be included in access token for logout

## Dependencies

- Requires: Story 2.3

---

## Story 5.2: Create Session Listing Endpoint

**Status:** draft
**Epic:** Session Management
**Priority:** P1

## User Story

As an authenticated user, I want to see all my active sessions so that I can monitor where I'm logged in.

## Acceptance Criteria

1. **AC-5.2.1:** GET /api/v1/users/me/sessions returns user's sessions
2. **AC-5.2.2:** Each session shows id, user_agent, ip_address, created_at
3. **AC-5.2.3:** Current session is marked with is_current: true
4. **AC-5.2.4:** Only non-revoked sessions are returned
5. **AC-5.2.5:** Sessions ordered by created_at descending (newest first)

## Tasks

- [ ] Task 1: Create SessionResponse schema (AC: 2, 3)
  - [ ] Subtask 1.1: Define schema with all session fields
  - [ ] Subtask 1.2: Add is_current boolean field
- [ ] Task 2: Implement SessionService.get_user_sessions method (AC: 4, 5)
  - [ ] Subtask 2.1: Query sessions where revoked_at is null
  - [ ] Subtask 2.2: Filter expired sessions
  - [ ] Subtask 2.3: Order by created_at DESC
- [ ] Task 3: Create sessions listing endpoint (AC: 1, 3)
  - [ ] Subtask 3.1: Define GET /api/v1/users/me/sessions
  - [ ] Subtask 3.2: Identify current session from token
  - [ ] Subtask 3.3: Mark current session in response

## Technical Notes

- Current session identified by session_id in access token
- Consider pagination for users with many devices
- User-agent parsing optional (show raw or parsed)

## Dependencies

- Requires: Story 5.1

---

## Story 5.3: Implement Single Session Revocation

**Status:** draft
**Epic:** Session Management
**Priority:** P1

## User Story

As an authenticated user, I want to logout a specific device so that I can revoke access from a lost or shared device.

## Acceptance Criteria

1. **AC-5.3.1:** DELETE /api/v1/users/me/sessions/{id} revokes specific session
2. **AC-5.3.2:** Only own sessions can be revoked (not other users')
3. **AC-5.3.3:** Revoking current session is allowed
4. **AC-5.3.4:** Non-existent session returns 404 Not Found
5. **AC-5.3.5:** Already revoked session returns 200 (idempotent)
6. **AC-5.3.6:** Successful revocation returns 204 No Content

## Tasks

- [ ] Task 1: Implement SessionService.revoke_session method (AC: 2, 5)
  - [ ] Subtask 1.1: Verify session belongs to user
  - [ ] Subtask 1.2: Set revoked_at timestamp
  - [ ] Subtask 1.3: Handle already revoked case
- [ ] Task 2: Create session revocation endpoint (AC: 1, 4, 6)
  - [ ] Subtask 2.1: Define DELETE /api/v1/users/me/sessions/{id}
  - [ ] Subtask 2.2: Validate session_id format (UUID)
  - [ ] Subtask 2.3: Return 204 on success
- [ ] Task 3: Handle current session revocation (AC: 3)
  - [ ] Subtask 3.1: Allow revoking current session
  - [ ] Subtask 3.2: User will need to login again

## Technical Notes

- Use path parameter for session ID
- Revoked sessions remain in database for audit
- Consider returning list of remaining sessions in response

## Dependencies

- Requires: Story 5.2

---

## Story 5.4: Create "Logout All Devices" Endpoint

**Status:** draft
**Epic:** Session Management
**Priority:** P1

## User Story

As an authenticated user, I want to logout from all devices at once so that I can secure my account after a security concern.

## Acceptance Criteria

1. **AC-5.4.1:** POST /api/v1/auth/logout-all revokes all user sessions
2. **AC-5.4.2:** All refresh tokens for user become invalid
3. **AC-5.4.3:** Current session is also revoked
4. **AC-5.4.4:** Returns count of revoked sessions
5. **AC-5.4.5:** Access tokens remain valid until expiry (by design)

## Tasks

- [ ] Task 1: Implement SessionService.revoke_all_sessions method (AC: 2, 3, 4)
  - [ ] Subtask 1.1: Update all user sessions with revoked_at
  - [ ] Subtask 1.2: Return count of affected sessions
  - [ ] Subtask 1.3: Handle case with no active sessions
- [ ] Task 2: Create logout-all endpoint (AC: 1, 4)
  - [ ] Subtask 2.1: Define POST /api/v1/auth/logout-all
  - [ ] Subtask 2.2: Require authentication
  - [ ] Subtask 2.3: Return revoked_count in response
- [ ] Task 3: Add audit log entry (AC: 1)
  - [ ] Subtask 3.1: Log logout_all event with session count

## Technical Notes

- This is a security feature for compromised accounts
- User must re-login on all devices after this
- Consider sending notification email (future enhancement)

## Dependencies

- Requires: Story 5.3
