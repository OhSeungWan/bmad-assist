---
epic_num: 4
title: RBAC System
status: draft
---

# Epic 4: RBAC System

Role-based access control with schema design, role assignment, permission checking, and route protection.

---

## Story 4.1: Design Roles and Permissions Schema

**Status:** draft
**Epic:** RBAC System
**Priority:** P1

## User Story

As a system architect, I want a flexible roles and permissions schema so that access control can be managed centrally.

## Acceptance Criteria

1. **AC-4.1.1:** Role model with id, name, and permissions (JSON array)
2. **AC-4.1.2:** Users can have multiple roles (many-to-many)
3. **AC-4.1.3:** Default roles: admin, user created on startup
4. **AC-4.1.4:** Admin role has all permissions
5. **AC-4.1.5:** User role has read:own, write:own permissions
6. **AC-4.1.6:** Role names are unique

## Tasks

- [ ] Task 1: Create Role SQLAlchemy model (AC: 1, 6)
  - [ ] Subtask 1.1: Define model in models/role.py
  - [ ] Subtask 1.2: Add permissions as JSON column
  - [ ] Subtask 1.3: Add unique constraint on name
- [ ] Task 2: Create UserRole association table (AC: 2)
  - [ ] Subtask 2.1: Define user_roles table with user_id, role_id
  - [ ] Subtask 2.2: Add relationship to User and Role models
- [ ] Task 3: Create database initialization script (AC: 3, 4, 5)
  - [ ] Subtask 3.1: Seed admin role with ["*"] permissions
  - [ ] Subtask 3.2: Seed user role with ["read:own", "write:own"]
  - [ ] Subtask 3.3: Run on application startup
- [ ] Task 4: Create Pydantic schemas for roles (AC: 1)
  - [ ] Subtask 4.1: Define RoleResponse schema
  - [ ] Subtask 4.2: Define RoleCreate schema (admin only)

## Technical Notes

- Permissions are strings like "users:read", "users:write", "admin:*"
- Wildcard "*" grants all permissions
- Consider using enum for predefined permissions

## Dependencies

- Requires: Story 1.1

---

## Story 4.2: Create Role Assignment Endpoint (Admin)

**Status:** draft
**Epic:** RBAC System
**Priority:** P1

## User Story

As an administrator, I want to assign roles to users so that I can manage their access levels.

## Acceptance Criteria

1. **AC-4.2.1:** POST /api/v1/admin/users/{id}/roles assigns role to user
2. **AC-4.2.2:** Request body includes role_name
3. **AC-4.2.3:** Only admin role can assign roles
4. **AC-4.2.4:** Non-admin returns 403 Forbidden
5. **AC-4.2.5:** Invalid role name returns 404 Not Found
6. **AC-4.2.6:** User already has role returns 200 (idempotent)
7. **AC-4.2.7:** DELETE /api/v1/admin/users/{id}/roles/{role} removes role

## Tasks

- [ ] Task 1: Create require_admin dependency (AC: 3, 4)
  - [ ] Subtask 1.1: Check if current user has admin role
  - [ ] Subtask 1.2: Raise 403 if not admin
- [ ] Task 2: Implement RoleService.assign_role method (AC: 1, 5, 6)
  - [ ] Subtask 2.1: Lookup role by name
  - [ ] Subtask 2.2: Add role to user if not present
  - [ ] Subtask 2.3: Handle duplicate assignment gracefully
- [ ] Task 3: Create role assignment endpoint (AC: 1, 2)
  - [ ] Subtask 3.1: Define POST /api/v1/admin/users/{id}/roles
  - [ ] Subtask 3.2: Apply require_admin dependency
- [ ] Task 4: Create role removal endpoint (AC: 7)
  - [ ] Subtask 4.1: Define DELETE /api/v1/admin/users/{id}/roles/{role}
  - [ ] Subtask 4.2: Remove role from user

## Technical Notes

- Use FastAPI path parameter for user_id and role_name
- Prevent admin from removing their own admin role (optional safety)
- Return updated user roles in response

## Dependencies

- Requires: Story 4.1

---

## Story 4.3: Implement Permission Checking Middleware

**Status:** draft
**Epic:** RBAC System
**Priority:** P1

## User Story

As a system, I want to check permissions on each request so that unauthorized actions are blocked.

## Acceptance Criteria

1. **AC-4.3.1:** Permissions are derived from user's roles
2. **AC-4.3.2:** Wildcard permission "*" grants all access
3. **AC-4.3.3:** Permission check is available as dependency
4. **AC-4.3.4:** Missing permission returns 403 Forbidden
5. **AC-4.3.5:** Permission check is reusable across endpoints

## Tasks

- [ ] Task 1: Create PermissionService (AC: 1, 2)
  - [ ] Subtask 1.1: Implement get_user_permissions method
  - [ ] Subtask 1.2: Flatten permissions from all user roles
  - [ ] Subtask 1.3: Handle wildcard matching
- [ ] Task 2: Create require_permission dependency factory (AC: 3, 4, 5)
  - [ ] Subtask 2.1: Accept permission string as parameter
  - [ ] Subtask 2.2: Check user has required permission
  - [ ] Subtask 2.3: Raise 403 if permission missing
- [ ] Task 3: Add example usage to admin endpoints (AC: 3)
  - [ ] Subtask 3.1: Apply require_permission("admin:users") to user management
  - [ ] Subtask 3.2: Document pattern for other endpoints

## Technical Notes

- Permission format: "resource:action" (e.g., "users:read", "admin:manage")
- Cache user permissions to avoid repeated database lookups
- Consider using functools.lru_cache or request-scoped caching

## Dependencies

- Requires: Story 4.1, Story 2.2

---

## Story 4.4: Create Permission Validation Endpoint

**Status:** draft
**Epic:** RBAC System
**Priority:** P1

## User Story

As an API consumer, I want to check if a token has a specific permission so that I can make access decisions in my application.

## Acceptance Criteria

1. **AC-4.4.1:** POST /api/v1/auth/check-permission validates token and permission
2. **AC-4.4.2:** Request includes permission string to check
3. **AC-4.4.3:** Response includes has_permission: true/false
4. **AC-4.4.4:** Invalid token returns 401 Unauthorized
5. **AC-4.4.5:** Response includes user_id for convenience

## Tasks

- [ ] Task 1: Create PermissionCheckRequest schema (AC: 2)
  - [ ] Subtask 1.1: Define schema with permission field
- [ ] Task 2: Create PermissionCheckResponse schema (AC: 3, 5)
  - [ ] Subtask 2.1: Include has_permission boolean
  - [ ] Subtask 2.2: Include user_id string
- [ ] Task 3: Create check-permission endpoint (AC: 1, 4)
  - [ ] Subtask 3.1: Define POST /api/v1/auth/check-permission
  - [ ] Subtask 3.2: Require authentication
  - [ ] Subtask 3.3: Use PermissionService to check access

## Technical Notes

- Useful for microservices that need to validate permissions without full token decode
- Consider caching permission checks for performance
- Do not expose list of all user permissions (security)

## Dependencies

- Requires: Story 4.3

---

## Story 4.5: Add Role-Based Route Protection

**Status:** draft
**Epic:** RBAC System
**Priority:** P1

## User Story

As a developer, I want to easily protect routes with role requirements so that access control is consistent.

## Acceptance Criteria

1. **AC-4.5.1:** Admin endpoints require admin role
2. **AC-4.5.2:** User endpoints require authenticated user
3. **AC-4.5.3:** Role requirements documented in OpenAPI
4. **AC-4.5.4:** Consistent 403 response format for role failures
5. **AC-4.5.5:** GET /api/v1/admin/users lists all users (admin only)
6. **AC-4.5.6:** DELETE /api/v1/admin/users/{id} deletes user (admin only)

## Tasks

- [ ] Task 1: Apply require_admin to all admin routes (AC: 1, 5, 6)
  - [ ] Subtask 1.1: Update api/admin.py routes
  - [ ] Subtask 1.2: Ensure consistent dependency usage
- [ ] Task 2: Document security requirements in routes (AC: 3)
  - [ ] Subtask 2.1: Add dependencies to FastAPI route definitions
  - [ ] Subtask 2.2: Verify OpenAPI shows security schemes
- [ ] Task 3: Implement admin user management endpoints (AC: 5, 6)
  - [ ] Subtask 3.1: GET /api/v1/admin/users with pagination
  - [ ] Subtask 3.2: DELETE /api/v1/admin/users/{id} with cascade
- [ ] Task 4: Create standardized error response (AC: 4)
  - [ ] Subtask 4.1: Define 403 response schema
  - [ ] Subtask 4.2: Include permission that was required

## Technical Notes

- Use FastAPI's Depends() for consistent security application
- Consider APIRouter with default dependencies for admin routes
- Document which permissions are checked in route docstrings

## Dependencies

- Requires: Story 4.2, Story 4.3
