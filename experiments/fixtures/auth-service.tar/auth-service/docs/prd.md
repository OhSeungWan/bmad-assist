# Product Requirements Document: Auth Microservice

## Vision

A standalone authentication microservice providing JWT-based authentication, refresh token rotation, and role-based access control (RBAC). Designed as a reusable auth backend for microservices architecture with single-user SQLite database for simplicity and stateless JWT validation.

## Goals

1. Provide secure user registration and authentication via JWT tokens
2. Implement refresh token rotation for extended sessions
3. Enable role-based access control for fine-grained permissions
4. Support session management with device tracking
5. Maintain audit logs for security compliance
6. Ensure high performance with rate limiting for abuse prevention

## User Personas

### End User
Regular application user who needs to register, login, manage their profile, and maintain secure sessions across devices.

### Administrator
System administrator who manages users, assigns roles, monitors audit logs, and handles security incidents.

### API Consumer
Backend service or frontend application that integrates with the auth service for user authentication and authorization.

---

## Functional Requirements

### User Management

| ID | Requirement | Priority |
|----|-------------|----------|
| FR-001 | User registration with email/password | P0 |
| FR-002 | User login returning JWT access + refresh tokens | P0 |
| FR-005 | User profile CRUD (get, update own profile) | P1 |
| FR-006 | Admin user management (list, disable, delete users) | P1 |

### Authentication & Tokens

| ID | Requirement | Priority |
|----|-------------|----------|
| FR-003 | Token refresh endpoint (rotate refresh token) | P0 |
| FR-008 | Permission checking endpoint (validate token + permission) | P1 |

### Password Management

| ID | Requirement | Priority |
|----|-------------|----------|
| FR-004 | Password reset via email token (mock email) | P1 |

### Role-Based Access Control

| ID | Requirement | Priority |
|----|-------------|----------|
| FR-007 | Role assignment (admin assigns roles to users) | P1 |

### Session Management

| ID | Requirement | Priority |
|----|-------------|----------|
| FR-009 | Session listing (user sees active sessions) | P1 |
| FR-010 | Session revocation (logout specific session) | P1 |
| FR-011 | Logout all sessions (revoke all refresh tokens) | P1 |

### Security & Monitoring

| ID | Requirement | Priority |
|----|-------------|----------|
| FR-012 | Audit log for auth events (login, logout, password change) | P2 |
| FR-013 | Rate limiting on auth endpoints (login, register, reset) | P1 |

---

## Non-Functional Requirements

| ID | Requirement | Category |
|----|-------------|----------|
| NFR-001 | Passwords hashed with bcrypt (cost factor 12) | Security |
| NFR-002 | JWT access token expiry: 15 minutes | Security |
| NFR-003 | JWT refresh token expiry: 7 days | Security |
| NFR-004 | Rate limit: 5 failed logins per 15 min per IP | Security |
| NFR-005 | API response time < 100ms (p95) | Performance |
| NFR-006 | Test coverage > 85% | Quality |
| NFR-007 | All endpoints documented with OpenAPI | Documentation |

---

## MVP Scope

The MVP includes all features in Epics 1-6:

1. **User Management** - Registration, login, profile management
2. **JWT Authentication** - Token generation, validation, refresh rotation
3. **Password Management** - Hashing, change, reset flow
4. **RBAC System** - Roles, permissions, route protection
5. **Session Management** - Tracking, listing, revocation
6. **Security & Monitoring** - Rate limiting, audit logging

### Out of Scope

- OAuth2/OIDC provider functionality
- Social login (Google, GitHub, etc.)
- Multi-tenancy
- API key authentication
- Two-factor authentication (2FA)
- Email verification on registration
- Account lockout policies
- Docker/deployment configuration
