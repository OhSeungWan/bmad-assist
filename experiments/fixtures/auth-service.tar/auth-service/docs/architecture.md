# Technical Architecture: Auth Microservice

## Overview

Standalone authentication microservice built with FastAPI providing JWT-based authentication, refresh token rotation, and role-based access control. Uses SQLite for persistence and stateless JWT validation for scalability.

## Tech Stack

| Component | Technology | Version |
|-----------|------------|---------|
| Language | Python | 3.11+ |
| Framework | FastAPI | 0.100+ |
| Database | SQLite | via aiosqlite |
| ORM | SQLAlchemy | 2.0 (async) |
| Auth | PyJWT, passlib[bcrypt] | - |
| Validation | Pydantic | v2 |
| Testing | pytest, pytest-asyncio, httpx | - |
| Linting | ruff | - |

## System Components

```
┌─────────────────────────────────────────────────────────────────┐
│                         API Layer                                │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐        │
│  │  /auth   │  │  /users  │  │  /admin  │  │  /health │        │
│  └────┬─────┘  └────┬─────┘  └────┬─────┘  └──────────┘        │
│       │             │             │                              │
│  ┌────┴─────────────┴─────────────┴────┐                        │
│  │           Middleware Layer           │                        │
│  │  ┌────────────┐  ┌────────────────┐ │                        │
│  │  │ Rate Limit │  │ JWT Validation │ │                        │
│  │  └────────────┘  └────────────────┘ │                        │
│  └──────────────────┬──────────────────┘                        │
└─────────────────────┼───────────────────────────────────────────┘
                      │
┌─────────────────────┼───────────────────────────────────────────┐
│                     │      Service Layer                         │
│  ┌──────────┐  ┌────┴─────┐  ┌──────────┐  ┌──────────┐        │
│  │   Auth   │  │   User   │  │  Token   │  │ Password │        │
│  │ Service  │  │ Service  │  │ Service  │  │ Service  │        │
│  └────┬─────┘  └────┬─────┘  └────┬─────┘  └────┬─────┘        │
└───────┼─────────────┼─────────────┼─────────────┼───────────────┘
        │             │             │             │
┌───────┴─────────────┴─────────────┴─────────────┴───────────────┐
│                        Data Layer                                │
│  ┌────────────────────────────────────────────────────────────┐ │
│  │                    SQLAlchemy ORM                           │ │
│  │  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐   │ │
│  │  │  User    │  │ Session  │  │  Role    │  │  Audit   │   │ │
│  │  │  Model   │  │  Model   │  │  Model   │  │  Model   │   │ │
│  │  └──────────┘  └──────────┘  └──────────┘  └──────────┘   │ │
│  └────────────────────────────────────────────────────────────┘ │
│                              │                                   │
│                      ┌───────┴───────┐                          │
│                      │    SQLite     │                          │
│                      │   Database    │                          │
│                      └───────────────┘                          │
└─────────────────────────────────────────────────────────────────┘
```

## Data Model

### Entity Relationship Diagram

```
┌─────────────────┐       ┌─────────────────┐
│     users       │       │     roles       │
├─────────────────┤       ├─────────────────┤
│ id (PK)         │       │ id (PK)         │
│ email           │───┐   │ name            │
│ password_hash   │   │   │ permissions     │
│ is_active       │   │   └────────┬────────┘
│ created_at      │   │            │
│ updated_at      │   │   ┌────────┴────────┐
└────────┬────────┘   │   │   user_roles    │
         │            │   ├─────────────────┤
         │            └──►│ user_id (FK)    │
         │                │ role_id (FK)    │
         │                └─────────────────┘
         │
         │            ┌─────────────────┐
         │            │    sessions     │
         │            ├─────────────────┤
         └───────────►│ id (PK)         │
                      │ user_id (FK)    │
                      │ refresh_token   │
                      │ user_agent      │
                      │ ip_address      │
                      │ expires_at      │
                      │ created_at      │
                      │ revoked_at      │
                      └─────────────────┘

         │            ┌─────────────────┐
         │            │   audit_logs    │
         │            ├─────────────────┤
         └───────────►│ id (PK)         │
                      │ user_id (FK)    │
                      │ event_type      │
                      │ ip_address      │
                      │ user_agent      │
                      │ details         │
                      │ created_at      │
                      └─────────────────┘
```

### Core Tables

| Table | Purpose |
|-------|---------|
| users | User accounts with credentials |
| roles | Named roles with permission sets |
| user_roles | Many-to-many user-role mapping |
| sessions | Active refresh tokens and device info |
| audit_logs | Authentication event history |

## API Design

### Authentication Endpoints

| Method | Path | Description |
|--------|------|-------------|
| POST | /api/v1/auth/register | Register new user |
| POST | /api/v1/auth/login | Login, get tokens |
| POST | /api/v1/auth/refresh | Refresh access token |
| POST | /api/v1/auth/logout | Revoke current session |
| POST | /api/v1/auth/logout-all | Revoke all sessions |

### Password Endpoints

| Method | Path | Description |
|--------|------|-------------|
| POST | /api/v1/password/change | Change password |
| POST | /api/v1/password/reset-request | Request reset token |
| POST | /api/v1/password/reset-confirm | Confirm reset |

### User Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | /api/v1/users/me | Get own profile |
| PATCH | /api/v1/users/me | Update own profile |
| GET | /api/v1/users/me/sessions | List active sessions |
| DELETE | /api/v1/users/me/sessions/{id} | Revoke session |

### Admin Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | /api/v1/admin/users | List all users |
| GET | /api/v1/admin/users/{id} | Get user by ID |
| PATCH | /api/v1/admin/users/{id} | Update user |
| DELETE | /api/v1/admin/users/{id} | Delete user |
| POST | /api/v1/admin/users/{id}/roles | Assign role |
| DELETE | /api/v1/admin/users/{id}/roles/{role} | Remove role |

### Permission Endpoints

| Method | Path | Description |
|--------|------|-------------|
| POST | /api/v1/auth/check-permission | Validate token + permission |

---

## Architecture Decision Records

### ADR-001: SQLite over PostgreSQL

**Status:** Accepted

**Context:** Need to choose a database for development and testing.

**Decision:** Use SQLite with aiosqlite for async support.

**Rationale:**
- Zero configuration required
- Single file database
- Sufficient for benchmark scope
- Simplifies setup and testing

**Trade-offs:**
- No concurrent writes (auth service is read-heavy, acceptable)
- Limited scalability (not a concern for this scope)

---

### ADR-002: Stateless JWT over Session Cookies

**Status:** Accepted

**Context:** Need to choose session management approach.

**Decision:** Use stateless JWT tokens for access control.

**Rationale:**
- Microservice-friendly architecture
- No session storage needed for access tokens
- Scalable across multiple instances

**Trade-offs:**
- Cannot instantly revoke access tokens
- Mitigated by short expiry (15 minutes)

---

### ADR-003: Refresh Token in Database (not stateless)

**Status:** Accepted

**Context:** Need to support token revocation and session tracking.

**Decision:** Store refresh tokens in database with session metadata.

**Rationale:**
- Enables immediate revocation
- Supports session tracking per device
- Allows "logout all devices" functionality

**Trade-offs:**
- Database lookup on every refresh
- Acceptable latency for refresh operations

---

### ADR-004: Bcrypt over Argon2

**Status:** Accepted

**Context:** Need to choose password hashing algorithm.

**Decision:** Use bcrypt with cost factor 12 via passlib.

**Rationale:**
- Widely supported and battle-tested
- passlib default algorithm
- Well-understood security properties

**Trade-offs:**
- Argon2 is newer with better memory-hard properties
- Bcrypt is sufficient for this application

---

### ADR-005: No Email Service Integration

**Status:** Accepted

**Context:** Password reset requires email delivery.

**Decision:** Mock email sending for password reset flow.

**Rationale:**
- Keeps scope focused on auth logic
- Avoids external service dependencies
- Sufficient for benchmark purposes

**Trade-offs:**
- Not production-ready without email integration
- Acceptable for testing and benchmarking
