# Project Context: UI Component Library

## 1. File Structure

```
src/
├── components/
│   ├── Button/
│   │   ├── Button.tsx
│   │   ├── Button.module.css
│   │   ├── Button.test.tsx
│   │   ├── Button.stories.tsx
│   │   └── index.ts
│   ├── Input/
│   │   ├── Input.tsx
│   │   ├── Input.module.css
│   │   ├── Input.test.tsx
│   │   ├── Input.stories.tsx
│   │   └── index.ts
│   ├── Select/
│   ├── Checkbox/
│   ├── Radio/
│   ├── Label/
│   ├── FormField/
│   ├── Card/
│   ├── Modal/
│   ├── Dropdown/
│   ├── Toast/
│   ├── Tooltip/
│   ├── Tabs/
│   ├── Form/
│   ├── Stack/
│   ├── Flex/
│   ├── Grid/
│   └── Container/
├── hooks/
│   ├── useTheme.ts
│   ├── useFocusTrap.ts
│   ├── useKeyboard.ts
│   ├── useId.ts
│   └── useMediaQuery.ts
├── context/
│   └── ThemeContext.tsx
├── tokens/
│   ├── colors.css
│   ├── spacing.css
│   ├── typography.css
│   ├── radii.css
│   ├── shadows.css
│   └── index.css
├── styles/
│   └── reset.css
├── utils/
│   ├── cn.ts              # classnames utility
│   └── mergeRefs.ts
├── index.ts               # Public exports
└── types.ts               # Shared types

.storybook/
├── main.ts
├── preview.ts
└── preview-head.html

tests/
├── setup.ts
└── utils/
    └── render.tsx
```

---

## 2. Naming Conventions

### Files

| Category | Convention | Example |
|----------|------------|---------|
| Components | PascalCase | `Button.tsx` |
| CSS Modules | PascalCase + `.module.css` | `Button.module.css` |
| Tests | PascalCase + `.test.tsx` | `Button.test.tsx` |
| Stories | PascalCase + `.stories.tsx` | `Button.stories.tsx` |
| Hooks | camelCase with `use` prefix | `useTheme.ts` |
| Utilities | camelCase | `cn.ts`, `mergeRefs.ts` |
| CSS token files | kebab-case | `colors.css` |

### Code

| Category | Convention | Example |
|----------|------------|---------|
| Components | PascalCase | `Button`, `FormField` |
| Props interfaces | `[Component]Props` | `ButtonProps`, `InputProps` |
| Hooks | camelCase with `use` prefix | `useTheme()`, `useFocusTrap()` |
| CSS class selectors | camelCase | `.buttonPrimary`, `.inputError` |
| CSS variables | kebab-case | `--color-primary`, `--spacing-md` |
| Event handlers | `on[Event]` | `onClick`, `onChange` |
| Boolean props | `is[State]` or `has[Thing]` | `isDisabled`, `hasError` |
| Constants | UPPER_SNAKE_CASE | `DEFAULT_THEME`, `MODAL_Z_INDEX` |

---

## 3. React/TypeScript Patterns

### 3.1 Component Definition

All components use `forwardRef` with explicit typing:

```tsx
import { forwardRef } from 'react';
import styles from './Button.module.css';
import { cn } from '../../utils/cn';

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger';
  size?: 'sm' | 'md' | 'lg';
  isLoading?: boolean;
}

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  (
    { variant = 'primary', size = 'md', isLoading, className, children, disabled, ...props },
    ref
  ) => {
    return (
      <button
        ref={ref}
        className={cn(
          styles.button,
          styles[variant],
          styles[size],
          isLoading && styles.loading,
          className
        )}
        disabled={disabled || isLoading}
        {...props}
      >
        {isLoading ? <Spinner /> : children}
      </button>
    );
  }
);

Button.displayName = 'Button';
```

### 3.2 Compound Components

Use Object.assign pattern for compound components:

```tsx
// Card.tsx
const CardRoot = forwardRef<HTMLDivElement, CardProps>((props, ref) => {
  // implementation
});

const CardHeader = forwardRef<HTMLDivElement, CardHeaderProps>((props, ref) => {
  // implementation
});

const CardBody = forwardRef<HTMLDivElement, CardBodyProps>((props, ref) => {
  // implementation
});

const CardFooter = forwardRef<HTMLDivElement, CardFooterProps>((props, ref) => {
  // implementation
});

export const Card = Object.assign(CardRoot, {
  Header: CardHeader,
  Body: CardBody,
  Footer: CardFooter,
});
```

### 3.3 Custom Hooks

Hooks follow consistent return patterns:

```tsx
// useTheme.ts
interface UseThemeReturn {
  theme: 'light' | 'dark';
  setTheme: (theme: 'light' | 'dark') => void;
  toggleTheme: () => void;
}

export function useTheme(): UseThemeReturn {
  const context = useContext(ThemeContext);
  if (!context) {
    throw new Error('useTheme must be used within ThemeProvider');
  }
  return context;
}
```

### 3.4 Event Handler Props

Callbacks receive typed event objects:

```tsx
interface InputProps {
  onChange?: (value: string, event: React.ChangeEvent<HTMLInputElement>) => void;
  onBlur?: (event: React.FocusEvent<HTMLInputElement>) => void;
}
```

### 3.5 Polymorphic Components

Use generics for `as` prop support:

```tsx
type StackProps<T extends React.ElementType = 'div'> = {
  as?: T;
  gap?: 'xs' | 'sm' | 'md' | 'lg' | 'xl';
  direction?: 'horizontal' | 'vertical';
} & Omit<React.ComponentPropsWithoutRef<T>, 'as' | 'gap' | 'direction'>;

export function Stack<T extends React.ElementType = 'div'>({
  as,
  gap = 'md',
  direction = 'vertical',
  className,
  ...props
}: StackProps<T>) {
  const Component = as || 'div';
  return (
    <Component
      className={cn(styles.stack, styles[gap], styles[direction], className)}
      {...props}
    />
  );
}
```

---

## 4. CSS Module Patterns

### 4.1 Base Component Styles

```css
/* Button.module.css */
.button {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: var(--spacing-sm);
  padding: var(--spacing-sm) var(--spacing-md);
  border-radius: var(--radius-md);
  font-size: var(--font-size-base);
  font-weight: var(--font-weight-medium);
  line-height: 1;
  transition: all var(--transition-fast);
  cursor: pointer;
}

.button:focus-visible {
  outline: 2px solid var(--color-border-focus);
  outline-offset: 2px;
}

.button:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
```

### 4.2 Variant Modifiers

```css
/* Variant classes */
.primary {
  background-color: var(--color-primary);
  color: var(--color-text-inverse);
  border: none;
}

.primary:hover:not(:disabled) {
  background-color: var(--color-primary-hover);
}

.secondary {
  background-color: var(--color-surface);
  color: var(--color-text);
  border: 1px solid var(--color-border);
}
```

### 4.3 Size Modifiers

```css
.sm {
  padding: var(--spacing-xs) var(--spacing-sm);
  font-size: var(--font-size-sm);
}

.md {
  padding: var(--spacing-sm) var(--spacing-md);
  font-size: var(--font-size-base);
}

.lg {
  padding: var(--spacing-md) var(--spacing-lg);
  font-size: var(--font-size-lg);
}
```

---

## 5. Testing Standards

### 5.1 Test File Structure

```tsx
// Button.test.tsx
import { render, screen } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { axe } from 'jest-axe';
import { Button } from './Button';

describe('Button', () => {
  describe('rendering', () => {
    it('renders with children', () => {
      render(<Button>Click me</Button>);
      expect(screen.getByRole('button', { name: 'Click me' })).toBeInTheDocument();
    });

    it('applies variant class', () => {
      render(<Button variant="danger">Delete</Button>);
      expect(screen.getByRole('button')).toHaveClass('danger');
    });
  });

  describe('interaction', () => {
    it('calls onClick when clicked', async () => {
      const onClick = vi.fn();
      const user = userEvent.setup();

      render(<Button onClick={onClick}>Click</Button>);
      await user.click(screen.getByRole('button'));

      expect(onClick).toHaveBeenCalledTimes(1);
    });

    it('does not call onClick when disabled', async () => {
      const onClick = vi.fn();
      const user = userEvent.setup();

      render(<Button onClick={onClick} disabled>Click</Button>);
      await user.click(screen.getByRole('button'));

      expect(onClick).not.toHaveBeenCalled();
    });
  });

  describe('accessibility', () => {
    it('has no accessibility violations', async () => {
      const { container } = render(<Button>Accessible</Button>);
      expect(await axe(container)).toHaveNoViolations();
    });

    it('supports keyboard activation', async () => {
      const onClick = vi.fn();
      const user = userEvent.setup();

      render(<Button onClick={onClick}>Press Enter</Button>);
      await user.tab();
      await user.keyboard('{Enter}');

      expect(onClick).toHaveBeenCalledTimes(1);
    });
  });
});
```

### 5.2 Testing Patterns

| Pattern | Use Case | Example |
|---------|----------|---------|
| `screen.getByRole` | Find by ARIA role | `getByRole('button')` |
| `screen.getByLabelText` | Find form controls | `getByLabelText('Email')` |
| `screen.getByText` | Find by text content | `getByText('Submit')` |
| `userEvent.click` | Simulate clicks | `await user.click(button)` |
| `userEvent.type` | Simulate typing | `await user.type(input, 'text')` |
| `userEvent.tab` | Simulate tab navigation | `await user.tab()` |
| `axe()` | Check accessibility | `expect(await axe(container)).toHaveNoViolations()` |

### 5.3 Required Test Coverage

Each component must test:

1. **Rendering**: Default render, with props, with children
2. **Variants**: All variant/size combinations render correctly
3. **Interaction**: Click, keyboard, focus behaviors
4. **States**: Disabled, loading, error states
5. **Accessibility**: No axe violations, keyboard operability

---

## 6. Storybook Standards

### 6.1 Story Structure

```tsx
// Button.stories.tsx
import type { Meta, StoryObj } from '@storybook/react';
import { Button } from './Button';

const meta: Meta<typeof Button> = {
  title: 'Components/Button',
  component: Button,
  tags: ['autodocs'],
  argTypes: {
    variant: {
      control: 'select',
      options: ['primary', 'secondary', 'ghost', 'danger'],
    },
    size: {
      control: 'select',
      options: ['sm', 'md', 'lg'],
    },
  },
};

export default meta;
type Story = StoryObj<typeof Button>;

export const Primary: Story = {
  args: {
    variant: 'primary',
    children: 'Primary Button',
  },
};

export const Secondary: Story = {
  args: {
    variant: 'secondary',
    children: 'Secondary Button',
  },
};

export const AllVariants: Story = {
  render: () => (
    <div style={{ display: 'flex', gap: '1rem' }}>
      <Button variant="primary">Primary</Button>
      <Button variant="secondary">Secondary</Button>
      <Button variant="ghost">Ghost</Button>
      <Button variant="danger">Danger</Button>
    </div>
  ),
};
```

### 6.2 Documentation Standards

Each component story file must include:

1. Default export with meta configuration
2. Individual stories for each variant
3. Composite story showing all variants together
4. Stories demonstrating interactive states
5. Accessibility annotations where relevant

---

## 7. Import/Export Patterns

### 7.1 Component Index Files

```tsx
// components/Button/index.ts
export { Button } from './Button';
export type { ButtonProps } from './Button';
```

### 7.2 Main Package Export

```tsx
// src/index.ts

// Components
export { Button } from './components/Button';
export { Input } from './components/Input';
export { Select } from './components/Select';
export { Checkbox } from './components/Checkbox';
export { Radio, RadioGroup } from './components/Radio';
export { Label } from './components/Label';
export { FormField } from './components/FormField';
export { Card } from './components/Card';
export { Modal } from './components/Modal';
export { Dropdown } from './components/Dropdown';
export { Toast, ToastProvider } from './components/Toast';
export { Tooltip } from './components/Tooltip';
export { Tabs } from './components/Tabs';
export { Form } from './components/Form';
export { Stack } from './components/Stack';
export { Flex } from './components/Flex';
export { Grid } from './components/Grid';
export { Container } from './components/Container';

// Context
export { ThemeProvider, useTheme } from './context/ThemeContext';

// Hooks
export { useFocusTrap } from './hooks/useFocusTrap';
export { useKeyboard } from './hooks/useKeyboard';

// Types
export type { Theme, ThemeConfig } from './types';
export type { ButtonProps } from './components/Button';
export type { InputProps } from './components/Input';
// ... other component prop types
```

---

## 8. Critical Patterns

### 8.1 Always Use

- `forwardRef` on all components
- `displayName` for debugging
- CSS Modules for styling
- `cn()` utility for class composition
- TypeScript strict mode
- Semantic HTML elements
- ARIA attributes where needed

### 8.2 Never Use

- Inline styles (except dynamic values)
- `any` type
- Default exports for components
- Direct DOM manipulation
- CSS-in-JS runtime libraries
- Non-semantic div soup
