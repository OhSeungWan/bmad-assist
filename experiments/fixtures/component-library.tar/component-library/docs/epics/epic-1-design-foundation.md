---
epic_num: 1
title: Design System Foundation
status: draft
---

# Epic 1: Design System Foundation

**Goal:** Establish the design token system and theming infrastructure that all components will use.

**Total Stories:** 4
**Dependencies:** None (foundation epic)

---

## Story 1.1: Create Design Tokens

**Status:** draft
**Epic:** Design System Foundation
**Priority:** P0

## User Story

As a developer, I want a comprehensive design token system so that all components use consistent colors, spacing, typography, and other visual properties.

## Acceptance Criteria

1. **AC-1.1.1:** Color tokens are defined as CSS custom properties including primary, secondary, success, warning, danger, background, surface, text, and text-muted values
2. **AC-1.1.2:** Spacing tokens follow a consistent scale (xs, sm, md, lg, xl, 2xl, 3xl) with rem-based values
3. **AC-1.1.3:** Typography tokens include font-family (sans, mono), font-size scale, font-weight options, and line-height values
4. **AC-1.1.4:** Border radius tokens provide sm, md, lg, and full options
5. **AC-1.1.5:** Shadow tokens provide sm, md, lg, and xl elevation levels
6. **AC-1.1.6:** Transition tokens define consistent timing (fast, normal, slow) with easing functions
7. **AC-1.1.7:** All tokens are exported from a single tokens/index.css file

## Tasks

- [ ] Task 1: Create tokens/colors.css with color custom properties (AC: 1)
  - [ ] Subtask 1.1: Define primary color palette (primary, primary-hover, primary-active)
  - [ ] Subtask 1.2: Define secondary color palette
  - [ ] Subtask 1.3: Define semantic colors (success, warning, danger with backgrounds)
  - [ ] Subtask 1.4: Define neutral colors (background, surface, border, text)
- [ ] Task 2: Create tokens/spacing.css with spacing scale (AC: 2)
  - [ ] Subtask 2.1: Define spacing-0 through spacing-3xl variables
- [ ] Task 3: Create tokens/typography.css with font tokens (AC: 3)
  - [ ] Subtask 3.1: Define font-family variables (sans, mono)
  - [ ] Subtask 3.2: Define font-size scale (xs through 3xl)
  - [ ] Subtask 3.3: Define font-weight options (normal, medium, semibold, bold)
  - [ ] Subtask 3.4: Define line-height options (tight, normal, relaxed)
- [ ] Task 4: Create tokens/radii.css with border radius tokens (AC: 4)
- [ ] Task 5: Create tokens/shadows.css with elevation tokens (AC: 5)
- [ ] Task 6: Create tokens/transitions.css with timing tokens (AC: 6)
- [ ] Task 7: Create tokens/index.css that imports all token files (AC: 7)

## Technical Notes

- Use CSS custom properties (--variable-name) for all tokens
- Follow the token values defined in ux-design.md
- Ensure all values use relative units (rem) for accessibility (font scaling)
- Shadow tokens should use rgb() with alpha for transparency

## Dependencies

- Requires: None

---

## Story 1.2: Implement Theme Provider with Context

**Status:** draft
**Epic:** Design System Foundation
**Priority:** P0

## User Story

As a developer, I want a ThemeProvider component so that I can provide theme context to all components in my application.

## Acceptance Criteria

1. **AC-1.2.1:** ThemeContext is created with theme value and setter function
2. **AC-1.2.2:** ThemeProvider component accepts children and optional initial theme prop
3. **AC-1.2.3:** useTheme hook provides access to current theme and setTheme function
4. **AC-1.2.4:** useTheme throws descriptive error when used outside ThemeProvider
5. **AC-1.2.5:** Theme values are 'light' or 'dark' union type
6. **AC-1.2.6:** ThemeProvider applies data-theme attribute to wrapper element for CSS targeting

## Tasks

- [ ] Task 1: Create theme type definitions in types.ts (AC: 5)
  - [ ] Subtask 1.1: Define Theme type as 'light' | 'dark'
  - [ ] Subtask 1.2: Define ThemeContextValue interface with theme and setTheme
- [ ] Task 2: Create context/ThemeContext.tsx with context and provider (AC: 1, 2, 6)
  - [ ] Subtask 2.1: Create ThemeContext with createContext
  - [ ] Subtask 2.2: Implement ThemeProvider component with useState
  - [ ] Subtask 2.3: Apply data-theme attribute to wrapper div
- [ ] Task 3: Implement useTheme hook (AC: 3, 4)
  - [ ] Subtask 3.1: Create useTheme that consumes ThemeContext
  - [ ] Subtask 3.2: Add error throwing when context is undefined
- [ ] Task 4: Write unit tests for ThemeProvider and useTheme
  - [ ] Subtask 4.1: Test default theme value
  - [ ] Subtask 4.2: Test initial theme prop
  - [ ] Subtask 4.3: Test setTheme updates value
  - [ ] Subtask 4.4: Test useTheme error outside provider
- [ ] Task 5: Export ThemeProvider and useTheme from index.ts

## Technical Notes

- Store theme in React state within ThemeProvider
- The data-theme attribute enables CSS to select theme-specific values
- Consider localStorage persistence in future story (not this one)

## Dependencies

- Requires: Story 1.1 (design tokens defined for theme switching to work)

---

## Story 1.3: Add Light/Dark Theme Switching

**Status:** draft
**Epic:** Design System Foundation
**Priority:** P0

## User Story

As a user, I want to switch between light and dark themes so that I can use the application in my preferred visual mode.

## Acceptance Criteria

1. **AC-1.3.1:** Light theme token values are defined with light backgrounds and dark text
2. **AC-1.3.2:** Dark theme token values are defined with dark backgrounds and light text
3. **AC-1.3.3:** Theme switching via setTheme('dark') or setTheme('light') updates all token values
4. **AC-1.3.4:** toggleTheme function is available to flip between light and dark
5. **AC-1.3.5:** Theme respects prefers-color-scheme media query for initial value when no explicit theme set
6. **AC-1.3.6:** Color contrast ratios meet WCAG AA (4.5:1 for text) in both themes

## Tasks

- [ ] Task 1: Create light theme CSS variables in tokens/themes/light.css (AC: 1)
  - [ ] Subtask 1.1: Define all color overrides for light theme
- [ ] Task 2: Create dark theme CSS variables in tokens/themes/dark.css (AC: 2)
  - [ ] Subtask 2.1: Define all color overrides for dark theme
  - [ ] Subtask 2.2: Adjust semantic colors (success-bg, warning-bg, danger-bg) for dark backgrounds
- [ ] Task 3: Update tokens/index.css to apply theme based on data-theme attribute (AC: 3)
  - [ ] Subtask 3.1: Use [data-theme="light"] selector for light theme
  - [ ] Subtask 3.2: Use [data-theme="dark"] selector for dark theme
- [ ] Task 4: Add toggleTheme function to ThemeContext (AC: 4)
- [ ] Task 5: Implement prefers-color-scheme detection in ThemeProvider (AC: 5)
  - [ ] Subtask 5.1: Use matchMedia to detect system preference
  - [ ] Subtask 5.2: Set initial theme based on system preference if no prop provided
- [ ] Task 6: Verify color contrast ratios using contrast checking tool (AC: 6)
- [ ] Task 7: Write tests for theme switching functionality

## Technical Notes

- Use CSS attribute selectors [data-theme="dark"] to scope theme variables
- matchMedia('(prefers-color-scheme: dark)') for system preference detection
- Dark theme should have sufficient contrast - test with WebAIM contrast checker

## Dependencies

- Requires: Story 1.1 (design tokens), Story 1.2 (ThemeProvider)

---

## Story 1.4: Create CSS Reset and Base Styles

**Status:** draft
**Epic:** Design System Foundation
**Priority:** P0

## User Story

As a developer, I want a CSS reset that normalizes browser defaults so that components render consistently across all browsers.

## Acceptance Criteria

1. **AC-1.4.1:** Box-sizing is set to border-box for all elements
2. **AC-1.4.2:** Default margins and padding are reset to zero
3. **AC-1.4.3:** List styles are removed from ul/ol elements
4. **AC-1.4.4:** Images and media are set to max-width: 100% and display: block
5. **AC-1.4.5:** Form elements inherit font properties from parent
6. **AC-1.4.6:** Focus-visible outline is styled consistently with design tokens
7. **AC-1.4.7:** Reduced motion media query disables animations for users who prefer it
8. **AC-1.4.8:** Base styles apply design tokens (font-family, background, text color)

## Tasks

- [ ] Task 1: Create styles/reset.css with browser normalization (AC: 1, 2, 3, 4, 5)
  - [ ] Subtask 1.1: Set box-sizing border-box on all elements
  - [ ] Subtask 1.2: Reset margin and padding to 0
  - [ ] Subtask 1.3: Remove list-style from ul and ol
  - [ ] Subtask 1.4: Set images to block and max-width 100%
  - [ ] Subtask 1.5: Make form elements inherit font
- [ ] Task 2: Add focus-visible styling using design tokens (AC: 6)
  - [ ] Subtask 2.1: Create consistent focus ring style (2px solid, 2px offset)
  - [ ] Subtask 2.2: Apply to all focusable elements
- [ ] Task 3: Add reduced motion media query (AC: 7)
  - [ ] Subtask 3.1: Set animation-duration and transition-duration to near-zero
- [ ] Task 4: Create base body/html styles using design tokens (AC: 8)
  - [ ] Subtask 4.1: Apply font-family from tokens
  - [ ] Subtask 4.2: Apply background-color and color from tokens
  - [ ] Subtask 4.3: Set line-height and font-size defaults
- [ ] Task 5: Import reset.css in tokens/index.css
- [ ] Task 6: Test reset in multiple browsers (Chrome, Firefox, Safari)

## Technical Notes

- Use modern CSS reset approach (not legacy normalize.css)
- :focus-visible only shows focus on keyboard navigation, not mouse clicks
- @media (prefers-reduced-motion: reduce) for motion preferences
- Reset should be minimal - only normalize, not add decorative styles

## Dependencies

- Requires: Story 1.1 (design tokens must exist for base styles to reference)
