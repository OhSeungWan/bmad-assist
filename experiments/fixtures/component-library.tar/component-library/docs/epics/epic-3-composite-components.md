---
epic_num: 3
title: Composite Components
status: draft
---

# Epic 3: Composite Components

**Goal:** Create complex interactive components that compose primitives and provide advanced functionality.

**Total Stories:** 6
**Dependencies:** Epic 1 (Design System Foundation), Epic 2 (Primitive Components)

---

## Story 3.1: Create Card Component with Slots

**Status:** draft
**Epic:** Composite Components
**Priority:** P1

## User Story

As a developer, I want a Card component with header, body, and footer slots so that I can create consistent content containers.

## Acceptance Criteria

1. **AC-3.1.1:** Card renders as an `<article>` element with surface background and shadow
2. **AC-3.1.2:** Card supports variant prop with values: elevated (default), outlined
3. **AC-3.1.3:** Card.Header renders as a `<header>` element with bottom border
4. **AC-3.1.4:** Card.Body renders as a `<div>` with padding
5. **AC-3.1.5:** Card.Footer renders as a `<footer>` element with top border and flex layout
6. **AC-3.1.6:** All sub-components forward refs
7. **AC-3.1.7:** Card accepts padding prop that applies consistent padding to all sections
8. **AC-3.1.8:** Compound components work independently (Card.Body can be used without Header)
9. **AC-3.1.9:** Components pass accessibility tests

## Tasks

- [ ] Task 1: Create Card component file structure (AC: 1)
  - [ ] Subtask 1.1: Create components/Card/Card.tsx
  - [ ] Subtask 1.2: Create components/Card/CardHeader.tsx
  - [ ] Subtask 1.3: Create components/Card/CardBody.tsx
  - [ ] Subtask 1.4: Create components/Card/CardFooter.tsx
  - [ ] Subtask 1.5: Create components/Card/Card.module.css
  - [ ] Subtask 1.6: Create components/Card/index.ts
- [ ] Task 2: Define CardProps and sub-component props interfaces (AC: 2, 7)
- [ ] Task 3: Implement Card root component (AC: 1, 2, 6)
  - [ ] Subtask 3.1: Use article element
  - [ ] Subtask 3.2: Add elevated and outlined variant styles
- [ ] Task 4: Implement Card.Header (AC: 3, 6)
- [ ] Task 5: Implement Card.Body (AC: 4, 6)
- [ ] Task 6: Implement Card.Footer with flex layout (AC: 5, 6)
- [ ] Task 7: Compose using Object.assign pattern (AC: 8)
- [ ] Task 8: Style with CSS Modules using design tokens
- [ ] Task 9: Write unit tests (AC: 9)
  - [ ] Subtask 9.1: Test composition patterns
  - [ ] Subtask 9.2: Test variants
  - [ ] Subtask 9.3: Add axe accessibility test
- [ ] Task 10: Create Storybook stories

## Technical Notes

- Use Object.assign(CardRoot, {Header, Body, Footer}) for compound pattern
- Elevated variant uses shadow-md, outlined uses border
- Footer typically contains action buttons - use flex with gap

## Dependencies

- Requires: Story 1.1 (design tokens)

---

## Story 3.2: Create Modal with Focus Trap

**Status:** draft
**Epic:** Composite Components
**Priority:** P0

## User Story

As a developer, I want a Modal component with focus trapping so that users can interact with dialogs accessibly.

## Acceptance Criteria

1. **AC-3.2.1:** Modal renders in a portal attached to document.body
2. **AC-3.2.2:** Modal displays backdrop overlay when open
3. **AC-3.2.3:** Modal has role="dialog" and aria-modal="true"
4. **AC-3.2.4:** Focus is trapped within modal when open (Tab cycles through modal elements only)
5. **AC-3.2.5:** Escape key closes the modal
6. **AC-3.2.6:** Clicking backdrop closes the modal (configurable via closeOnOverlayClick prop)
7. **AC-3.2.7:** Focus returns to trigger element when modal closes
8. **AC-3.2.8:** Modal.Header, Modal.Body, Modal.Footer compound components available
9. **AC-3.2.9:** Modal supports isOpen and onClose props for controlled behavior
10. **AC-3.2.10:** Modal passes accessibility tests

## Tasks

- [ ] Task 1: Create useFocusTrap hook (AC: 4)
  - [ ] Subtask 1.1: Create hooks/useFocusTrap.ts
  - [ ] Subtask 1.2: Find all focusable elements within container
  - [ ] Subtask 1.3: Trap Tab key to cycle within container
  - [ ] Subtask 1.4: Handle Shift+Tab for reverse cycling
- [ ] Task 2: Create Modal component file structure (AC: 1)
  - [ ] Subtask 2.1: Create components/Modal/Modal.tsx
  - [ ] Subtask 2.2: Create sub-components
  - [ ] Subtask 2.3: Create components/Modal/Modal.module.css
- [ ] Task 3: Define ModalProps interface (AC: 6, 9)
- [ ] Task 4: Implement portal rendering (AC: 1)
  - [ ] Subtask 4.1: Use createPortal to render to document.body
- [ ] Task 5: Implement backdrop overlay (AC: 2, 6)
- [ ] Task 6: Add dialog ARIA attributes (AC: 3)
- [ ] Task 7: Integrate focus trap hook (AC: 4, 7)
  - [ ] Subtask 7.1: Save trigger element ref on open
  - [ ] Subtask 7.2: Focus first element in modal on open
  - [ ] Subtask 7.3: Restore focus to trigger on close
- [ ] Task 8: Implement Escape key handler (AC: 5)
- [ ] Task 9: Create compound sub-components (AC: 8)
- [ ] Task 10: Write unit tests (AC: 10)
  - [ ] Subtask 10.1: Test focus trap behavior
  - [ ] Subtask 10.2: Test Escape closes modal
  - [ ] Subtask 10.3: Test backdrop click
  - [ ] Subtask 10.4: Add axe accessibility test
- [ ] Task 11: Create Storybook stories

## Technical Notes

- Use ReactDOM.createPortal for portal rendering
- Focus trap: query all [tabindex], button, a, input, select, textarea
- Store document.activeElement before opening to restore on close
- Prevent body scroll when modal is open (overflow: hidden on body)

## Dependencies

- Requires: Story 2.1 (Button for close button)

---

## Story 3.3: Create Dropdown Menu

**Status:** draft
**Epic:** Composite Components
**Priority:** P1

## User Story

As a developer, I want a Dropdown menu component so that users can access actions from a trigger button.

## Acceptance Criteria

1. **AC-3.3.1:** Dropdown consists of Trigger and Menu compound components
2. **AC-3.3.2:** Menu opens on trigger click and closes on outside click
3. **AC-3.3.3:** Menu renders in a portal with smart positioning
4. **AC-3.3.4:** Arrow keys navigate between menu items
5. **AC-3.3.5:** Enter key activates focused menu item
6. **AC-3.3.6:** Escape key closes menu and returns focus to trigger
7. **AC-3.3.7:** Menu items support disabled state
8. **AC-3.3.8:** Dropdown.Item accepts onClick handler
9. **AC-3.3.9:** Menu has role="menu" and items have role="menuitem"
10. **AC-3.3.10:** Component passes accessibility tests

## Tasks

- [ ] Task 1: Create Dropdown component file structure (AC: 1)
  - [ ] Subtask 1.1: Create components/Dropdown/Dropdown.tsx
  - [ ] Subtask 1.2: Create components/Dropdown/DropdownTrigger.tsx
  - [ ] Subtask 1.3: Create components/Dropdown/DropdownMenu.tsx
  - [ ] Subtask 1.4: Create components/Dropdown/DropdownItem.tsx
  - [ ] Subtask 1.5: Create components/Dropdown/Dropdown.module.css
- [ ] Task 2: Create DropdownContext for state management (AC: 1)
  - [ ] Subtask 2.1: Track isOpen, activeIndex, triggerRef
- [ ] Task 3: Implement trigger with toggle behavior (AC: 2)
- [ ] Task 4: Implement menu with portal rendering (AC: 3)
  - [ ] Subtask 4.1: Position menu below trigger
  - [ ] Subtask 4.2: Flip to above if near viewport bottom
- [ ] Task 5: Implement keyboard navigation (AC: 4, 5, 6)
  - [ ] Subtask 5.1: Arrow Down moves to next item
  - [ ] Subtask 5.2: Arrow Up moves to previous item
  - [ ] Subtask 5.3: Enter activates item
  - [ ] Subtask 5.4: Escape closes and focuses trigger
- [ ] Task 6: Implement click outside detection (AC: 2)
- [ ] Task 7: Implement menu item with disabled support (AC: 7, 8)
- [ ] Task 8: Add ARIA roles and attributes (AC: 9)
- [ ] Task 9: Write unit tests (AC: 10)
  - [ ] Subtask 9.1: Test open/close behavior
  - [ ] Subtask 9.2: Test keyboard navigation
  - [ ] Subtask 9.3: Add axe accessibility test
- [ ] Task 10: Create Storybook stories

## Technical Notes

- Use context to coordinate trigger and menu state
- roving tabindex pattern for menu items (only active item is tabbable)
- aria-haspopup="menu" on trigger, aria-expanded for open state

## Dependencies

- Requires: Story 2.1 (Button for trigger)

---

## Story 3.4: Create Toast Notification System

**Status:** draft
**Epic:** Composite Components
**Priority:** P1

## User Story

As a developer, I want a Toast notification system so that I can display temporary messages to users.

## Acceptance Criteria

1. **AC-3.4.1:** ToastProvider wraps app and manages toast queue
2. **AC-3.4.2:** useToast hook provides toast() function to show notifications
3. **AC-3.4.3:** Toast supports variant prop: info, success, warning, error
4. **AC-3.4.4:** Toast auto-dismisses after configurable duration (default 5s)
5. **AC-3.4.5:** Toast can be manually dismissed via close button
6. **AC-3.4.6:** Multiple toasts stack vertically with animation
7. **AC-3.4.7:** Toast has role="alert" for screen reader announcements
8. **AC-3.4.8:** Toasts respect prefers-reduced-motion for animations
9. **AC-3.4.9:** ToastContainer positions toasts at screen corner (configurable)
10. **AC-3.4.10:** Component passes accessibility tests

## Tasks

- [ ] Task 1: Create Toast component file structure (AC: 1)
  - [ ] Subtask 1.1: Create components/Toast/Toast.tsx
  - [ ] Subtask 1.2: Create components/Toast/ToastProvider.tsx
  - [ ] Subtask 1.3: Create components/Toast/ToastContainer.tsx
  - [ ] Subtask 1.4: Create components/Toast/Toast.module.css
- [ ] Task 2: Create ToastContext with queue state (AC: 1, 2)
  - [ ] Subtask 2.1: Define Toast interface {id, message, variant, duration}
  - [ ] Subtask 2.2: Implement add/remove toast functions
- [ ] Task 3: Implement useToast hook (AC: 2)
  - [ ] Subtask 3.1: Return toast() function
  - [ ] Subtask 3.2: Support options: variant, duration
- [ ] Task 4: Implement Toast component (AC: 3, 5, 7)
  - [ ] Subtask 4.1: Style variants with appropriate icons/colors
  - [ ] Subtask 4.2: Add close button
  - [ ] Subtask 4.3: Add role="alert"
- [ ] Task 5: Implement auto-dismiss timer (AC: 4)
  - [ ] Subtask 5.1: Use setTimeout to remove toast
  - [ ] Subtask 5.2: Clear timer on manual dismiss
- [ ] Task 6: Implement ToastContainer with stacking (AC: 6, 9)
  - [ ] Subtask 6.1: Position fixed to screen corner
  - [ ] Subtask 6.2: Render toasts with gap
- [ ] Task 7: Add enter/exit animations (AC: 8)
  - [ ] Subtask 7.1: Slide in from right
  - [ ] Subtask 7.2: Respect reduced motion
- [ ] Task 8: Write unit tests (AC: 10)
  - [ ] Subtask 8.1: Test toast display
  - [ ] Subtask 8.2: Test auto-dismiss
  - [ ] Subtask 8.3: Add axe accessibility test
- [ ] Task 9: Create Storybook stories

## Technical Notes

- Use portal to render ToastContainer at body level
- Generate unique ID for each toast (useId or uuid)
- Consider pause-on-hover for toast timer

## Dependencies

- Requires: Story 2.1 (Button for close)

---

## Story 3.5: Create Tooltip Component

**Status:** draft
**Epic:** Composite Components
**Priority:** P1

## User Story

As a developer, I want a Tooltip component so that I can provide additional context on hover or focus.

## Acceptance Criteria

1. **AC-3.5.1:** Tooltip shows on hover and focus of trigger element
2. **AC-3.5.2:** Tooltip hides on mouse leave and blur
3. **AC-3.5.3:** Tooltip supports placement prop: top, bottom, left, right
4. **AC-3.5.4:** Tooltip repositions if it would overflow viewport
5. **AC-3.5.5:** Tooltip has delay before showing (configurable, default 200ms)
6. **AC-3.5.6:** Tooltip content passed via content prop or children
7. **AC-3.5.7:** Tooltip has role="tooltip" and trigger has aria-describedby
8. **AC-3.5.8:** Escape key hides tooltip
9. **AC-3.5.9:** Tooltip respects reduced motion preference
10. **AC-3.5.10:** Component passes accessibility tests

## Tasks

- [ ] Task 1: Create Tooltip component file structure (AC: 1)
  - [ ] Subtask 1.1: Create components/Tooltip/Tooltip.tsx
  - [ ] Subtask 1.2: Create components/Tooltip/Tooltip.module.css
- [ ] Task 2: Define TooltipProps interface (AC: 3, 5, 6)
- [ ] Task 3: Implement hover/focus listeners (AC: 1, 2)
  - [ ] Subtask 3.1: Add onMouseEnter/onMouseLeave to trigger
  - [ ] Subtask 3.2: Add onFocus/onBlur to trigger
- [ ] Task 4: Implement show delay with timer (AC: 5)
- [ ] Task 5: Implement tooltip positioning (AC: 3, 4)
  - [ ] Subtask 5.1: Calculate position based on placement prop
  - [ ] Subtask 5.2: Check viewport boundaries and flip if needed
- [ ] Task 6: Render tooltip in portal
- [ ] Task 7: Add ARIA attributes (AC: 7)
  - [ ] Subtask 7.1: Add role="tooltip"
  - [ ] Subtask 7.2: Connect with aria-describedby
- [ ] Task 8: Implement Escape to close (AC: 8)
- [ ] Task 9: Add animation with reduced motion support (AC: 9)
- [ ] Task 10: Write unit tests (AC: 10)
  - [ ] Subtask 10.1: Test show on hover
  - [ ] Subtask 10.2: Test hide on leave
  - [ ] Subtask 10.3: Add axe accessibility test
- [ ] Task 11: Create Storybook stories

## Technical Notes

- Clonе trigger element to attach event handlers
- Use getBoundingClientRect for positioning
- Generate unique ID for tooltip and aria-describedby connection

## Dependencies

- Requires: Story 1.1 (design tokens for styling)

---

## Story 3.6: Create Tabs Component

**Status:** draft
**Epic:** Composite Components
**Priority:** P1

## User Story

As a developer, I want a Tabs component so that I can organize content into selectable panels.

## Acceptance Criteria

1. **AC-3.6.1:** Tabs consists of TabList, Tab, and TabPanel compound components
2. **AC-3.6.2:** Clicking a Tab shows corresponding TabPanel
3. **AC-3.6.3:** Arrow keys navigate between tabs within TabList
4. **AC-3.6.4:** Enter/Space activates focused tab
5. **AC-3.6.5:** TabList has role="tablist"
6. **AC-3.6.6:** Tab has role="tab" with aria-selected and aria-controls
7. **AC-3.6.7:** TabPanel has role="tabpanel" with aria-labelledby
8. **AC-3.6.8:** Tabs supports controlled mode with value/onChange props
9. **AC-3.6.9:** Tabs supports defaultValue for uncontrolled mode
10. **AC-3.6.10:** Component passes accessibility tests

## Tasks

- [ ] Task 1: Create Tabs component file structure (AC: 1)
  - [ ] Subtask 1.1: Create components/Tabs/Tabs.tsx
  - [ ] Subtask 1.2: Create components/Tabs/TabList.tsx
  - [ ] Subtask 1.3: Create components/Tabs/Tab.tsx
  - [ ] Subtask 1.4: Create components/Tabs/TabPanel.tsx
  - [ ] Subtask 1.5: Create components/Tabs/Tabs.module.css
- [ ] Task 2: Create TabsContext for state (AC: 8, 9)
  - [ ] Subtask 2.1: Track activeValue, provide setActiveValue
  - [ ] Subtask 2.2: Support both controlled and uncontrolled modes
- [ ] Task 3: Implement Tabs root component (AC: 8, 9)
  - [ ] Subtask 3.1: Handle value/onChange (controlled)
  - [ ] Subtask 3.2: Handle defaultValue (uncontrolled) with internal state
- [ ] Task 4: Implement TabList (AC: 5)
  - [ ] Subtask 4.1: Add role="tablist"
  - [ ] Subtask 4.2: Handle keyboard navigation
- [ ] Task 5: Implement Tab component (AC: 2, 3, 4, 6)
  - [ ] Subtask 5.1: Add role="tab"
  - [ ] Subtask 5.2: Add aria-selected and aria-controls
  - [ ] Subtask 5.3: Handle click to activate
- [ ] Task 6: Implement TabPanel component (AC: 7)
  - [ ] Subtask 6.1: Add role="tabpanel"
  - [ ] Subtask 6.2: Add aria-labelledby
  - [ ] Subtask 6.3: Show/hide based on active tab
- [ ] Task 7: Style active tab indicator
- [ ] Task 8: Write unit tests (AC: 10)
  - [ ] Subtask 8.1: Test tab switching
  - [ ] Subtask 8.2: Test keyboard navigation
  - [ ] Subtask 8.3: Add axe accessibility test
- [ ] Task 9: Create Storybook stories

## Technical Notes

- Tab and TabPanel connected by matching value prop
- Generate IDs for ARIA connections (tab-1-tab, tab-1-panel)
- Only one panel visible at a time (others hidden but in DOM for a11y)

## Dependencies

- Requires: Story 1.1 (design tokens)
