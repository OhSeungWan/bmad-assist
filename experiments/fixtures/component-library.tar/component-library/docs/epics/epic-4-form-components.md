---
epic_num: 4
title: Form Components
status: draft
---

# Epic 4: Form Components

**Goal:** Provide form management components that integrate validation and error handling.

**Total Stories:** 5
**Dependencies:** Epic 2 (Primitive Components)

---

## Story 4.1: Create Form Wrapper Component

**Status:** draft
**Epic:** Form Components
**Priority:** P1

## User Story

As a developer, I want a Form component that handles submission so that I can build forms with consistent behavior.

## Acceptance Criteria

1. **AC-4.1.1:** Form renders as a native `<form>` element
2. **AC-4.1.2:** Form prevents default submission behavior
3. **AC-4.1.3:** Form calls onSubmit prop with form data on valid submission
4. **AC-4.1.4:** Form supports noValidate prop to disable browser validation
5. **AC-4.1.5:** Form provides FormContext with form state to children
6. **AC-4.1.6:** Form supports isSubmitting state that disables form controls
7. **AC-4.1.7:** Form accepts initialValues prop for controlled forms
8. **AC-4.1.8:** Form forwards ref to the form element
9. **AC-4.1.9:** Component passes accessibility tests

## Tasks

- [ ] Task 1: Create Form component file structure (AC: 1)
  - [ ] Subtask 1.1: Create components/Form/Form.tsx
  - [ ] Subtask 1.2: Create components/Form/FormContext.tsx
  - [ ] Subtask 1.3: Create components/Form/Form.module.css
  - [ ] Subtask 1.4: Create components/Form/index.ts
- [ ] Task 2: Define FormProps interface (AC: 3, 4, 6, 7)
  - [ ] Subtask 2.1: Add onSubmit, noValidate, isSubmitting, initialValues props
- [ ] Task 3: Create FormContext (AC: 5)
  - [ ] Subtask 3.1: Define FormContextValue with values, errors, isSubmitting
  - [ ] Subtask 3.2: Provide register function for field registration
- [ ] Task 4: Implement Form component (AC: 1, 2, 8)
  - [ ] Subtask 4.1: Handle form submit event
  - [ ] Subtask 4.2: Prevent default
  - [ ] Subtask 4.3: Call onSubmit with collected form data
- [ ] Task 5: Implement isSubmitting state (AC: 6)
  - [ ] Subtask 5.1: Pass isSubmitting via context
  - [ ] Subtask 5.2: Disable submit button when submitting
- [ ] Task 6: Support initialValues (AC: 7)
- [ ] Task 7: Write unit tests (AC: 9)
  - [ ] Subtask 7.1: Test submission handling
  - [ ] Subtask 7.2: Test isSubmitting state
  - [ ] Subtask 7.3: Add axe accessibility test
- [ ] Task 8: Create Storybook stories

## Technical Notes

- Use FormContext to provide form state to nested components
- Consider FormData API or custom state for collecting values
- isSubmitting should be async-compatible (set true, await onSubmit, set false)

## Dependencies

- Requires: Story 2.2 (Input), Story 2.6 (FormField)

---

## Story 4.2: Add Form Validation Integration

**Status:** draft
**Epic:** Form Components
**Priority:** P1

## User Story

As a developer, I want to validate form fields so that users receive feedback before submission.

## Acceptance Criteria

1. **AC-4.2.1:** Form supports validate prop as validation function
2. **AC-4.2.2:** Validation runs on submit, returning errors object
3. **AC-4.2.3:** Validation errors are accessible via FormContext
4. **AC-4.2.4:** Form does not call onSubmit if validation fails
5. **AC-4.2.5:** Individual fields can access their error via useFormField hook
6. **AC-4.2.6:** Form supports validateOnBlur prop for field-level validation
7. **AC-4.2.7:** Form supports validateOnChange prop for real-time validation
8. **AC-4.2.8:** Errors are keyed by field name (errors.fieldName format)
9. **AC-4.2.9:** Validation integrates with FormField to display errors

## Tasks

- [ ] Task 1: Extend FormProps with validation props (AC: 1, 6, 7)
  - [ ] Subtask 1.1: Add validate function prop
  - [ ] Subtask 1.2: Add validateOnBlur boolean
  - [ ] Subtask 1.3: Add validateOnChange boolean
- [ ] Task 2: Implement validation on submit (AC: 2, 4)
  - [ ] Subtask 2.1: Call validate function with form values
  - [ ] Subtask 2.2: Set errors state from validation result
  - [ ] Subtask 2.3: Only call onSubmit if errors object is empty
- [ ] Task 3: Store errors in FormContext (AC: 3, 8)
- [ ] Task 4: Create useFormField hook (AC: 5)
  - [ ] Subtask 4.1: Accept field name parameter
  - [ ] Subtask 4.2: Return value, error, onChange, onBlur
- [ ] Task 5: Implement validateOnBlur (AC: 6)
  - [ ] Subtask 5.1: Track touched fields
  - [ ] Subtask 5.2: Validate field on blur if touched
- [ ] Task 6: Implement validateOnChange (AC: 7)
  - [ ] Subtask 6.1: Validate on each value change
  - [ ] Subtask 6.2: Debounce validation for performance
- [ ] Task 7: Update FormField to consume errors from context (AC: 9)
- [ ] Task 8: Write unit tests
  - [ ] Subtask 8.1: Test validation blocks submission
  - [ ] Subtask 8.2: Test errors display in FormField
  - [ ] Subtask 8.3: Test validateOnBlur behavior
- [ ] Task 9: Update Storybook stories with validation examples

## Technical Notes

- validate(values) returns {fieldName: errorMessage} or empty object
- Consider integrating with popular validation libraries (yup, zod) in examples
- Debounce validateOnChange with 300ms delay

## Dependencies

- Requires: Story 4.1 (Form wrapper)

---

## Story 4.3: Create FormError Display Component

**Status:** draft
**Epic:** Form Components
**Priority:** P1

## User Story

As a developer, I want a FormError component so that I can display validation errors consistently.

## Acceptance Criteria

1. **AC-4.3.1:** FormError renders error message text with danger styling
2. **AC-4.3.2:** FormError accepts name prop to automatically get error from FormContext
3. **AC-4.3.3:** FormError accepts error prop for manual error display
4. **AC-4.3.4:** FormError renders nothing when no error present
5. **AC-4.3.5:** FormError has id for aria-describedby association
6. **AC-4.3.6:** FormError includes aria-live="polite" for screen reader announcements
7. **AC-4.3.7:** FormError supports custom className for styling overrides
8. **AC-4.3.8:** FormError animates in when error appears (respects reduced motion)

## Tasks

- [ ] Task 1: Create FormError component file structure (AC: 1)
  - [ ] Subtask 1.1: Create components/Form/FormError.tsx
  - [ ] Subtask 1.2: Add styles to Form.module.css
- [ ] Task 2: Define FormErrorProps interface (AC: 2, 3, 5, 7)
  - [ ] Subtask 2.1: Add name, error, id, className props
- [ ] Task 3: Implement error retrieval from context (AC: 2)
  - [ ] Subtask 3.1: Use FormContext to get error by name
- [ ] Task 4: Implement direct error prop (AC: 3)
- [ ] Task 5: Return null when no error (AC: 4)
- [ ] Task 6: Add id for aria-describedby (AC: 5)
  - [ ] Subtask 6.1: Generate id from name prop if not provided
- [ ] Task 7: Add aria-live attribute (AC: 6)
- [ ] Task 8: Add enter animation (AC: 8)
  - [ ] Subtask 8.1: Fade and slide in
  - [ ] Subtask 8.2: Disable for reduced motion
- [ ] Task 9: Write unit tests
  - [ ] Subtask 9.1: Test error display
  - [ ] Subtask 9.2: Test null render on no error
  - [ ] Subtask 9.3: Test aria attributes
- [ ] Task 10: Update Storybook stories

## Technical Notes

- aria-live="polite" announces error when it appears
- Consider icon (!) before error text for visual emphasis
- Error text color: var(--color-danger)

## Dependencies

- Requires: Story 4.1 (FormContext)

---

## Story 4.4: Add Async Validation Support

**Status:** draft
**Epic:** Form Components
**Priority:** P2

## User Story

As a developer, I want to perform async validation so that I can validate against server data (e.g., username availability).

## Acceptance Criteria

1. **AC-4.4.1:** Form validate function can return Promise<errors>
2. **AC-4.4.2:** Form shows loading state during async validation
3. **AC-4.4.3:** Field-level async validation is debounced
4. **AC-4.4.4:** Async validation errors are displayed same as sync errors
5. **AC-4.4.5:** Submit is blocked during async validation
6. **AC-4.4.6:** Async validation can be cancelled if new validation starts
7. **AC-4.4.7:** Individual fields support asyncValidate prop

## Tasks

- [ ] Task 1: Update Form to handle async validate (AC: 1)
  - [ ] Subtask 1.1: Await validate() result
  - [ ] Subtask 1.2: Handle rejected promise
- [ ] Task 2: Add validating state to FormContext (AC: 2)
  - [ ] Subtask 2.1: Set validating=true during async validation
  - [ ] Subtask 2.2: Pass to children via context
- [ ] Task 3: Block submit during validation (AC: 5)
- [ ] Task 4: Implement field-level asyncValidate (AC: 7)
  - [ ] Subtask 4.1: Accept asyncValidate prop on useFormField
  - [ ] Subtask 4.2: Debounce calls (500ms)
- [ ] Task 5: Implement validation cancellation (AC: 6)
  - [ ] Subtask 5.1: Use AbortController pattern
  - [ ] Subtask 5.2: Cancel previous validation on new input
- [ ] Task 6: Write unit tests
  - [ ] Subtask 6.1: Test async validation waits for result
  - [ ] Subtask 6.2: Test validation cancellation
  - [ ] Subtask 6.3: Test debouncing
- [ ] Task 7: Create Storybook story with username availability example

## Technical Notes

- Use AbortController for cancellable requests
- Debounce field-level async validation to avoid excessive API calls
- Consider showing loading indicator on field during async validation

## Dependencies

- Requires: Story 4.2 (validation integration)

---

## Story 4.5: Create Complete Form Example

**Status:** draft
**Epic:** Form Components
**Priority:** P1

## User Story

As a developer, I want a complete form example so that I can understand how to use all form components together.

## Acceptance Criteria

1. **AC-4.5.1:** Example includes all primitive form components (Input, Select, Checkbox, Radio)
2. **AC-4.5.2:** Example demonstrates FormField with labels and error display
3. **AC-4.5.3:** Example includes sync validation with error messages
4. **AC-4.5.4:** Example shows submit handling with loading state
5. **AC-4.5.5:** Example is documented in Storybook with code snippets
6. **AC-4.5.6:** Example demonstrates controlled form pattern
7. **AC-4.5.7:** Example includes a reset button that clears form

## Tasks

- [ ] Task 1: Create registration form example (AC: 1)
  - [ ] Subtask 1.1: Include email Input
  - [ ] Subtask 1.2: Include password Input
  - [ ] Subtask 1.3: Include country Select
  - [ ] Subtask 1.4: Include terms Checkbox
  - [ ] Subtask 1.5: Include plan RadioGroup
- [ ] Task 2: Wrap all fields in FormField (AC: 2)
  - [ ] Subtask 2.1: Add labels
  - [ ] Subtask 2.2: Add help text where appropriate
- [ ] Task 3: Implement validation function (AC: 3)
  - [ ] Subtask 3.1: Validate required fields
  - [ ] Subtask 3.2: Validate email format
  - [ ] Subtask 3.3: Validate password strength
- [ ] Task 4: Implement submit handler (AC: 4)
  - [ ] Subtask 4.1: Simulate async submission (setTimeout)
  - [ ] Subtask 4.2: Show loading state on button
  - [ ] Subtask 4.3: Show success message after submit
- [ ] Task 5: Add controlled form state (AC: 6)
- [ ] Task 6: Add reset button functionality (AC: 7)
- [ ] Task 7: Create comprehensive Storybook story (AC: 5)
  - [ ] Subtask 7.1: Add story description
  - [ ] Subtask 7.2: Show code example in docs
- [ ] Task 8: Add inline documentation comments

## Technical Notes

- This is a documentation/example story, not a reusable component
- Code should serve as a reference implementation
- Include common validation patterns as examples

## Dependencies

- Requires: Stories 4.1-4.4, Stories 2.1-2.6
