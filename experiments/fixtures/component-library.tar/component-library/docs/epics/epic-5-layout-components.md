---
epic_num: 5
title: Layout Components
status: draft
---

# Epic 5: Layout Components

**Goal:** Create layout primitives for consistent spacing and structure across applications.

**Total Stories:** 4
**Dependencies:** Epic 1 (Design System Foundation)

---

## Story 5.1: Create Stack Component

**Status:** draft
**Epic:** Layout Components
**Priority:** P1

## User Story

As a developer, I want a Stack component so that I can easily create vertical or horizontal layouts with consistent spacing.

## Acceptance Criteria

1. **AC-5.1.1:** Stack renders as a `<div>` element with flexbox layout
2. **AC-5.1.2:** Stack supports direction prop with values: vertical (default), horizontal
3. **AC-5.1.3:** Stack supports gap prop using spacing tokens (xs, sm, md, lg, xl)
4. **AC-5.1.4:** Stack supports align prop for cross-axis alignment (start, center, end, stretch)
5. **AC-5.1.5:** Stack supports justify prop for main-axis alignment (start, center, end, between, around)
6. **AC-5.1.6:** Stack supports wrap prop to enable flex-wrap
7. **AC-5.1.7:** Stack supports as prop for polymorphic element type
8. **AC-5.1.8:** Stack forwards ref to the underlying element
9. **AC-5.1.9:** Children maintain their natural sizing by default

## Tasks

- [ ] Task 1: Create Stack component file structure (AC: 1)
  - [ ] Subtask 1.1: Create components/Stack/Stack.tsx
  - [ ] Subtask 1.2: Create components/Stack/Stack.module.css
  - [ ] Subtask 1.3: Create components/Stack/index.ts
- [ ] Task 2: Define StackProps interface (AC: 2, 3, 4, 5, 6, 7)
  - [ ] Subtask 2.1: Add direction, gap, align, justify, wrap, as props
- [ ] Task 3: Implement polymorphic component (AC: 7, 8)
  - [ ] Subtask 3.1: Use generic type for as prop
  - [ ] Subtask 3.2: Merge props from polymorphic element type
- [ ] Task 4: Create CSS Module with flexbox styles (AC: 1)
- [ ] Task 5: Implement direction styles (AC: 2)
  - [ ] Subtask 5.1: .vertical: flex-direction: column
  - [ ] Subtask 5.2: .horizontal: flex-direction: row
- [ ] Task 6: Implement gap using CSS custom properties (AC: 3)
  - [ ] Subtask 6.1: Map gap prop to --spacing-* tokens
- [ ] Task 7: Implement align and justify styles (AC: 4, 5)
- [ ] Task 8: Implement wrap style (AC: 6)
- [ ] Task 9: Write unit tests
  - [ ] Subtask 9.1: Test direction rendering
  - [ ] Subtask 9.2: Test gap spacing
  - [ ] Subtask 9.3: Test polymorphic as prop
- [ ] Task 10: Create Storybook stories

## Technical Notes

- Use CSS gap property for spacing (no margin hacks)
- Polymorphic: `<Stack as="nav">` renders `<nav>` instead of `<div>`
- Consider Stack.Item sub-component for future individual item control

## Dependencies

- Requires: Story 1.1 (spacing tokens)

---

## Story 5.2: Create Flex Component with Gap Support

**Status:** draft
**Epic:** Layout Components
**Priority:** P1

## User Story

As a developer, I want a Flex component so that I can create flexible layouts with full flexbox control.

## Acceptance Criteria

1. **AC-5.2.1:** Flex renders as a `<div>` element with display: flex
2. **AC-5.2.2:** Flex supports all flexbox properties as props (direction, wrap, justify, align, gap)
3. **AC-5.2.3:** Flex supports inline prop for display: inline-flex
4. **AC-5.2.4:** Flex supports as prop for polymorphic element type
5. **AC-5.2.5:** Flex forwards ref to the underlying element
6. **AC-5.2.6:** Flex.Item component supports grow, shrink, basis, align-self props
7. **AC-5.2.7:** Gap prop maps to spacing tokens

## Tasks

- [ ] Task 1: Create Flex component file structure (AC: 1)
  - [ ] Subtask 1.1: Create components/Flex/Flex.tsx
  - [ ] Subtask 1.2: Create components/Flex/FlexItem.tsx
  - [ ] Subtask 1.3: Create components/Flex/Flex.module.css
  - [ ] Subtask 1.4: Create components/Flex/index.ts
- [ ] Task 2: Define FlexProps interface (AC: 2, 3, 4)
  - [ ] Subtask 2.1: Add direction, wrap, justify, alignItems, alignContent, gap, inline props
- [ ] Task 3: Define FlexItemProps interface (AC: 6)
  - [ ] Subtask 3.1: Add grow, shrink, basis, alignSelf props
- [ ] Task 4: Implement polymorphic Flex component (AC: 4, 5)
- [ ] Task 5: Create CSS Module styles (AC: 1, 2, 3)
  - [ ] Subtask 5.1: Base .flex with display: flex
  - [ ] Subtask 5.2: .inline with display: inline-flex
- [ ] Task 6: Map props to CSS using style attribute for flexibility (AC: 2)
- [ ] Task 7: Implement FlexItem component (AC: 6)
- [ ] Task 8: Map gap to spacing tokens (AC: 7)
- [ ] Task 9: Write unit tests
  - [ ] Subtask 9.1: Test flex properties apply correctly
  - [ ] Subtask 9.2: Test FlexItem props
- [ ] Task 10: Create Storybook stories

## Technical Notes

- Flex is lower-level than Stack, offers more control
- Use CSS custom properties or inline styles for dynamic props
- flex-grow, flex-shrink, flex-basis on FlexItem

## Dependencies

- Requires: Story 1.1 (spacing tokens)

---

## Story 5.3: Create Grid Component

**Status:** draft
**Epic:** Layout Components
**Priority:** P1

## User Story

As a developer, I want a Grid component so that I can create two-dimensional layouts easily.

## Acceptance Criteria

1. **AC-5.3.1:** Grid renders as a `<div>` element with display: grid
2. **AC-5.3.2:** Grid supports columns prop (number or string template)
3. **AC-5.3.3:** Grid supports rows prop (number or string template)
4. **AC-5.3.4:** Grid supports gap prop using spacing tokens
5. **AC-5.3.5:** Grid supports rowGap and columnGap for separate axis gaps
6. **AC-5.3.6:** Grid.Item component supports span, colStart, colEnd, rowStart, rowEnd props
7. **AC-5.3.7:** Grid supports as prop for polymorphic element type
8. **AC-5.3.8:** Grid forwards ref to the underlying element
9. **AC-5.3.9:** Grid supports responsive columns via breakpoint object

## Tasks

- [ ] Task 1: Create Grid component file structure (AC: 1)
  - [ ] Subtask 1.1: Create components/Grid/Grid.tsx
  - [ ] Subtask 1.2: Create components/Grid/GridItem.tsx
  - [ ] Subtask 1.3: Create components/Grid/Grid.module.css
  - [ ] Subtask 1.4: Create components/Grid/index.ts
- [ ] Task 2: Define GridProps interface (AC: 2, 3, 4, 5, 7, 9)
  - [ ] Subtask 2.1: columns: number | string
  - [ ] Subtask 2.2: rows: number | string
  - [ ] Subtask 2.3: gap, rowGap, columnGap
  - [ ] Subtask 2.4: as prop for polymorphic
- [ ] Task 3: Define GridItemProps interface (AC: 6)
  - [ ] Subtask 3.1: span, colStart, colEnd, rowStart, rowEnd
- [ ] Task 4: Implement Grid component (AC: 1, 8)
  - [ ] Subtask 4.1: Use inline styles for grid-template-columns/rows
- [ ] Task 5: Handle numeric columns (AC: 2)
  - [ ] Subtask 5.1: Convert number to repeat(n, 1fr)
- [ ] Task 6: Implement gap using spacing tokens (AC: 4, 5)
- [ ] Task 7: Implement GridItem component (AC: 6)
- [ ] Task 8: Implement responsive columns (AC: 9)
  - [ ] Subtask 8.1: Accept {base, sm, md, lg} object
  - [ ] Subtask 8.2: Generate CSS with media queries
- [ ] Task 9: Write unit tests
  - [ ] Subtask 9.1: Test grid generation
  - [ ] Subtask 9.2: Test GridItem positioning
- [ ] Task 10: Create Storybook stories

## Technical Notes

- columns={3} becomes grid-template-columns: repeat(3, 1fr)
- columns="1fr 2fr 1fr" passes through directly
- Responsive: use CSS custom properties or generate classes

## Dependencies

- Requires: Story 1.1 (spacing tokens)

---

## Story 5.4: Create Container Component with Max-Width

**Status:** draft
**Epic:** Layout Components
**Priority:** P1

## User Story

As a developer, I want a Container component so that I can center content with a maximum width.

## Acceptance Criteria

1. **AC-5.4.1:** Container renders as a `<div>` element
2. **AC-5.4.2:** Container is horizontally centered with margin: 0 auto
3. **AC-5.4.3:** Container supports size prop with values: sm (640px), md (768px), lg (1024px), xl (1280px), full
4. **AC-5.4.4:** Container supports padding prop for horizontal padding
5. **AC-5.4.5:** Container supports as prop for polymorphic element type
6. **AC-5.4.6:** Container forwards ref to the underlying element
7. **AC-5.4.7:** Container children take full width of container

## Tasks

- [ ] Task 1: Create Container component file structure (AC: 1)
  - [ ] Subtask 1.1: Create components/Container/Container.tsx
  - [ ] Subtask 1.2: Create components/Container/Container.module.css
  - [ ] Subtask 1.3: Create components/Container/index.ts
- [ ] Task 2: Define ContainerProps interface (AC: 3, 4, 5)
  - [ ] Subtask 2.1: Add size, padding, as props
- [ ] Task 3: Implement Container component (AC: 1, 6)
- [ ] Task 4: Create CSS Module styles (AC: 2)
  - [ ] Subtask 4.1: Base .container with margin: 0 auto, width: 100%
- [ ] Task 5: Implement size variants (AC: 3)
  - [ ] Subtask 5.1: .sm { max-width: 640px }
  - [ ] Subtask 5.2: .md { max-width: 768px }
  - [ ] Subtask 5.3: .lg { max-width: 1024px }
  - [ ] Subtask 5.4: .xl { max-width: 1280px }
  - [ ] Subtask 5.5: .full { max-width: none }
- [ ] Task 6: Implement padding using spacing tokens (AC: 4)
- [ ] Task 7: Implement polymorphic as prop (AC: 5)
- [ ] Task 8: Write unit tests
  - [ ] Subtask 8.1: Test max-width sizes
  - [ ] Subtask 8.2: Test centering
  - [ ] Subtask 8.3: Test polymorphic rendering
- [ ] Task 9: Create Storybook stories
  - [ ] Subtask 9.1: Show all sizes
  - [ ] Subtask 9.2: Show with content overflow

## Technical Notes

- Default size should be lg (1024px) for common use case
- Use box-sizing: border-box so padding doesn't affect max-width
- Consider responsive size changes based on viewport

## Dependencies

- Requires: Story 1.1 (spacing tokens)
