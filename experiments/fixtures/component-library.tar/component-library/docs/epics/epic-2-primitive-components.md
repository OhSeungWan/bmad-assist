---
epic_num: 2
title: Primitive Components
status: draft
---

# Epic 2: Primitive Components

**Goal:** Build the foundational interactive components that serve as building blocks for more complex UI.

**Total Stories:** 6
**Dependencies:** Epic 1 (Design System Foundation)

---

## Story 2.1: Create Button Component with Variants

**Status:** draft
**Epic:** Primitive Components
**Priority:** P0

## User Story

As a developer, I want a Button component with multiple variants so that I can use appropriate button styles for different actions.

## Acceptance Criteria

1. **AC-2.1.1:** Button renders as a native `<button>` element with type="button" by default
2. **AC-2.1.2:** Button supports variant prop with values: primary, secondary, ghost, danger
3. **AC-2.1.3:** Button supports size prop with values: sm, md (default), lg
4. **AC-2.1.4:** Button supports isLoading prop that shows spinner and disables interaction
5. **AC-2.1.5:** Button supports leftIcon and rightIcon props for icon placement
6. **AC-2.1.6:** Button forwards ref to the underlying button element
7. **AC-2.1.7:** Button applies focus-visible ring on keyboard focus
8. **AC-2.1.8:** Disabled button has 50% opacity and cursor not-allowed
9. **AC-2.1.9:** Button passes accessibility tests (no axe violations)

## Tasks

- [ ] Task 1: Create Button component file structure (AC: 1)
  - [ ] Subtask 1.1: Create components/Button/Button.tsx
  - [ ] Subtask 1.2: Create components/Button/Button.module.css
  - [ ] Subtask 1.3: Create components/Button/index.ts
- [ ] Task 2: Define ButtonProps interface (AC: 2, 3, 4, 5)
  - [ ] Subtask 2.1: Extend React.ButtonHTMLAttributes
  - [ ] Subtask 2.2: Add variant, size, isLoading, leftIcon, rightIcon props
- [ ] Task 3: Implement Button component with forwardRef (AC: 1, 6)
- [ ] Task 4: Create CSS Module styles for variants (AC: 2)
  - [ ] Subtask 4.1: Style .primary with primary colors
  - [ ] Subtask 4.2: Style .secondary with surface/border colors
  - [ ] Subtask 4.3: Style .ghost with transparent background
  - [ ] Subtask 4.4: Style .danger with danger colors
- [ ] Task 5: Create CSS Module styles for sizes (AC: 3)
- [ ] Task 6: Implement loading state with spinner (AC: 4)
- [ ] Task 7: Add icon support with gap spacing (AC: 5)
- [ ] Task 8: Add focus-visible and disabled styles (AC: 7, 8)
- [ ] Task 9: Write unit tests (AC: 9)
  - [ ] Subtask 9.1: Test rendering with variants
  - [ ] Subtask 9.2: Test click handling
  - [ ] Subtask 9.3: Test disabled state
  - [ ] Subtask 9.4: Test loading state
  - [ ] Subtask 9.5: Add axe accessibility test
- [ ] Task 10: Create Storybook stories for all variants

## Technical Notes

- Use cn() utility for composing CSS classes
- Spinner should be inline SVG or separate component
- Button must be keyboard accessible (Enter and Space activate)

## Dependencies

- Requires: Story 1.1 (design tokens), Story 1.4 (CSS reset)

---

## Story 2.2: Create Input Component with States

**Status:** draft
**Epic:** Primitive Components
**Priority:** P0

## User Story

As a developer, I want an Input component with validation states so that I can build forms with clear visual feedback.

## Acceptance Criteria

1. **AC-2.2.1:** Input renders as a native `<input>` element
2. **AC-2.2.2:** Input supports type prop with common values (text, password, email, number)
3. **AC-2.2.3:** Input supports hasError prop that applies error styling (red border, red background)
4. **AC-2.2.4:** Input supports isSuccess prop that applies success styling (green border)
5. **AC-2.2.5:** Input supports size prop with values: sm, md (default), lg
6. **AC-2.2.6:** Input supports leftElement and rightElement props for icons/addons
7. **AC-2.2.7:** Input forwards ref to the underlying input element
8. **AC-2.2.8:** Input supports aria-describedby for error/help text association
9. **AC-2.2.9:** Disabled input has muted styling and cursor not-allowed
10. **AC-2.2.10:** Input passes accessibility tests

## Tasks

- [ ] Task 1: Create Input component file structure (AC: 1)
  - [ ] Subtask 1.1: Create components/Input/Input.tsx
  - [ ] Subtask 1.2: Create components/Input/Input.module.css
  - [ ] Subtask 1.3: Create components/Input/index.ts
- [ ] Task 2: Define InputProps interface (AC: 2, 3, 4, 5, 6, 8)
  - [ ] Subtask 2.1: Extend React.InputHTMLAttributes
  - [ ] Subtask 2.2: Add hasError, isSuccess, size, leftElement, rightElement props
- [ ] Task 3: Implement Input component with forwardRef (AC: 1, 7)
- [ ] Task 4: Create wrapper for element positioning (AC: 6)
- [ ] Task 5: Create CSS Module styles for states (AC: 3, 4)
  - [ ] Subtask 5.1: Style .error with danger border and background
  - [ ] Subtask 5.2: Style .success with success border
- [ ] Task 6: Create CSS Module styles for sizes (AC: 5)
- [ ] Task 7: Add disabled styles (AC: 9)
- [ ] Task 8: Add focus-visible styles
- [ ] Task 9: Write unit tests (AC: 10)
  - [ ] Subtask 9.1: Test value changes
  - [ ] Subtask 9.2: Test error state styling
  - [ ] Subtask 9.3: Test disabled state
  - [ ] Subtask 9.4: Add axe accessibility test
- [ ] Task 10: Create Storybook stories for all states

## Technical Notes

- Wrapper div needed for positioning left/right elements
- Use aria-invalid="true" when hasError is true
- Password inputs should support toggle visibility (optional enhancement)

## Dependencies

- Requires: Story 1.1 (design tokens), Story 1.4 (CSS reset)

---

## Story 2.3: Create Select Component with Keyboard Navigation

**Status:** draft
**Epic:** Primitive Components
**Priority:** P0

## User Story

As a developer, I want a Select component with keyboard navigation so that users can choose from options accessibly.

## Acceptance Criteria

1. **AC-2.3.1:** Select renders as a native `<select>` element with custom styling
2. **AC-2.3.2:** Select accepts options prop as array of {value, label} objects
3. **AC-2.3.3:** Select supports placeholder prop for empty state
4. **AC-2.3.4:** Select supports hasError prop matching Input error styling
5. **AC-2.3.5:** Select supports size prop matching Input sizes
6. **AC-2.3.6:** Arrow keys navigate between options
7. **AC-2.3.7:** Enter key selects the focused option
8. **AC-2.3.8:** Select forwards ref to the underlying select element
9. **AC-2.3.9:** Disabled state applies muted styling
10. **AC-2.3.10:** Select passes accessibility tests

## Tasks

- [ ] Task 1: Create Select component file structure (AC: 1)
  - [ ] Subtask 1.1: Create components/Select/Select.tsx
  - [ ] Subtask 1.2: Create components/Select/Select.module.css
  - [ ] Subtask 1.3: Create components/Select/index.ts
- [ ] Task 2: Define SelectProps interface (AC: 2, 3, 4, 5)
  - [ ] Subtask 2.1: Define Option type {value: string, label: string}
  - [ ] Subtask 2.2: Add options, placeholder, hasError, size props
- [ ] Task 3: Implement Select component with forwardRef (AC: 1, 8)
- [ ] Task 4: Map options to option elements (AC: 2)
- [ ] Task 5: Implement placeholder as disabled first option (AC: 3)
- [ ] Task 6: Style select to match Input component (AC: 4, 5)
  - [ ] Subtask 6.1: Match border, padding, sizing
  - [ ] Subtask 6.2: Add custom dropdown arrow icon
- [ ] Task 7: Verify native keyboard navigation works (AC: 6, 7)
- [ ] Task 8: Add disabled styles (AC: 9)
- [ ] Task 9: Write unit tests (AC: 10)
  - [ ] Subtask 9.1: Test option selection
  - [ ] Subtask 9.2: Test keyboard navigation
  - [ ] Subtask 9.3: Add axe accessibility test
- [ ] Task 10: Create Storybook stories

## Technical Notes

- Native select provides built-in keyboard navigation
- Custom styling requires appearance: none and custom arrow
- Placeholder option should have disabled attribute and empty value

## Dependencies

- Requires: Story 2.2 (Input component for consistent styling)

---

## Story 2.4: Create Checkbox Component

**Status:** draft
**Epic:** Primitive Components
**Priority:** P0

## User Story

As a developer, I want a Checkbox component so that users can toggle binary options with visual feedback.

## Acceptance Criteria

1. **AC-2.4.1:** Checkbox renders as a native `<input type="checkbox">` with custom styling
2. **AC-2.4.2:** Checkbox displays checkmark icon when checked
3. **AC-2.4.3:** Checkbox supports indeterminate state visually
4. **AC-2.4.4:** Checkbox supports label prop or children for label text
5. **AC-2.4.5:** Clicking label toggles checkbox state
6. **AC-2.4.6:** Checkbox supports hasError prop for error styling
7. **AC-2.4.7:** Space key toggles checkbox when focused
8. **AC-2.4.8:** Checkbox forwards ref to the input element
9. **AC-2.4.9:** Disabled checkbox has muted styling
10. **AC-2.4.10:** Checkbox passes accessibility tests

## Tasks

- [ ] Task 1: Create Checkbox component file structure (AC: 1)
  - [ ] Subtask 1.1: Create components/Checkbox/Checkbox.tsx
  - [ ] Subtask 1.2: Create components/Checkbox/Checkbox.module.css
  - [ ] Subtask 1.3: Create components/Checkbox/index.ts
- [ ] Task 2: Define CheckboxProps interface (AC: 4, 6)
  - [ ] Subtask 2.1: Extend React.InputHTMLAttributes<HTMLInputElement>
  - [ ] Subtask 2.2: Add label, hasError props
- [ ] Task 3: Implement Checkbox with hidden native input (AC: 1, 8)
  - [ ] Subtask 3.1: Create wrapper with label element
  - [ ] Subtask 3.2: Hide native checkbox visually but keep accessible
  - [ ] Subtask 3.3: Create custom checkbox visual indicator
- [ ] Task 4: Add checkmark icon for checked state (AC: 2)
- [ ] Task 5: Implement indeterminate visual state (AC: 3)
- [ ] Task 6: Ensure label click toggles checkbox (AC: 5)
- [ ] Task 7: Style error and disabled states (AC: 6, 9)
- [ ] Task 8: Add focus-visible ring on custom indicator
- [ ] Task 9: Write unit tests (AC: 7, 10)
  - [ ] Subtask 9.1: Test checked/unchecked states
  - [ ] Subtask 9.2: Test keyboard toggle
  - [ ] Subtask 9.3: Test label click
  - [ ] Subtask 9.4: Add axe accessibility test
- [ ] Task 10: Create Storybook stories

## Technical Notes

- Use visually-hidden class for native input (sr-only pattern)
- Custom checkbox should use ::before/::after for check icon
- Indeterminate state set via ref.current.indeterminate = true

## Dependencies

- Requires: Story 1.1 (design tokens)

---

## Story 2.5: Create Radio and RadioGroup Components

**Status:** draft
**Epic:** Primitive Components
**Priority:** P0

## User Story

As a developer, I want Radio and RadioGroup components so that users can select one option from a group.

## Acceptance Criteria

1. **AC-2.5.1:** Radio renders as a native `<input type="radio">` with custom styling
2. **AC-2.5.2:** Radio displays filled circle when selected
3. **AC-2.5.3:** RadioGroup manages selected value state and provides context
4. **AC-2.5.4:** RadioGroup supports name prop applied to all child radios
5. **AC-2.5.5:** RadioGroup supports value and onChange for controlled usage
6. **AC-2.5.6:** Arrow keys navigate between radios within a group
7. **AC-2.5.7:** Radio supports label prop or children for label text
8. **AC-2.5.8:** Radio forwards ref to the input element
9. **AC-2.5.9:** RadioGroup supports orientation prop (vertical/horizontal)
10. **AC-2.5.10:** Components pass accessibility tests with proper role="radiogroup"

## Tasks

- [ ] Task 1: Create Radio component file structure (AC: 1)
  - [ ] Subtask 1.1: Create components/Radio/Radio.tsx
  - [ ] Subtask 1.2: Create components/Radio/RadioGroup.tsx
  - [ ] Subtask 1.3: Create components/Radio/Radio.module.css
  - [ ] Subtask 1.4: Create components/Radio/index.ts
- [ ] Task 2: Define RadioProps and RadioGroupProps interfaces (AC: 4, 5, 7, 9)
- [ ] Task 3: Create RadioGroupContext for state management (AC: 3)
- [ ] Task 4: Implement Radio with hidden native input (AC: 1, 8)
  - [ ] Subtask 4.1: Use similar pattern to Checkbox
  - [ ] Subtask 4.2: Create circular custom indicator
- [ ] Task 5: Add selected circle indicator (AC: 2)
- [ ] Task 6: Implement RadioGroup wrapper (AC: 3, 4, 9)
  - [ ] Subtask 6.1: Add role="radiogroup"
  - [ ] Subtask 6.2: Apply name to children via context
- [ ] Task 7: Verify native arrow key navigation (AC: 6)
- [ ] Task 8: Style vertical and horizontal orientations (AC: 9)
- [ ] Task 9: Write unit tests (AC: 10)
  - [ ] Subtask 9.1: Test selection within group
  - [ ] Subtask 9.2: Test keyboard navigation
  - [ ] Subtask 9.3: Add axe accessibility test for radiogroup
- [ ] Task 10: Create Storybook stories

## Technical Notes

- Native radio groups with same name attribute get arrow key navigation
- RadioGroup should set aria-label or aria-labelledby
- Use context to pass name and onChange to child Radio components

## Dependencies

- Requires: Story 2.4 (Checkbox pattern for custom styling)

---

## Story 2.6: Create Label and FormField Wrapper

**Status:** draft
**Epic:** Primitive Components
**Priority:** P0

## User Story

As a developer, I want Label and FormField components so that I can build accessible, consistently styled forms.

## Acceptance Criteria

1. **AC-2.6.1:** Label renders as a native `<label>` element
2. **AC-2.6.2:** Label supports required prop that shows asterisk indicator
3. **AC-2.6.3:** Label supports htmlFor prop for input association
4. **AC-2.6.4:** FormField wraps label, input, and help/error text with consistent spacing
5. **AC-2.6.5:** FormField auto-generates id for input and connects label via htmlFor
6. **AC-2.6.6:** FormField supports error prop that displays error message below input
7. **AC-2.6.7:** FormField supports helpText prop for descriptions
8. **AC-2.6.8:** Error message has aria-live="polite" for screen reader announcements
9. **AC-2.6.9:** Components pass accessibility tests

## Tasks

- [ ] Task 1: Create Label component (AC: 1, 2, 3)
  - [ ] Subtask 1.1: Create components/Label/Label.tsx
  - [ ] Subtask 1.2: Create components/Label/Label.module.css
  - [ ] Subtask 1.3: Add required asterisk styling
- [ ] Task 2: Create FormField component structure (AC: 4)
  - [ ] Subtask 2.1: Create components/FormField/FormField.tsx
  - [ ] Subtask 2.2: Create components/FormField/FormField.module.css
- [ ] Task 3: Define FormFieldProps interface (AC: 5, 6, 7)
  - [ ] Subtask 3.1: Add label, error, helpText, required props
  - [ ] Subtask 3.2: Accept children (the form control)
- [ ] Task 4: Implement auto-generated id with useId hook (AC: 5)
- [ ] Task 5: Clone child element to inject id and aria-describedby (AC: 5)
- [ ] Task 6: Implement error message display (AC: 6, 8)
  - [ ] Subtask 6.1: Style error text with danger color
  - [ ] Subtask 6.2: Add aria-live="polite"
- [ ] Task 7: Implement help text display (AC: 7)
- [ ] Task 8: Write unit tests (AC: 9)
  - [ ] Subtask 8.1: Test label-input association
  - [ ] Subtask 8.2: Test error message display
  - [ ] Subtask 8.3: Add axe accessibility test
- [ ] Task 9: Create Storybook stories showing FormField with various inputs

## Technical Notes

- Use React.cloneElement to inject props into child input
- useId hook (React 18) for generating unique IDs
- Error message id should be passed via aria-describedby

## Dependencies

- Requires: Story 2.2 (Input component for demonstration)
