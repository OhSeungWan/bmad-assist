---
epic_num: 6
title: Documentation & Polish
status: draft
---

# Epic 6: Documentation & Polish

**Goal:** Set up comprehensive documentation and prepare the library for distribution.

**Total Stories:** 3
**Dependencies:** All previous epics

---

## Story 6.1: Set Up Storybook with All Stories

**Status:** draft
**Epic:** Documentation & Polish
**Priority:** P0

## User Story

As a developer, I want Storybook configured with all component stories so that I can explore and test components in isolation.

## Acceptance Criteria

1. **AC-6.1.1:** Storybook 7+ is installed and configured with React and TypeScript
2. **AC-6.1.2:** All components have at least one story file
3. **AC-6.1.3:** Stories are organized by category (Design System, Primitives, Composite, Form, Layout)
4. **AC-6.1.4:** Each component story includes:
   - Default story with basic usage
   - Variants story showing all options
   - Interactive story with controls
5. **AC-6.1.5:** Storybook includes addon-docs for documentation
6. **AC-6.1.6:** Storybook includes addon-a11y for accessibility testing
7. **AC-6.1.7:** Storybook theme matches component library design tokens
8. **AC-6.1.8:** Storybook builds successfully for static deployment

## Tasks

- [ ] Task 1: Install Storybook dependencies (AC: 1)
  - [ ] Subtask 1.1: Install @storybook/react-vite
  - [ ] Subtask 1.2: Install @storybook/addon-essentials
  - [ ] Subtask 1.3: Install @storybook/addon-a11y
  - [ ] Subtask 1.4: Install @storybook/addon-interactions
- [ ] Task 2: Configure Storybook (AC: 1)
  - [ ] Subtask 2.1: Create .storybook/main.ts
  - [ ] Subtask 2.2: Create .storybook/preview.ts
  - [ ] Subtask 2.3: Import design tokens in preview
- [ ] Task 3: Organize stories by category (AC: 3)
  - [ ] Subtask 3.1: Design System/Tokens
  - [ ] Subtask 3.2: Primitives/Button, Input, etc.
  - [ ] Subtask 3.3: Composite/Modal, Dropdown, etc.
  - [ ] Subtask 3.4: Form/Form, FormField, etc.
  - [ ] Subtask 3.5: Layout/Stack, Grid, etc.
- [ ] Task 4: Verify all component stories exist (AC: 2)
  - [ ] Subtask 4.1: Audit each component for .stories.tsx file
  - [ ] Subtask 4.2: Create missing stories
- [ ] Task 5: Enhance stories with controls and docs (AC: 4, 5)
  - [ ] Subtask 5.1: Add argTypes for all props
  - [ ] Subtask 5.2: Add JSDoc comments for autodocs
- [ ] Task 6: Configure addon-a11y (AC: 6)
  - [ ] Subtask 6.1: Enable a11y panel
  - [ ] Subtask 6.2: Add a11y rules to stories
- [ ] Task 7: Customize Storybook theme (AC: 7)
  - [ ] Subtask 7.1: Create custom theme matching tokens
  - [ ] Subtask 7.2: Update preview.ts with theme
- [ ] Task 8: Test static build (AC: 8)
  - [ ] Subtask 8.1: Run storybook build
  - [ ] Subtask 8.2: Verify all stories render

## Technical Notes

- Use Storybook 7 with Vite builder for fast HMR
- Autodocs generates documentation from TypeScript types
- Deploy static build to GitHub Pages or similar

## Dependencies

- Requires: All component stories from previous epics

---

## Story 6.2: Add Accessibility Documentation

**Status:** draft
**Epic:** Documentation & Polish
**Priority:** P0

## User Story

As a developer, I want accessibility documentation so that I understand how to use components in an accessible way.

## Acceptance Criteria

1. **AC-6.2.1:** Accessibility documentation page exists in Storybook
2. **AC-6.2.2:** Document explains WCAG 2.1 AA compliance approach
3. **AC-6.2.3:** Each component has accessibility notes in its story
4. **AC-6.2.4:** Keyboard navigation patterns are documented per component
5. **AC-6.2.5:** ARIA usage is explained with examples
6. **AC-6.2.6:** Color contrast information is provided
7. **AC-6.2.7:** Focus management patterns are documented (Modal, Dropdown)
8. **AC-6.2.8:** Screen reader testing recommendations are included

## Tasks

- [ ] Task 1: Create accessibility overview page (AC: 1, 2)
  - [ ] Subtask 1.1: Create docs/accessibility.mdx
  - [ ] Subtask 1.2: Explain WCAG 2.1 AA goals
  - [ ] Subtask 1.3: List testing tools used
- [ ] Task 2: Document keyboard patterns (AC: 4)
  - [ ] Subtask 2.1: Table of keyboard shortcuts per component
  - [ ] Subtask 2.2: Explain Tab, Enter, Escape, Arrow patterns
- [ ] Task 3: Document ARIA usage (AC: 5)
  - [ ] Subtask 3.1: List ARIA roles used (button, dialog, menu, etc.)
  - [ ] Subtask 3.2: Explain aria-label, aria-describedby usage
  - [ ] Subtask 3.3: Provide code examples
- [ ] Task 4: Document color contrast (AC: 6)
  - [ ] Subtask 4.1: List contrast ratios for text colors
  - [ ] Subtask 4.2: Explain how to maintain contrast with theming
- [ ] Task 5: Document focus management (AC: 7)
  - [ ] Subtask 5.1: Explain focus trap in Modal
  - [ ] Subtask 5.2: Explain focus restoration after close
- [ ] Task 6: Add screen reader notes (AC: 8)
  - [ ] Subtask 6.1: Recommend testing with NVDA, VoiceOver
  - [ ] Subtask 6.2: List known screen reader behaviors
- [ ] Task 7: Add accessibility notes to each component story (AC: 3)
  - [ ] Subtask 7.1: Update story meta with a11y notes
  - [ ] Subtask 7.2: Link to relevant ARIA patterns

## Technical Notes

- Use MDX for rich documentation in Storybook
- Reference WAI-ARIA Authoring Practices for patterns
- Include links to external resources (WebAIM, ARIA specs)

## Dependencies

- Requires: Story 6.1 (Storybook setup)

---

## Story 6.3: Create Package Build and Exports

**Status:** draft
**Epic:** Documentation & Polish
**Priority:** P0

## User Story

As a developer, I want the library properly built and exported so that I can install and use it in my projects.

## Acceptance Criteria

1. **AC-6.3.1:** Vite library mode builds ES modules and CommonJS outputs
2. **AC-6.3.2:** TypeScript declaration files (.d.ts) are generated
3. **AC-6.3.3:** CSS is bundled into a single styles.css file
4. **AC-6.3.4:** Package.json exports field is correctly configured
5. **AC-6.3.5:** Package has correct peerDependencies (react, react-dom)
6. **AC-6.3.6:** Build output is < 50KB gzipped (core components)
7. **AC-6.3.7:** Tree-shaking works correctly (unused components are excluded)
8. **AC-6.3.8:** Package can be installed and imported successfully

## Tasks

- [ ] Task 1: Configure Vite library build (AC: 1)
  - [ ] Subtask 1.1: Update vite.config.ts with lib settings
  - [ ] Subtask 1.2: Set entry point to src/index.ts
  - [ ] Subtask 1.3: Configure output formats (es, cjs)
  - [ ] Subtask 1.4: Externalize react, react-dom
- [ ] Task 2: Configure TypeScript declarations (AC: 2)
  - [ ] Subtask 2.1: Update tsconfig.json with declaration: true
  - [ ] Subtask 2.2: Generate .d.ts files to dist/
- [ ] Task 3: Bundle CSS (AC: 3)
  - [ ] Subtask 3.1: Configure Vite to extract CSS
  - [ ] Subtask 3.2: Output to dist/styles.css
- [ ] Task 4: Configure package.json exports (AC: 4)
  - [ ] Subtask 4.1: Add "exports" field for module resolution
  - [ ] Subtask 4.2: Add "types" field for TypeScript
  - [ ] Subtask 4.3: Add "./styles" export for CSS
- [ ] Task 5: Set peerDependencies (AC: 5)
  - [ ] Subtask 5.1: react: ^18.0.0
  - [ ] Subtask 5.2: react-dom: ^18.0.0
- [ ] Task 6: Verify bundle size (AC: 6)
  - [ ] Subtask 6.1: Run build and check dist size
  - [ ] Subtask 6.2: Measure gzipped size
  - [ ] Subtask 6.3: Optimize if over 50KB
- [ ] Task 7: Test tree-shaking (AC: 7)
  - [ ] Subtask 7.1: Create test project importing single component
  - [ ] Subtask 7.2: Verify only that component is bundled
- [ ] Task 8: Test package installation (AC: 8)
  - [ ] Subtask 8.1: Pack package with npm pack
  - [ ] Subtask 8.2: Install in test project
  - [ ] Subtask 8.3: Verify imports work

## Technical Notes

- Use vite-plugin-dts for TypeScript declaration generation
- rollupOptions.external to exclude peer dependencies
- exports field with proper "import", "require", "types" conditions

```json
{
  "exports": {
    ".": {
      "import": "./dist/index.es.js",
      "require": "./dist/index.cjs.js",
      "types": "./dist/index.d.ts"
    },
    "./styles": "./dist/styles.css"
  }
}
```

## Dependencies

- Requires: All components completed and tested
