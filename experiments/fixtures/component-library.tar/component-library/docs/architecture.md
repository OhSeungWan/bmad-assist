# Technical Architecture: UI Component Library

## 1. Overview

The UI Component Library is a React-based component library built with TypeScript, designed for accessibility-first development. It uses CSS Modules for zero-runtime styling, compound component patterns for composability, and provides a comprehensive design token system for theming.

### Architecture Principles

1. **Zero Runtime Styling**: CSS Modules compile to static CSS, eliminating runtime overhead
2. **Composition over Configuration**: Compound components (Card.Header, Modal.Body) enable flexible composition
3. **Accessibility by Default**: Components implement ARIA patterns out of the box
4. **Type Safety**: Full TypeScript coverage with strict mode enabled
5. **Headless Patterns**: Complex components expose render props for maximum flexibility

## 2. Tech Stack

| Category | Technology | Version | Purpose |
|----------|------------|---------|---------|
| Language | TypeScript | 5.0+ | Type-safe development |
| Framework | React | 18+ | Component library foundation |
| Styling | CSS Modules | - | Scoped, zero-runtime styles |
| Styling | CSS Custom Properties | - | Design token implementation |
| Documentation | Storybook | 7+ | Component documentation and playground |
| Testing | Vitest | - | Unit and integration testing |
| Testing | React Testing Library | - | Component testing utilities |
| Build | Vite | - | Library mode bundling |
| Linting | ESLint | - | Code quality |
| Formatting | Prettier | - | Code formatting |

## 3. Component Architecture

### 3.1 Component Structure

Each component follows a consistent file structure:

```
src/components/Button/
├── Button.tsx           # Main component implementation
├── Button.module.css    # Scoped styles
├── Button.test.tsx      # Unit tests
├── Button.stories.tsx   # Storybook stories
└── index.ts             # Public exports
```

### 3.2 Component Patterns

#### Primitive Components
Simple, single-purpose components that serve as building blocks:
- Button, Input, Select, Checkbox, Radio, Label

```typescript
// Example: Button with forwardRef
export const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  ({ variant = 'primary', size = 'md', children, ...props }, ref) => {
    return (
      <button
        ref={ref}
        className={clsx(styles.button, styles[variant], styles[size])}
        {...props}
      >
        {children}
      </button>
    );
  }
);
```

#### Compound Components
Components with sub-components for composition:
- Card (Card.Header, Card.Body, Card.Footer)
- Modal (Modal.Header, Modal.Body, Modal.Footer)
- Tabs (Tabs.List, Tabs.Tab, Tabs.Panel)

```typescript
// Example: Card compound component
const Card = Object.assign(CardRoot, {
  Header: CardHeader,
  Body: CardBody,
  Footer: CardFooter,
});
```

#### Headless Components
Components that expose render props for full customization:
- Modal (focus trap logic)
- Dropdown (keyboard navigation logic)

### 3.3 Props Interfaces

All components follow consistent prop naming:

```typescript
interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: 'primary' | 'secondary' | 'ghost' | 'danger';
  size?: 'sm' | 'md' | 'lg';
  isLoading?: boolean;
  leftIcon?: React.ReactNode;
  rightIcon?: React.ReactNode;
}
```

## 4. Design Tokens

### 4.1 Token Categories

Design tokens are implemented as CSS Custom Properties:

```css
/* Colors */
--color-primary: #2563eb;
--color-secondary: #64748b;
--color-success: #22c55e;
--color-warning: #f59e0b;
--color-danger: #ef4444;
--color-background: #ffffff;
--color-surface: #f8fafc;
--color-text: #1e293b;
--color-text-muted: #64748b;

/* Spacing */
--spacing-xs: 0.25rem;
--spacing-sm: 0.5rem;
--spacing-md: 1rem;
--spacing-lg: 1.5rem;
--spacing-xl: 2rem;

/* Typography */
--font-sans: system-ui, sans-serif;
--font-mono: ui-monospace, monospace;
--font-size-sm: 0.875rem;
--font-size-base: 1rem;
--font-size-lg: 1.125rem;

/* Radii */
--radius-sm: 0.25rem;
--radius-md: 0.375rem;
--radius-lg: 0.5rem;

/* Shadows */
--shadow-sm: 0 1px 2px rgb(0 0 0 / 5%);
--shadow-md: 0 4px 6px rgb(0 0 0 / 10%);
```

### 4.2 Theme Provider

Themes are implemented via CSS custom property overrides:

```typescript
interface Theme {
  colors: ColorTokens;
  spacing: SpacingTokens;
  typography: TypographyTokens;
}

const ThemeContext = createContext<ThemeContextValue>(defaultTheme);

export function ThemeProvider({ theme, children }: ThemeProviderProps) {
  return (
    <ThemeContext.Provider value={theme}>
      <div style={themeToCSS(theme)}>{children}</div>
    </ThemeContext.Provider>
  );
}
```

## 5. Architectural Decision Records

### ADR-001: CSS Modules over styled-components

**Status:** Accepted

**Context:**
We need a styling solution that provides scoped styles without runtime overhead. Options considered: styled-components, Emotion, CSS Modules, Tailwind CSS.

**Decision:**
Use CSS Modules with CSS Custom Properties for theming.

**Consequences:**
- (+) Zero runtime overhead - styles compile to static CSS
- (+) Native CSS features (custom properties, media queries, container queries)
- (+) Better performance - no style injection at runtime
- (+) Smaller bundle size - no styling library dependency
- (-) Less dynamic styling capabilities
- (-) Requires separate CSS files

---

### ADR-002: Headless patterns for complex components

**Status:** Accepted

**Context:**
Complex interactive components (Modal, Dropdown) need to balance providing functionality with allowing customization.

**Decision:**
Implement Modal and Dropdown using render props pattern, exposing headless hooks for consumers who need full control.

**Consequences:**
- (+) Maximum flexibility for customization
- (+) Logic reusable without prescribed UI
- (+) Easier to meet varied accessibility requirements
- (-) Slightly more complex API
- (-) More documentation needed

---

### ADR-003: Compound components pattern

**Status:** Accepted

**Context:**
Components like Card, Modal, and Tabs have logical sub-sections that users need to compose flexibly.

**Decision:**
Use compound component pattern (Card.Header, Card.Body, Card.Footer) using Object.assign for attachment.

**Consequences:**
- (+) Cleaner composition API
- (+) Clear parent-child relationships
- (+) Better TypeScript support with explicit sub-components
- (-) More components to export
- (-) Slightly more complex implementation

---

### ADR-004: forwardRef on all components

**Status:** Accepted

**Context:**
Library consumers often need direct DOM access for focus management, animations, or third-party integrations.

**Decision:**
Wrap all components with React.forwardRef to enable ref forwarding.

**Consequences:**
- (+) Consumers can access underlying DOM elements
- (+) Better integration with form libraries
- (+) Required for proper focus management
- (-) Slightly more boilerplate per component
- (-) Must use forwardRef consistently

---

### ADR-005: No external icon library

**Status:** Accepted

**Context:**
Icons are commonly needed in components (buttons, inputs, etc.), but icon preferences vary widely.

**Decision:**
Do not bundle an icon library. Components accept ReactNode for icon slots, consumers bring their own icons.

**Consequences:**
- (+) Minimal bundle size
- (+) Consumers use their preferred icon set
- (+) No style conflicts with icon libraries
- (-) No default icons - slight DX cost
- (-) Consumers must configure icons themselves

## 6. Module Dependencies

```
┌─────────────────────────────────────────────────────────────┐
│                         index.ts                             │
│                    (Public API exports)                      │
└─────────────────────────────────────────────────────────────┘
                              │
       ┌──────────────────────┼──────────────────────┐
       │                      │                      │
       ▼                      ▼                      ▼
┌─────────────┐      ┌─────────────┐      ┌─────────────────┐
│ components/ │      │   hooks/    │      │    context/     │
│             │      │             │      │                 │
│ Button      │◄────►│ useTheme    │◄────►│ ThemeContext    │
│ Input       │      │ useFocusTrap│      └─────────────────┘
│ Modal       │      │ useKeyboard │
│ ...         │      └─────────────┘
└─────────────┘
       │
       ▼
┌─────────────┐
│   tokens/   │
│             │
│ colors.css  │
│ spacing.css │
│ typography  │
└─────────────┘
```

## 7. Build Configuration

### Library Build (Vite)

```typescript
// vite.config.ts
export default defineConfig({
  build: {
    lib: {
      entry: resolve(__dirname, 'src/index.ts'),
      name: 'ComponentLibrary',
      formats: ['es', 'cjs'],
    },
    rollupOptions: {
      external: ['react', 'react-dom'],
      output: {
        globals: {
          react: 'React',
          'react-dom': 'ReactDOM',
        },
      },
    },
  },
});
```

### Package Exports

```json
{
  "exports": {
    ".": {
      "import": "./dist/index.es.js",
      "require": "./dist/index.cjs.js",
      "types": "./dist/index.d.ts"
    },
    "./styles": "./dist/styles.css"
  }
}
```

## 8. Testing Strategy

### Unit Tests
- Component rendering
- Prop variations
- Event handling
- Accessibility attributes

### Integration Tests
- Keyboard navigation
- Focus management
- Theme switching
- Compound component composition

### Accessibility Tests
- axe-core automated checks
- Screen reader announcements
- Color contrast validation
- Focus order verification
