# UI/UX Design: UI Component Library

## 1. Design Tokens

### 1.1 Colors

```css
/* Primary Palette */
--color-primary: #2563eb;        /* Primary actions, links */
--color-primary-hover: #1d4ed8;  /* Primary hover state */
--color-primary-active: #1e40af; /* Primary active/pressed state */

/* Secondary Palette */
--color-secondary: #64748b;       /* Secondary actions */
--color-secondary-hover: #475569; /* Secondary hover state */
--color-secondary-active: #334155;/* Secondary active state */

/* Semantic Colors */
--color-success: #22c55e;         /* Success states, confirmations */
--color-success-bg: #f0fdf4;      /* Success background */
--color-warning: #f59e0b;         /* Warning states, cautions */
--color-warning-bg: #fffbeb;      /* Warning background */
--color-danger: #ef4444;          /* Error states, destructive actions */
--color-danger-bg: #fef2f2;       /* Error background */

/* Neutral Palette */
--color-background: #ffffff;      /* Page background */
--color-surface: #f8fafc;         /* Card/panel background */
--color-border: #e2e8f0;          /* Default borders */
--color-border-focus: #2563eb;    /* Focus ring color */

/* Text Colors */
--color-text: #1e293b;            /* Primary text */
--color-text-muted: #64748b;      /* Secondary/helper text */
--color-text-disabled: #94a3b8;   /* Disabled text */
--color-text-inverse: #ffffff;    /* Text on dark backgrounds */
```

### 1.2 Spacing

```css
/* Spacing Scale (4px base) */
--spacing-0: 0;
--spacing-xs: 0.25rem;   /* 4px */
--spacing-sm: 0.5rem;    /* 8px */
--spacing-md: 1rem;      /* 16px */
--spacing-lg: 1.5rem;    /* 24px */
--spacing-xl: 2rem;      /* 32px */
--spacing-2xl: 3rem;     /* 48px */
--spacing-3xl: 4rem;     /* 64px */
```

### 1.3 Typography

```css
/* Font Families */
--font-sans: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
--font-mono: ui-monospace, SFMono-Regular, 'SF Mono', Menlo, Consolas, monospace;

/* Font Sizes */
--font-size-xs: 0.75rem;    /* 12px */
--font-size-sm: 0.875rem;   /* 14px */
--font-size-base: 1rem;     /* 16px */
--font-size-lg: 1.125rem;   /* 18px */
--font-size-xl: 1.25rem;    /* 20px */
--font-size-2xl: 1.5rem;    /* 24px */
--font-size-3xl: 1.875rem;  /* 30px */

/* Font Weights */
--font-weight-normal: 400;
--font-weight-medium: 500;
--font-weight-semibold: 600;
--font-weight-bold: 700;

/* Line Heights */
--line-height-tight: 1.25;
--line-height-normal: 1.5;
--line-height-relaxed: 1.75;
```

### 1.4 Border Radii

```css
--radius-none: 0;
--radius-sm: 0.25rem;    /* 4px */
--radius-md: 0.375rem;   /* 6px */
--radius-lg: 0.5rem;     /* 8px */
--radius-xl: 0.75rem;    /* 12px */
--radius-full: 9999px;   /* Pill shape */
```

### 1.5 Shadows

```css
--shadow-sm: 0 1px 2px 0 rgb(0 0 0 / 0.05);
--shadow-md: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
--shadow-lg: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);
--shadow-xl: 0 20px 25px -5px rgb(0 0 0 / 0.1), 0 8px 10px -6px rgb(0 0 0 / 0.1);
```

### 1.6 Transitions

```css
--transition-fast: 150ms ease;
--transition-normal: 200ms ease;
--transition-slow: 300ms ease;
```

---

## 2. Component States

### 2.1 Interactive State Matrix

| State | Visual Treatment | Cursor | Opacity |
|-------|------------------|--------|---------|
| Default | Base styling | pointer | 100% |
| Hover | Darker background/border | pointer | 100% |
| Active | Darkest background, slight scale | pointer | 100% |
| Focus | Focus ring (2px solid, 2px offset) | pointer | 100% |
| Disabled | Muted colors | not-allowed | 50% |
| Loading | Spinner, disabled interaction | wait | 100% |

### 2.2 Focus States

All focusable elements display a consistent focus ring:

```css
.focus-ring:focus-visible {
  outline: 2px solid var(--color-border-focus);
  outline-offset: 2px;
}
```

Focus is visible only on keyboard navigation (`:focus-visible`), not on mouse clicks.

### 2.3 Button States

| Variant | Default | Hover | Active | Disabled |
|---------|---------|-------|--------|----------|
| Primary | bg: primary, text: white | bg: primary-hover | bg: primary-active | opacity: 50% |
| Secondary | bg: surface, border: border | bg: gray-100 | bg: gray-200 | opacity: 50% |
| Ghost | bg: transparent | bg: gray-100 | bg: gray-200 | opacity: 50% |
| Danger | bg: danger, text: white | bg: red-600 | bg: red-700 | opacity: 50% |

### 2.4 Input States

| State | Border Color | Background | Additional |
|-------|--------------|------------|------------|
| Default | border | background | - |
| Hover | border-hover | background | - |
| Focus | border-focus | background | Focus ring |
| Error | danger | danger-bg | Error icon, message |
| Success | success | success-bg | Check icon |
| Disabled | border-disabled | surface | cursor: not-allowed |

---

## 3. Accessibility Checklist

### 3.1 Semantic HTML

- [ ] Use semantic HTML elements (`<button>`, `<input>`, `<nav>`, etc.)
- [ ] Avoid div soup - use appropriate elements for structure
- [ ] Use heading hierarchy correctly (h1 → h2 → h3)
- [ ] Use `<label>` elements associated with form controls

### 3.2 ARIA Attributes

- [ ] Add `aria-label` for icon-only buttons
- [ ] Use `aria-describedby` for input help text and errors
- [ ] Apply `aria-expanded` for expandable components
- [ ] Include `aria-haspopup` for dropdown triggers
- [ ] Set `aria-modal="true"` on modal dialogs
- [ ] Use `role="alert"` for live announcements (toasts, errors)

### 3.3 Keyboard Navigation

- [ ] All interactive elements focusable via Tab
- [ ] Logical tab order matches visual order
- [ ] Escape closes modals, dropdowns, tooltips
- [ ] Enter/Space activates buttons and checkboxes
- [ ] Arrow keys navigate within composite widgets
- [ ] Home/End for list navigation where appropriate

### 3.4 Focus Management

- [ ] Focus visible on all interactive elements
- [ ] Focus trapped within modals when open
- [ ] Focus returned to trigger after modal closes
- [ ] No focus traps in normal navigation
- [ ] Skip links available for complex layouts

### 3.5 Color & Contrast

- [ ] Text contrast ratio ≥ 4.5:1 (WCAG AA)
- [ ] Large text contrast ratio ≥ 3:1
- [ ] Non-text contrast ratio ≥ 3:1 (icons, borders)
- [ ] Information not conveyed by color alone
- [ ] Focus indicators have sufficient contrast

### 3.6 Motion & Animation

- [ ] Respect `prefers-reduced-motion` preference
- [ ] No flashing content (≤3 flashes per second)
- [ ] Animations can be paused or disabled
- [ ] Essential motion still works (focus, state changes)

---

## 4. Component API Patterns

### 4.1 Prop Naming Conventions

```typescript
// Boolean props use "is" or "has" prefix
isDisabled?: boolean;
isLoading?: boolean;
isOpen?: boolean;
hasError?: boolean;

// Callback props use "on" prefix
onClick?: () => void;
onChange?: (value: T) => void;
onClose?: () => void;
onOpen?: () => void;

// Variant props are literal unions
variant?: 'primary' | 'secondary' | 'ghost' | 'danger';
size?: 'sm' | 'md' | 'lg';
```

### 4.2 Component Composition

#### Slot-based Components

```tsx
// Card with named slots
<Card>
  <Card.Header>
    <h2>Title</h2>
  </Card.Header>
  <Card.Body>
    Content here
  </Card.Body>
  <Card.Footer>
    <Button>Action</Button>
  </Card.Footer>
</Card>
```

#### Render Props Pattern

```tsx
// Modal with render props for advanced customization
<Modal>
  {({ isOpen, close }) => (
    <>
      <Modal.Header onClose={close}>Title</Modal.Header>
      <Modal.Body>Content</Modal.Body>
    </>
  )}
</Modal>
```

### 4.3 Ref Forwarding

All components forward refs to the underlying DOM element:

```tsx
const buttonRef = useRef<HTMLButtonElement>(null);

<Button ref={buttonRef}>Click me</Button>
```

### 4.4 Polymorphic Components

Layout components support the `as` prop for element type:

```tsx
<Stack as="nav" gap="md">
  <Link>Home</Link>
  <Link>About</Link>
</Stack>
```

### 4.5 Controlled vs Uncontrolled

Components support both patterns:

```tsx
// Uncontrolled (internal state)
<Input defaultValue="initial" />

// Controlled (external state)
<Input value={value} onChange={setValue} />
```

---

## 5. Dark Mode Support

### 5.1 Color Transformations

```css
/* Dark theme overrides */
[data-theme="dark"] {
  --color-background: #0f172a;
  --color-surface: #1e293b;
  --color-text: #f1f5f9;
  --color-text-muted: #94a3b8;
  --color-border: #334155;

  /* Adjust semantic colors for dark bg */
  --color-primary: #3b82f6;
  --color-success-bg: #052e16;
  --color-warning-bg: #422006;
  --color-danger-bg: #450a0a;
}
```

### 5.2 Theme Toggle Implementation

```tsx
// ThemeProvider exposes toggle function
const { theme, setTheme } = useTheme();

<Button onClick={() => setTheme(theme === 'light' ? 'dark' : 'light')}>
  Toggle Theme
</Button>
```

---

## 6. Responsive Design

### 6.1 Breakpoints

```css
--breakpoint-sm: 640px;   /* Mobile landscape */
--breakpoint-md: 768px;   /* Tablet portrait */
--breakpoint-lg: 1024px;  /* Tablet landscape / small desktop */
--breakpoint-xl: 1280px;  /* Desktop */
--breakpoint-2xl: 1536px; /* Large desktop */
```

### 6.2 Component Responsiveness

- Modal: Full-screen on mobile, centered overlay on desktop
- Dropdown: Bottom sheet on mobile, positioned overlay on desktop
- Grid: Responsive column counts via props
- Stack: Direction changes based on breakpoint

---

## 7. Animation Guidelines

### 7.1 Timing

| Animation Type | Duration | Easing |
|----------------|----------|--------|
| Micro-interactions (hover, focus) | 150ms | ease-out |
| State changes (expand, collapse) | 200ms | ease |
| Page transitions | 300ms | ease-in-out |
| Complex animations | 400-600ms | custom bezier |

### 7.2 Reduced Motion

```css
@media (prefers-reduced-motion: reduce) {
  *,
  *::before,
  *::after {
    animation-duration: 0.01ms !important;
    animation-iteration-count: 1 !important;
    transition-duration: 0.01ms !important;
  }
}
```
